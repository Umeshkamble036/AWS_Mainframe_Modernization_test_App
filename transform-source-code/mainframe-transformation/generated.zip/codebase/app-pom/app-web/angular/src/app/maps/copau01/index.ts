import { Copau01Copau1aComponent } from './copau01-copau1a.component';

export { Copau01Module } from './copau01.module';

export const Copau01SubComponentsMap = {
	
};

export const Copau01ComponentsMap = {
	"copau01-copau1a": Copau01Copau1aComponent
};

