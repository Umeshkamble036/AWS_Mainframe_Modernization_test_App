import { CotrtupCtrtupaComponent } from './cotrtup-ctrtupa.component';

export { CotrtupModule } from './cotrtup.module';

export const CotrtupSubComponentsMap = {
	
};

export const CotrtupComponentsMap = {
	"cotrtup-ctrtupa": CotrtupCtrtupaComponent
};

