import { Component } from '@angular/core';
import { Overlay } from "./../commonMap/overlay";

@Component({
    selector: 'cotrtup-ctrtupa',
    standalone: false,
    templateUrl: './cotrtup-ctrtupa.component.html'
})
export class CotrtupCtrtupaComponent extends Overlay {
    trnname: any = {};
    title01: any = {};
    curdate: any = {'value': 'mm\/dd\/yy'};
    pgmname: any = {};
    title02: any = {};
    curtime: any = {'value': 'hh:mm:ss'};
    trtypcd: any = {};
    trtydsc: any = {};
    infomsg: any = {};
    errmsg: any = {};
    fkeys: any = {'value': 'ENTER=Process F3=Exit'};
    fkey04: any = {'value': 'F4=Delete'};
    fkey05: any = {'value': 'F5=Save'};
    fkey06: any = {'value': 'F6=Add'};
    fkey12: any = {'value': 'F12=Cancel'};

    public FIELDS: string[] = ['trnname', 'title01', 'curdate', 'pgmname', 'title02', 'curtime', 'trtypcd', 'trtydsc', 'infomsg', 'errmsg', 'fkeys', 'fkey04', 'fkey05', 'fkey06', 'fkey12'];
    public LINES: number[] = [1, 2, 22, 7, 23, 24, 12, 14];

    ngAfterViewInit(): void {
    }
}
