import { NgModule } from '@angular/core';
import { Copau00Copau0aComponent } from './copau00-copau0a.component';
import { SharedModule } from '../../shared.module';
import { MapRegistryService } from '../../services/map-registry.service';
import { Copau00ComponentsMap, Copau00SubComponentsMap } from '.';

@NgModule({
    imports: [SharedModule],
    exports: [],
    declarations: [Copau00Copau0aComponent]
})
export class Copau00Module {
  constructor(mapRegistryService: MapRegistryService) {
    mapRegistryService.registerModuleComponents(Copau00ComponentsMap);
    mapRegistryService.registerModuleSubComponents(Copau00SubComponentsMap);
  }
}

