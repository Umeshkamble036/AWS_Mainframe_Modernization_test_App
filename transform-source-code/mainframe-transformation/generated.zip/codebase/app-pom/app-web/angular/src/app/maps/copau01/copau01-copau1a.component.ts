import { Component } from '@angular/core';
import { Overlay } from "./../commonMap/overlay";

@Component({
    selector: 'copau01-copau1a',
    standalone: false,
    templateUrl: './copau01-copau1a.component.html'
})
export class Copau01Copau1aComponent extends Overlay {
    trnname: any = {};
    title01: any = {};
    curdate: any = {'value': 'mm\/dd\/yy'};
    pgmname: any = {};
    title02: any = {};
    curtime: any = {'value': 'hh:mm:ss'};
    cardnum: any = {};
    authdt: any = {};
    authtm: any = {};
    authrsp: any = {};
    authrsn: any = {};
    authcd: any = {};
    authamt: any = {};
    posemd: any = {};
    authsrc: any = {};
    mcccd: any = {};
    crdexp: any = {};
    authtyp: any = {};
    trnid: any = {};
    authmtc: any = {};
    authfrd: any = {};
    mername: any = {};
    merid: any = {};
    mercity: any = {};
    merst: any = {};
    merzip: any = {};
    errmsg: any = {};

    public FIELDS: string[] = ['trnname', 'title01', 'curdate', 'pgmname', 'title02', 'curtime', 'cardnum', 'authdt', 'authtm', 'authrsp', 'authrsn', 'authcd', 'authamt', 'posemd', 'authsrc', 'mcccd', 'crdexp', 'authtyp', 'trnid', 'authmtc', 'authfrd', 'mername', 'merid', 'mercity', 'merst', 'merzip', 'errmsg'];
    public LINES: number[] = [1, 2, 4, 7, 9, 11, 13, 15, 17, 19, 21, 23, 24];

    ngAfterViewInit(): void {
    }
}
