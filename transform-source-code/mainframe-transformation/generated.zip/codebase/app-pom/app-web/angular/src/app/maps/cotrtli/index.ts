import { CotrtliCtrtliaComponent } from './cotrtli-ctrtlia.component';

export { CotrtliModule } from './cotrtli.module';

export const CotrtliSubComponentsMap = {
	
};

export const CotrtliComponentsMap = {
	"cotrtli-ctrtlia": CotrtliCtrtliaComponent
};

