import { Copau00Copau0aComponent } from './copau00-copau0a.component';

export { Copau00Module } from './copau00.module';

export const Copau00SubComponentsMap = {
	
};

export const Copau00ComponentsMap = {
	"copau00-copau0a": Copau00Copau0aComponent
};

