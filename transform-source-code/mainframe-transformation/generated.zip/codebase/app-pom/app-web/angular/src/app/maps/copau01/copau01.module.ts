import { NgModule } from '@angular/core';
import { Copau01Copau1aComponent } from './copau01-copau1a.component';
import { SharedModule } from '../../shared.module';
import { MapRegistryService } from '../../services/map-registry.service';
import { Copau01ComponentsMap, Copau01SubComponentsMap } from '.';

@NgModule({
    imports: [SharedModule],
    exports: [],
    declarations: [Copau01Copau1aComponent]
})
export class Copau01Module {
  constructor(mapRegistryService: MapRegistryService) {
    mapRegistryService.registerModuleComponents(Copau01ComponentsMap);
    mapRegistryService.registerModuleSubComponents(Copau01SubComponentsMap);
  }
}

