import { NgModule } from '@angular/core';
import { CotrtupCtrtupaComponent } from './cotrtup-ctrtupa.component';
import { SharedModule } from '../../shared.module';
import { MapRegistryService } from '../../services/map-registry.service';
import { CotrtupComponentsMap, CotrtupSubComponentsMap } from '.';

@NgModule({
    imports: [SharedModule],
    exports: [],
    declarations: [CotrtupCtrtupaComponent]
})
export class CotrtupModule {
  constructor(mapRegistryService: MapRegistryService) {
    mapRegistryService.registerModuleComponents(CotrtupComponentsMap);
    mapRegistryService.registerModuleSubComponents(CotrtupSubComponentsMap);
  }
}

