import { NgModule } from '@angular/core';
import { CotrtliCtrtliaComponent } from './cotrtli-ctrtlia.component';
import { SharedModule } from '../../shared.module';
import { MapRegistryService } from '../../services/map-registry.service';
import { CotrtliComponentsMap, CotrtliSubComponentsMap } from '.';

@NgModule({
    imports: [SharedModule],
    exports: [],
    declarations: [CotrtliCtrtliaComponent]
})
export class CotrtliModule {
  constructor(mapRegistryService: MapRegistryService) {
    mapRegistryService.registerModuleComponents(CotrtliComponentsMap);
    mapRegistryService.registerModuleSubComponents(CotrtliSubComponentsMap);
  }
}

