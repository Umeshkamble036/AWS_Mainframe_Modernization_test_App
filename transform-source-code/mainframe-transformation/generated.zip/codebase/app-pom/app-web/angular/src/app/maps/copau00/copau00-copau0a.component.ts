import { Component } from '@angular/core';
import { Overlay } from "./../commonMap/overlay";

@Component({
    selector: 'copau00-copau0a',
    standalone: false,
    templateUrl: './copau00-copau0a.component.html'
})
export class Copau00Copau0aComponent extends Overlay {
    trnname: any = {};
    title01: any = {};
    curdate: any = {'value': 'mm\/dd\/yy'};
    pgmname: any = {};
    title02: any = {};
    curtime: any = {'value': 'hh:mm:ss'};
    acctid: any = {};
    cname: any = {};
    custid: any = {};
    addr001: any = {};
    accstat: any = {};
    addr002: any = {};
    phone1: any = {};
    apprcnt: any = {};
    declcnt: any = {};
    credlim: any = {};
    cashlim: any = {};
    appramt: any = {};
    credbal: any = {};
    cashbal: any = {};
    declamt: any = {};
    sel0001: any = {};
    trnid01: any = {};
    pdate01: any = {};
    ptime01: any = {};
    ptype01: any = {};
    paprv01: any = {};
    pstat01: any = {};
    pamt001: any = {};
    sel0002: any = {};
    trnid02: any = {};
    pdate02: any = {};
    ptime02: any = {};
    ptype02: any = {};
    paprv02: any = {};
    pstat02: any = {};
    pamt002: any = {};
    sel0003: any = {};
    trnid03: any = {};
    pdate03: any = {};
    ptime03: any = {};
    ptype03: any = {};
    paprv03: any = {};
    pstat03: any = {};
    pamt003: any = {};
    sel0004: any = {};
    trnid04: any = {};
    pdate04: any = {};
    ptime04: any = {};
    ptype04: any = {};
    paprv04: any = {};
    pstat04: any = {};
    pamt004: any = {};
    trnid05: any = {};
    pdate05: any = {};
    ptime05: any = {};
    ptype05: any = {};
    paprv05: any = {};
    pstat05: any = {};
    pamt005: any = {};
    sel0005: any = {};
    errmsg: any = {};

    public FIELDS: string[] = ['trnname', 'title01', 'curdate', 'pgmname', 'title02', 'curtime', 'acctid', 'cname', 'custid', 'addr001', 'accstat', 'addr002', 'phone1', 'apprcnt', 'declcnt', 'credlim', 'cashlim', 'appramt', 'credbal', 'cashbal', 'declamt', 'sel0001', 'trnid01', 'pdate01', 'ptime01', 'ptype01', 'paprv01', 'pstat01', 'pamt001', 'sel0002', 'trnid02', 'pdate02', 'ptime02', 'ptype02', 'paprv02', 'pstat02', 'pamt002', 'sel0003', 'trnid03', 'pdate03', 'ptime03', 'ptype03', 'paprv03', 'pstat03', 'pamt003', 'sel0004', 'trnid04', 'pdate04', 'ptime04', 'ptype04', 'paprv04', 'pstat04', 'pamt004', 'trnid05', 'pdate05', 'ptime05', 'ptype05', 'paprv05', 'pstat05', 'pamt005', 'sel0005', 'errmsg'];
    public LINES: number[] = [1, 2, 3, 5, 6, 7, 8, 9, 11, 12, 14, 15, 16, 17, 18, 19, 20, 22, 23, 24];

    ngAfterViewInit(): void {
    }
}
