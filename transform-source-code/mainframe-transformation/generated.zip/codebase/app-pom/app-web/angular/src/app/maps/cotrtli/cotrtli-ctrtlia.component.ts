import { Component } from '@angular/core';
import { Overlay } from "./../commonMap/overlay";

@Component({
    selector: 'cotrtli-ctrtlia',
    standalone: false,
    templateUrl: './cotrtli-ctrtlia.component.html'
})
export class CotrtliCtrtliaComponent extends Overlay {
    trnname: any = {};
    title01: any = {};
    curdate: any = {'value': 'mm\/dd\/yy'};
    pgmname: any = {};
    title02: any = {};
    curtime: any = {'value': 'hh:mm:ss'};
    pageno: any = {};
    trtype: any = {};
    trdesc: any = {};
    trtsel1: any = {};
    trttyp1: any = {};
    trtypd1: any = {};
    trtsel2: any = {};
    trttyp2: any = {};
    trtypd2: any = {};
    trtsel3: any = {};
    trttyp3: any = {};
    trtypd3: any = {};
    trtsel4: any = {};
    trttyp4: any = {};
    trtypd4: any = {};
    trtsel5: any = {};
    trttyp5: any = {};
    trtypd5: any = {};
    trtsel6: any = {};
    trttyp6: any = {};
    trtypd6: any = {};
    trtsel7: any = {};
    trttyp7: any = {};
    trtypd7: any = {};
    trtsela: any = {};
    trttypa: any = {};
    trtdsca: any = {};
    infomsg: any = {};
    errmsg: any = {};
    butnf02: any = {'value': 'F2=Add'};
    butnf03: any = {'value': 'F3=Exit'};
    butnf07: any = {'value': 'F7=Page Up'};
    butnf08: any = {'value': 'F8=Page Dn'};
    butnf10: any = {'value': 'F10=Save'};

    public FIELDS: string[] = ['trnname', 'title01', 'curdate', 'pgmname', 'title02', 'curtime', 'pageno', 'trtype', 'trdesc', 'trtsel1', 'trttyp1', 'trtypd1', 'trtsel2', 'trttyp2', 'trtypd2', 'trtsel3', 'trttyp3', 'trtypd3', 'trtsel4', 'trttyp4', 'trtypd4', 'trtsel5', 'trttyp5', 'trtypd5', 'trtsel6', 'trttyp6', 'trtypd6', 'trtsel7', 'trttyp7', 'trtypd7', 'trtsela', 'trttypa', 'trtdsca', 'infomsg', 'errmsg', 'butnf02', 'butnf03', 'butnf07', 'butnf08', 'butnf10'];
    public LINES: number[] = [1, 2, 4, 6, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 21, 23, 24];

    ngAfterViewInit(): void {
    }
}
