package com.company.app.core.exceptions;

/**
 * Exception class used for unsupported elements.
 */
public class UnsupportedException extends RuntimeException {

	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 7096945487699409189L;

	/**
	 * Constructs a new unsupported exception with {@code null} as its detail
	 * message. The cause is not initialized, and may subsequently be initialized
	 * by a call to {@link #initCause}.
	 */
	public UnsupportedException() {
		super();
	}

	/**
	 * Constructs a new unsupported exception with the specified detail message.
	 * The cause is not initialized, and may subsequently be initialized by a call
	 * to {@link #initCause}.
	 *
	 * @param message
	 *          the detail message. The detail message is saved for later
	 *          retrieval by the {@link #getMessage()} method.
	 */
	public UnsupportedException(String message) {
		super(message);
	}

	/**
	 * Constructs a new unsupported exception with the specified detail message
	 * and cause.
	 * <p>
	 * Note that the detail message associated with {@code cause} is <i>not</i>
	 * automatically incorporated in this unsupported exception''s detail
	 * message.
	 *
	 * @param message
	 *          the detail message (which is saved for later retrieval by the
	 *          {@link #getMessage()} method).
	 * @param cause
	 *          the cause (which is saved for later retrieval by the
	 *          {@link #getCause()} method). (A <tt>null</tt> value is permitted,
	 *          and indicates that the cause is nonexistent or unknown.)
	 * @since 1.4
	 */
	public UnsupportedException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Constructs a new unsupported exception with the specified cause and a
	 * detail message of <tt>(cause==null ? null : cause.toString())</tt> (which
	 * typically contains the class and detail message of <tt>cause</tt>). This
	 * constructor is useful for unsupported exceptions that are little more
	 * than wrappers for other throwables.
	 *
	 * @param cause
	 *          the cause (which is saved for later retrieval by the
	 *          {@link #getCause()} method). (A <tt>null</tt> value is permitted,
	 *          and indicates that the cause is nonexistent or unknown.)
	 * @since 1.4
	 */
	public UnsupportedException(Throwable cause) {
		super(cause);
	}

	/**
	 * Constructs a new unsupported exception with the specified detail message,
	 * cause, suppression enabled or disabled, and writable stack trace enabled or
	 * disabled.
	 *
	 * @param message
	 *          the detail message.
	 * @param cause
	 *          the cause. (A {@code null} value is permitted, and indicates that
	 *          the cause is nonexistent or unknown.)
	 * @param enableSuppression
	 *          whether or not suppression is enabled or disabled
	 * @param writableStackTrace
	 *          whether or not the stack trace should be writable
	 *
	 * @since 1.7
	 */
	protected UnsupportedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
