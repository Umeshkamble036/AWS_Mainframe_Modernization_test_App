package com.company.app.cobtupdt.business.context;
import com.company.app.cobtupdt.business.model.Flags;
import com.company.app.cobtupdt.business.model.Sqlca;
import com.company.app.cobtupdt.business.model.TrRecord;
import com.company.app.cobtupdt.business.model.WorkingVariables;
import com.company.app.cobtupdt.business.model.WsInfStatus;
import com.company.app.cobtupdt.business.model.WsInputRec;
import com.company.app.cobtupdt.business.model.WsMiscVars;
import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.io.metadata.builder.SequentialFileDescriptionBuilder;
import com.netfective.bluage.gapwalk.rt.io.AccessMode;
import com.netfective.bluage.gapwalk.rt.io.SequentialFile;
import com.netfective.bluage.gapwalk.rt.jics.context.JicsRuntimeContext;
import com.netfective.bluage.gapwalk.rt.shared.ExecutionContext;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Data simplifier context CobtupdtContext.
 * 
 * <p>About 'onCode' field, <br>
 * </p>
 * 
 * <p>About 'onChar' field, <br>
 * </p>
 * 
 * <p>About 'trRecord' file, <br>uml entity: com.company.app.cobtupdt.business.model.TrRecord
 * <br></p>
 * 
 * <p>About 'sqlca' field, <br>uml entity: com.company.app.cobtupdt.business.model.Sqlca
 * <br></p>
 * 
 * <p>About 'flags' field, <br>uml entity: com.company.app.cobtupdt.business.model.Flags
 * <br></p>
 * 
 * <p>About 'workingVariables' field, <br>uml entity: com.company.app.cobtupdt.business.model.WorkingVariables
 * <br></p>
 * 
 * <p>About 'wsMiscVars' field, <br>uml entity: com.company.app.cobtupdt.business.model.WsMiscVars
 * <br></p>
 * 
 * <p>About 'wsInfStatus' field, <br>uml entity: com.company.app.cobtupdt.business.model.WsInfStatus
 * <br></p>
 * 
 * <p>About 'wsInputRec' field, <br>uml entity: com.company.app.cobtupdt.business.model.WsInputRec
 * <br></p>
 * 
 */
@Component("com.company.app.cobtupdt.business.context.CobtupdtContext")
@Import({
	com.company.app.cobtupdt.business.model.TrRecord.class
})
@Lazy
@Scope("prototype")
public class CobtupdtContext extends JicsRuntimeContext {

	@Autowired
	private TrRecord trRecord;

	private SequentialFile trRecordFile;	
	
	private Sqlca sqlca;
	private Flags flags;
	private WorkingVariables workingVariables;
	private WsMiscVars wsMiscVars;
	private WsInfStatus wsInfStatus;
	private WsInputRec wsInputRec;

	private List<RecordEntity> recordEntities;

	/**
	 * Default constructor.
	 * @param configuration the datasimplifier configuration
	 */
	public CobtupdtContext (@Qualifier("CobtupdtContextConfiguration") Configuration configuration) {
		super(configuration);
		initWorking(configuration);
		
		initRecordEntities();
	}
	
	

	/**
	 * Getter for the file trRecord.
	 * @return the trRecord
	 */
	public TrRecord getTrRecord() {
		return this.trRecord;
	}
	
	/**
	 * Getter for the file handler trRecordFile.
	 * @param executionContext the execution context
	 * @return the trRecordFile
	 */
	public SequentialFile getTrRecordHandler(ExecutionContext executionContext) {
		
		if(this.trRecordFile == null){
			this.trRecordFile = executionContext.getFileProvider().getFile(
				"INPFILE",
				new SequentialFileDescriptionBuilder()
					.fileStatus(this.getWsInfStatus())
					.accessMode(AccessMode.SEQUENTIAL)
					.build(),
				getConfiguration(), trRecord);
		}
		return this.trRecordFile;	
	}

	/**
	 * Getter for sqlca.
	 * @return the sqlca
	 */
	public Sqlca getSqlca() {
		return this.sqlca;
	}

	/**
	 * Setter for sqlca.
	 * @param reference the new value for sqlca
	 */
	public void setSqlca(RangeReference reference) {
		this.sqlca.setBytes(reference.getBytes());
	}

	/**
	 * Getter for flags.
	 * @return the flags
	 */
	public Flags getFlags() {
		return this.flags;
	}

	/**
	 * Setter for flags.
	 * @param reference the new value for flags
	 */
	public void setFlags(RangeReference reference) {
		this.flags.setBytes(reference.getBytes());
	}

	/**
	 * Getter for workingVariables.
	 * @return the workingVariables
	 */
	public WorkingVariables getWorkingVariables() {
		return this.workingVariables;
	}

	/**
	 * Setter for workingVariables.
	 * @param reference the new value for workingVariables
	 */
	public void setWorkingVariables(RangeReference reference) {
		this.workingVariables.setBytes(reference.getBytes());
	}

	/**
	 * Getter for wsMiscVars.
	 * @return the wsMiscVars
	 */
	public WsMiscVars getWsMiscVars() {
		return this.wsMiscVars;
	}

	/**
	 * Setter for wsMiscVars.
	 * @param reference the new value for wsMiscVars
	 */
	public void setWsMiscVars(RangeReference reference) {
		this.wsMiscVars.setBytes(reference.getBytes());
	}

	/**
	 * Getter for wsInfStatus.
	 * @return the wsInfStatus
	 */
	public WsInfStatus getWsInfStatus() {
		return this.wsInfStatus;
	}

	/**
	 * Setter for wsInfStatus.
	 * @param reference the new value for wsInfStatus
	 */
	public void setWsInfStatus(RangeReference reference) {
		this.wsInfStatus.setBytes(reference.getBytes());
	}

	/**
	 * Getter for wsInputRec.
	 * @return the wsInputRec
	 */
	public WsInputRec getWsInputRec() {
		return this.wsInputRec;
	}

	/**
	 * Setter for wsInputRec.
	 * @param reference the new value for wsInputRec
	 */
	public void setWsInputRec(RangeReference reference) {
		this.wsInputRec.setBytes(reference.getBytes());
	}

	@Override 
	public void cleanUp(){
		if(this.trRecordFile !=null && this.trRecordFile.isOpen() && !this.trRecordFile.isShared()) {
			this.trRecordFile.close();
		}
		if(this.trRecordFile !=null && !this.trRecordFile.isShared()){
			this.trRecordFile = null;
		}
	}

	@Override
	protected void doReset() {
		cleanUp();
		this.trRecord.reset();
	    // reset the working
		recordEntities.stream().forEach(e -> e.reset());
	}

	
	private void initWorking(Configuration configuration) {
		sqlca = new Sqlca(configuration);
		flags = new Flags(configuration);
		workingVariables = new WorkingVariables(configuration);
		wsMiscVars = new WsMiscVars(configuration);
		wsInfStatus = new WsInfStatus(configuration);
		wsInputRec = new WsInputRec(configuration);
	}

	private void initRecordEntities() {
		recordEntities = Arrays.asList(sqlca, flags, workingVariables, wsMiscVars, wsInfStatus, wsInputRec);
	}

	@Override
	public String toString(){
		StringBuilder toSB = new StringBuilder("\nCobtupdtContext:\n");
		if(!this.recordEntities.isEmpty()){
			this.recordEntities.forEach(e -> toSB.append(e.getClass().getSimpleName()).append(" : [").append(e.toString()).append("]\n"));
		}
		return toSB.toString();
	}

}
