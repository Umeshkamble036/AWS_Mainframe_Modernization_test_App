package com.company.app.cbimport.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Data simplifier file ExportInput.
 * 
 * <p>About 'exportInputRecord' field, <br>uml entity: com.company.app.cbimport.business.model.ExportInputRecord
 * <br></p>
 * 
 */
@Component("com.company.app.cbimport.business.model.ExportInput")
@Lazy
@Scope("prototype")
public class ExportInput extends RecordEntity {

	private final Group root = new Group(getData());
	private final Elementary exportInputRecord = new Elementary(root,new AlphanumericType(500));
	 
	/**
	 * Instantiate a new ExportInput.
	 * @param configuration the configuration
	 */
	public ExportInput(@Qualifier("CbimportContextConfiguration") Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}
 
	/**
	 * Gets the reference for attribute exportInputRecord.
	 * @return the exportInputRecord attribute reference
	 */
	public ElementaryRangeReference getExportInputRecordReference() {
		return exportInputRecord.getReference();
	}

	/**
	 * Getter for exportInputRecord attribute.
	 * @return exportInputRecord attribute
	 */
	public String getExportInputRecord() {
		return exportInputRecord.getValue();
	}

	/**
	 * Setter for exportInputRecord attribute.
	 * @param exportInputRecord the new value of exportInputRecord
	 */
	public void setExportInputRecord(String exportInputRecord) {
		this.exportInputRecord.setValue(exportInputRecord);
	}
}
