package com.company.app.cbimport.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ConditionReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.ConditionName;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
/**
 * Data simplifier entity WsFileStatusArea.
<pre>
 * 
 * Legacy Documentation:<br>
 *   File Status Variables<br>
</pre>
 * 
 * <p>About 'wsExportStatus' field, <br>
 * </p>
 * 
 * <p>About 'wsExportEof' field, <br>
 * </p>
 * 
 * <p>About 'wsExportOk' field, <br>
 * </p>
 * 
 * <p>About 'wsCustomerStatus' field, <br>
 * </p>
 * 
 * <p>About 'wsCustomerOk' field, <br>
 * </p>
 * 
 * <p>About 'wsAccountStatus' field, <br>
 * </p>
 * 
 * <p>About 'wsAccountOk' field, <br>
 * </p>
 * 
 * <p>About 'wsXrefStatus' field, <br>
 * </p>
 * 
 * <p>About 'wsXrefOk' field, <br>
 * </p>
 * 
 * <p>About 'wsTransactionStatus' field, <br>
 * </p>
 * 
 * <p>About 'wsTransactionOk' field, <br>
 * </p>
 * 
 * <p>About 'wsCardStatus' field, <br>
 * </p>
 * 
 * <p>About 'wsCardOk' field, <br>
 * </p>
 * 
 * <p>About 'wsErrorStatus' field, <br>
 * </p>
 * 
 * <p>About 'wsErrorOk' field, <br>
 * </p>
 * 
 * @see RecordEntity
 */
public class WsFileStatusArea extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Elementary wsExportStatus = new Elementary(root,new AlphanumericType(2));
	private final ConditionName wsExportEof=new ConditionName(wsExportStatus,"10");
	private final ConditionName wsExportOk=new ConditionName(wsExportStatus,"00");
	private final Elementary wsCustomerStatus = new Elementary(root,new AlphanumericType(2));
	private final ConditionName wsCustomerOk=new ConditionName(wsCustomerStatus,"00");
	private final Elementary wsAccountStatus = new Elementary(root,new AlphanumericType(2));
	private final ConditionName wsAccountOk=new ConditionName(wsAccountStatus,"00");
	private final Elementary wsXrefStatus = new Elementary(root,new AlphanumericType(2));
	private final ConditionName wsXrefOk=new ConditionName(wsXrefStatus,"00");
	private final Elementary wsTransactionStatus = new Elementary(root,new AlphanumericType(2));
	private final ConditionName wsTransactionOk=new ConditionName(wsTransactionStatus,"00");
	private final Elementary wsCardStatus = new Elementary(root,new AlphanumericType(2));
	private final ConditionName wsCardOk=new ConditionName(wsCardStatus,"00");
	private final Elementary wsErrorStatus = new Elementary(root,new AlphanumericType(2));
	private final ConditionName wsErrorOk=new ConditionName(wsErrorStatus,"00");
	
	/**
	 * Instantiate a new WsFileStatusArea with a default record.
	 * @param configuration the configuration
	 */
	public WsFileStatusArea(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new WsFileStatusArea bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public WsFileStatusArea(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	/**
	 * Gets the reference for attribute wsExportStatus.
	 * @return the wsExportStatus attribute reference
	 */
	public ElementaryRangeReference getWsExportStatusReference() {
		return wsExportStatus.getReference();
	}

	/**
	 * Getter for wsExportStatus attribute.
	 * @return wsExportStatus attribute
	 */
	public String getWsExportStatus() {
		return wsExportStatus.getValue();
	}

	/**
	 * Setter for wsExportStatus attribute.
	 * @param wsExportStatus the new value of wsExportStatus
	 */
	public void setWsExportStatus(String wsExportStatus) {
		this.wsExportStatus.setValue(wsExportStatus);
	}
	/**
	 * Gets the reference for attribute wsExportEof.
	 * @return the wsExportEof attribute reference
	 */
	public ConditionReference getWsExportEofReference() {
		return wsExportStatus.getCondition(wsExportEof);	
	}

	/**
	 * Getter for wsExportEof attribute.
	 * @return wsExportEof attribute
	 */
	public boolean isWsExportEof() {
		return getWsExportEofReference().getValue();	
	}

	/**
	 * Setter for wsExportEof attribute.
	 * @param wsExportEof the new value of wsExportEof
	 */
	public void setWsExportEof(boolean wsExportEof) {
		getWsExportEofReference().setValue(wsExportEof);	
	}
	/**
	 * Gets the reference for attribute wsExportOk.
	 * @return the wsExportOk attribute reference
	 */
	public ConditionReference getWsExportOkReference() {
		return wsExportStatus.getCondition(wsExportOk);	
	}

	/**
	 * Getter for wsExportOk attribute.
	 * @return wsExportOk attribute
	 */
	public boolean isWsExportOk() {
		return getWsExportOkReference().getValue();	
	}

	/**
	 * Setter for wsExportOk attribute.
	 * @param wsExportOk the new value of wsExportOk
	 */
	public void setWsExportOk(boolean wsExportOk) {
		getWsExportOkReference().setValue(wsExportOk);	
	}
	/**
	 * Gets the reference for attribute wsCustomerStatus.
	 * @return the wsCustomerStatus attribute reference
	 */
	public ElementaryRangeReference getWsCustomerStatusReference() {
		return wsCustomerStatus.getReference();
	}

	/**
	 * Getter for wsCustomerStatus attribute.
	 * @return wsCustomerStatus attribute
	 */
	public String getWsCustomerStatus() {
		return wsCustomerStatus.getValue();
	}

	/**
	 * Setter for wsCustomerStatus attribute.
	 * @param wsCustomerStatus the new value of wsCustomerStatus
	 */
	public void setWsCustomerStatus(String wsCustomerStatus) {
		this.wsCustomerStatus.setValue(wsCustomerStatus);
	}
	/**
	 * Gets the reference for attribute wsCustomerOk.
	 * @return the wsCustomerOk attribute reference
	 */
	public ConditionReference getWsCustomerOkReference() {
		return wsCustomerStatus.getCondition(wsCustomerOk);	
	}

	/**
	 * Getter for wsCustomerOk attribute.
	 * @return wsCustomerOk attribute
	 */
	public boolean isWsCustomerOk() {
		return getWsCustomerOkReference().getValue();	
	}

	/**
	 * Setter for wsCustomerOk attribute.
	 * @param wsCustomerOk the new value of wsCustomerOk
	 */
	public void setWsCustomerOk(boolean wsCustomerOk) {
		getWsCustomerOkReference().setValue(wsCustomerOk);	
	}
	/**
	 * Gets the reference for attribute wsAccountStatus.
	 * @return the wsAccountStatus attribute reference
	 */
	public ElementaryRangeReference getWsAccountStatusReference() {
		return wsAccountStatus.getReference();
	}

	/**
	 * Getter for wsAccountStatus attribute.
	 * @return wsAccountStatus attribute
	 */
	public String getWsAccountStatus() {
		return wsAccountStatus.getValue();
	}

	/**
	 * Setter for wsAccountStatus attribute.
	 * @param wsAccountStatus the new value of wsAccountStatus
	 */
	public void setWsAccountStatus(String wsAccountStatus) {
		this.wsAccountStatus.setValue(wsAccountStatus);
	}
	/**
	 * Gets the reference for attribute wsAccountOk.
	 * @return the wsAccountOk attribute reference
	 */
	public ConditionReference getWsAccountOkReference() {
		return wsAccountStatus.getCondition(wsAccountOk);	
	}

	/**
	 * Getter for wsAccountOk attribute.
	 * @return wsAccountOk attribute
	 */
	public boolean isWsAccountOk() {
		return getWsAccountOkReference().getValue();	
	}

	/**
	 * Setter for wsAccountOk attribute.
	 * @param wsAccountOk the new value of wsAccountOk
	 */
	public void setWsAccountOk(boolean wsAccountOk) {
		getWsAccountOkReference().setValue(wsAccountOk);	
	}
	/**
	 * Gets the reference for attribute wsXrefStatus.
	 * @return the wsXrefStatus attribute reference
	 */
	public ElementaryRangeReference getWsXrefStatusReference() {
		return wsXrefStatus.getReference();
	}

	/**
	 * Getter for wsXrefStatus attribute.
	 * @return wsXrefStatus attribute
	 */
	public String getWsXrefStatus() {
		return wsXrefStatus.getValue();
	}

	/**
	 * Setter for wsXrefStatus attribute.
	 * @param wsXrefStatus the new value of wsXrefStatus
	 */
	public void setWsXrefStatus(String wsXrefStatus) {
		this.wsXrefStatus.setValue(wsXrefStatus);
	}
	/**
	 * Gets the reference for attribute wsXrefOk.
	 * @return the wsXrefOk attribute reference
	 */
	public ConditionReference getWsXrefOkReference() {
		return wsXrefStatus.getCondition(wsXrefOk);	
	}

	/**
	 * Getter for wsXrefOk attribute.
	 * @return wsXrefOk attribute
	 */
	public boolean isWsXrefOk() {
		return getWsXrefOkReference().getValue();	
	}

	/**
	 * Setter for wsXrefOk attribute.
	 * @param wsXrefOk the new value of wsXrefOk
	 */
	public void setWsXrefOk(boolean wsXrefOk) {
		getWsXrefOkReference().setValue(wsXrefOk);	
	}
	/**
	 * Gets the reference for attribute wsTransactionStatus.
	 * @return the wsTransactionStatus attribute reference
	 */
	public ElementaryRangeReference getWsTransactionStatusReference() {
		return wsTransactionStatus.getReference();
	}

	/**
	 * Getter for wsTransactionStatus attribute.
	 * @return wsTransactionStatus attribute
	 */
	public String getWsTransactionStatus() {
		return wsTransactionStatus.getValue();
	}

	/**
	 * Setter for wsTransactionStatus attribute.
	 * @param wsTransactionStatus the new value of wsTransactionStatus
	 */
	public void setWsTransactionStatus(String wsTransactionStatus) {
		this.wsTransactionStatus.setValue(wsTransactionStatus);
	}
	/**
	 * Gets the reference for attribute wsTransactionOk.
	 * @return the wsTransactionOk attribute reference
	 */
	public ConditionReference getWsTransactionOkReference() {
		return wsTransactionStatus.getCondition(wsTransactionOk);	
	}

	/**
	 * Getter for wsTransactionOk attribute.
	 * @return wsTransactionOk attribute
	 */
	public boolean isWsTransactionOk() {
		return getWsTransactionOkReference().getValue();	
	}

	/**
	 * Setter for wsTransactionOk attribute.
	 * @param wsTransactionOk the new value of wsTransactionOk
	 */
	public void setWsTransactionOk(boolean wsTransactionOk) {
		getWsTransactionOkReference().setValue(wsTransactionOk);	
	}
	/**
	 * Gets the reference for attribute wsCardStatus.
	 * @return the wsCardStatus attribute reference
	 */
	public ElementaryRangeReference getWsCardStatusReference() {
		return wsCardStatus.getReference();
	}

	/**
	 * Getter for wsCardStatus attribute.
	 * @return wsCardStatus attribute
	 */
	public String getWsCardStatus() {
		return wsCardStatus.getValue();
	}

	/**
	 * Setter for wsCardStatus attribute.
	 * @param wsCardStatus the new value of wsCardStatus
	 */
	public void setWsCardStatus(String wsCardStatus) {
		this.wsCardStatus.setValue(wsCardStatus);
	}
	/**
	 * Gets the reference for attribute wsCardOk.
	 * @return the wsCardOk attribute reference
	 */
	public ConditionReference getWsCardOkReference() {
		return wsCardStatus.getCondition(wsCardOk);	
	}

	/**
	 * Getter for wsCardOk attribute.
	 * @return wsCardOk attribute
	 */
	public boolean isWsCardOk() {
		return getWsCardOkReference().getValue();	
	}

	/**
	 * Setter for wsCardOk attribute.
	 * @param wsCardOk the new value of wsCardOk
	 */
	public void setWsCardOk(boolean wsCardOk) {
		getWsCardOkReference().setValue(wsCardOk);	
	}
	/**
	 * Gets the reference for attribute wsErrorStatus.
	 * @return the wsErrorStatus attribute reference
	 */
	public ElementaryRangeReference getWsErrorStatusReference() {
		return wsErrorStatus.getReference();
	}

	/**
	 * Getter for wsErrorStatus attribute.
	 * @return wsErrorStatus attribute
	 */
	public String getWsErrorStatus() {
		return wsErrorStatus.getValue();
	}

	/**
	 * Setter for wsErrorStatus attribute.
	 * @param wsErrorStatus the new value of wsErrorStatus
	 */
	public void setWsErrorStatus(String wsErrorStatus) {
		this.wsErrorStatus.setValue(wsErrorStatus);
	}
	/**
	 * Gets the reference for attribute wsErrorOk.
	 * @return the wsErrorOk attribute reference
	 */
	public ConditionReference getWsErrorOkReference() {
		return wsErrorStatus.getCondition(wsErrorOk);	
	}

	/**
	 * Getter for wsErrorOk attribute.
	 * @return wsErrorOk attribute
	 */
	public boolean isWsErrorOk() {
		return getWsErrorOkReference().getValue();	
	}

	/**
	 * Setter for wsErrorOk attribute.
	 * @param wsErrorOk the new value of wsErrorOk
	 */
	public void setWsErrorOk(boolean wsErrorOk) {
		getWsErrorOkReference().setValue(wsErrorOk);	
	}
}
