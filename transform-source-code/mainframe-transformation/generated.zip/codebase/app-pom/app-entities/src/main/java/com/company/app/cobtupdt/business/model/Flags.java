package com.company.app.cobtupdt.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
/**
 * Data simplifier entity Flags.
 * 
 * <p>About 'lastrec' field, <br>
 * </p>
 * 
 * @see RecordEntity
 */
public class Flags extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Elementary lastrec = new Elementary(root,new AlphanumericType(1)," ");
	
	/**
	 * Instantiate a new Flags with a default record.
	 * @param configuration the configuration
	 */
	public Flags(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new Flags bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public Flags(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	/**
	 * Gets the reference for attribute lastrec.
	 * @return the lastrec attribute reference
	 */
	public ElementaryRangeReference getLastrecReference() {
		return lastrec.getReference();
	}

	/**
	 * Getter for lastrec attribute.
	 * @return lastrec attribute
	 */
	public String getLastrec() {
		return lastrec.getValue();
	}

	/**
	 * Setter for lastrec attribute.
	 * @param lastrec the new value of lastrec
	 */
	public void setLastrec(String lastrec) {
		this.lastrec.setValue(lastrec);
	}
}
