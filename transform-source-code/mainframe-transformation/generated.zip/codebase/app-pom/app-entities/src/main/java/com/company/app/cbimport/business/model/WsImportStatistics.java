package com.company.app.cbimport.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.ZonedType;
/**
 * Data simplifier entity WsImportStatistics.
<pre>
 * 
 * Legacy Documentation:<br>
 *   Statistics Counters<br>
</pre>
 * 
 * <p>About 'wsTotalRecordsRead' field, <br>
 * </p>
 * 
 * <p>About 'wsCustomerRecordsImported' field, <br>
 * </p>
 * 
 * <p>About 'wsAccountRecordsImported' field, <br>
 * </p>
 * 
 * <p>About 'wsXrefRecordsImported' field, <br>
 * </p>
 * 
 * <p>About 'wsTranRecordsImported' field, <br>
 * </p>
 * 
 * <p>About 'wsCardRecordsImported' field, <br>
 * </p>
 * 
 * <p>About 'wsErrorRecordsWritten' field, <br>
 * </p>
 * 
 * <p>About 'wsUnknownRecordTypeCount' field, <br>
 * </p>
 * 
 * @see RecordEntity
 */
public class WsImportStatistics extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Elementary wsTotalRecordsRead = new Elementary(root,new ZonedType(9, 0, false),Integer.valueOf("0"));
	private final Elementary wsCustomerRecordsImported = new Elementary(root,new ZonedType(9, 0, false),Integer.valueOf("0"));
	private final Elementary wsAccountRecordsImported = new Elementary(root,new ZonedType(9, 0, false),Integer.valueOf("0"));
	private final Elementary wsXrefRecordsImported = new Elementary(root,new ZonedType(9, 0, false),Integer.valueOf("0"));
	private final Elementary wsTranRecordsImported = new Elementary(root,new ZonedType(9, 0, false),Integer.valueOf("0"));
	private final Elementary wsCardRecordsImported = new Elementary(root,new ZonedType(9, 0, false),Integer.valueOf("0"));
	private final Elementary wsErrorRecordsWritten = new Elementary(root,new ZonedType(9, 0, false),Integer.valueOf("0"));
	private final Elementary wsUnknownRecordTypeCount = new Elementary(root,new ZonedType(9, 0, false),Integer.valueOf("0"));
	
	/**
	 * Instantiate a new WsImportStatistics with a default record.
	 * @param configuration the configuration
	 */
	public WsImportStatistics(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new WsImportStatistics bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public WsImportStatistics(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	/**
	 * Gets the reference for attribute wsTotalRecordsRead.
	 * @return the wsTotalRecordsRead attribute reference
	 */
	public ElementaryRangeReference getWsTotalRecordsReadReference() {
		return wsTotalRecordsRead.getReference();
	}

	/**
	 * Getter for wsTotalRecordsRead attribute.
	 * @return wsTotalRecordsRead attribute
	 */
	public int getWsTotalRecordsRead() {
		return wsTotalRecordsRead.getValue();
	}

	/**
	 * Setter for wsTotalRecordsRead attribute.
	 * @param wsTotalRecordsRead the new value of wsTotalRecordsRead
	 */
	public void setWsTotalRecordsRead(int wsTotalRecordsRead) {
		this.wsTotalRecordsRead.setValue(wsTotalRecordsRead);
	}
	/**
	 * Gets the reference for attribute wsCustomerRecordsImported.
	 * @return the wsCustomerRecordsImported attribute reference
	 */
	public ElementaryRangeReference getWsCustomerRecordsImportedReference() {
		return wsCustomerRecordsImported.getReference();
	}

	/**
	 * Getter for wsCustomerRecordsImported attribute.
	 * @return wsCustomerRecordsImported attribute
	 */
	public int getWsCustomerRecordsImported() {
		return wsCustomerRecordsImported.getValue();
	}

	/**
	 * Setter for wsCustomerRecordsImported attribute.
	 * @param wsCustomerRecordsImported the new value of wsCustomerRecordsImported
	 */
	public void setWsCustomerRecordsImported(int wsCustomerRecordsImported) {
		this.wsCustomerRecordsImported.setValue(wsCustomerRecordsImported);
	}
	/**
	 * Gets the reference for attribute wsAccountRecordsImported.
	 * @return the wsAccountRecordsImported attribute reference
	 */
	public ElementaryRangeReference getWsAccountRecordsImportedReference() {
		return wsAccountRecordsImported.getReference();
	}

	/**
	 * Getter for wsAccountRecordsImported attribute.
	 * @return wsAccountRecordsImported attribute
	 */
	public int getWsAccountRecordsImported() {
		return wsAccountRecordsImported.getValue();
	}

	/**
	 * Setter for wsAccountRecordsImported attribute.
	 * @param wsAccountRecordsImported the new value of wsAccountRecordsImported
	 */
	public void setWsAccountRecordsImported(int wsAccountRecordsImported) {
		this.wsAccountRecordsImported.setValue(wsAccountRecordsImported);
	}
	/**
	 * Gets the reference for attribute wsXrefRecordsImported.
	 * @return the wsXrefRecordsImported attribute reference
	 */
	public ElementaryRangeReference getWsXrefRecordsImportedReference() {
		return wsXrefRecordsImported.getReference();
	}

	/**
	 * Getter for wsXrefRecordsImported attribute.
	 * @return wsXrefRecordsImported attribute
	 */
	public int getWsXrefRecordsImported() {
		return wsXrefRecordsImported.getValue();
	}

	/**
	 * Setter for wsXrefRecordsImported attribute.
	 * @param wsXrefRecordsImported the new value of wsXrefRecordsImported
	 */
	public void setWsXrefRecordsImported(int wsXrefRecordsImported) {
		this.wsXrefRecordsImported.setValue(wsXrefRecordsImported);
	}
	/**
	 * Gets the reference for attribute wsTranRecordsImported.
	 * @return the wsTranRecordsImported attribute reference
	 */
	public ElementaryRangeReference getWsTranRecordsImportedReference() {
		return wsTranRecordsImported.getReference();
	}

	/**
	 * Getter for wsTranRecordsImported attribute.
	 * @return wsTranRecordsImported attribute
	 */
	public int getWsTranRecordsImported() {
		return wsTranRecordsImported.getValue();
	}

	/**
	 * Setter for wsTranRecordsImported attribute.
	 * @param wsTranRecordsImported the new value of wsTranRecordsImported
	 */
	public void setWsTranRecordsImported(int wsTranRecordsImported) {
		this.wsTranRecordsImported.setValue(wsTranRecordsImported);
	}
	/**
	 * Gets the reference for attribute wsCardRecordsImported.
	 * @return the wsCardRecordsImported attribute reference
	 */
	public ElementaryRangeReference getWsCardRecordsImportedReference() {
		return wsCardRecordsImported.getReference();
	}

	/**
	 * Getter for wsCardRecordsImported attribute.
	 * @return wsCardRecordsImported attribute
	 */
	public int getWsCardRecordsImported() {
		return wsCardRecordsImported.getValue();
	}

	/**
	 * Setter for wsCardRecordsImported attribute.
	 * @param wsCardRecordsImported the new value of wsCardRecordsImported
	 */
	public void setWsCardRecordsImported(int wsCardRecordsImported) {
		this.wsCardRecordsImported.setValue(wsCardRecordsImported);
	}
	/**
	 * Gets the reference for attribute wsErrorRecordsWritten.
	 * @return the wsErrorRecordsWritten attribute reference
	 */
	public ElementaryRangeReference getWsErrorRecordsWrittenReference() {
		return wsErrorRecordsWritten.getReference();
	}

	/**
	 * Getter for wsErrorRecordsWritten attribute.
	 * @return wsErrorRecordsWritten attribute
	 */
	public int getWsErrorRecordsWritten() {
		return wsErrorRecordsWritten.getValue();
	}

	/**
	 * Setter for wsErrorRecordsWritten attribute.
	 * @param wsErrorRecordsWritten the new value of wsErrorRecordsWritten
	 */
	public void setWsErrorRecordsWritten(int wsErrorRecordsWritten) {
		this.wsErrorRecordsWritten.setValue(wsErrorRecordsWritten);
	}
	/**
	 * Gets the reference for attribute wsUnknownRecordTypeCount.
	 * @return the wsUnknownRecordTypeCount attribute reference
	 */
	public ElementaryRangeReference getWsUnknownRecordTypeCountReference() {
		return wsUnknownRecordTypeCount.getReference();
	}

	/**
	 * Getter for wsUnknownRecordTypeCount attribute.
	 * @return wsUnknownRecordTypeCount attribute
	 */
	public int getWsUnknownRecordTypeCount() {
		return wsUnknownRecordTypeCount.getValue();
	}

	/**
	 * Setter for wsUnknownRecordTypeCount attribute.
	 * @param wsUnknownRecordTypeCount the new value of wsUnknownRecordTypeCount
	 */
	public void setWsUnknownRecordTypeCount(int wsUnknownRecordTypeCount) {
		this.wsUnknownRecordTypeCount.setValue(wsUnknownRecordTypeCount);
	}
}
