package com.company.app.cotrtupc.business.context;
import com.company.app.cotrtupc.business.model.Dfhaid;
import com.company.app.cotrtupc.business.model.Dfhbmsca;
import com.company.app.cotrtupc.business.model.Dfhcommarea;
import com.company.app.cotrtupc.business.model.Dfheiblk;
import com.company.app.cotrtupc.business.model.LitAllAlphaFrom;
import com.company.app.cotrtupc.business.model.LitAllAlphanumFrom;
import com.company.app.cotrtupc.business.model.LitAllNumFrom;
import com.company.app.cotrtupc.business.model.LitAlphaSpacesTo;
import com.company.app.cotrtupc.business.model.LitAlphanumSpacesTo;
import com.company.app.cotrtupc.business.model.LitNumSpacesTo;
import com.company.app.cotrtupc.business.model.Sqlca;
import com.company.app.cotrtupc.business.model.WsCommarea;
import com.company.app.cotrtupc.business.model.WsLiterals;
import com.company.app.cotrtupc.business.model.WsMiscStorage;
import com.company.app.cotrtupc.business.model.WsThisProgcommarea;
import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.rt.jics.context.JicsRuntimeContext;
import com.netfective.bluage.gapwalk.rt.utils.EntityUtils;
import jakarta.annotation.PostConstruct;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Data simplifier context CotrtupcContext.
 * 
 * <p>About 'onCode' field, <br>
 * </p>
 * 
 * <p>About 'onChar' field, <br>
 * </p>
 * 
 * <p>About 'wsMiscStorage' field, <br>uml entity: com.company.app.cotrtupc.business.model.WsMiscStorage
 * <br></p>
 * 
 * <p>About 'wsLiterals' field, <br>uml entity: com.company.app.cotrtupc.business.model.WsLiterals
 * <br></p>
 * 
 * <p>About 'litAllAlphaFrom' field, <br>uml entity: com.company.app.cotrtupc.business.model.LitAllAlphaFrom
 * <br></p>
 * 
 * <p>About 'litAllAlphanumFrom' field, <br>uml entity: com.company.app.cotrtupc.business.model.LitAllAlphanumFrom
 * <br></p>
 * 
 * <p>About 'litAllNumFrom' field, <br>uml entity: com.company.app.cotrtupc.business.model.LitAllNumFrom
 * <br></p>
 * 
 * <p>About 'litAlphaSpacesTo' field, <br>uml entity: com.company.app.cotrtupc.business.model.LitAlphaSpacesTo
 * <br></p>
 * 
 * <p>About 'litAlphanumSpacesTo' field, <br>uml entity: com.company.app.cotrtupc.business.model.LitAlphanumSpacesTo
 * <br></p>
 * 
 * <p>About 'litNumSpacesTo' field, <br>uml entity: com.company.app.cotrtupc.business.model.LitNumSpacesTo
 * <br></p>
 * 
 * <p>About 'dfhbmsca' field, <br>uml entity: com.company.app.cotrtupc.business.model.Dfhbmsca
 * <br></p>
 * 
 * <p>About 'dfhaid' field, <br>uml entity: com.company.app.cotrtupc.business.model.Dfhaid
 * <br></p>
 * 
 * <p>About 'sqlca' field, <br>uml entity: com.company.app.cotrtupc.business.model.Sqlca
 * <br></p>
 * 
 * <p>About 'wsThisProgcommarea' field, <br>uml entity: com.company.app.cotrtupc.business.model.WsThisProgcommarea
 * <br></p>
 * 
 * <p>About 'wsCommarea' field, <br>uml entity: com.company.app.cotrtupc.business.model.WsCommarea
 * <br></p>
 * 
 * <p>About 'dfheiblk' field, <br>uml entity: com.company.app.cotrtupc.business.model.Dfheiblk
 * <br></p>
 * 
 * <p>About 'dfhcommarea' field, <br>uml entity: com.company.app.cotrtupc.business.model.Dfhcommarea
 * <br></p>
 * 
 */
@Component("com.company.app.cotrtupc.business.context.CotrtupcContext")
@Lazy
@Scope("prototype")
public class CotrtupcContext extends JicsRuntimeContext {
	
	private WsMiscStorage wsMiscStorage;
	private WsLiterals wsLiterals;
	private LitAllAlphaFrom litAllAlphaFrom;
	private LitAllAlphanumFrom litAllAlphanumFrom;
	private LitAllNumFrom litAllNumFrom;
	private LitAlphaSpacesTo litAlphaSpacesTo;
	private LitAlphanumSpacesTo litAlphanumSpacesTo;
	private LitNumSpacesTo litNumSpacesTo;
	private Dfhbmsca dfhbmsca;
	private Dfhaid dfhaid;
	private Sqlca sqlca;
	private WsThisProgcommarea wsThisProgcommarea;
	private WsCommarea wsCommarea;
	private Dfheiblk dfheiblk;
	private Dfhcommarea dfhcommarea;

	private List<RecordEntity> recordEntities;

	/**
	 * Default constructor.
	 * @param configuration the datasimplifier configuration
	 */
	public CotrtupcContext (@Qualifier("CotrtupcContextConfiguration") Configuration configuration) {
		super(configuration);
		initWorking(configuration);
		initLinkage(configuration);
		initRecordEntities();
	}
	
	/**
	 * Add count holders:
	 * 
	 * Once all entities/files have been initialized, bind the
	 * elementary references that act as count holder for 
	 * variable size arrays.
	 */
	@PostConstruct
	public void addCountHolders(){
		dfhcommarea.setTableCountHolder(dfheiblk.getEibcalenReference());
	}
	

	/**
	 * Getter for wsMiscStorage.
	 * @return the wsMiscStorage
	 */
	public WsMiscStorage getWsMiscStorage() {
		return this.wsMiscStorage;
	}

	/**
	 * Setter for wsMiscStorage.
	 * @param reference the new value for wsMiscStorage
	 */
	public void setWsMiscStorage(RangeReference reference) {
		this.wsMiscStorage.setBytes(reference.getBytes());
	}

	/**
	 * Getter for wsLiterals.
	 * @return the wsLiterals
	 */
	public WsLiterals getWsLiterals() {
		return this.wsLiterals;
	}

	/**
	 * Setter for wsLiterals.
	 * @param reference the new value for wsLiterals
	 */
	public void setWsLiterals(RangeReference reference) {
		this.wsLiterals.setBytes(reference.getBytes());
	}

	/**
	 * Getter for litAllAlphaFrom.
	 * @return the litAllAlphaFrom
	 */
	public LitAllAlphaFrom getLitAllAlphaFrom() {
		return this.litAllAlphaFrom;
	}

	/**
	 * Setter for litAllAlphaFrom.
	 * @param reference the new value for litAllAlphaFrom
	 */
	public void setLitAllAlphaFrom(RangeReference reference) {
		this.litAllAlphaFrom.setBytes(reference.getBytes());
	}

	/**
	 * Getter for litAllAlphanumFrom.
	 * @return the litAllAlphanumFrom
	 */
	public LitAllAlphanumFrom getLitAllAlphanumFrom() {
		return this.litAllAlphanumFrom;
	}

	/**
	 * Setter for litAllAlphanumFrom.
	 * @param reference the new value for litAllAlphanumFrom
	 */
	public void setLitAllAlphanumFrom(RangeReference reference) {
		this.litAllAlphanumFrom.setBytes(reference.getBytes());
	}

	/**
	 * Getter for litAllNumFrom.
	 * @return the litAllNumFrom
	 */
	public LitAllNumFrom getLitAllNumFrom() {
		return this.litAllNumFrom;
	}

	/**
	 * Setter for litAllNumFrom.
	 * @param reference the new value for litAllNumFrom
	 */
	public void setLitAllNumFrom(RangeReference reference) {
		this.litAllNumFrom.setBytes(reference.getBytes());
	}

	/**
	 * Getter for litAlphaSpacesTo.
	 * @return the litAlphaSpacesTo
	 */
	public LitAlphaSpacesTo getLitAlphaSpacesTo() {
		return this.litAlphaSpacesTo;
	}

	/**
	 * Setter for litAlphaSpacesTo.
	 * @param reference the new value for litAlphaSpacesTo
	 */
	public void setLitAlphaSpacesTo(RangeReference reference) {
		this.litAlphaSpacesTo.setBytes(reference.getBytes());
	}

	/**
	 * Getter for litAlphanumSpacesTo.
	 * @return the litAlphanumSpacesTo
	 */
	public LitAlphanumSpacesTo getLitAlphanumSpacesTo() {
		return this.litAlphanumSpacesTo;
	}

	/**
	 * Setter for litAlphanumSpacesTo.
	 * @param reference the new value for litAlphanumSpacesTo
	 */
	public void setLitAlphanumSpacesTo(RangeReference reference) {
		this.litAlphanumSpacesTo.setBytes(reference.getBytes());
	}

	/**
	 * Getter for litNumSpacesTo.
	 * @return the litNumSpacesTo
	 */
	public LitNumSpacesTo getLitNumSpacesTo() {
		return this.litNumSpacesTo;
	}

	/**
	 * Setter for litNumSpacesTo.
	 * @param reference the new value for litNumSpacesTo
	 */
	public void setLitNumSpacesTo(RangeReference reference) {
		this.litNumSpacesTo.setBytes(reference.getBytes());
	}

	/**
	 * Getter for dfhbmsca.
	 * @return the dfhbmsca
	 */
	public Dfhbmsca getDfhbmsca() {
		return this.dfhbmsca;
	}

	/**
	 * Setter for dfhbmsca.
	 * @param reference the new value for dfhbmsca
	 */
	public void setDfhbmsca(RangeReference reference) {
		this.dfhbmsca.setBytes(reference.getBytes());
	}

	/**
	 * Getter for dfhaid.
	 * @return the dfhaid
	 */
	public Dfhaid getDfhaid() {
		return this.dfhaid;
	}

	/**
	 * Setter for dfhaid.
	 * @param reference the new value for dfhaid
	 */
	public void setDfhaid(RangeReference reference) {
		this.dfhaid.setBytes(reference.getBytes());
	}

	/**
	 * Getter for sqlca.
	 * @return the sqlca
	 */
	public Sqlca getSqlca() {
		return this.sqlca;
	}

	/**
	 * Setter for sqlca.
	 * @param reference the new value for sqlca
	 */
	public void setSqlca(RangeReference reference) {
		this.sqlca.setBytes(reference.getBytes());
	}

	/**
	 * Getter for wsThisProgcommarea.
	 * @return the wsThisProgcommarea
	 */
	public WsThisProgcommarea getWsThisProgcommarea() {
		return this.wsThisProgcommarea;
	}

	/**
	 * Setter for wsThisProgcommarea.
	 * @param reference the new value for wsThisProgcommarea
	 */
	public void setWsThisProgcommarea(RangeReference reference) {
		this.wsThisProgcommarea.setBytes(reference.getBytes());
	}

	/**
	 * Getter for wsCommarea.
	 * @return the wsCommarea
	 */
	public WsCommarea getWsCommarea() {
		return this.wsCommarea;
	}

	/**
	 * Setter for wsCommarea.
	 * @param reference the new value for wsCommarea
	 */
	public void setWsCommarea(RangeReference reference) {
		this.wsCommarea.setBytes(reference.getBytes());
	}

	/**
	 * Getter for dfheiblk.
	 * @return the dfheiblk
	 */
	public Dfheiblk getDfheiblk() {
		return this.dfheiblk;
	}

	/**
	 * Setter for dfheiblk.
	 * @param reference the new value for dfheiblk
	 */
	public void setDfheiblk(RangeReference reference) {
		this.dfheiblk.setBytes(reference.getBytes());
	}

	/**
	 * Getter for dfhcommarea.
	 * @return the dfhcommarea
	 */
	public Dfhcommarea getDfhcommarea() {
		return this.dfhcommarea;
	}

	/**
	 * Setter for dfhcommarea.
	 * @param reference the new value for dfhcommarea
	 */
	public void setDfhcommarea(RangeReference reference) {
		this.dfhcommarea.setBytes(reference.getBytes());
	}

	/**
	 * Getter for Jics Exec Interface Block.
	 * @return the Jics Exec Interface Block
	 */
	public Dfheiblk getJicsEiblk() {
		return this.dfheiblk;
	}

	@Override 
	public void cleanUp(){
	}

	@Override
	protected void doReset() {
		cleanUp();
	    // reset the working
		recordEntities.stream().forEach(e -> e.reset());
	}

	
	private void initWorking(Configuration configuration) {
		wsMiscStorage = new WsMiscStorage(configuration);
		wsLiterals = new WsLiterals(configuration);
		litAllAlphaFrom = new LitAllAlphaFrom(configuration);
		litAllAlphanumFrom = new LitAllAlphanumFrom(configuration);
		litAllNumFrom = new LitAllNumFrom(configuration);
		litAlphaSpacesTo = new LitAlphaSpacesTo(configuration);
		litAlphanumSpacesTo = new LitAlphanumSpacesTo(configuration);
		litNumSpacesTo = new LitNumSpacesTo(configuration);
		dfhbmsca = new Dfhbmsca(configuration);
		dfhaid = new Dfhaid(configuration);
		sqlca = new Sqlca(configuration);
		wsThisProgcommarea = new WsThisProgcommarea(configuration);
		wsCommarea = new WsCommarea(configuration);
	}
	
	private void initLinkage(Configuration configuration) {
		dfheiblk = new Dfheiblk(configuration, EntityUtils.getUnlinkedRecord());
		dfhcommarea = new Dfhcommarea(configuration, EntityUtils.getUnlinkedRecord());
	
	}

	private void initRecordEntities() {
		recordEntities = Arrays.asList(wsMiscStorage, wsLiterals, litAllAlphaFrom, litAllAlphanumFrom, litAllNumFrom, litAlphaSpacesTo, litAlphanumSpacesTo, litNumSpacesTo, dfhbmsca, dfhaid, sqlca, wsThisProgcommarea, wsCommarea);
	}

	@Override
	public String toString(){
		StringBuilder toSB = new StringBuilder("\nCotrtupcContext:\n");
		if(!this.recordEntities.isEmpty()){
			this.recordEntities.forEach(e -> toSB.append(e.getClass().getSimpleName()).append(" : [").append(e.toString()).append("]\n"));
		}
		toSB.append("Dfheiblk : [").append(dfheiblk.toString()).append("]\n");
		toSB.append("Dfhcommarea : [").append(dfhcommarea.toString()).append("]\n");
		return toSB.toString();
	}

}
