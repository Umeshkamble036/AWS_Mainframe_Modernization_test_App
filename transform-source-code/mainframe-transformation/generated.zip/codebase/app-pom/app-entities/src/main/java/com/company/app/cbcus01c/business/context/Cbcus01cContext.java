package com.company.app.cbcus01c.business.context;
import com.company.app.cbcus01c.business.model.Abcode;
import com.company.app.cbcus01c.business.model.ApplResult;
import com.company.app.cbcus01c.business.model.CustfileFile;
import com.company.app.cbcus01c.business.model.CustfileStatus;
import com.company.app.cbcus01c.business.model.EndOfFile;
import com.company.app.cbcus01c.business.model.Group1;
import com.company.app.cbcus01c.business.model.IoStatus;
import com.company.app.cbcus01c.business.model.IoStatus04;
import com.company.app.cbcus01c.business.model.Timing;
import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.io.metadata.builder.IndexedFileDescriptionBuilder;
import com.netfective.bluage.gapwalk.rt.io.AccessMode;
import com.netfective.bluage.gapwalk.rt.io.IndexedFile;
import com.netfective.bluage.gapwalk.rt.jics.context.JicsRuntimeContext;
import com.netfective.bluage.gapwalk.rt.shared.ExecutionContext;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Data simplifier context Cbcus01cContext.
 * 
 * <p>About 'onCode' field, <br>
 * </p>
 * 
 * <p>About 'onChar' field, <br>
 * </p>
 * 
 * <p>About 'custfileFile' file, <br>uml entity: com.company.app.cbcus01c.business.model.CustfileFile
 * <br></p>
 * 
 * <p>About 'custfileStatus' field, <br>uml entity: com.company.app.cbcus01c.business.model.CustfileStatus
 * <br></p>
 * 
 * <p>About 'ioStatus' field, <br>uml entity: com.company.app.cbcus01c.business.model.IoStatus
 * <br></p>
 * 
 * <p>About 'group1' field, <br>uml entity: com.company.app.cbcus01c.business.model.Group1
 * <br></p>
 * 
 * <p>About 'ioStatus04' field, <br>uml entity: com.company.app.cbcus01c.business.model.IoStatus04
 * <br></p>
 * 
 * <p>About 'applResult' field, <br>uml entity: com.company.app.cbcus01c.business.model.ApplResult
 * <br></p>
 * 
 * <p>About 'endOfFile' field, <br>uml entity: com.company.app.cbcus01c.business.model.EndOfFile
 * <br></p>
 * 
 * <p>About 'abcode' field, <br>uml entity: com.company.app.cbcus01c.business.model.Abcode
 * <br></p>
 * 
 * <p>About 'timing' field, <br>uml entity: com.company.app.cbcus01c.business.model.Timing
 * <br></p>
 * 
 */
@Component("com.company.app.cbcus01c.business.context.Cbcus01cContext")
@Import({
	com.company.app.cbcus01c.business.model.CustfileFile.class
})
@Lazy
@Scope("prototype")
public class Cbcus01cContext extends JicsRuntimeContext {

	@Autowired
	private CustfileFile custfileFile;

	private IndexedFile custfileFileFile;	
	
	private CustfileStatus custfileStatus;
	private IoStatus ioStatus;
	private Group1 group1;
	private IoStatus04 ioStatus04;
	private ApplResult applResult;
	private EndOfFile endOfFile;
	private Abcode abcode;
	private Timing timing;

	private List<RecordEntity> recordEntities;

	/**
	 * Default constructor.
	 * @param configuration the datasimplifier configuration
	 */
	public Cbcus01cContext (@Qualifier("Cbcus01cContextConfiguration") Configuration configuration) {
		super(configuration);
		initWorking(configuration);
		
		initRecordEntities();
	}
	
	

	/**
	 * Getter for the file custfileFile.
	 * @return the custfileFile
	 */
	public CustfileFile getCustfileFile() {
		return this.custfileFile;
	}
	
	/**
	 * Getter for the file handler custfileFileFile.
	 * @param executionContext the execution context
	 * @return the custfileFileFile
	 */
	public IndexedFile getCustfileFileHandler(ExecutionContext executionContext) {
		
		if(this.custfileFileFile == null){
			this.custfileFileFile = executionContext.getFileProvider().getFile(
				"CUSTFILE",
				new IndexedFileDescriptionBuilder()
					.fileStatus(this.getCustfileStatus())
					.accessMode(AccessMode.SEQUENTIAL)
					.primaryKey(this.getCustfileFile().getFdCustIdReference())
					.build(),
				getConfiguration(), custfileFile);
		}
		return this.custfileFileFile;	
	}

	/**
	 * Getter for custfileStatus.
	 * @return the custfileStatus
	 */
	public CustfileStatus getCustfileStatus() {
		return this.custfileStatus;
	}

	/**
	 * Setter for custfileStatus.
	 * @param reference the new value for custfileStatus
	 */
	public void setCustfileStatus(RangeReference reference) {
		this.custfileStatus.setBytes(reference.getBytes());
	}

	/**
	 * Getter for ioStatus.
	 * @return the ioStatus
	 */
	public IoStatus getIoStatus() {
		return this.ioStatus;
	}

	/**
	 * Setter for ioStatus.
	 * @param reference the new value for ioStatus
	 */
	public void setIoStatus(RangeReference reference) {
		this.ioStatus.setBytes(reference.getBytes());
	}

	/**
	 * Getter for group1.
	 * @return the group1
	 */
	public Group1 getGroup1() {
		return this.group1;
	}

	/**
	 * Setter for group1.
	 * @param reference the new value for group1
	 */
	public void setGroup1(RangeReference reference) {
		this.group1.setBytes(reference.getBytes());
	}

	/**
	 * Getter for ioStatus04.
	 * @return the ioStatus04
	 */
	public IoStatus04 getIoStatus04() {
		return this.ioStatus04;
	}

	/**
	 * Setter for ioStatus04.
	 * @param reference the new value for ioStatus04
	 */
	public void setIoStatus04(RangeReference reference) {
		this.ioStatus04.setBytes(reference.getBytes());
	}

	/**
	 * Getter for applResult.
	 * @return the applResult
	 */
	public ApplResult getApplResult() {
		return this.applResult;
	}

	/**
	 * Setter for applResult.
	 * @param reference the new value for applResult
	 */
	public void setApplResult(RangeReference reference) {
		this.applResult.setBytes(reference.getBytes());
	}

	/**
	 * Getter for endOfFile.
	 * @return the endOfFile
	 */
	public EndOfFile getEndOfFile() {
		return this.endOfFile;
	}

	/**
	 * Setter for endOfFile.
	 * @param reference the new value for endOfFile
	 */
	public void setEndOfFile(RangeReference reference) {
		this.endOfFile.setBytes(reference.getBytes());
	}

	/**
	 * Getter for abcode.
	 * @return the abcode
	 */
	public Abcode getAbcode() {
		return this.abcode;
	}

	/**
	 * Setter for abcode.
	 * @param reference the new value for abcode
	 */
	public void setAbcode(RangeReference reference) {
		this.abcode.setBytes(reference.getBytes());
	}

	/**
	 * Getter for timing.
	 * @return the timing
	 */
	public Timing getTiming() {
		return this.timing;
	}

	/**
	 * Setter for timing.
	 * @param reference the new value for timing
	 */
	public void setTiming(RangeReference reference) {
		this.timing.setBytes(reference.getBytes());
	}

	@Override 
	public void cleanUp(){
		if(this.custfileFileFile !=null && this.custfileFileFile.isOpen() && !this.custfileFileFile.isShared()) {
			this.custfileFileFile.close();
		}
		if(this.custfileFileFile !=null && !this.custfileFileFile.isShared()){
			this.custfileFileFile = null;
		}
	}

	@Override
	protected void doReset() {
		cleanUp();
		this.custfileFile.reset();
	    // reset the working
		recordEntities.stream().forEach(e -> e.reset());
	}

	
	private void initWorking(Configuration configuration) {
		custfileStatus = new CustfileStatus(configuration);
		ioStatus = new IoStatus(configuration);
		group1 = new Group1(configuration);
		ioStatus04 = new IoStatus04(configuration);
		applResult = new ApplResult(configuration);
		endOfFile = new EndOfFile(configuration);
		abcode = new Abcode(configuration);
		timing = new Timing(configuration);
	}

	private void initRecordEntities() {
		recordEntities = Arrays.asList(custfileStatus, ioStatus, group1, ioStatus04, applResult, endOfFile, abcode, timing);
	}

	@Override
	public String toString(){
		StringBuilder toSB = new StringBuilder("\nCbcus01cContext:\n");
		if(!this.recordEntities.isEmpty()){
			this.recordEntities.forEach(e -> toSB.append(e.getClass().getSimpleName()).append(" : [").append(e.toString()).append("]\n"));
		}
		return toSB.toString();
	}

}
