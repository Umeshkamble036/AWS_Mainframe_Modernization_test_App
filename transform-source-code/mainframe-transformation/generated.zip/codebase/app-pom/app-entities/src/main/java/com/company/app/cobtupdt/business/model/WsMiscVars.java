package com.company.app.cobtupdt.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.NumericEditedType;
/**
 * Data simplifier entity WsMiscVars.
 * 
 * <p>About 'wsVarSqlcode' field, <br>
 * </p>
 * 
 * @see RecordEntity
 */
public class WsMiscVars extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Elementary wsVarSqlcode = new Elementary(root,new NumericEditedType("----9"));
	
	/**
	 * Instantiate a new WsMiscVars with a default record.
	 * @param configuration the configuration
	 */
	public WsMiscVars(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new WsMiscVars bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public WsMiscVars(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	/**
	 * Gets the reference for attribute wsVarSqlcode.
	 * @return the wsVarSqlcode attribute reference
	 */
	public ElementaryRangeReference getWsVarSqlcodeReference() {
		return wsVarSqlcode.getReference();
	}

	/**
	 * Getter for wsVarSqlcode attribute.
	 * @return wsVarSqlcode attribute
	 */
	public String getWsVarSqlcode() {
		return wsVarSqlcode.getValue();
	}

	/**
	 * Setter for wsVarSqlcode attribute.
	 * @param wsVarSqlcode the new value of wsVarSqlcode
	 */
	public void setWsVarSqlcode(String wsVarSqlcode) {
		this.wsVarSqlcode.setValue(wsVarSqlcode);
	}
}
