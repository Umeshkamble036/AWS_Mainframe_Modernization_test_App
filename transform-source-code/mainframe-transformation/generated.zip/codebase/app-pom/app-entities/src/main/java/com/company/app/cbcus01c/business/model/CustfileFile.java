package com.company.app.cbcus01c.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.ZonedType;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Data simplifier file CustfileFile.
<pre>
 * 
 * Legacy Documentation:<br>
 *  *****************************************************************<br>
 *   Program     : CBCUS01C.CBL<br>
 *   Application : CardDemo<br>
 *   Type        : BATCH COBOL Program<br>
 *   Function    : Read and print customer data file.<br>
 *  *****************************************************************<br>
 *   Copyright Amazon.com, Inc. or its affiliates.<br>
 *   All Rights Reserved.<br>
 *  <br>
 *   Licensed under the Apache License, Version 2.0 (the "License").<br>
 *   You may not use this file except in compliance with the License.<br>
 *   You may obtain a copy of the License at<br>
 *  <br>
 *      http://www.apache.org/licenses/LICENSE-2.0<br>
 *  <br>
 *   Unless required by applicable law or agreed to in writing,<br>
 *   software distributed under the License is distributed on an<br>
 *   "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,<br>
 *   either express or implied. See the License for the specific<br>
 *   language governing permissions and limitations under the License<br>
 *  *****************************************************************<br>
 *  <br>
</pre>
 * 
 * <p>About 'fdCustfileRec' field, <br>uml entity: com.company.app.cbcus01c.business.model.FdCustfileRec
 * <br></p>
 * 
 */
@Component("com.company.app.cbcus01c.business.model.CustfileFile")
@Lazy
@Scope("prototype")
public class CustfileFile extends RecordEntity {

	private final Group root = new Group(getData());
	private final Group fdCustfileRec = new Group(root);
	private final Elementary fdCustId = new Elementary(fdCustfileRec,new ZonedType(9, 0, false));
	private final Elementary fdCustData = new Elementary(fdCustfileRec,new AlphanumericType(491));
	 
	/**
	 * Instantiate a new CustfileFile.
	 * @param configuration the configuration
	 */
	public CustfileFile(@Qualifier("Cbcus01cContextConfiguration") Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}
	
	/**
	 * Gets the reference for attribute fdCustfileRec.
	 * @return the fdCustfileRec attribute reference
	 */
	public RangeReference getFdCustfileRecReference() {
		return fdCustfileRec.getReference();
	}	
				
	/**
	 * Setter for fdCustfileRec .
	 */
   	public void setFdCustfileRec(RangeReference reference) {
       	fdCustfileRec.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute fdCustId.
	 * @return the fdCustId attribute reference
	 */
	public ElementaryRangeReference getFdCustIdReference() {
		return fdCustId.getReference();
	}

	/**
	 * Getter for fdCustId attribute.
	 * @return fdCustId attribute
	 */
	public int getFdCustId() {
		return fdCustId.getValue();
	}

	/**
	 * Setter for fdCustId attribute.
	 * @param fdCustId the new value of fdCustId
	 */
	public void setFdCustId(int fdCustId) {
		this.fdCustId.setValue(fdCustId);
	}
	/**
	 * Gets the reference for attribute fdCustData.
	 * @return the fdCustData attribute reference
	 */
	public ElementaryRangeReference getFdCustDataReference() {
		return fdCustData.getReference();
	}

	/**
	 * Getter for fdCustData attribute.
	 * @return fdCustData attribute
	 */
	public String getFdCustData() {
		return fdCustData.getValue();
	}

	/**
	 * Setter for fdCustData attribute.
	 * @param fdCustData the new value of fdCustData
	 */
	public void setFdCustData(String fdCustData) {
		this.fdCustData.setValue(fdCustData);
	}
}
