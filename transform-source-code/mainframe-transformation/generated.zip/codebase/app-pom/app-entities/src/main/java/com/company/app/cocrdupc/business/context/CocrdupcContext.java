package com.company.app.cocrdupc.business.context;
import com.company.app.cocrdupc.business.model.Dfhaid;
import com.company.app.cocrdupc.business.model.Dfhbmsca;
import com.company.app.cocrdupc.business.model.Dfhcommarea;
import com.company.app.cocrdupc.business.model.Dfheiblk;
import com.company.app.cocrdupc.business.model.WsCommarea;
import com.company.app.cocrdupc.business.model.WsLiterals;
import com.company.app.cocrdupc.business.model.WsMiscStorage;
import com.company.app.cocrdupc.business.model.WsThisProgcommarea;
import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.rt.jics.context.JicsRuntimeContext;
import com.netfective.bluage.gapwalk.rt.utils.EntityUtils;
import jakarta.annotation.PostConstruct;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Data simplifier context CocrdupcContext.
 * 
 * <p>About 'onCode' field, <br>
 * </p>
 * 
 * <p>About 'onChar' field, <br>
 * </p>
 * 
 * <p>About 'wsMiscStorage' field, <br>uml entity: com.company.app.cocrdupc.business.model.WsMiscStorage
 * <br></p>
 * 
 * <p>About 'wsLiterals' field, <br>uml entity: com.company.app.cocrdupc.business.model.WsLiterals
 * <br></p>
 * 
 * <p>About 'wsThisProgcommarea' field, <br>uml entity: com.company.app.cocrdupc.business.model.WsThisProgcommarea
 * <br></p>
 * 
 * <p>About 'wsCommarea' field, <br>uml entity: com.company.app.cocrdupc.business.model.WsCommarea
 * <br></p>
 * 
 * <p>About 'dfhbmsca' field, <br>uml entity: com.company.app.cocrdupc.business.model.Dfhbmsca
 * <br></p>
 * 
 * <p>About 'dfhaid' field, <br>uml entity: com.company.app.cocrdupc.business.model.Dfhaid
 * <br></p>
 * 
 * <p>About 'dfheiblk' field, <br>uml entity: com.company.app.cocrdupc.business.model.Dfheiblk
 * <br></p>
 * 
 * <p>About 'dfhcommarea' field, <br>uml entity: com.company.app.cocrdupc.business.model.Dfhcommarea
 * <br></p>
 * 
 */
@Component("com.company.app.cocrdupc.business.context.CocrdupcContext")
@Lazy
@Scope("prototype")
public class CocrdupcContext extends JicsRuntimeContext {
	
	private WsMiscStorage wsMiscStorage;
	private WsLiterals wsLiterals;
	private WsThisProgcommarea wsThisProgcommarea;
	private WsCommarea wsCommarea;
	private Dfhbmsca dfhbmsca;
	private Dfhaid dfhaid;
	private Dfheiblk dfheiblk;
	private Dfhcommarea dfhcommarea;

	private List<RecordEntity> recordEntities;

	/**
	 * Default constructor.
	 * @param configuration the datasimplifier configuration
	 */
	public CocrdupcContext (@Qualifier("CocrdupcContextConfiguration") Configuration configuration) {
		super(configuration);
		initWorking(configuration);
		initLinkage(configuration);
		initRecordEntities();
	}
	
	/**
	 * Add count holders:
	 * 
	 * Once all entities/files have been initialized, bind the
	 * elementary references that act as count holder for 
	 * variable size arrays.
	 */
	@PostConstruct
	public void addCountHolders(){
		dfhcommarea.setTableCountHolder(dfheiblk.getEibcalenReference());
	}
	

	/**
	 * Getter for wsMiscStorage.
	 * @return the wsMiscStorage
	 */
	public WsMiscStorage getWsMiscStorage() {
		return this.wsMiscStorage;
	}

	/**
	 * Setter for wsMiscStorage.
	 * @param reference the new value for wsMiscStorage
	 */
	public void setWsMiscStorage(RangeReference reference) {
		this.wsMiscStorage.setBytes(reference.getBytes());
	}

	/**
	 * Getter for wsLiterals.
	 * @return the wsLiterals
	 */
	public WsLiterals getWsLiterals() {
		return this.wsLiterals;
	}

	/**
	 * Setter for wsLiterals.
	 * @param reference the new value for wsLiterals
	 */
	public void setWsLiterals(RangeReference reference) {
		this.wsLiterals.setBytes(reference.getBytes());
	}

	/**
	 * Getter for wsThisProgcommarea.
	 * @return the wsThisProgcommarea
	 */
	public WsThisProgcommarea getWsThisProgcommarea() {
		return this.wsThisProgcommarea;
	}

	/**
	 * Setter for wsThisProgcommarea.
	 * @param reference the new value for wsThisProgcommarea
	 */
	public void setWsThisProgcommarea(RangeReference reference) {
		this.wsThisProgcommarea.setBytes(reference.getBytes());
	}

	/**
	 * Getter for wsCommarea.
	 * @return the wsCommarea
	 */
	public WsCommarea getWsCommarea() {
		return this.wsCommarea;
	}

	/**
	 * Setter for wsCommarea.
	 * @param reference the new value for wsCommarea
	 */
	public void setWsCommarea(RangeReference reference) {
		this.wsCommarea.setBytes(reference.getBytes());
	}

	/**
	 * Getter for dfhbmsca.
	 * @return the dfhbmsca
	 */
	public Dfhbmsca getDfhbmsca() {
		return this.dfhbmsca;
	}

	/**
	 * Setter for dfhbmsca.
	 * @param reference the new value for dfhbmsca
	 */
	public void setDfhbmsca(RangeReference reference) {
		this.dfhbmsca.setBytes(reference.getBytes());
	}

	/**
	 * Getter for dfhaid.
	 * @return the dfhaid
	 */
	public Dfhaid getDfhaid() {
		return this.dfhaid;
	}

	/**
	 * Setter for dfhaid.
	 * @param reference the new value for dfhaid
	 */
	public void setDfhaid(RangeReference reference) {
		this.dfhaid.setBytes(reference.getBytes());
	}

	/**
	 * Getter for dfheiblk.
	 * @return the dfheiblk
	 */
	public Dfheiblk getDfheiblk() {
		return this.dfheiblk;
	}

	/**
	 * Setter for dfheiblk.
	 * @param reference the new value for dfheiblk
	 */
	public void setDfheiblk(RangeReference reference) {
		this.dfheiblk.setBytes(reference.getBytes());
	}

	/**
	 * Getter for dfhcommarea.
	 * @return the dfhcommarea
	 */
	public Dfhcommarea getDfhcommarea() {
		return this.dfhcommarea;
	}

	/**
	 * Setter for dfhcommarea.
	 * @param reference the new value for dfhcommarea
	 */
	public void setDfhcommarea(RangeReference reference) {
		this.dfhcommarea.setBytes(reference.getBytes());
	}

	/**
	 * Getter for Jics Exec Interface Block.
	 * @return the Jics Exec Interface Block
	 */
	public Dfheiblk getJicsEiblk() {
		return this.dfheiblk;
	}

	@Override 
	public void cleanUp(){
	}

	@Override
	protected void doReset() {
		cleanUp();
	    // reset the working
		recordEntities.stream().forEach(e -> e.reset());
	}

	
	private void initWorking(Configuration configuration) {
		wsMiscStorage = new WsMiscStorage(configuration);
		wsLiterals = new WsLiterals(configuration);
		wsThisProgcommarea = new WsThisProgcommarea(configuration);
		wsCommarea = new WsCommarea(configuration);
		dfhbmsca = new Dfhbmsca(configuration);
		dfhaid = new Dfhaid(configuration);
	}
	
	private void initLinkage(Configuration configuration) {
		dfheiblk = new Dfheiblk(configuration, EntityUtils.getUnlinkedRecord());
		dfhcommarea = new Dfhcommarea(configuration, EntityUtils.getUnlinkedRecord());
	
	}

	private void initRecordEntities() {
		recordEntities = Arrays.asList(wsMiscStorage, wsLiterals, wsThisProgcommarea, wsCommarea, dfhbmsca, dfhaid);
	}

	@Override
	public String toString(){
		StringBuilder toSB = new StringBuilder("\nCocrdupcContext:\n");
		if(!this.recordEntities.isEmpty()){
			this.recordEntities.forEach(e -> toSB.append(e.getClass().getSimpleName()).append(" : [").append(e.toString()).append("]\n"));
		}
		toSB.append("Dfheiblk : [").append(dfheiblk.toString()).append("]\n");
		toSB.append("Dfhcommarea : [").append(dfhcommarea.toString()).append("]\n");
		return toSB.toString();
	}

}
