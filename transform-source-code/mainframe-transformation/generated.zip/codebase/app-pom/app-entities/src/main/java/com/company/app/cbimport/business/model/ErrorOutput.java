package com.company.app.cbimport.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Data simplifier file ErrorOutput.
 * 
 * <p>About 'errorOutputRecord' field, <br>uml entity: com.company.app.cbimport.business.model.ErrorOutputRecord
 * <br></p>
 * 
 */
@Component("com.company.app.cbimport.business.model.ErrorOutput")
@Lazy
@Scope("prototype")
public class ErrorOutput extends RecordEntity {

	private final Group root = new Group(getData());
	private final Elementary errorOutputRecord = new Elementary(root,new AlphanumericType(132));
	 
	/**
	 * Instantiate a new ErrorOutput.
	 * @param configuration the configuration
	 */
	public ErrorOutput(@Qualifier("CbimportContextConfiguration") Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}
 
	/**
	 * Gets the reference for attribute errorOutputRecord.
	 * @return the errorOutputRecord attribute reference
	 */
	public ElementaryRangeReference getErrorOutputRecordReference() {
		return errorOutputRecord.getReference();
	}

	/**
	 * Getter for errorOutputRecord attribute.
	 * @return errorOutputRecord attribute
	 */
	public String getErrorOutputRecord() {
		return errorOutputRecord.getValue();
	}

	/**
	 * Setter for errorOutputRecord attribute.
	 * @param errorOutputRecord the new value of errorOutputRecord
	 */
	public void setErrorOutputRecord(String errorOutputRecord) {
		this.errorOutputRecord.setValue(errorOutputRecord);
	}
}
