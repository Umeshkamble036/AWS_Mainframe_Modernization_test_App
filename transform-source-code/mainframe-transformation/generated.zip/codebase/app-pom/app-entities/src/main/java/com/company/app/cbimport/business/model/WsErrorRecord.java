package com.company.app.cbimport.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Filler;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.ZonedType;
/**
 * Data simplifier entity WsErrorRecord.
<pre>
 * 
 * Legacy Documentation:<br>
 *   Error Record Layout<br>
</pre>
 * 
 * <p>About 'errTimestamp' field, <br>
 * </p>
 * 
 * <p>About 'errRecordType' field, <br>
 * </p>
 * 
 * <p>About 'errSequence' field, <br>
 * </p>
 * 
 * <p>About 'errMessage' field, <br>
 * </p>
 * 
 * @see RecordEntity
 */
public class WsErrorRecord extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Elementary errTimestamp = new Elementary(root,new AlphanumericType(26));
	@SuppressWarnings("unused")
	private final Filler filler = new Filler(root,new AlphanumericType(1),"|");
	private final Elementary errRecordType = new Elementary(root,new AlphanumericType(1));
	@SuppressWarnings("unused")
	private final Filler filler1 = new Filler(root,new AlphanumericType(1),"|");
	private final Elementary errSequence = new Elementary(root,new ZonedType(7, 0, false));
	@SuppressWarnings("unused")
	private final Filler filler2 = new Filler(root,new AlphanumericType(1),"|");
	private final Elementary errMessage = new Elementary(root,new AlphanumericType(50));
	@SuppressWarnings("unused")
	private final Filler filler3 = new Filler(root,new AlphanumericType(43)," ");
	
	/**
	 * Instantiate a new WsErrorRecord with a default record.
	 * @param configuration the configuration
	 */
	public WsErrorRecord(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new WsErrorRecord bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public WsErrorRecord(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	/**
	 * Gets the reference for attribute errTimestamp.
	 * @return the errTimestamp attribute reference
	 */
	public ElementaryRangeReference getErrTimestampReference() {
		return errTimestamp.getReference();
	}

	/**
	 * Getter for errTimestamp attribute.
	 * @return errTimestamp attribute
	 */
	public String getErrTimestamp() {
		return errTimestamp.getValue();
	}

	/**
	 * Setter for errTimestamp attribute.
	 * @param errTimestamp the new value of errTimestamp
	 */
	public void setErrTimestamp(String errTimestamp) {
		this.errTimestamp.setValue(errTimestamp);
	}
	/**
	 * Gets the reference for attribute errRecordType.
	 * @return the errRecordType attribute reference
	 */
	public ElementaryRangeReference getErrRecordTypeReference() {
		return errRecordType.getReference();
	}

	/**
	 * Getter for errRecordType attribute.
	 * @return errRecordType attribute
	 */
	public String getErrRecordType() {
		return errRecordType.getValue();
	}

	/**
	 * Setter for errRecordType attribute.
	 * @param errRecordType the new value of errRecordType
	 */
	public void setErrRecordType(String errRecordType) {
		this.errRecordType.setValue(errRecordType);
	}
	/**
	 * Gets the reference for attribute errSequence.
	 * @return the errSequence attribute reference
	 */
	public ElementaryRangeReference getErrSequenceReference() {
		return errSequence.getReference();
	}

	/**
	 * Getter for errSequence attribute.
	 * @return errSequence attribute
	 */
	public int getErrSequence() {
		return errSequence.getValue();
	}

	/**
	 * Setter for errSequence attribute.
	 * @param errSequence the new value of errSequence
	 */
	public void setErrSequence(int errSequence) {
		this.errSequence.setValue(errSequence);
	}
	/**
	 * Gets the reference for attribute errMessage.
	 * @return the errMessage attribute reference
	 */
	public ElementaryRangeReference getErrMessageReference() {
		return errMessage.getReference();
	}

	/**
	 * Getter for errMessage attribute.
	 * @return errMessage attribute
	 */
	public String getErrMessage() {
		return errMessage.getValue();
	}

	/**
	 * Setter for errMessage attribute.
	 * @param errMessage the new value of errMessage
	 */
	public void setErrMessage(String errMessage) {
		this.errMessage.setValue(errMessage);
	}
}
