package com.company.app.cotrtupc.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
/**
 * Data simplifier entity WsLiterals.
<pre>
 * 
 * Legacy Documentation:<br>
 *  ****************************************************************<br>
 *        Literals and Constants<br>
 *  ****************************************************************<br>
</pre>
 * 
 * <p>About 'litThispgm' field, <br>
 * </p>
 * 
 * <p>About 'litThistranid' field, <br>
 * </p>
 * 
 * <p>About 'litThismapset' field, <br>
 * </p>
 * 
 * <p>About 'litThismap' field, <br>
 * </p>
 * 
 * <p>About 'litAdminpgm' field, <br>
 * </p>
 * 
 * <p>About 'litAdmintranid' field, <br>
 * </p>
 * 
 * <p>About 'litAdminmapset' field, <br>
 * </p>
 * 
 * <p>About 'litAdminmap' field, <br>
 * </p>
 * 
 * <p>About 'litListtpgm' field, <br>
 * </p>
 * 
 * <p>About 'litListttranid' field, <br>
 * </p>
 * 
 * <p>About 'litListtmapset' field, <br>
 * </p>
 * 
 * <p>About 'litListtmap' field, <br>
 * </p>
 * 
 * <p>About 'litAllAlphanumFromX' field, <br>uml entity: com.company.app.cotrtupc.business.model.LitAllAlphanumFromX
 * <br></p>
 * 
 * @see RecordEntity
 */
public class WsLiterals extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Elementary litThispgm = new Elementary(root,new AlphanumericType(8),"COTRTUPC");
	private final Elementary litThistranid = new Elementary(root,new AlphanumericType(4),"CTTU");
	private final Elementary litThismapset = new Elementary(root,new AlphanumericType(8),"COTRTUP ");
	private final Elementary litThismap = new Elementary(root,new AlphanumericType(7),"CTRTUPA");
	private final Elementary litAdminpgm = new Elementary(root,new AlphanumericType(8),"COADM01C");
	private final Elementary litAdmintranid = new Elementary(root,new AlphanumericType(4),"CA00");
	private final Elementary litAdminmapset = new Elementary(root,new AlphanumericType(7),"COADM01");
	private final Elementary litAdminmap = new Elementary(root,new AlphanumericType(7),"COADM1A");
	private final Elementary litListtpgm = new Elementary(root,new AlphanumericType(8),"COTRTLIC");
	private final Elementary litListttranid = new Elementary(root,new AlphanumericType(4),"CTLI");
	private final Elementary litListtmapset = new Elementary(root,new AlphanumericType(7),"COTRTLI");
	private final Elementary litListtmap = new Elementary(root,new AlphanumericType(7),"CTRTLIA");
	
	/**
	 * ****************************************************************
	 * Literals for use in INSPECT statements
	 * ****************************************************************
	 */
	private final Group litAllAlphanumFromX = new Group(root);
	private final Group litAllAlphaFromX = new Group(litAllAlphanumFromX);
	private final Elementary litUpper = new Elementary(litAllAlphaFromX,new AlphanumericType(26),"ABCDEFGHIJKLMNOPQRSTUVWXYZ");
	private final Elementary litLower = new Elementary(litAllAlphaFromX,new AlphanumericType(26),"abcdefghijklmnopqrstuvwxyz");
	private final Elementary litNumbers = new Elementary(litAllAlphanumFromX,new AlphanumericType(10),"0123456789");
	
	/**
	 * Instantiate a new WsLiterals with a default record.
	 * @param configuration the configuration
	 */
	public WsLiterals(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new WsLiterals bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public WsLiterals(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	/**
	 * Gets the reference for attribute litThispgm.
	 * @return the litThispgm attribute reference
	 */
	public ElementaryRangeReference getLitThispgmReference() {
		return litThispgm.getReference();
	}

	/**
	 * Getter for litThispgm attribute.
	 * @return litThispgm attribute
	 */
	public String getLitThispgm() {
		return litThispgm.getValue();
	}

	/**
	 * Setter for litThispgm attribute.
	 * @param litThispgm the new value of litThispgm
	 */
	public void setLitThispgm(String litThispgm) {
		this.litThispgm.setValue(litThispgm);
	}
	/**
	 * Gets the reference for attribute litThistranid.
	 * @return the litThistranid attribute reference
	 */
	public ElementaryRangeReference getLitThistranidReference() {
		return litThistranid.getReference();
	}

	/**
	 * Getter for litThistranid attribute.
	 * @return litThistranid attribute
	 */
	public String getLitThistranid() {
		return litThistranid.getValue();
	}

	/**
	 * Setter for litThistranid attribute.
	 * @param litThistranid the new value of litThistranid
	 */
	public void setLitThistranid(String litThistranid) {
		this.litThistranid.setValue(litThistranid);
	}
	/**
	 * Gets the reference for attribute litThismapset.
	 * @return the litThismapset attribute reference
	 */
	public ElementaryRangeReference getLitThismapsetReference() {
		return litThismapset.getReference();
	}

	/**
	 * Getter for litThismapset attribute.
	 * @return litThismapset attribute
	 */
	public String getLitThismapset() {
		return litThismapset.getValue();
	}

	/**
	 * Setter for litThismapset attribute.
	 * @param litThismapset the new value of litThismapset
	 */
	public void setLitThismapset(String litThismapset) {
		this.litThismapset.setValue(litThismapset);
	}
	/**
	 * Gets the reference for attribute litThismap.
	 * @return the litThismap attribute reference
	 */
	public ElementaryRangeReference getLitThismapReference() {
		return litThismap.getReference();
	}

	/**
	 * Getter for litThismap attribute.
	 * @return litThismap attribute
	 */
	public String getLitThismap() {
		return litThismap.getValue();
	}

	/**
	 * Setter for litThismap attribute.
	 * @param litThismap the new value of litThismap
	 */
	public void setLitThismap(String litThismap) {
		this.litThismap.setValue(litThismap);
	}
	/**
	 * Gets the reference for attribute litAdminpgm.
	 * @return the litAdminpgm attribute reference
	 */
	public ElementaryRangeReference getLitAdminpgmReference() {
		return litAdminpgm.getReference();
	}

	/**
	 * Getter for litAdminpgm attribute.
	 * @return litAdminpgm attribute
	 */
	public String getLitAdminpgm() {
		return litAdminpgm.getValue();
	}

	/**
	 * Setter for litAdminpgm attribute.
	 * @param litAdminpgm the new value of litAdminpgm
	 */
	public void setLitAdminpgm(String litAdminpgm) {
		this.litAdminpgm.setValue(litAdminpgm);
	}
	/**
	 * Gets the reference for attribute litAdmintranid.
	 * @return the litAdmintranid attribute reference
	 */
	public ElementaryRangeReference getLitAdmintranidReference() {
		return litAdmintranid.getReference();
	}

	/**
	 * Getter for litAdmintranid attribute.
	 * @return litAdmintranid attribute
	 */
	public String getLitAdmintranid() {
		return litAdmintranid.getValue();
	}

	/**
	 * Setter for litAdmintranid attribute.
	 * @param litAdmintranid the new value of litAdmintranid
	 */
	public void setLitAdmintranid(String litAdmintranid) {
		this.litAdmintranid.setValue(litAdmintranid);
	}
	/**
	 * Gets the reference for attribute litAdminmapset.
	 * @return the litAdminmapset attribute reference
	 */
	public ElementaryRangeReference getLitAdminmapsetReference() {
		return litAdminmapset.getReference();
	}

	/**
	 * Getter for litAdminmapset attribute.
	 * @return litAdminmapset attribute
	 */
	public String getLitAdminmapset() {
		return litAdminmapset.getValue();
	}

	/**
	 * Setter for litAdminmapset attribute.
	 * @param litAdminmapset the new value of litAdminmapset
	 */
	public void setLitAdminmapset(String litAdminmapset) {
		this.litAdminmapset.setValue(litAdminmapset);
	}
	/**
	 * Gets the reference for attribute litAdminmap.
	 * @return the litAdminmap attribute reference
	 */
	public ElementaryRangeReference getLitAdminmapReference() {
		return litAdminmap.getReference();
	}

	/**
	 * Getter for litAdminmap attribute.
	 * @return litAdminmap attribute
	 */
	public String getLitAdminmap() {
		return litAdminmap.getValue();
	}

	/**
	 * Setter for litAdminmap attribute.
	 * @param litAdminmap the new value of litAdminmap
	 */
	public void setLitAdminmap(String litAdminmap) {
		this.litAdminmap.setValue(litAdminmap);
	}
	/**
	 * Gets the reference for attribute litListtpgm.
	 * @return the litListtpgm attribute reference
	 */
	public ElementaryRangeReference getLitListtpgmReference() {
		return litListtpgm.getReference();
	}

	/**
	 * Getter for litListtpgm attribute.
	 * @return litListtpgm attribute
	 */
	public String getLitListtpgm() {
		return litListtpgm.getValue();
	}

	/**
	 * Setter for litListtpgm attribute.
	 * @param litListtpgm the new value of litListtpgm
	 */
	public void setLitListtpgm(String litListtpgm) {
		this.litListtpgm.setValue(litListtpgm);
	}
	/**
	 * Gets the reference for attribute litListttranid.
	 * @return the litListttranid attribute reference
	 */
	public ElementaryRangeReference getLitListttranidReference() {
		return litListttranid.getReference();
	}

	/**
	 * Getter for litListttranid attribute.
	 * @return litListttranid attribute
	 */
	public String getLitListttranid() {
		return litListttranid.getValue();
	}

	/**
	 * Setter for litListttranid attribute.
	 * @param litListttranid the new value of litListttranid
	 */
	public void setLitListttranid(String litListttranid) {
		this.litListttranid.setValue(litListttranid);
	}
	/**
	 * Gets the reference for attribute litListtmapset.
	 * @return the litListtmapset attribute reference
	 */
	public ElementaryRangeReference getLitListtmapsetReference() {
		return litListtmapset.getReference();
	}

	/**
	 * Getter for litListtmapset attribute.
	 * @return litListtmapset attribute
	 */
	public String getLitListtmapset() {
		return litListtmapset.getValue();
	}

	/**
	 * Setter for litListtmapset attribute.
	 * @param litListtmapset the new value of litListtmapset
	 */
	public void setLitListtmapset(String litListtmapset) {
		this.litListtmapset.setValue(litListtmapset);
	}
	/**
	 * Gets the reference for attribute litListtmap.
	 * @return the litListtmap attribute reference
	 */
	public ElementaryRangeReference getLitListtmapReference() {
		return litListtmap.getReference();
	}

	/**
	 * Getter for litListtmap attribute.
	 * @return litListtmap attribute
	 */
	public String getLitListtmap() {
		return litListtmap.getValue();
	}

	/**
	 * Setter for litListtmap attribute.
	 * @param litListtmap the new value of litListtmap
	 */
	public void setLitListtmap(String litListtmap) {
		this.litListtmap.setValue(litListtmap);
	}
	
	/**
	 * Gets the reference for attribute litAllAlphanumFromX.
	 * @return the litAllAlphanumFromX attribute reference
	 */
	public RangeReference getLitAllAlphanumFromXReference() {
		return litAllAlphanumFromX.getReference();
	}	
				
	/**
	 * Setter for litAllAlphanumFromX .
	 */
   	public void setLitAllAlphanumFromX(RangeReference reference) {
       	litAllAlphanumFromX.getReference().setBytes(reference.getBytes());
   	}
 
	
	/**
	 * Gets the reference for attribute litAllAlphaFromX.
	 * @return the litAllAlphaFromX attribute reference
	 */
	public RangeReference getLitAllAlphaFromXReference() {
		return litAllAlphaFromX.getReference();
	}	
				
	/**
	 * Setter for litAllAlphaFromX .
	 */
   	public void setLitAllAlphaFromX(RangeReference reference) {
       	litAllAlphaFromX.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute litUpper.
	 * @return the litUpper attribute reference
	 */
	public ElementaryRangeReference getLitUpperReference() {
		return litUpper.getReference();
	}

	/**
	 * Getter for litUpper attribute.
	 * @return litUpper attribute
	 */
	public String getLitUpper() {
		return litUpper.getValue();
	}

	/**
	 * Setter for litUpper attribute.
	 * @param litUpper the new value of litUpper
	 */
	public void setLitUpper(String litUpper) {
		this.litUpper.setValue(litUpper);
	}
	/**
	 * Gets the reference for attribute litLower.
	 * @return the litLower attribute reference
	 */
	public ElementaryRangeReference getLitLowerReference() {
		return litLower.getReference();
	}

	/**
	 * Getter for litLower attribute.
	 * @return litLower attribute
	 */
	public String getLitLower() {
		return litLower.getValue();
	}

	/**
	 * Setter for litLower attribute.
	 * @param litLower the new value of litLower
	 */
	public void setLitLower(String litLower) {
		this.litLower.setValue(litLower);
	}
	/**
	 * Gets the reference for attribute litNumbers.
	 * @return the litNumbers attribute reference
	 */
	public ElementaryRangeReference getLitNumbersReference() {
		return litNumbers.getReference();
	}

	/**
	 * Getter for litNumbers attribute.
	 * @return litNumbers attribute
	 */
	public String getLitNumbers() {
		return litNumbers.getValue();
	}

	/**
	 * Setter for litNumbers attribute.
	 * @param litNumbers the new value of litNumbers
	 */
	public void setLitNumbers(String litNumbers) {
		this.litNumbers.setValue(litNumbers);
	}
}
