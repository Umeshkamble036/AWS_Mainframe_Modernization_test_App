package com.company.app.cobtupdt.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
/**
 * Data simplifier entity WsInputRec.
 * 
 * <p>About 'inputRecType' field, <br>
 * </p>
 * 
 * <p>About 'inputRecNumber' field, <br>
 * </p>
 * 
 * <p>About 'inputRecDesc' field, <br>
 * </p>
 * 
 * @see RecordEntity
 */
public class WsInputRec extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Elementary inputRecType = new Elementary(root,new AlphanumericType(1)," ");
	private final Elementary inputRecNumber = new Elementary(root,new AlphanumericType(2)," ");
	private final Elementary inputRecDesc = new Elementary(root,new AlphanumericType(50)," ");
	
	/**
	 * Instantiate a new WsInputRec with a default record.
	 * @param configuration the configuration
	 */
	public WsInputRec(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new WsInputRec bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public WsInputRec(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	/**
	 * Gets the reference for attribute inputRecType.
	 * @return the inputRecType attribute reference
	 */
	public ElementaryRangeReference getInputRecTypeReference() {
		return inputRecType.getReference();
	}

	/**
	 * Getter for inputRecType attribute.
	 * @return inputRecType attribute
	 */
	public String getInputRecType() {
		return inputRecType.getValue();
	}

	/**
	 * Setter for inputRecType attribute.
	 * @param inputRecType the new value of inputRecType
	 */
	public void setInputRecType(String inputRecType) {
		this.inputRecType.setValue(inputRecType);
	}
	/**
	 * Gets the reference for attribute inputRecNumber.
	 * @return the inputRecNumber attribute reference
	 */
	public ElementaryRangeReference getInputRecNumberReference() {
		return inputRecNumber.getReference();
	}

	/**
	 * Getter for inputRecNumber attribute.
	 * @return inputRecNumber attribute
	 */
	public String getInputRecNumber() {
		return inputRecNumber.getValue();
	}

	/**
	 * Setter for inputRecNumber attribute.
	 * @param inputRecNumber the new value of inputRecNumber
	 */
	public void setInputRecNumber(String inputRecNumber) {
		this.inputRecNumber.setValue(inputRecNumber);
	}
	/**
	 * Gets the reference for attribute inputRecDesc.
	 * @return the inputRecDesc attribute reference
	 */
	public ElementaryRangeReference getInputRecDescReference() {
		return inputRecDesc.getReference();
	}

	/**
	 * Getter for inputRecDesc attribute.
	 * @return inputRecDesc attribute
	 */
	public String getInputRecDesc() {
		return inputRecDesc.getValue();
	}

	/**
	 * Setter for inputRecDesc attribute.
	 * @param inputRecDesc the new value of inputRecDesc
	 */
	public void setInputRecDesc(String inputRecDesc) {
		this.inputRecDesc.setValue(inputRecDesc);
	}
}
