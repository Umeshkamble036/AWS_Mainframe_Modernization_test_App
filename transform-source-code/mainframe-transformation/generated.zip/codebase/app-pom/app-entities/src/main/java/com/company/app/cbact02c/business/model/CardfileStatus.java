package com.company.app.cbact02c.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
/**
 * Data simplifier entity CardfileStatus.
<pre>
 * 
 * Legacy Documentation:<br>
 *  ****************************************************************<br>
</pre>
 * 
 * <p>About 'cardfileStat1' field, <br>
 * </p>
 * 
 * <p>About 'cardfileStat2' field, <br>
 * </p>
 * 
 * @see RecordEntity
 */
public class CardfileStatus extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Elementary cardfileStat1 = new Elementary(root,new AlphanumericType(1));
	private final Elementary cardfileStat2 = new Elementary(root,new AlphanumericType(1));
	
	/**
	 * Instantiate a new CardfileStatus with a default record.
	 * @param configuration the configuration
	 */
	public CardfileStatus(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new CardfileStatus bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public CardfileStatus(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	/**
	 * Gets the reference for attribute cardfileStat1.
	 * @return the cardfileStat1 attribute reference
	 */
	public ElementaryRangeReference getCardfileStat1Reference() {
		return cardfileStat1.getReference();
	}

	/**
	 * Getter for cardfileStat1 attribute.
	 * @return cardfileStat1 attribute
	 */
	public String getCardfileStat1() {
		return cardfileStat1.getValue();
	}

	/**
	 * Setter for cardfileStat1 attribute.
	 * @param cardfileStat1 the new value of cardfileStat1
	 */
	public void setCardfileStat1(String cardfileStat1) {
		this.cardfileStat1.setValue(cardfileStat1);
	}
	/**
	 * Gets the reference for attribute cardfileStat2.
	 * @return the cardfileStat2 attribute reference
	 */
	public ElementaryRangeReference getCardfileStat2Reference() {
		return cardfileStat2.getReference();
	}

	/**
	 * Getter for cardfileStat2 attribute.
	 * @return cardfileStat2 attribute
	 */
	public String getCardfileStat2() {
		return cardfileStat2.getValue();
	}

	/**
	 * Setter for cardfileStat2 attribute.
	 * @param cardfileStat2 the new value of cardfileStat2
	 */
	public void setCardfileStat2(String cardfileStat2) {
		this.cardfileStat2.setValue(cardfileStat2);
	}
}
