package com.company.app.cousr00c.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Filler;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.FixedArray;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ConditionReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.ConditionName;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.ZonedType;
/**
 * Data simplifier entity WsUserData.
 * 
 * <p>About 'userRec' field, <br>uml entity: com.company.app.cousr00c.business.model.userRec
 * <br></p>
 * 
 * @see RecordEntity
 */
public class WsUserData extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Group userRec = new Group(root,new FixedArray(10));
	private final Elementary userSel = new Elementary(userRec,new AlphanumericType(1));
	@SuppressWarnings("unused")
	private final Filler filler = new Filler(userRec,new AlphanumericType(2));
	private final Elementary userId = new Elementary(userRec,new AlphanumericType(8));
	@SuppressWarnings("unused")
	private final Filler filler1 = new Filler(userRec,new AlphanumericType(2));
	private final Elementary userName = new Elementary(userRec,new AlphanumericType(25));
	@SuppressWarnings("unused")
	private final Filler filler2 = new Filler(userRec,new AlphanumericType(2));
	private final Elementary userType = new Elementary(userRec,new AlphanumericType(8));
	private final Group cdemoCu00Info = new Group(userRec);
	private final Elementary cdemoCu00UsridFirst = new Elementary(cdemoCu00Info,new AlphanumericType(8));
	private final Elementary cdemoCu00UsridLast = new Elementary(cdemoCu00Info,new AlphanumericType(8));
	private final Elementary cdemoCu00PageNum = new Elementary(cdemoCu00Info,new ZonedType(8, 0, false));
	private final Elementary cdemoCu00NextPageFlg = new Elementary(cdemoCu00Info,new AlphanumericType(1),"N");
	private final ConditionName nextPageYes=new ConditionName(cdemoCu00NextPageFlg,"Y");
	private final ConditionName nextPageNo=new ConditionName(cdemoCu00NextPageFlg,"N");
	private final Elementary cdemoCu00UsrSelFlg = new Elementary(cdemoCu00Info,new AlphanumericType(1));
	private final Elementary cdemoCu00UsrSelected = new Elementary(cdemoCu00Info,new AlphanumericType(8));
	
	/**
	 * Instantiate a new WsUserData with a default record.
	 * @param configuration the configuration
	 */
	public WsUserData(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new WsUserData bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public WsUserData(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	/**
	 * Indexed getter for group userRec attribute.
	 * @param indexes the indexes
	 * @return userRec attribute
	 */
	public RangeReference getItemFromUserRecReference(Integer... indexes){
		return userRec.getIndexedReference(indexes);
	}
	
	/**
	 * Indexed setter for group userRec attribute.
	 * @param RangeReference rangeReference to copy bytes from.
	 * @param indexes the indexes
	 */
	public void setItemFromUserRec( RangeReference rangeReference, Integer... indexes){
		userRec.getIndexedReference(indexes).setBytes(rangeReference.getBytes());
	}

	/**
	 * Collection size getter for group userRec attribute.
	 * @return  the collection size for attribute userRec
	 */
	public int getUserRecSize(){	
		return userRec.getRepetition().getCount();
	}	
	
	/**
	 * Gets the reference for attribute userRec.
	 * @return the userRec attribute reference
	 */
	public RangeReference getUserRecReference() {
		return userRec.getReference();
	}			
	
	/**
	 * Indexed getter for userSel attribute.
	 * @param indexes the indexes
	 * @return userSel attribute
	 */
	public ElementaryRangeReference getItemFromUserSelReference(Integer... indexes) {
		return userSel.getIndexedReference(indexes);
	}
	
	/**
	 * Indexed getter for userSel attribute.
	 * @param indexes the indexes
	 * @return userSel attribute
	 */
	public String getItemFromUserSel(Integer... indexes) {
		return userSel.getIndexedValue(indexes);
	}
	
	/**
	 * Indexed setter for userSel attribute.
	 * @param userSel the new value of userSel for given indexes
	 * @param indexes the indexes
	 */
	public void setItemFromUserSel(String userSel,Integer... indexes) {
		this.userSel.setIndexedValue(userSel,indexes);
	}
	
	/**
	 * Collection size getter for userSel attribute.
	 * @return  the collection size for attributeuserSel
	 */
	public int getUserSelSize(){
		return userSel.getRepetition().getCount();
	}
	
	/**
	 * Indexed getter for userSel attribute.
	 * @param indexes the indexes
	 * @return userSel attribute
	 */
	public ElementaryRangeReference getUserSelReference() {
		return userSel.getReference();
	}
	
	/**
	 * Indexed getter for userSel attribute.
	 * @param indexes the indexes
	 * @return userSel attribute
	 */
	public String getUserSel() {
		return userSel.getValue();
	}
	
	/**
	 * Indexed setter for userSel attribute.
	 * @param userSel the new value of userSel for given indexes
	 * @param indexes the indexes
	 */
	public void setUserSel(String userSel) {
		this.userSel.setValue(userSel);
	}
	
	/**
	 * Indexed getter for userId attribute.
	 * @param indexes the indexes
	 * @return userId attribute
	 */
	public ElementaryRangeReference getItemFromUserIdReference(Integer... indexes) {
		return userId.getIndexedReference(indexes);
	}
	
	/**
	 * Indexed getter for userId attribute.
	 * @param indexes the indexes
	 * @return userId attribute
	 */
	public String getItemFromUserId(Integer... indexes) {
		return userId.getIndexedValue(indexes);
	}
	
	/**
	 * Indexed setter for userId attribute.
	 * @param userId the new value of userId for given indexes
	 * @param indexes the indexes
	 */
	public void setItemFromUserId(String userId,Integer... indexes) {
		this.userId.setIndexedValue(userId,indexes);
	}
	
	/**
	 * Collection size getter for userId attribute.
	 * @return  the collection size for attributeuserId
	 */
	public int getUserIdSize(){
		return userId.getRepetition().getCount();
	}
	
	/**
	 * Indexed getter for userId attribute.
	 * @param indexes the indexes
	 * @return userId attribute
	 */
	public ElementaryRangeReference getUserIdReference() {
		return userId.getReference();
	}
	
	/**
	 * Indexed getter for userId attribute.
	 * @param indexes the indexes
	 * @return userId attribute
	 */
	public String getUserId() {
		return userId.getValue();
	}
	
	/**
	 * Indexed setter for userId attribute.
	 * @param userId the new value of userId for given indexes
	 * @param indexes the indexes
	 */
	public void setUserId(String userId) {
		this.userId.setValue(userId);
	}
	
	/**
	 * Indexed getter for userName attribute.
	 * @param indexes the indexes
	 * @return userName attribute
	 */
	public ElementaryRangeReference getItemFromUserNameReference(Integer... indexes) {
		return userName.getIndexedReference(indexes);
	}
	
	/**
	 * Indexed getter for userName attribute.
	 * @param indexes the indexes
	 * @return userName attribute
	 */
	public String getItemFromUserName(Integer... indexes) {
		return userName.getIndexedValue(indexes);
	}
	
	/**
	 * Indexed setter for userName attribute.
	 * @param userName the new value of userName for given indexes
	 * @param indexes the indexes
	 */
	public void setItemFromUserName(String userName,Integer... indexes) {
		this.userName.setIndexedValue(userName,indexes);
	}
	
	/**
	 * Collection size getter for userName attribute.
	 * @return  the collection size for attributeuserName
	 */
	public int getUserNameSize(){
		return userName.getRepetition().getCount();
	}
	
	/**
	 * Indexed getter for userName attribute.
	 * @param indexes the indexes
	 * @return userName attribute
	 */
	public ElementaryRangeReference getUserNameReference() {
		return userName.getReference();
	}
	
	/**
	 * Indexed getter for userName attribute.
	 * @param indexes the indexes
	 * @return userName attribute
	 */
	public String getUserName() {
		return userName.getValue();
	}
	
	/**
	 * Indexed setter for userName attribute.
	 * @param userName the new value of userName for given indexes
	 * @param indexes the indexes
	 */
	public void setUserName(String userName) {
		this.userName.setValue(userName);
	}
	
	/**
	 * Indexed getter for userType attribute.
	 * @param indexes the indexes
	 * @return userType attribute
	 */
	public ElementaryRangeReference getItemFromUserTypeReference(Integer... indexes) {
		return userType.getIndexedReference(indexes);
	}
	
	/**
	 * Indexed getter for userType attribute.
	 * @param indexes the indexes
	 * @return userType attribute
	 */
	public String getItemFromUserType(Integer... indexes) {
		return userType.getIndexedValue(indexes);
	}
	
	/**
	 * Indexed setter for userType attribute.
	 * @param userType the new value of userType for given indexes
	 * @param indexes the indexes
	 */
	public void setItemFromUserType(String userType,Integer... indexes) {
		this.userType.setIndexedValue(userType,indexes);
	}
	
	/**
	 * Collection size getter for userType attribute.
	 * @return  the collection size for attributeuserType
	 */
	public int getUserTypeSize(){
		return userType.getRepetition().getCount();
	}
	
	/**
	 * Indexed getter for userType attribute.
	 * @param indexes the indexes
	 * @return userType attribute
	 */
	public ElementaryRangeReference getUserTypeReference() {
		return userType.getReference();
	}
	
	/**
	 * Indexed getter for userType attribute.
	 * @param indexes the indexes
	 * @return userType attribute
	 */
	public String getUserType() {
		return userType.getValue();
	}
	
	/**
	 * Indexed setter for userType attribute.
	 * @param userType the new value of userType for given indexes
	 * @param indexes the indexes
	 */
	public void setUserType(String userType) {
		this.userType.setValue(userType);
	}
	
	/**
	 * Indexed getter for group cdemoCu00Info attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00Info attribute
	 */
	public RangeReference getItemFromCdemoCu00InfoReference(Integer... indexes){
		return cdemoCu00Info.getIndexedReference(indexes);
	}
	
	/**
	 * Indexed setter for group cdemoCu00Info attribute.
	 * @param RangeReference rangeReference to copy bytes from.
	 * @param indexes the indexes
	 */
	public void setItemFromCdemoCu00Info( RangeReference rangeReference, Integer... indexes){
		cdemoCu00Info.getIndexedReference(indexes).setBytes(rangeReference.getBytes());
	}

	/**
	 * Collection size getter for group cdemoCu00Info attribute.
	 * @return  the collection size for attribute cdemoCu00Info
	 */
	public int getCdemoCu00InfoSize(){	
		return cdemoCu00Info.getRepetition().getCount();
	}	
	
	/**
	 * Gets the reference for attribute cdemoCu00Info.
	 * @return the cdemoCu00Info attribute reference
	 */
	public RangeReference getCdemoCu00InfoReference() {
		return cdemoCu00Info.getReference();
	}			
	
	/**
	 * Indexed getter for cdemoCu00UsridFirst attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsridFirst attribute
	 */
	public ElementaryRangeReference getItemFromCdemoCu00UsridFirstReference(Integer... indexes) {
		return cdemoCu00UsridFirst.getIndexedReference(indexes);
	}
	
	/**
	 * Indexed getter for cdemoCu00UsridFirst attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsridFirst attribute
	 */
	public String getItemFromCdemoCu00UsridFirst(Integer... indexes) {
		return cdemoCu00UsridFirst.getIndexedValue(indexes);
	}
	
	/**
	 * Indexed setter for cdemoCu00UsridFirst attribute.
	 * @param cdemoCu00UsridFirst the new value of cdemoCu00UsridFirst for given indexes
	 * @param indexes the indexes
	 */
	public void setItemFromCdemoCu00UsridFirst(String cdemoCu00UsridFirst,Integer... indexes) {
		this.cdemoCu00UsridFirst.setIndexedValue(cdemoCu00UsridFirst,indexes);
	}
	
	/**
	 * Collection size getter for cdemoCu00UsridFirst attribute.
	 * @return  the collection size for attributecdemoCu00UsridFirst
	 */
	public int getCdemoCu00UsridFirstSize(){
		return cdemoCu00UsridFirst.getRepetition().getCount();
	}
	
	/**
	 * Indexed getter for cdemoCu00UsridFirst attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsridFirst attribute
	 */
	public ElementaryRangeReference getCdemoCu00UsridFirstReference() {
		return cdemoCu00UsridFirst.getReference();
	}
	
	/**
	 * Indexed getter for cdemoCu00UsridFirst attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsridFirst attribute
	 */
	public String getCdemoCu00UsridFirst() {
		return cdemoCu00UsridFirst.getValue();
	}
	
	/**
	 * Indexed setter for cdemoCu00UsridFirst attribute.
	 * @param cdemoCu00UsridFirst the new value of cdemoCu00UsridFirst for given indexes
	 * @param indexes the indexes
	 */
	public void setCdemoCu00UsridFirst(String cdemoCu00UsridFirst) {
		this.cdemoCu00UsridFirst.setValue(cdemoCu00UsridFirst);
	}
	
	/**
	 * Indexed getter for cdemoCu00UsridLast attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsridLast attribute
	 */
	public ElementaryRangeReference getItemFromCdemoCu00UsridLastReference(Integer... indexes) {
		return cdemoCu00UsridLast.getIndexedReference(indexes);
	}
	
	/**
	 * Indexed getter for cdemoCu00UsridLast attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsridLast attribute
	 */
	public String getItemFromCdemoCu00UsridLast(Integer... indexes) {
		return cdemoCu00UsridLast.getIndexedValue(indexes);
	}
	
	/**
	 * Indexed setter for cdemoCu00UsridLast attribute.
	 * @param cdemoCu00UsridLast the new value of cdemoCu00UsridLast for given indexes
	 * @param indexes the indexes
	 */
	public void setItemFromCdemoCu00UsridLast(String cdemoCu00UsridLast,Integer... indexes) {
		this.cdemoCu00UsridLast.setIndexedValue(cdemoCu00UsridLast,indexes);
	}
	
	/**
	 * Collection size getter for cdemoCu00UsridLast attribute.
	 * @return  the collection size for attributecdemoCu00UsridLast
	 */
	public int getCdemoCu00UsridLastSize(){
		return cdemoCu00UsridLast.getRepetition().getCount();
	}
	
	/**
	 * Indexed getter for cdemoCu00UsridLast attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsridLast attribute
	 */
	public ElementaryRangeReference getCdemoCu00UsridLastReference() {
		return cdemoCu00UsridLast.getReference();
	}
	
	/**
	 * Indexed getter for cdemoCu00UsridLast attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsridLast attribute
	 */
	public String getCdemoCu00UsridLast() {
		return cdemoCu00UsridLast.getValue();
	}
	
	/**
	 * Indexed setter for cdemoCu00UsridLast attribute.
	 * @param cdemoCu00UsridLast the new value of cdemoCu00UsridLast for given indexes
	 * @param indexes the indexes
	 */
	public void setCdemoCu00UsridLast(String cdemoCu00UsridLast) {
		this.cdemoCu00UsridLast.setValue(cdemoCu00UsridLast);
	}
	
	/**
	 * Indexed getter for cdemoCu00PageNum attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00PageNum attribute
	 */
	public ElementaryRangeReference getItemFromCdemoCu00PageNumReference(Integer... indexes) {
		return cdemoCu00PageNum.getIndexedReference(indexes);
	}
	
	/**
	 * Indexed getter for cdemoCu00PageNum attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00PageNum attribute
	 */
	public int getItemFromCdemoCu00PageNum(Integer... indexes) {
		return cdemoCu00PageNum.getIndexedValue(indexes);
	}
	
	/**
	 * Indexed setter for cdemoCu00PageNum attribute.
	 * @param cdemoCu00PageNum the new value of cdemoCu00PageNum for given indexes
	 * @param indexes the indexes
	 */
	public void setItemFromCdemoCu00PageNum(int cdemoCu00PageNum,Integer... indexes) {
		this.cdemoCu00PageNum.setIndexedValue(cdemoCu00PageNum,indexes);
	}
	
	/**
	 * Collection size getter for cdemoCu00PageNum attribute.
	 * @return  the collection size for attributecdemoCu00PageNum
	 */
	public int getCdemoCu00PageNumSize(){
		return cdemoCu00PageNum.getRepetition().getCount();
	}
	
	/**
	 * Indexed getter for cdemoCu00PageNum attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00PageNum attribute
	 */
	public ElementaryRangeReference getCdemoCu00PageNumReference() {
		return cdemoCu00PageNum.getReference();
	}
	
	/**
	 * Indexed getter for cdemoCu00PageNum attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00PageNum attribute
	 */
	public int getCdemoCu00PageNum() {
		return cdemoCu00PageNum.getValue();
	}
	
	/**
	 * Indexed setter for cdemoCu00PageNum attribute.
	 * @param cdemoCu00PageNum the new value of cdemoCu00PageNum for given indexes
	 * @param indexes the indexes
	 */
	public void setCdemoCu00PageNum(int cdemoCu00PageNum) {
		this.cdemoCu00PageNum.setValue(cdemoCu00PageNum);
	}
	
	/**
	 * Indexed getter for cdemoCu00NextPageFlg attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00NextPageFlg attribute
	 */
	public ElementaryRangeReference getItemFromCdemoCu00NextPageFlgReference(Integer... indexes) {
		return cdemoCu00NextPageFlg.getIndexedReference(indexes);
	}
	
	/**
	 * Indexed getter for cdemoCu00NextPageFlg attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00NextPageFlg attribute
	 */
	public String getItemFromCdemoCu00NextPageFlg(Integer... indexes) {
		return cdemoCu00NextPageFlg.getIndexedValue(indexes);
	}
	
	/**
	 * Indexed setter for cdemoCu00NextPageFlg attribute.
	 * @param cdemoCu00NextPageFlg the new value of cdemoCu00NextPageFlg for given indexes
	 * @param indexes the indexes
	 */
	public void setItemFromCdemoCu00NextPageFlg(String cdemoCu00NextPageFlg,Integer... indexes) {
		this.cdemoCu00NextPageFlg.setIndexedValue(cdemoCu00NextPageFlg,indexes);
	}
	
	/**
	 * Collection size getter for cdemoCu00NextPageFlg attribute.
	 * @return  the collection size for attributecdemoCu00NextPageFlg
	 */
	public int getCdemoCu00NextPageFlgSize(){
		return cdemoCu00NextPageFlg.getRepetition().getCount();
	}
	
	/**
	 * Indexed getter for cdemoCu00NextPageFlg attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00NextPageFlg attribute
	 */
	public ElementaryRangeReference getCdemoCu00NextPageFlgReference() {
		return cdemoCu00NextPageFlg.getReference();
	}
	
	/**
	 * Indexed getter for cdemoCu00NextPageFlg attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00NextPageFlg attribute
	 */
	public String getCdemoCu00NextPageFlg() {
		return cdemoCu00NextPageFlg.getValue();
	}
	
	/**
	 * Indexed setter for cdemoCu00NextPageFlg attribute.
	 * @param cdemoCu00NextPageFlg the new value of cdemoCu00NextPageFlg for given indexes
	 * @param indexes the indexes
	 */
	public void setCdemoCu00NextPageFlg(String cdemoCu00NextPageFlg) {
		this.cdemoCu00NextPageFlg.setValue(cdemoCu00NextPageFlg);
	}
	
	/**
	 * Getter for nextPageYes attribute.
	 * @param indexes the indexes
	 * @return nextPageYes attribute
	 */
	public ConditionReference getItemFromNextPageYes(Integer... indexes) {
		return cdemoCu00NextPageFlg.getIndexedConditionReference(nextPageYes, indexes);
	}
	
	/**
	 * Indexed getter for nextPageYes attribute.
	 * @param indexes the indexes
	 * @return nextPageYes attribute
	 */
	public Boolean isItemFromNextPageYes(Integer... indexes) {
		return cdemoCu00NextPageFlg.getIndexedConditionReference(nextPageYes, indexes).getValue();
	}
	
	/**
	 * Indexed setter for nextPageYes attribute.
	 * @param nextPageYesValue the new value of nextPageYes for given indexes
	 * @param indexes the indexes
	 */
	public void setItemFromNextPageYes(Boolean nextPageYesValue, Integer... indexes) {
		cdemoCu00NextPageFlg.getIndexedConditionReference(nextPageYes, indexes).setValue(nextPageYesValue);
	}
	
	/**
	 * Getter for nextPageNo attribute.
	 * @param indexes the indexes
	 * @return nextPageNo attribute
	 */
	public ConditionReference getItemFromNextPageNo(Integer... indexes) {
		return cdemoCu00NextPageFlg.getIndexedConditionReference(nextPageNo, indexes);
	}
	
	/**
	 * Indexed getter for nextPageNo attribute.
	 * @param indexes the indexes
	 * @return nextPageNo attribute
	 */
	public Boolean isItemFromNextPageNo(Integer... indexes) {
		return cdemoCu00NextPageFlg.getIndexedConditionReference(nextPageNo, indexes).getValue();
	}
	
	/**
	 * Indexed setter for nextPageNo attribute.
	 * @param nextPageNoValue the new value of nextPageNo for given indexes
	 * @param indexes the indexes
	 */
	public void setItemFromNextPageNo(Boolean nextPageNoValue, Integer... indexes) {
		cdemoCu00NextPageFlg.getIndexedConditionReference(nextPageNo, indexes).setValue(nextPageNoValue);
	}
	
	/**
	 * Indexed getter for cdemoCu00UsrSelFlg attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsrSelFlg attribute
	 */
	public ElementaryRangeReference getItemFromCdemoCu00UsrSelFlgReference(Integer... indexes) {
		return cdemoCu00UsrSelFlg.getIndexedReference(indexes);
	}
	
	/**
	 * Indexed getter for cdemoCu00UsrSelFlg attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsrSelFlg attribute
	 */
	public String getItemFromCdemoCu00UsrSelFlg(Integer... indexes) {
		return cdemoCu00UsrSelFlg.getIndexedValue(indexes);
	}
	
	/**
	 * Indexed setter for cdemoCu00UsrSelFlg attribute.
	 * @param cdemoCu00UsrSelFlg the new value of cdemoCu00UsrSelFlg for given indexes
	 * @param indexes the indexes
	 */
	public void setItemFromCdemoCu00UsrSelFlg(String cdemoCu00UsrSelFlg,Integer... indexes) {
		this.cdemoCu00UsrSelFlg.setIndexedValue(cdemoCu00UsrSelFlg,indexes);
	}
	
	/**
	 * Collection size getter for cdemoCu00UsrSelFlg attribute.
	 * @return  the collection size for attributecdemoCu00UsrSelFlg
	 */
	public int getCdemoCu00UsrSelFlgSize(){
		return cdemoCu00UsrSelFlg.getRepetition().getCount();
	}
	
	/**
	 * Indexed getter for cdemoCu00UsrSelFlg attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsrSelFlg attribute
	 */
	public ElementaryRangeReference getCdemoCu00UsrSelFlgReference() {
		return cdemoCu00UsrSelFlg.getReference();
	}
	
	/**
	 * Indexed getter for cdemoCu00UsrSelFlg attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsrSelFlg attribute
	 */
	public String getCdemoCu00UsrSelFlg() {
		return cdemoCu00UsrSelFlg.getValue();
	}
	
	/**
	 * Indexed setter for cdemoCu00UsrSelFlg attribute.
	 * @param cdemoCu00UsrSelFlg the new value of cdemoCu00UsrSelFlg for given indexes
	 * @param indexes the indexes
	 */
	public void setCdemoCu00UsrSelFlg(String cdemoCu00UsrSelFlg) {
		this.cdemoCu00UsrSelFlg.setValue(cdemoCu00UsrSelFlg);
	}
	
	/**
	 * Indexed getter for cdemoCu00UsrSelected attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsrSelected attribute
	 */
	public ElementaryRangeReference getItemFromCdemoCu00UsrSelectedReference(Integer... indexes) {
		return cdemoCu00UsrSelected.getIndexedReference(indexes);
	}
	
	/**
	 * Indexed getter for cdemoCu00UsrSelected attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsrSelected attribute
	 */
	public String getItemFromCdemoCu00UsrSelected(Integer... indexes) {
		return cdemoCu00UsrSelected.getIndexedValue(indexes);
	}
	
	/**
	 * Indexed setter for cdemoCu00UsrSelected attribute.
	 * @param cdemoCu00UsrSelected the new value of cdemoCu00UsrSelected for given indexes
	 * @param indexes the indexes
	 */
	public void setItemFromCdemoCu00UsrSelected(String cdemoCu00UsrSelected,Integer... indexes) {
		this.cdemoCu00UsrSelected.setIndexedValue(cdemoCu00UsrSelected,indexes);
	}
	
	/**
	 * Collection size getter for cdemoCu00UsrSelected attribute.
	 * @return  the collection size for attributecdemoCu00UsrSelected
	 */
	public int getCdemoCu00UsrSelectedSize(){
		return cdemoCu00UsrSelected.getRepetition().getCount();
	}
	
	/**
	 * Indexed getter for cdemoCu00UsrSelected attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsrSelected attribute
	 */
	public ElementaryRangeReference getCdemoCu00UsrSelectedReference() {
		return cdemoCu00UsrSelected.getReference();
	}
	
	/**
	 * Indexed getter for cdemoCu00UsrSelected attribute.
	 * @param indexes the indexes
	 * @return cdemoCu00UsrSelected attribute
	 */
	public String getCdemoCu00UsrSelected() {
		return cdemoCu00UsrSelected.getValue();
	}
	
	/**
	 * Indexed setter for cdemoCu00UsrSelected attribute.
	 * @param cdemoCu00UsrSelected the new value of cdemoCu00UsrSelected for given indexes
	 * @param indexes the indexes
	 */
	public void setCdemoCu00UsrSelected(String cdemoCu00UsrSelected) {
		this.cdemoCu00UsrSelected.setValue(cdemoCu00UsrSelected);
	}
	
}
