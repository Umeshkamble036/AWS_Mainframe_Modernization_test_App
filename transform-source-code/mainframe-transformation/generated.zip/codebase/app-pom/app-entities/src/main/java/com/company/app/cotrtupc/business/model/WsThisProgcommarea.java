package com.company.app.cotrtupc.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.Record;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ConditionReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.ConditionName;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
/**
 * Data simplifier entity WsThisProgcommarea.
<pre>
 * 
 * Legacy Documentation:<br>
 *  ****************************************************************<br>
 *  Application Commmarea Copybook<br>
</pre>
 * 
 * <p>About 'ttupUpdateScreenData' field, <br>uml entity: com.company.app.cotrtupc.business.model.TtupUpdateScreenData
 * <br></p>
 * 
 * <p>About 'ttupOldDetails' field, <br>uml entity: com.company.app.cotrtupc.business.model.TtupOldDetails
 * <br></p>
 * 
 * <p>About 'ttupNewDetails' field, <br>uml entity: com.company.app.cotrtupc.business.model.TtupNewDetails
 * <br></p>
 * 
 * @see RecordEntity
 */
public class WsThisProgcommarea extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Group ttupUpdateScreenData = new Group(root);
	private final Elementary ttupChangeAction = new Elementary(ttupUpdateScreenData,new AlphanumericType(1),Record.LOW_VALUES);
	private final ConditionName ttupDetailsNotFetched=new ConditionName(ttupChangeAction,Record.LOW_VALUES,
	" ");
	private final ConditionName ttupInvalidSearchKeys=new ConditionName(ttupChangeAction,"K");
	private final ConditionName ttupDetailsNotFound=new ConditionName(ttupChangeAction,"X");
	private final ConditionName ttupShowDetails=new ConditionName(ttupChangeAction,"S");
	private final ConditionName ttupCreateNewRecord=new ConditionName(ttupChangeAction,"R");
	private final ConditionName ttupReviewNewRecord=new ConditionName(ttupChangeAction,"V");
	private final ConditionName ttupDeleteInProgress=new ConditionName(ttupChangeAction,"9",
	"8",
	"7",
	"6");
	private final ConditionName ttupConfirmDelete=new ConditionName(ttupChangeAction,"9");
	private final ConditionName ttupStartDelete=new ConditionName(ttupChangeAction,"8");
	private final ConditionName ttupDeleteDone=new ConditionName(ttupChangeAction,"7");
	private final ConditionName ttupDeleteFailed=new ConditionName(ttupChangeAction,"6");
	private final ConditionName ttupChangesMade=new ConditionName(ttupChangeAction,"E",
	"N",
	"L",
	"F");
	private final ConditionName ttupChangesNotOk=new ConditionName(ttupChangeAction,"E");
	private final ConditionName ttupChangesOkNotConfirmed=new ConditionName(ttupChangeAction,"N");
	private final ConditionName ttupChangesFailed=new ConditionName(ttupChangeAction,"L",
	"F");
	private final ConditionName ttupChangesOkayedLockError=new ConditionName(ttupChangeAction,"L");
	private final ConditionName ttupChangesOkayedButFailed=new ConditionName(ttupChangeAction,"F");
	private final ConditionName ttupChangesOkayedAndDone=new ConditionName(ttupChangeAction,"C");
	private final ConditionName ttupChangesBackedOut=new ConditionName(ttupChangeAction,"B");
	private final Group ttupOldDetails = new Group(root);
	private final Group ttupOldTtypData = new Group(ttupOldDetails);
	private final Elementary ttupOldTtypType = new Elementary(ttupOldTtypData,new AlphanumericType(2));
	private final Elementary ttupOldTtypTypeDesc = new Elementary(ttupOldTtypData,new AlphanumericType(50));
	private final Group ttupNewDetails = new Group(root);
	private final Group ttupNewTtypData = new Group(ttupNewDetails);
	private final Elementary ttupNewTtypType = new Elementary(ttupNewTtypData,new AlphanumericType(2));
	private final Elementary ttupNewTtypTypeDesc = new Elementary(ttupNewTtypData,new AlphanumericType(50));
	
	/**
	 * Instantiate a new WsThisProgcommarea with a default record.
	 * @param configuration the configuration
	 */
	public WsThisProgcommarea(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new WsThisProgcommarea bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public WsThisProgcommarea(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	
	/**
	 * Gets the reference for attribute ttupUpdateScreenData.
	 * @return the ttupUpdateScreenData attribute reference
	 */
	public RangeReference getTtupUpdateScreenDataReference() {
		return ttupUpdateScreenData.getReference();
	}	
				
	/**
	 * Setter for ttupUpdateScreenData .
	 */
   	public void setTtupUpdateScreenData(RangeReference reference) {
       	ttupUpdateScreenData.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute ttupChangeAction.
	 * @return the ttupChangeAction attribute reference
	 */
	public ElementaryRangeReference getTtupChangeActionReference() {
		return ttupChangeAction.getReference();
	}

	/**
	 * Getter for ttupChangeAction attribute.
	 * @return ttupChangeAction attribute
	 */
	public String getTtupChangeAction() {
		return ttupChangeAction.getValue();
	}

	/**
	 * Setter for ttupChangeAction attribute.
	 * @param ttupChangeAction the new value of ttupChangeAction
	 */
	public void setTtupChangeAction(String ttupChangeAction) {
		this.ttupChangeAction.setValue(ttupChangeAction);
	}
	/**
	 * Gets the reference for attribute ttupDetailsNotFetched.
	 * @return the ttupDetailsNotFetched attribute reference
	 */
	public ConditionReference getTtupDetailsNotFetchedReference() {
		return ttupChangeAction.getCondition(ttupDetailsNotFetched);	
	}

	/**
	 * Getter for ttupDetailsNotFetched attribute.
	 * @return ttupDetailsNotFetched attribute
	 */
	public boolean isTtupDetailsNotFetched() {
		return getTtupDetailsNotFetchedReference().getValue();	
	}

	/**
	 * Setter for ttupDetailsNotFetched attribute.
	 * @param ttupDetailsNotFetched the new value of ttupDetailsNotFetched
	 */
	public void setTtupDetailsNotFetched(boolean ttupDetailsNotFetched) {
		getTtupDetailsNotFetchedReference().setValue(ttupDetailsNotFetched);	
	}
	/**
	 * Gets the reference for attribute ttupInvalidSearchKeys.
	 * @return the ttupInvalidSearchKeys attribute reference
	 */
	public ConditionReference getTtupInvalidSearchKeysReference() {
		return ttupChangeAction.getCondition(ttupInvalidSearchKeys);	
	}

	/**
	 * Getter for ttupInvalidSearchKeys attribute.
	 * @return ttupInvalidSearchKeys attribute
	 */
	public boolean isTtupInvalidSearchKeys() {
		return getTtupInvalidSearchKeysReference().getValue();	
	}

	/**
	 * Setter for ttupInvalidSearchKeys attribute.
	 * @param ttupInvalidSearchKeys the new value of ttupInvalidSearchKeys
	 */
	public void setTtupInvalidSearchKeys(boolean ttupInvalidSearchKeys) {
		getTtupInvalidSearchKeysReference().setValue(ttupInvalidSearchKeys);	
	}
	/**
	 * Gets the reference for attribute ttupDetailsNotFound.
	 * @return the ttupDetailsNotFound attribute reference
	 */
	public ConditionReference getTtupDetailsNotFoundReference() {
		return ttupChangeAction.getCondition(ttupDetailsNotFound);	
	}

	/**
	 * Getter for ttupDetailsNotFound attribute.
	 * @return ttupDetailsNotFound attribute
	 */
	public boolean isTtupDetailsNotFound() {
		return getTtupDetailsNotFoundReference().getValue();	
	}

	/**
	 * Setter for ttupDetailsNotFound attribute.
	 * @param ttupDetailsNotFound the new value of ttupDetailsNotFound
	 */
	public void setTtupDetailsNotFound(boolean ttupDetailsNotFound) {
		getTtupDetailsNotFoundReference().setValue(ttupDetailsNotFound);	
	}
	/**
	 * Gets the reference for attribute ttupShowDetails.
	 * @return the ttupShowDetails attribute reference
	 */
	public ConditionReference getTtupShowDetailsReference() {
		return ttupChangeAction.getCondition(ttupShowDetails);	
	}

	/**
	 * Getter for ttupShowDetails attribute.
	 * @return ttupShowDetails attribute
	 */
	public boolean isTtupShowDetails() {
		return getTtupShowDetailsReference().getValue();	
	}

	/**
	 * Setter for ttupShowDetails attribute.
	 * @param ttupShowDetails the new value of ttupShowDetails
	 */
	public void setTtupShowDetails(boolean ttupShowDetails) {
		getTtupShowDetailsReference().setValue(ttupShowDetails);	
	}
	/**
	 * Gets the reference for attribute ttupCreateNewRecord.
	 * @return the ttupCreateNewRecord attribute reference
	 */
	public ConditionReference getTtupCreateNewRecordReference() {
		return ttupChangeAction.getCondition(ttupCreateNewRecord);	
	}

	/**
	 * Getter for ttupCreateNewRecord attribute.
	 * @return ttupCreateNewRecord attribute
	 */
	public boolean isTtupCreateNewRecord() {
		return getTtupCreateNewRecordReference().getValue();	
	}

	/**
	 * Setter for ttupCreateNewRecord attribute.
	 * @param ttupCreateNewRecord the new value of ttupCreateNewRecord
	 */
	public void setTtupCreateNewRecord(boolean ttupCreateNewRecord) {
		getTtupCreateNewRecordReference().setValue(ttupCreateNewRecord);	
	}
	/**
	 * Gets the reference for attribute ttupReviewNewRecord.
	 * @return the ttupReviewNewRecord attribute reference
	 */
	public ConditionReference getTtupReviewNewRecordReference() {
		return ttupChangeAction.getCondition(ttupReviewNewRecord);	
	}

	/**
	 * Getter for ttupReviewNewRecord attribute.
	 * @return ttupReviewNewRecord attribute
	 */
	public boolean isTtupReviewNewRecord() {
		return getTtupReviewNewRecordReference().getValue();	
	}

	/**
	 * Setter for ttupReviewNewRecord attribute.
	 * @param ttupReviewNewRecord the new value of ttupReviewNewRecord
	 */
	public void setTtupReviewNewRecord(boolean ttupReviewNewRecord) {
		getTtupReviewNewRecordReference().setValue(ttupReviewNewRecord);	
	}
	/**
	 * Gets the reference for attribute ttupDeleteInProgress.
	 * @return the ttupDeleteInProgress attribute reference
	 */
	public ConditionReference getTtupDeleteInProgressReference() {
		return ttupChangeAction.getCondition(ttupDeleteInProgress);	
	}

	/**
	 * Getter for ttupDeleteInProgress attribute.
	 * @return ttupDeleteInProgress attribute
	 */
	public boolean isTtupDeleteInProgress() {
		return getTtupDeleteInProgressReference().getValue();	
	}

	/**
	 * Setter for ttupDeleteInProgress attribute.
	 * @param ttupDeleteInProgress the new value of ttupDeleteInProgress
	 */
	public void setTtupDeleteInProgress(boolean ttupDeleteInProgress) {
		getTtupDeleteInProgressReference().setValue(ttupDeleteInProgress);	
	}
	/**
	 * Gets the reference for attribute ttupConfirmDelete.
	 * @return the ttupConfirmDelete attribute reference
	 */
	public ConditionReference getTtupConfirmDeleteReference() {
		return ttupChangeAction.getCondition(ttupConfirmDelete);	
	}

	/**
	 * Getter for ttupConfirmDelete attribute.
	 * @return ttupConfirmDelete attribute
	 */
	public boolean isTtupConfirmDelete() {
		return getTtupConfirmDeleteReference().getValue();	
	}

	/**
	 * Setter for ttupConfirmDelete attribute.
	 * @param ttupConfirmDelete the new value of ttupConfirmDelete
	 */
	public void setTtupConfirmDelete(boolean ttupConfirmDelete) {
		getTtupConfirmDeleteReference().setValue(ttupConfirmDelete);	
	}
	/**
	 * Gets the reference for attribute ttupStartDelete.
	 * @return the ttupStartDelete attribute reference
	 */
	public ConditionReference getTtupStartDeleteReference() {
		return ttupChangeAction.getCondition(ttupStartDelete);	
	}

	/**
	 * Getter for ttupStartDelete attribute.
	 * @return ttupStartDelete attribute
	 */
	public boolean isTtupStartDelete() {
		return getTtupStartDeleteReference().getValue();	
	}

	/**
	 * Setter for ttupStartDelete attribute.
	 * @param ttupStartDelete the new value of ttupStartDelete
	 */
	public void setTtupStartDelete(boolean ttupStartDelete) {
		getTtupStartDeleteReference().setValue(ttupStartDelete);	
	}
	/**
	 * Gets the reference for attribute ttupDeleteDone.
	 * @return the ttupDeleteDone attribute reference
	 */
	public ConditionReference getTtupDeleteDoneReference() {
		return ttupChangeAction.getCondition(ttupDeleteDone);	
	}

	/**
	 * Getter for ttupDeleteDone attribute.
	 * @return ttupDeleteDone attribute
	 */
	public boolean isTtupDeleteDone() {
		return getTtupDeleteDoneReference().getValue();	
	}

	/**
	 * Setter for ttupDeleteDone attribute.
	 * @param ttupDeleteDone the new value of ttupDeleteDone
	 */
	public void setTtupDeleteDone(boolean ttupDeleteDone) {
		getTtupDeleteDoneReference().setValue(ttupDeleteDone);	
	}
	/**
	 * Gets the reference for attribute ttupDeleteFailed.
	 * @return the ttupDeleteFailed attribute reference
	 */
	public ConditionReference getTtupDeleteFailedReference() {
		return ttupChangeAction.getCondition(ttupDeleteFailed);	
	}

	/**
	 * Getter for ttupDeleteFailed attribute.
	 * @return ttupDeleteFailed attribute
	 */
	public boolean isTtupDeleteFailed() {
		return getTtupDeleteFailedReference().getValue();	
	}

	/**
	 * Setter for ttupDeleteFailed attribute.
	 * @param ttupDeleteFailed the new value of ttupDeleteFailed
	 */
	public void setTtupDeleteFailed(boolean ttupDeleteFailed) {
		getTtupDeleteFailedReference().setValue(ttupDeleteFailed);	
	}
	/**
	 * Gets the reference for attribute ttupChangesMade.
	 * @return the ttupChangesMade attribute reference
	 */
	public ConditionReference getTtupChangesMadeReference() {
		return ttupChangeAction.getCondition(ttupChangesMade);	
	}

	/**
	 * Getter for ttupChangesMade attribute.
	 * @return ttupChangesMade attribute
	 */
	public boolean isTtupChangesMade() {
		return getTtupChangesMadeReference().getValue();	
	}

	/**
	 * Setter for ttupChangesMade attribute.
	 * @param ttupChangesMade the new value of ttupChangesMade
	 */
	public void setTtupChangesMade(boolean ttupChangesMade) {
		getTtupChangesMadeReference().setValue(ttupChangesMade);	
	}
	/**
	 * Gets the reference for attribute ttupChangesNotOk.
	 * @return the ttupChangesNotOk attribute reference
	 */
	public ConditionReference getTtupChangesNotOkReference() {
		return ttupChangeAction.getCondition(ttupChangesNotOk);	
	}

	/**
	 * Getter for ttupChangesNotOk attribute.
	 * @return ttupChangesNotOk attribute
	 */
	public boolean isTtupChangesNotOk() {
		return getTtupChangesNotOkReference().getValue();	
	}

	/**
	 * Setter for ttupChangesNotOk attribute.
	 * @param ttupChangesNotOk the new value of ttupChangesNotOk
	 */
	public void setTtupChangesNotOk(boolean ttupChangesNotOk) {
		getTtupChangesNotOkReference().setValue(ttupChangesNotOk);	
	}
	/**
	 * Gets the reference for attribute ttupChangesOkNotConfirmed.
	 * @return the ttupChangesOkNotConfirmed attribute reference
	 */
	public ConditionReference getTtupChangesOkNotConfirmedReference() {
		return ttupChangeAction.getCondition(ttupChangesOkNotConfirmed);	
	}

	/**
	 * Getter for ttupChangesOkNotConfirmed attribute.
	 * @return ttupChangesOkNotConfirmed attribute
	 */
	public boolean isTtupChangesOkNotConfirmed() {
		return getTtupChangesOkNotConfirmedReference().getValue();	
	}

	/**
	 * Setter for ttupChangesOkNotConfirmed attribute.
	 * @param ttupChangesOkNotConfirmed the new value of ttupChangesOkNotConfirmed
	 */
	public void setTtupChangesOkNotConfirmed(boolean ttupChangesOkNotConfirmed) {
		getTtupChangesOkNotConfirmedReference().setValue(ttupChangesOkNotConfirmed);	
	}
	/**
	 * Gets the reference for attribute ttupChangesFailed.
	 * @return the ttupChangesFailed attribute reference
	 */
	public ConditionReference getTtupChangesFailedReference() {
		return ttupChangeAction.getCondition(ttupChangesFailed);	
	}

	/**
	 * Getter for ttupChangesFailed attribute.
	 * @return ttupChangesFailed attribute
	 */
	public boolean isTtupChangesFailed() {
		return getTtupChangesFailedReference().getValue();	
	}

	/**
	 * Setter for ttupChangesFailed attribute.
	 * @param ttupChangesFailed the new value of ttupChangesFailed
	 */
	public void setTtupChangesFailed(boolean ttupChangesFailed) {
		getTtupChangesFailedReference().setValue(ttupChangesFailed);	
	}
	/**
	 * Gets the reference for attribute ttupChangesOkayedLockError.
	 * @return the ttupChangesOkayedLockError attribute reference
	 */
	public ConditionReference getTtupChangesOkayedLockErrorReference() {
		return ttupChangeAction.getCondition(ttupChangesOkayedLockError);	
	}

	/**
	 * Getter for ttupChangesOkayedLockError attribute.
	 * @return ttupChangesOkayedLockError attribute
	 */
	public boolean isTtupChangesOkayedLockError() {
		return getTtupChangesOkayedLockErrorReference().getValue();	
	}

	/**
	 * Setter for ttupChangesOkayedLockError attribute.
	 * @param ttupChangesOkayedLockError the new value of ttupChangesOkayedLockError
	 */
	public void setTtupChangesOkayedLockError(boolean ttupChangesOkayedLockError) {
		getTtupChangesOkayedLockErrorReference().setValue(ttupChangesOkayedLockError);	
	}
	/**
	 * Gets the reference for attribute ttupChangesOkayedButFailed.
	 * @return the ttupChangesOkayedButFailed attribute reference
	 */
	public ConditionReference getTtupChangesOkayedButFailedReference() {
		return ttupChangeAction.getCondition(ttupChangesOkayedButFailed);	
	}

	/**
	 * Getter for ttupChangesOkayedButFailed attribute.
	 * @return ttupChangesOkayedButFailed attribute
	 */
	public boolean isTtupChangesOkayedButFailed() {
		return getTtupChangesOkayedButFailedReference().getValue();	
	}

	/**
	 * Setter for ttupChangesOkayedButFailed attribute.
	 * @param ttupChangesOkayedButFailed the new value of ttupChangesOkayedButFailed
	 */
	public void setTtupChangesOkayedButFailed(boolean ttupChangesOkayedButFailed) {
		getTtupChangesOkayedButFailedReference().setValue(ttupChangesOkayedButFailed);	
	}
	/**
	 * Gets the reference for attribute ttupChangesOkayedAndDone.
	 * @return the ttupChangesOkayedAndDone attribute reference
	 */
	public ConditionReference getTtupChangesOkayedAndDoneReference() {
		return ttupChangeAction.getCondition(ttupChangesOkayedAndDone);	
	}

	/**
	 * Getter for ttupChangesOkayedAndDone attribute.
	 * @return ttupChangesOkayedAndDone attribute
	 */
	public boolean isTtupChangesOkayedAndDone() {
		return getTtupChangesOkayedAndDoneReference().getValue();	
	}

	/**
	 * Setter for ttupChangesOkayedAndDone attribute.
	 * @param ttupChangesOkayedAndDone the new value of ttupChangesOkayedAndDone
	 */
	public void setTtupChangesOkayedAndDone(boolean ttupChangesOkayedAndDone) {
		getTtupChangesOkayedAndDoneReference().setValue(ttupChangesOkayedAndDone);	
	}
	/**
	 * Gets the reference for attribute ttupChangesBackedOut.
	 * @return the ttupChangesBackedOut attribute reference
	 */
	public ConditionReference getTtupChangesBackedOutReference() {
		return ttupChangeAction.getCondition(ttupChangesBackedOut);	
	}

	/**
	 * Getter for ttupChangesBackedOut attribute.
	 * @return ttupChangesBackedOut attribute
	 */
	public boolean isTtupChangesBackedOut() {
		return getTtupChangesBackedOutReference().getValue();	
	}

	/**
	 * Setter for ttupChangesBackedOut attribute.
	 * @param ttupChangesBackedOut the new value of ttupChangesBackedOut
	 */
	public void setTtupChangesBackedOut(boolean ttupChangesBackedOut) {
		getTtupChangesBackedOutReference().setValue(ttupChangesBackedOut);	
	}
	
	/**
	 * Gets the reference for attribute ttupOldDetails.
	 * @return the ttupOldDetails attribute reference
	 */
	public RangeReference getTtupOldDetailsReference() {
		return ttupOldDetails.getReference();
	}	
				
	/**
	 * Setter for ttupOldDetails .
	 */
   	public void setTtupOldDetails(RangeReference reference) {
       	ttupOldDetails.getReference().setBytes(reference.getBytes());
   	}
 
	
	/**
	 * Gets the reference for attribute ttupOldTtypData.
	 * @return the ttupOldTtypData attribute reference
	 */
	public RangeReference getTtupOldTtypDataReference() {
		return ttupOldTtypData.getReference();
	}	
				
	/**
	 * Setter for ttupOldTtypData .
	 */
   	public void setTtupOldTtypData(RangeReference reference) {
       	ttupOldTtypData.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute ttupOldTtypType.
	 * @return the ttupOldTtypType attribute reference
	 */
	public ElementaryRangeReference getTtupOldTtypTypeReference() {
		return ttupOldTtypType.getReference();
	}

	/**
	 * Getter for ttupOldTtypType attribute.
	 * @return ttupOldTtypType attribute
	 */
	public String getTtupOldTtypType() {
		return ttupOldTtypType.getValue();
	}

	/**
	 * Setter for ttupOldTtypType attribute.
	 * @param ttupOldTtypType the new value of ttupOldTtypType
	 */
	public void setTtupOldTtypType(String ttupOldTtypType) {
		this.ttupOldTtypType.setValue(ttupOldTtypType);
	}
	/**
	 * Gets the reference for attribute ttupOldTtypTypeDesc.
	 * @return the ttupOldTtypTypeDesc attribute reference
	 */
	public ElementaryRangeReference getTtupOldTtypTypeDescReference() {
		return ttupOldTtypTypeDesc.getReference();
	}

	/**
	 * Getter for ttupOldTtypTypeDesc attribute.
	 * @return ttupOldTtypTypeDesc attribute
	 */
	public String getTtupOldTtypTypeDesc() {
		return ttupOldTtypTypeDesc.getValue();
	}

	/**
	 * Setter for ttupOldTtypTypeDesc attribute.
	 * @param ttupOldTtypTypeDesc the new value of ttupOldTtypTypeDesc
	 */
	public void setTtupOldTtypTypeDesc(String ttupOldTtypTypeDesc) {
		this.ttupOldTtypTypeDesc.setValue(ttupOldTtypTypeDesc);
	}
	
	/**
	 * Gets the reference for attribute ttupNewDetails.
	 * @return the ttupNewDetails attribute reference
	 */
	public RangeReference getTtupNewDetailsReference() {
		return ttupNewDetails.getReference();
	}	
				
	/**
	 * Setter for ttupNewDetails .
	 */
   	public void setTtupNewDetails(RangeReference reference) {
       	ttupNewDetails.getReference().setBytes(reference.getBytes());
   	}
 
	
	/**
	 * Gets the reference for attribute ttupNewTtypData.
	 * @return the ttupNewTtypData attribute reference
	 */
	public RangeReference getTtupNewTtypDataReference() {
		return ttupNewTtypData.getReference();
	}	
				
	/**
	 * Setter for ttupNewTtypData .
	 */
   	public void setTtupNewTtypData(RangeReference reference) {
       	ttupNewTtypData.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute ttupNewTtypType.
	 * @return the ttupNewTtypType attribute reference
	 */
	public ElementaryRangeReference getTtupNewTtypTypeReference() {
		return ttupNewTtypType.getReference();
	}

	/**
	 * Getter for ttupNewTtypType attribute.
	 * @return ttupNewTtypType attribute
	 */
	public String getTtupNewTtypType() {
		return ttupNewTtypType.getValue();
	}

	/**
	 * Setter for ttupNewTtypType attribute.
	 * @param ttupNewTtypType the new value of ttupNewTtypType
	 */
	public void setTtupNewTtypType(String ttupNewTtypType) {
		this.ttupNewTtypType.setValue(ttupNewTtypType);
	}
	/**
	 * Gets the reference for attribute ttupNewTtypTypeDesc.
	 * @return the ttupNewTtypTypeDesc attribute reference
	 */
	public ElementaryRangeReference getTtupNewTtypTypeDescReference() {
		return ttupNewTtypTypeDesc.getReference();
	}

	/**
	 * Getter for ttupNewTtypTypeDesc attribute.
	 * @return ttupNewTtypTypeDesc attribute
	 */
	public String getTtupNewTtypTypeDesc() {
		return ttupNewTtypTypeDesc.getValue();
	}

	/**
	 * Setter for ttupNewTtypTypeDesc attribute.
	 * @param ttupNewTtypTypeDesc the new value of ttupNewTtypTypeDesc
	 */
	public void setTtupNewTtypTypeDesc(String ttupNewTtypTypeDesc) {
		this.ttupNewTtypTypeDesc.setValue(ttupNewTtypTypeDesc);
	}
}
