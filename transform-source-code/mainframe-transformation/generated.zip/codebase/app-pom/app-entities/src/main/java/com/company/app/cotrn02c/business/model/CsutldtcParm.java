package com.company.app.cotrn02c.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Filler;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ConditionReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.ConditionName;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.ZonedType;
/**
 * Data simplifier entity CsutldtcParm.
 * 
 * <p>About 'csutldtcDate' field, <br>
 * </p>
 * 
 * <p>About 'csutldtcDateFormat' field, <br>
 * </p>
 * 
 * <p>About 'csutldtcResult' field, <br>uml entity: com.company.app.cotrn02c.business.model.CsutldtcResult
 * <br></p>
 * 
 * <p>About 'cdemoCt02Info' field, <br>uml entity: com.company.app.cotrn02c.business.model.CdemoCt02Info
 * <br></p>
 * 
 * @see RecordEntity
 */
public class CsutldtcParm extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Elementary csutldtcDate = new Elementary(root,new AlphanumericType(10));
	private final Elementary csutldtcDateFormat = new Elementary(root,new AlphanumericType(10));
	private final Group csutldtcResult = new Group(root);
	private final Elementary csutldtcResultSevCd = new Elementary(csutldtcResult,new AlphanumericType(4));
	@SuppressWarnings("unused")
	private final Filler filler = new Filler(csutldtcResult,new AlphanumericType(11));
	private final Elementary csutldtcResultMsgNum = new Elementary(csutldtcResult,new AlphanumericType(4));
	private final Elementary csutldtcResultMsg = new Elementary(csutldtcResult,new AlphanumericType(61));
	private final Group cdemoCt02Info = new Group(root);
	private final Elementary cdemoCt02TrnidFirst = new Elementary(cdemoCt02Info,new AlphanumericType(16));
	private final Elementary cdemoCt02TrnidLast = new Elementary(cdemoCt02Info,new AlphanumericType(16));
	private final Elementary cdemoCt02PageNum = new Elementary(cdemoCt02Info,new ZonedType(8, 0, false));
	private final Elementary cdemoCt02NextPageFlg = new Elementary(cdemoCt02Info,new AlphanumericType(1),"N");
	private final ConditionName nextPageYes=new ConditionName(cdemoCt02NextPageFlg,"Y");
	private final ConditionName nextPageNo=new ConditionName(cdemoCt02NextPageFlg,"N");
	private final Elementary cdemoCt02TrnSelFlg = new Elementary(cdemoCt02Info,new AlphanumericType(1));
	private final Elementary cdemoCt02TrnSelected = new Elementary(cdemoCt02Info,new AlphanumericType(16));
	
	/**
	 * Instantiate a new CsutldtcParm with a default record.
	 * @param configuration the configuration
	 */
	public CsutldtcParm(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new CsutldtcParm bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public CsutldtcParm(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	/**
	 * Gets the reference for attribute csutldtcDate.
	 * @return the csutldtcDate attribute reference
	 */
	public ElementaryRangeReference getCsutldtcDateReference() {
		return csutldtcDate.getReference();
	}

	/**
	 * Getter for csutldtcDate attribute.
	 * @return csutldtcDate attribute
	 */
	public String getCsutldtcDate() {
		return csutldtcDate.getValue();
	}

	/**
	 * Setter for csutldtcDate attribute.
	 * @param csutldtcDate the new value of csutldtcDate
	 */
	public void setCsutldtcDate(String csutldtcDate) {
		this.csutldtcDate.setValue(csutldtcDate);
	}
	/**
	 * Gets the reference for attribute csutldtcDateFormat.
	 * @return the csutldtcDateFormat attribute reference
	 */
	public ElementaryRangeReference getCsutldtcDateFormatReference() {
		return csutldtcDateFormat.getReference();
	}

	/**
	 * Getter for csutldtcDateFormat attribute.
	 * @return csutldtcDateFormat attribute
	 */
	public String getCsutldtcDateFormat() {
		return csutldtcDateFormat.getValue();
	}

	/**
	 * Setter for csutldtcDateFormat attribute.
	 * @param csutldtcDateFormat the new value of csutldtcDateFormat
	 */
	public void setCsutldtcDateFormat(String csutldtcDateFormat) {
		this.csutldtcDateFormat.setValue(csutldtcDateFormat);
	}
	
	/**
	 * Gets the reference for attribute csutldtcResult.
	 * @return the csutldtcResult attribute reference
	 */
	public RangeReference getCsutldtcResultReference() {
		return csutldtcResult.getReference();
	}	
				
	/**
	 * Setter for csutldtcResult .
	 */
   	public void setCsutldtcResult(RangeReference reference) {
       	csutldtcResult.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute csutldtcResultSevCd.
	 * @return the csutldtcResultSevCd attribute reference
	 */
	public ElementaryRangeReference getCsutldtcResultSevCdReference() {
		return csutldtcResultSevCd.getReference();
	}

	/**
	 * Getter for csutldtcResultSevCd attribute.
	 * @return csutldtcResultSevCd attribute
	 */
	public String getCsutldtcResultSevCd() {
		return csutldtcResultSevCd.getValue();
	}

	/**
	 * Setter for csutldtcResultSevCd attribute.
	 * @param csutldtcResultSevCd the new value of csutldtcResultSevCd
	 */
	public void setCsutldtcResultSevCd(String csutldtcResultSevCd) {
		this.csutldtcResultSevCd.setValue(csutldtcResultSevCd);
	}
	/**
	 * Gets the reference for attribute csutldtcResultMsgNum.
	 * @return the csutldtcResultMsgNum attribute reference
	 */
	public ElementaryRangeReference getCsutldtcResultMsgNumReference() {
		return csutldtcResultMsgNum.getReference();
	}

	/**
	 * Getter for csutldtcResultMsgNum attribute.
	 * @return csutldtcResultMsgNum attribute
	 */
	public String getCsutldtcResultMsgNum() {
		return csutldtcResultMsgNum.getValue();
	}

	/**
	 * Setter for csutldtcResultMsgNum attribute.
	 * @param csutldtcResultMsgNum the new value of csutldtcResultMsgNum
	 */
	public void setCsutldtcResultMsgNum(String csutldtcResultMsgNum) {
		this.csutldtcResultMsgNum.setValue(csutldtcResultMsgNum);
	}
	/**
	 * Gets the reference for attribute csutldtcResultMsg.
	 * @return the csutldtcResultMsg attribute reference
	 */
	public ElementaryRangeReference getCsutldtcResultMsgReference() {
		return csutldtcResultMsg.getReference();
	}

	/**
	 * Getter for csutldtcResultMsg attribute.
	 * @return csutldtcResultMsg attribute
	 */
	public String getCsutldtcResultMsg() {
		return csutldtcResultMsg.getValue();
	}

	/**
	 * Setter for csutldtcResultMsg attribute.
	 * @param csutldtcResultMsg the new value of csutldtcResultMsg
	 */
	public void setCsutldtcResultMsg(String csutldtcResultMsg) {
		this.csutldtcResultMsg.setValue(csutldtcResultMsg);
	}
	
	/**
	 * Gets the reference for attribute cdemoCt02Info.
	 * @return the cdemoCt02Info attribute reference
	 */
	public RangeReference getCdemoCt02InfoReference() {
		return cdemoCt02Info.getReference();
	}	
				
	/**
	 * Setter for cdemoCt02Info .
	 */
   	public void setCdemoCt02Info(RangeReference reference) {
       	cdemoCt02Info.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute cdemoCt02TrnidFirst.
	 * @return the cdemoCt02TrnidFirst attribute reference
	 */
	public ElementaryRangeReference getCdemoCt02TrnidFirstReference() {
		return cdemoCt02TrnidFirst.getReference();
	}

	/**
	 * Getter for cdemoCt02TrnidFirst attribute.
	 * @return cdemoCt02TrnidFirst attribute
	 */
	public String getCdemoCt02TrnidFirst() {
		return cdemoCt02TrnidFirst.getValue();
	}

	/**
	 * Setter for cdemoCt02TrnidFirst attribute.
	 * @param cdemoCt02TrnidFirst the new value of cdemoCt02TrnidFirst
	 */
	public void setCdemoCt02TrnidFirst(String cdemoCt02TrnidFirst) {
		this.cdemoCt02TrnidFirst.setValue(cdemoCt02TrnidFirst);
	}
	/**
	 * Gets the reference for attribute cdemoCt02TrnidLast.
	 * @return the cdemoCt02TrnidLast attribute reference
	 */
	public ElementaryRangeReference getCdemoCt02TrnidLastReference() {
		return cdemoCt02TrnidLast.getReference();
	}

	/**
	 * Getter for cdemoCt02TrnidLast attribute.
	 * @return cdemoCt02TrnidLast attribute
	 */
	public String getCdemoCt02TrnidLast() {
		return cdemoCt02TrnidLast.getValue();
	}

	/**
	 * Setter for cdemoCt02TrnidLast attribute.
	 * @param cdemoCt02TrnidLast the new value of cdemoCt02TrnidLast
	 */
	public void setCdemoCt02TrnidLast(String cdemoCt02TrnidLast) {
		this.cdemoCt02TrnidLast.setValue(cdemoCt02TrnidLast);
	}
	/**
	 * Gets the reference for attribute cdemoCt02PageNum.
	 * @return the cdemoCt02PageNum attribute reference
	 */
	public ElementaryRangeReference getCdemoCt02PageNumReference() {
		return cdemoCt02PageNum.getReference();
	}

	/**
	 * Getter for cdemoCt02PageNum attribute.
	 * @return cdemoCt02PageNum attribute
	 */
	public int getCdemoCt02PageNum() {
		return cdemoCt02PageNum.getValue();
	}

	/**
	 * Setter for cdemoCt02PageNum attribute.
	 * @param cdemoCt02PageNum the new value of cdemoCt02PageNum
	 */
	public void setCdemoCt02PageNum(int cdemoCt02PageNum) {
		this.cdemoCt02PageNum.setValue(cdemoCt02PageNum);
	}
	/**
	 * Gets the reference for attribute cdemoCt02NextPageFlg.
	 * @return the cdemoCt02NextPageFlg attribute reference
	 */
	public ElementaryRangeReference getCdemoCt02NextPageFlgReference() {
		return cdemoCt02NextPageFlg.getReference();
	}

	/**
	 * Getter for cdemoCt02NextPageFlg attribute.
	 * @return cdemoCt02NextPageFlg attribute
	 */
	public String getCdemoCt02NextPageFlg() {
		return cdemoCt02NextPageFlg.getValue();
	}

	/**
	 * Setter for cdemoCt02NextPageFlg attribute.
	 * @param cdemoCt02NextPageFlg the new value of cdemoCt02NextPageFlg
	 */
	public void setCdemoCt02NextPageFlg(String cdemoCt02NextPageFlg) {
		this.cdemoCt02NextPageFlg.setValue(cdemoCt02NextPageFlg);
	}
	/**
	 * Gets the reference for attribute nextPageYes.
	 * @return the nextPageYes attribute reference
	 */
	public ConditionReference getNextPageYesReference() {
		return cdemoCt02NextPageFlg.getCondition(nextPageYes);	
	}

	/**
	 * Getter for nextPageYes attribute.
	 * @return nextPageYes attribute
	 */
	public boolean isNextPageYes() {
		return getNextPageYesReference().getValue();	
	}

	/**
	 * Setter for nextPageYes attribute.
	 * @param nextPageYes the new value of nextPageYes
	 */
	public void setNextPageYes(boolean nextPageYes) {
		getNextPageYesReference().setValue(nextPageYes);	
	}
	/**
	 * Gets the reference for attribute nextPageNo.
	 * @return the nextPageNo attribute reference
	 */
	public ConditionReference getNextPageNoReference() {
		return cdemoCt02NextPageFlg.getCondition(nextPageNo);	
	}

	/**
	 * Getter for nextPageNo attribute.
	 * @return nextPageNo attribute
	 */
	public boolean isNextPageNo() {
		return getNextPageNoReference().getValue();	
	}

	/**
	 * Setter for nextPageNo attribute.
	 * @param nextPageNo the new value of nextPageNo
	 */
	public void setNextPageNo(boolean nextPageNo) {
		getNextPageNoReference().setValue(nextPageNo);	
	}
	/**
	 * Gets the reference for attribute cdemoCt02TrnSelFlg.
	 * @return the cdemoCt02TrnSelFlg attribute reference
	 */
	public ElementaryRangeReference getCdemoCt02TrnSelFlgReference() {
		return cdemoCt02TrnSelFlg.getReference();
	}

	/**
	 * Getter for cdemoCt02TrnSelFlg attribute.
	 * @return cdemoCt02TrnSelFlg attribute
	 */
	public String getCdemoCt02TrnSelFlg() {
		return cdemoCt02TrnSelFlg.getValue();
	}

	/**
	 * Setter for cdemoCt02TrnSelFlg attribute.
	 * @param cdemoCt02TrnSelFlg the new value of cdemoCt02TrnSelFlg
	 */
	public void setCdemoCt02TrnSelFlg(String cdemoCt02TrnSelFlg) {
		this.cdemoCt02TrnSelFlg.setValue(cdemoCt02TrnSelFlg);
	}
	/**
	 * Gets the reference for attribute cdemoCt02TrnSelected.
	 * @return the cdemoCt02TrnSelected attribute reference
	 */
	public ElementaryRangeReference getCdemoCt02TrnSelectedReference() {
		return cdemoCt02TrnSelected.getReference();
	}

	/**
	 * Getter for cdemoCt02TrnSelected attribute.
	 * @return cdemoCt02TrnSelected attribute
	 */
	public String getCdemoCt02TrnSelected() {
		return cdemoCt02TrnSelected.getValue();
	}

	/**
	 * Setter for cdemoCt02TrnSelected attribute.
	 * @param cdemoCt02TrnSelected the new value of cdemoCt02TrnSelected
	 */
	public void setCdemoCt02TrnSelected(String cdemoCt02TrnSelected) {
		this.cdemoCt02TrnSelected.setValue(cdemoCt02TrnSelected);
	}
}
