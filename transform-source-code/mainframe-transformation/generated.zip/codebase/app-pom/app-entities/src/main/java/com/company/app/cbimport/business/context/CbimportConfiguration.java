package com.company.app.cbimport.business.context;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration.LegacySystem;
import com.netfective.bluage.gapwalk.datasimplifier.configuration.ConfigurationBuilder;
import java.nio.charset.Charset;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;

/**
 * Creates Datasimplifier configuration for the CbimportContext context.
 */
@org.springframework.context.annotation.Configuration
@Lazy
public class CbimportConfiguration {

	
	@Bean(name = "CbimportContextConfiguration")
	public Configuration configuration() {
		return new ConfigurationBuilder()
				.humanReadableEncoding(Charset.forName("ISO-8859-15"))
				.initDefaultByte(0)
				.legacySystem(LegacySystem.ZOS)
				.outDD("STDOUT")
				.build();
	}

}
