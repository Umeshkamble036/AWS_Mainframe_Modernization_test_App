package com.company.app.cotrn02c.business.context;
import com.company.app.cotrn02c.business.model.CsutldtcParm;
import com.company.app.cotrn02c.business.model.Dfhaid;
import com.company.app.cotrn02c.business.model.Dfhbmsca;
import com.company.app.cotrn02c.business.model.Dfhcommarea;
import com.company.app.cotrn02c.business.model.Dfheiblk;
import com.company.app.cotrn02c.business.model.WsVariables;
import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.rt.jics.context.JicsRuntimeContext;
import com.netfective.bluage.gapwalk.rt.utils.EntityUtils;
import jakarta.annotation.PostConstruct;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Data simplifier context Cotrn02cContext.
 * 
 * <p>About 'onCode' field, <br>
 * </p>
 * 
 * <p>About 'onChar' field, <br>
 * </p>
 * 
 * <p>About 'wsVariables' field, <br>uml entity: com.company.app.cotrn02c.business.model.WsVariables
 * <br></p>
 * 
 * <p>About 'csutldtcParm' field, <br>uml entity: com.company.app.cotrn02c.business.model.CsutldtcParm
 * <br></p>
 * 
 * <p>About 'dfhaid' field, <br>uml entity: com.company.app.cotrn02c.business.model.Dfhaid
 * <br></p>
 * 
 * <p>About 'dfhbmsca' field, <br>uml entity: com.company.app.cotrn02c.business.model.Dfhbmsca
 * <br></p>
 * 
 * <p>About 'dfheiblk' field, <br>uml entity: com.company.app.cotrn02c.business.model.Dfheiblk
 * <br></p>
 * 
 * <p>About 'dfhcommarea' field, <br>uml entity: com.company.app.cotrn02c.business.model.Dfhcommarea
 * <br></p>
 * 
 */
@Component("com.company.app.cotrn02c.business.context.Cotrn02cContext")
@Lazy
@Scope("prototype")
public class Cotrn02cContext extends JicsRuntimeContext {
	
	private WsVariables wsVariables;
	private CsutldtcParm csutldtcParm;
	private Dfhaid dfhaid;
	private Dfhbmsca dfhbmsca;
	private Dfheiblk dfheiblk;
	private Dfhcommarea dfhcommarea;

	private List<RecordEntity> recordEntities;

	/**
	 * Default constructor.
	 * @param configuration the datasimplifier configuration
	 */
	public Cotrn02cContext (@Qualifier("Cotrn02cContextConfiguration") Configuration configuration) {
		super(configuration);
		initWorking(configuration);
		initLinkage(configuration);
		initRecordEntities();
	}
	
	/**
	 * Add count holders:
	 * 
	 * Once all entities/files have been initialized, bind the
	 * elementary references that act as count holder for 
	 * variable size arrays.
	 */
	@PostConstruct
	public void addCountHolders(){
		dfhcommarea.setLkCommareaCountHolder(dfheiblk.getEibcalenReference());
	}
	

	/**
	 * Getter for wsVariables.
	 * @return the wsVariables
	 */
	public WsVariables getWsVariables() {
		return this.wsVariables;
	}

	/**
	 * Setter for wsVariables.
	 * @param reference the new value for wsVariables
	 */
	public void setWsVariables(RangeReference reference) {
		this.wsVariables.setBytes(reference.getBytes());
	}

	/**
	 * Getter for csutldtcParm.
	 * @return the csutldtcParm
	 */
	public CsutldtcParm getCsutldtcParm() {
		return this.csutldtcParm;
	}

	/**
	 * Setter for csutldtcParm.
	 * @param reference the new value for csutldtcParm
	 */
	public void setCsutldtcParm(RangeReference reference) {
		this.csutldtcParm.setBytes(reference.getBytes());
	}

	/**
	 * Getter for dfhaid.
	 * @return the dfhaid
	 */
	public Dfhaid getDfhaid() {
		return this.dfhaid;
	}

	/**
	 * Setter for dfhaid.
	 * @param reference the new value for dfhaid
	 */
	public void setDfhaid(RangeReference reference) {
		this.dfhaid.setBytes(reference.getBytes());
	}

	/**
	 * Getter for dfhbmsca.
	 * @return the dfhbmsca
	 */
	public Dfhbmsca getDfhbmsca() {
		return this.dfhbmsca;
	}

	/**
	 * Setter for dfhbmsca.
	 * @param reference the new value for dfhbmsca
	 */
	public void setDfhbmsca(RangeReference reference) {
		this.dfhbmsca.setBytes(reference.getBytes());
	}

	/**
	 * Getter for dfheiblk.
	 * @return the dfheiblk
	 */
	public Dfheiblk getDfheiblk() {
		return this.dfheiblk;
	}

	/**
	 * Setter for dfheiblk.
	 * @param reference the new value for dfheiblk
	 */
	public void setDfheiblk(RangeReference reference) {
		this.dfheiblk.setBytes(reference.getBytes());
	}

	/**
	 * Getter for dfhcommarea.
	 * @return the dfhcommarea
	 */
	public Dfhcommarea getDfhcommarea() {
		return this.dfhcommarea;
	}

	/**
	 * Setter for dfhcommarea.
	 * @param reference the new value for dfhcommarea
	 */
	public void setDfhcommarea(RangeReference reference) {
		this.dfhcommarea.setBytes(reference.getBytes());
	}

	/**
	 * Getter for Jics Exec Interface Block.
	 * @return the Jics Exec Interface Block
	 */
	public Dfheiblk getJicsEiblk() {
		return this.dfheiblk;
	}

	@Override 
	public void cleanUp(){
	}

	@Override
	protected void doReset() {
		cleanUp();
	    // reset the working
		recordEntities.stream().forEach(e -> e.reset());
	}

	
	private void initWorking(Configuration configuration) {
		wsVariables = new WsVariables(configuration);
		csutldtcParm = new CsutldtcParm(configuration);
		dfhaid = new Dfhaid(configuration);
		dfhbmsca = new Dfhbmsca(configuration);
	}
	
	private void initLinkage(Configuration configuration) {
		dfheiblk = new Dfheiblk(configuration, EntityUtils.getUnlinkedRecord());
		dfhcommarea = new Dfhcommarea(configuration, EntityUtils.getUnlinkedRecord());
	
	}

	private void initRecordEntities() {
		recordEntities = Arrays.asList(wsVariables, csutldtcParm, dfhaid, dfhbmsca);
	}

	@Override
	public String toString(){
		StringBuilder toSB = new StringBuilder("\nCotrn02cContext:\n");
		if(!this.recordEntities.isEmpty()){
			this.recordEntities.forEach(e -> toSB.append(e.getClass().getSimpleName()).append(" : [").append(e.toString()).append("]\n"));
		}
		toSB.append("Dfheiblk : [").append(dfheiblk.toString()).append("]\n");
		toSB.append("Dfhcommarea : [").append(dfhcommarea.toString()).append("]\n");
		return toSB.toString();
	}

}
