package com.company.app.cobtupdt.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Data simplifier file TrRecord.
<pre>
 * 
 * Legacy Documentation:<br>
 *  *************************************** *************************<br>
 *   Program:     COBTUPDT.CBL                                      *<br>
 *   Layer:       Business logic                                    *<br>
 *   Function:    Update Transaction type based on user input       *<br>
 *  *****************************************************************<br>
 *   Copyright Amazon.com, Inc. or its affiliates.<br>
 *   All Rights Reserved.<br>
 *  <br>
 *   Licensed under the Apache License, Version 2.0 (the "License").<br>
 *   You may not use this file except in compliance with the License.<br>
 *   You may obtain a copy of the License at<br>
 *  <br>
 *      http://www.apache.org/licenses/LICENSE-2.0<br>
 *  <br>
 *   Unless required by applicable law or agreed to in writing,<br>
 *   software distributed under the License is distributed on an<br>
 *   "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,<br>
 *   either express or implied. See the License for the specific<br>
 *   language governing permissions and limitations under the License<br>
 *  *****************************************************************<br>
</pre>
 * 
 * <p>About 'wsInputVars' field, <br>uml entity: com.company.app.cobtupdt.business.model.WsInputVars
 * <br></p>
 * 
 */
@Component("com.company.app.cobtupdt.business.model.TrRecord")
@Lazy
@Scope("prototype")
public class TrRecord extends RecordEntity {

	private final Group root = new Group(getData());
	private final Group wsInputVars = new Group(root);
	private final Elementary inputType = new Elementary(wsInputVars,new AlphanumericType(1)," ");
	private final Elementary inputTrNumber = new Elementary(wsInputVars,new AlphanumericType(2)," ");
	private final Elementary inputTrDesc = new Elementary(wsInputVars,new AlphanumericType(50)," ");
	 
	/**
	 * Instantiate a new TrRecord.
	 * @param configuration the configuration
	 */
	public TrRecord(@Qualifier("CobtupdtContextConfiguration") Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}
	
	/**
	 * Gets the reference for attribute wsInputVars.
	 * @return the wsInputVars attribute reference
	 */
	public RangeReference getWsInputVarsReference() {
		return wsInputVars.getReference();
	}	
				
	/**
	 * Setter for wsInputVars .
	 */
   	public void setWsInputVars(RangeReference reference) {
       	wsInputVars.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute inputType.
	 * @return the inputType attribute reference
	 */
	public ElementaryRangeReference getInputTypeReference() {
		return inputType.getReference();
	}

	/**
	 * Getter for inputType attribute.
	 * @return inputType attribute
	 */
	public String getInputType() {
		return inputType.getValue();
	}

	/**
	 * Setter for inputType attribute.
	 * @param inputType the new value of inputType
	 */
	public void setInputType(String inputType) {
		this.inputType.setValue(inputType);
	}
	/**
	 * Gets the reference for attribute inputTrNumber.
	 * @return the inputTrNumber attribute reference
	 */
	public ElementaryRangeReference getInputTrNumberReference() {
		return inputTrNumber.getReference();
	}

	/**
	 * Getter for inputTrNumber attribute.
	 * @return inputTrNumber attribute
	 */
	public String getInputTrNumber() {
		return inputTrNumber.getValue();
	}

	/**
	 * Setter for inputTrNumber attribute.
	 * @param inputTrNumber the new value of inputTrNumber
	 */
	public void setInputTrNumber(String inputTrNumber) {
		this.inputTrNumber.setValue(inputTrNumber);
	}
	/**
	 * Gets the reference for attribute inputTrDesc.
	 * @return the inputTrDesc attribute reference
	 */
	public ElementaryRangeReference getInputTrDescReference() {
		return inputTrDesc.getReference();
	}

	/**
	 * Getter for inputTrDesc attribute.
	 * @return inputTrDesc attribute
	 */
	public String getInputTrDesc() {
		return inputTrDesc.getValue();
	}

	/**
	 * Setter for inputTrDesc attribute.
	 * @param inputTrDesc the new value of inputTrDesc
	 */
	public void setInputTrDesc(String inputTrDesc) {
		this.inputTrDesc.setValue(inputTrDesc);
	}
}
