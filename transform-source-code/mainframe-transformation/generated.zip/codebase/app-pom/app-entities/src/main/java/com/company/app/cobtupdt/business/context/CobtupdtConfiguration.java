package com.company.app.cobtupdt.business.context;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration.LegacySystem;
import com.netfective.bluage.gapwalk.datasimplifier.configuration.ConfigurationBuilder;
import java.nio.charset.Charset;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;

/**
 * Creates Datasimplifier configuration for the CobtupdtContext context.
 */
@org.springframework.context.annotation.Configuration
@Lazy
public class CobtupdtConfiguration {

	
	@Bean(name = "CobtupdtContextConfiguration")
	public Configuration configuration() {
		return new ConfigurationBuilder()
				.humanReadableEncoding(Charset.forName("ISO-8859-15"))
				.initDefaultByte(0)
				.legacySystem(LegacySystem.ZOS)
				.outDD("STDOUT")
				.build();
	}

}
