package com.company.app.cbact02c.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Data simplifier file CardfileFile.
<pre>
 * 
 * Legacy Documentation:<br>
 *  *****************************************************************<br>
 *   Program     : CBACT02C.CBL<br>
 *   Application : CardDemo<br>
 *   Type        : BATCH COBOL Program<br>
 *   Function    : Read and print card data file.<br>
 *  *****************************************************************<br>
 *   Copyright Amazon.com, Inc. or its affiliates.<br>
 *   All Rights Reserved.<br>
 *  <br>
 *   Licensed under the Apache License, Version 2.0 (the "License").<br>
 *   You may not use this file except in compliance with the License.<br>
 *   You may obtain a copy of the License at<br>
 *  <br>
 *      http://www.apache.org/licenses/LICENSE-2.0<br>
 *  <br>
 *   Unless required by applicable law or agreed to in writing,<br>
 *   software distributed under the License is distributed on an<br>
 *   "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,<br>
 *   either express or implied. See the License for the specific<br>
 *   language governing permissions and limitations under the License<br>
 *  *****************************************************************<br>
 *  <br>
</pre>
 * 
 * <p>About 'fdCardfileRec' field, <br>uml entity: com.company.app.cbact02c.business.model.FdCardfileRec
 * <br></p>
 * 
 */
@Component("com.company.app.cbact02c.business.model.CardfileFile")
@Lazy
@Scope("prototype")
public class CardfileFile extends RecordEntity {

	private final Group root = new Group(getData());
	private final Group fdCardfileRec = new Group(root);
	private final Elementary fdCardNum = new Elementary(fdCardfileRec,new AlphanumericType(16));
	private final Elementary fdCardData = new Elementary(fdCardfileRec,new AlphanumericType(134));
	 
	/**
	 * Instantiate a new CardfileFile.
	 * @param configuration the configuration
	 */
	public CardfileFile(@Qualifier("Cbact02cContextConfiguration") Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}
	
	/**
	 * Gets the reference for attribute fdCardfileRec.
	 * @return the fdCardfileRec attribute reference
	 */
	public RangeReference getFdCardfileRecReference() {
		return fdCardfileRec.getReference();
	}	
				
	/**
	 * Setter for fdCardfileRec .
	 */
   	public void setFdCardfileRec(RangeReference reference) {
       	fdCardfileRec.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute fdCardNum.
	 * @return the fdCardNum attribute reference
	 */
	public ElementaryRangeReference getFdCardNumReference() {
		return fdCardNum.getReference();
	}

	/**
	 * Getter for fdCardNum attribute.
	 * @return fdCardNum attribute
	 */
	public String getFdCardNum() {
		return fdCardNum.getValue();
	}

	/**
	 * Setter for fdCardNum attribute.
	 * @param fdCardNum the new value of fdCardNum
	 */
	public void setFdCardNum(String fdCardNum) {
		this.fdCardNum.setValue(fdCardNum);
	}
	/**
	 * Gets the reference for attribute fdCardData.
	 * @return the fdCardData attribute reference
	 */
	public ElementaryRangeReference getFdCardDataReference() {
		return fdCardData.getReference();
	}

	/**
	 * Getter for fdCardData attribute.
	 * @return fdCardData attribute
	 */
	public String getFdCardData() {
		return fdCardData.getValue();
	}

	/**
	 * Setter for fdCardData attribute.
	 * @param fdCardData the new value of fdCardData
	 */
	public void setFdCardData(String fdCardData) {
		this.fdCardData.setValue(fdCardData);
	}
}
