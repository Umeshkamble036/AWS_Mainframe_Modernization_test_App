package com.company.app.cobtupdt.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
/**
 * Data simplifier entity WsInfStatus.
 * 
 * <p>About 'wsInfStat1' field, <br>
 * </p>
 * 
 * <p>About 'wsInfStat2' field, <br>
 * </p>
 * 
 * @see RecordEntity
 */
public class WsInfStatus extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Elementary wsInfStat1 = new Elementary(root,new AlphanumericType(1));
	private final Elementary wsInfStat2 = new Elementary(root,new AlphanumericType(1));
	
	/**
	 * Instantiate a new WsInfStatus with a default record.
	 * @param configuration the configuration
	 */
	public WsInfStatus(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new WsInfStatus bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public WsInfStatus(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	/**
	 * Gets the reference for attribute wsInfStat1.
	 * @return the wsInfStat1 attribute reference
	 */
	public ElementaryRangeReference getWsInfStat1Reference() {
		return wsInfStat1.getReference();
	}

	/**
	 * Getter for wsInfStat1 attribute.
	 * @return wsInfStat1 attribute
	 */
	public String getWsInfStat1() {
		return wsInfStat1.getValue();
	}

	/**
	 * Setter for wsInfStat1 attribute.
	 * @param wsInfStat1 the new value of wsInfStat1
	 */
	public void setWsInfStat1(String wsInfStat1) {
		this.wsInfStat1.setValue(wsInfStat1);
	}
	/**
	 * Gets the reference for attribute wsInfStat2.
	 * @return the wsInfStat2 attribute reference
	 */
	public ElementaryRangeReference getWsInfStat2Reference() {
		return wsInfStat2.getReference();
	}

	/**
	 * Getter for wsInfStat2 attribute.
	 * @return wsInfStat2 attribute
	 */
	public String getWsInfStat2() {
		return wsInfStat2.getValue();
	}

	/**
	 * Setter for wsInfStat2 attribute.
	 * @param wsInfStat2 the new value of wsInfStat2
	 */
	public void setWsInfStat2(String wsInfStat2) {
		this.wsInfStat2.setValue(wsInfStat2);
	}
}
