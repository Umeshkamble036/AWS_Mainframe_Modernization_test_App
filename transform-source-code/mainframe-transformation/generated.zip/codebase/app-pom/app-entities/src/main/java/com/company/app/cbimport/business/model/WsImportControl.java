package com.company.app.cbimport.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
/**
 * Data simplifier entity WsImportControl.
<pre>
 * 
 * Legacy Documentation:<br>
 *   Import Control Variables<br>
</pre>
 * 
 * <p>About 'wsImportDate' field, <br>
 * </p>
 * 
 * <p>About 'wsImportTime' field, <br>
 * </p>
 * 
 * @see RecordEntity
 */
public class WsImportControl extends RecordEntity {

	private final Group root = new Group(getData()); 
	private final Elementary wsImportDate = new Elementary(root,new AlphanumericType(10));
	private final Elementary wsImportTime = new Elementary(root,new AlphanumericType(8));
	
	/**
	 * Instantiate a new WsImportControl with a default record.
	 * @param configuration the configuration
	 */
	public WsImportControl(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new WsImportControl bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public WsImportControl(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	/**
	 * Gets the reference for attribute wsImportDate.
	 * @return the wsImportDate attribute reference
	 */
	public ElementaryRangeReference getWsImportDateReference() {
		return wsImportDate.getReference();
	}

	/**
	 * Getter for wsImportDate attribute.
	 * @return wsImportDate attribute
	 */
	public String getWsImportDate() {
		return wsImportDate.getValue();
	}

	/**
	 * Setter for wsImportDate attribute.
	 * @param wsImportDate the new value of wsImportDate
	 */
	public void setWsImportDate(String wsImportDate) {
		this.wsImportDate.setValue(wsImportDate);
	}
	/**
	 * Gets the reference for attribute wsImportTime.
	 * @return the wsImportTime attribute reference
	 */
	public ElementaryRangeReference getWsImportTimeReference() {
		return wsImportTime.getReference();
	}

	/**
	 * Getter for wsImportTime attribute.
	 * @return wsImportTime attribute
	 */
	public String getWsImportTime() {
		return wsImportTime.getValue();
	}

	/**
	 * Setter for wsImportTime attribute.
	 * @param wsImportTime the new value of wsImportTime
	 */
	public void setWsImportTime(String wsImportTime) {
		this.wsImportTime.setValue(wsImportTime);
	}
}
