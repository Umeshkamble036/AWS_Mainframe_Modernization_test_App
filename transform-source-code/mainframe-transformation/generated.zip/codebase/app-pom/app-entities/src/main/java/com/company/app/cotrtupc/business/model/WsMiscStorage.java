package com.company.app.cotrtupc.business.model;

import com.netfective.bluage.gapwalk.datasimplifier.configuration.Configuration;
import com.netfective.bluage.gapwalk.datasimplifier.data.Record;
import com.netfective.bluage.gapwalk.datasimplifier.data.RecordAdaptable;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Elementary;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Filler;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Group;
import com.netfective.bluage.gapwalk.datasimplifier.data.structure.Union;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ConditionReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.ElementaryRangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RangeReference;
import com.netfective.bluage.gapwalk.datasimplifier.entity.RecordEntity;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.ConditionName;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.AlphanumericType;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.BinaryType;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.NumericEditedType;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.PackedType;
import com.netfective.bluage.gapwalk.datasimplifier.metadata.type.ZonedType;
/**
 * Data simplifier entity WsMiscStorage.
<pre>
 * 
 * Legacy Documentation:<br>
 *  *************************************** *************************<br>
 *   Program:     COTRTUPC.CBL                                      *<br>
 *   Layer:       Business logic                                    *<br>
 *   Function:    Accept and process TRANSACTION TYPE UPDATE        *<br>
 *  *****************************************************************<br>
 *   Copyright Amazon.com, Inc. or its affiliates.<br>
 *   All Rights Reserved.<br>
 *  <br>
 *   Licensed under the Apache License, Version 2.0 (the "License").<br>
 *   You may not use this file except in compliance with the License.<br>
 *   You may obtain a copy of the License at<br>
 *  <br>
 *      http://www.apache.org/licenses/LICENSE-2.0<br>
 *  <br>
 *   Unless required by applicable law or agreed to in writing,<br>
 *   software distributed under the License is distributed on an<br>
 *   "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,<br>
 *   either express or implied. See the License for the specific<br>
 *   language governing permissions and limitations under the License<br>
 *  *****************************************************************<br>
</pre>
 * 
 * <p>About 'wsCicsProcessngVars' field, <br>uml entity: com.company.app.cotrtupc.business.model.WsCicsProcessngVars
 * <br></p>
 * 
 * <p>About 'wsGenericEdits' field, <br>uml entity: com.company.app.cotrtupc.business.model.WsGenericEdits
 * <br></p>
 * 
 * <p>About 'wsMiscVars' field, <br>uml entity: com.company.app.cotrtupc.business.model.WsMiscVars
 * <br></p>
 * 
 * <p>About 'wsDatachangedFlag' field, <br>
 *  ****************************************************************<br>
 *      Generic date edit variables CCYYMMDD<br>
 *  ****************************************************************<br>
 *  ****************************************************************<br></p>
 * 
 * <p>About 'noChangesFound' field, <br>
 * </p>
 * 
 * <p>About 'changeHasOccurred' field, <br>
 * </p>
 * 
 * <p>About 'wsInputFlag' field, <br>
 * </p>
 * 
 * <p>About 'inputOk' field, <br>
 * </p>
 * 
 * <p>About 'inputError' field, <br>
 * </p>
 * 
 * <p>About 'inputPending' field, <br>
 * </p>
 * 
 * <p>About 'wsReturnFlag' field, <br>
 * </p>
 * 
 * <p>About 'wsReturnFlagOff' field, <br>
 * </p>
 * 
 * <p>About 'wsReturnFlagOn' field, <br>
 * </p>
 * 
 * <p>About 'wsPfkFlag' field, <br>
 * </p>
 * 
 * <p>About 'pfkValid' field, <br>
 * </p>
 * 
 * <p>About 'pfkInvalid' field, <br>
 * </p>
 * 
 * <p>About 'wsEditTtypFlag' field, <br>
 *    Program specific edits<br>
 *  <br></p>
 * 
 * <p>About 'flgTranfilterIsvalid' field, <br>
 * </p>
 * 
 * <p>About 'flgTranfilterNotOk' field, <br>
 * </p>
 * 
 * <p>About 'flgTranfilterBlank' field, <br>
 * </p>
 * 
 * <p>About 'wsNonKeyFlags' field, <br>uml entity: com.company.app.cotrtupc.business.model.WsNonKeyFlags
 * <br></p>
 * 
 * <p>About 'cicsOutputEditVars' field, <br>uml entity: com.company.app.cotrtupc.business.model.CicsOutputEditVars
 * <br></p>
 * 
 * <p>About 'wsTableReadFlags' field, <br>uml entity: com.company.app.cotrtupc.business.model.WsTableReadFlags
 * <br></p>
 * 
 * <p>About 'ttypUpdateRecord' field, <br>uml entity: com.company.app.cotrtupc.business.model.TtypUpdateRecord
 * <br></p>
 * 
 * <p>About 'wsInfoMsg' field, <br>
 *  ****************************************************************<br>
 *        Output Message Construction<br>
 *  ****************************************************************<br></p>
 * 
 * <p>About 'wsNoInfoMessage' field, <br>
 * </p>
 * 
 * <p>About 'foundTrantypeData' field, <br>
 * </p>
 * 
 * <p>About 'promptForSearchKeys' field, <br>
 * </p>
 * 
 * <p>About 'promptCreateNewRecord' field, <br>
 * </p>
 * 
 * <p>About 'promptDeleteConfirm' field, <br>
 * </p>
 * 
 * <p>About 'confirmDeleteSuccess' field, <br>
 * </p>
 * 
 * <p>About 'promptForChanges' field, <br>
 * </p>
 * 
 * <p>About 'promptForNewdata' field, <br>
 * </p>
 * 
 * <p>About 'promptForConfirmation' field, <br>
 * </p>
 * 
 * <p>About 'confirmUpdateSuccess' field, <br>
 * </p>
 * 
 * <p>About 'informFailure' field, <br>
 * </p>
 * 
 * <p>About 'wsReturnMsg' field, <br>
 * </p>
 * 
 * <p>About 'wsReturnMsgOff' field, <br>
 * </p>
 * 
 * <p>About 'wsExitMessage' field, <br>
 * </p>
 * 
 * <p>About 'wsInvalidKey' field, <br>
 * </p>
 * 
 * <p>About 'wsNameMustBeAlpha' field, <br>
 * </p>
 * 
 * <p>About 'wsRecordNotFound' field, <br>
 * </p>
 * 
 * <p>About 'noSearchCriteriaReceived' field, <br>
 * </p>
 * 
 * <p>About 'noChangesDetected' field, <br>
 * </p>
 * 
 * <p>About 'couldNotLockRecForUpdate' field, <br>
 * </p>
 * 
 * <p>About 'dataWasChangedBeforeUpdate' field, <br>
 * </p>
 * 
 * <p>About 'wsUpdateWasCancelled' field, <br>
 * </p>
 * 
 * <p>About 'tableUpdateFailed' field, <br>
 * </p>
 * 
 * <p>About 'recordDeleteFailed' field, <br>
 * </p>
 * 
 * <p>About 'wsDeleteWasCancelled' field, <br>
 * </p>
 * 
 * <p>About 'wsInvalidKeyPressed' field, <br>
 * </p>
 * 
 * <p>About 'codingToBeDone' field, <br>
 * </p>
 * 
 * @see RecordEntity
 */
public class WsMiscStorage extends RecordEntity {

	private final Group root = new Group(getData()); 
	
	/**
	 * ****************************************************************
	 * General CICS related
	 * ****************************************************************
	 */
	private final Group wsCicsProcessngVars = new Group(root);
	private final Elementary wsRespCd = new Elementary(wsCicsProcessngVars,new BinaryType(9, 0, "STD", false, false, true),Integer.valueOf("0"));
	private final Elementary wsReasCd = new Elementary(wsCicsProcessngVars,new BinaryType(9, 0, "STD", false, false, true),Integer.valueOf("0"));
	private final Elementary wsTranid = new Elementary(wsCicsProcessngVars,new AlphanumericType(4)," ");
	private final Elementary wsUctrans = new Elementary(wsCicsProcessngVars,new AlphanumericType(4)," ");
	
	/**
	 * ****************************************************************
	 * Input edits
	 * ****************************************************************
	 * Generic Input Edits
	 */
	private final Group wsGenericEdits = new Group(root);
	private final Elementary wsEditVariableName = new Elementary(wsGenericEdits,new AlphanumericType(25));
	private final Elementary wsEditAlphanumOnly = new Elementary(wsGenericEdits,new AlphanumericType(256));
	private final Elementary wsEditAlphanumLength = new Elementary(wsGenericEdits,new PackedType(4, 0, false, false, true));
	private final Elementary wsEditAlphanumOnlyFlags = new Elementary(wsGenericEdits,new AlphanumericType(1));
	private final ConditionName flgAlphnanumIsvalid=new ConditionName(wsEditAlphanumOnlyFlags,Record.LOW_VALUES);
	private final ConditionName flgAlphnanumNotOk=new ConditionName(wsEditAlphanumOnlyFlags,"0");
	private final ConditionName flgAlphnanumBlank=new ConditionName(wsEditAlphanumOnlyFlags,"B");
	
	/**
	 * ****************************************************************
	 * Work variables
	 * ****************************************************************
	 */
	private final Group wsMiscVars = new Group(root);
	private final Elementary wsDispSqlcode = new Elementary(wsMiscVars,new NumericEditedType("----9"));
	private final Elementary wsStringMid = new Elementary(wsMiscVars,new ZonedType(3, 0, false),Short.valueOf("0"));
	private final Elementary wsStringLen = new Elementary(wsMiscVars,new ZonedType(3, 0, false),Short.valueOf("0"));
	private final Elementary wsStringOut = new Elementary(wsMiscVars,new AlphanumericType(40));
	
	/**
	 * ****************************************************************
	 * Generic date edit variables CCYYMMDD
	 * ****************************************************************
	 * ****************************************************************
	 */
	private final Elementary wsDatachangedFlag = new Elementary(root,new AlphanumericType(1));
	private final ConditionName noChangesFound=new ConditionName(wsDatachangedFlag,"0");
	private final ConditionName changeHasOccurred=new ConditionName(wsDatachangedFlag,"1");
	private final Elementary wsInputFlag = new Elementary(root,new AlphanumericType(1));
	private final ConditionName inputOk=new ConditionName(wsInputFlag,"0");
	private final ConditionName inputError=new ConditionName(wsInputFlag,"1");
	private final ConditionName inputPending=new ConditionName(wsInputFlag,Record.LOW_VALUES);
	private final Elementary wsReturnFlag = new Elementary(root,new AlphanumericType(1));
	private final ConditionName wsReturnFlagOff=new ConditionName(wsReturnFlag,Record.LOW_VALUES);
	private final ConditionName wsReturnFlagOn=new ConditionName(wsReturnFlag,"1");
	private final Elementary wsPfkFlag = new Elementary(root,new AlphanumericType(1));
	private final ConditionName pfkValid=new ConditionName(wsPfkFlag,"0");
	private final ConditionName pfkInvalid=new ConditionName(wsPfkFlag,"1");
	
	/**
	 * Program specific edits
	 * 
	 */
	private final Elementary wsEditTtypFlag = new Elementary(root,new AlphanumericType(1));
	private final ConditionName flgTranfilterIsvalid=new ConditionName(wsEditTtypFlag,Record.LOW_VALUES);
	private final ConditionName flgTranfilterNotOk=new ConditionName(wsEditTtypFlag,"0");
	private final ConditionName flgTranfilterBlank=new ConditionName(wsEditTtypFlag,"B");
	private final Group wsNonKeyFlags = new Group(root);
	private final Elementary wsEditDescFlags = new Elementary(wsNonKeyFlags,new AlphanumericType(1));
	private final ConditionName flgDescriptionIsvalid=new ConditionName(wsEditDescFlags,Record.LOW_VALUES);
	private final ConditionName flgDescriptionNotOk=new ConditionName(wsEditDescFlags,"0");
	private final ConditionName flgDescriptionBlank=new ConditionName(wsEditDescFlags,"B");
	
	/**
	 * ****************************************************************
	 * Output edits
	 * ****************************************************************
	 */
	private final Group cicsOutputEditVars = new Group(root);
	private final Union union = new Union(cicsOutputEditVars);
	@SuppressWarnings("unused")
	private final Filler filler = new Filler(union,new AlphanumericType(10));
	private final Group group = new Group(union);
	private final Elementary wsEditDateXYear = new Elementary(group,new AlphanumericType(4));
	@SuppressWarnings("unused")
	private final Filler filler1 = new Filler(group,new AlphanumericType(1));
	private final Elementary wsEditDateMonth = new Elementary(group,new AlphanumericType(2));
	@SuppressWarnings("unused")
	private final Filler filler2 = new Filler(group,new AlphanumericType(1));
	private final Elementary wsEditDateDay = new Elementary(group,new AlphanumericType(2));
	private final Union union1 = new Union(cicsOutputEditVars);
	@SuppressWarnings("unused")
	private final Filler filler3 = new Filler(union1,new ZonedType(10, 0, false));
	@SuppressWarnings("unused")
	private final Filler filler4 = new Filler(union1,new ZonedType(10, 0, false));
	private final Elementary wsEditCurrency92 = new Elementary(cicsOutputEditVars,new AlphanumericType(15));
	private final Elementary wsEditCurrency92F = new Elementary(cicsOutputEditVars,new NumericEditedType("+ZZZ,ZZZ,ZZZ.99"));
	private final Elementary wsEditNumeric2 = new Elementary(cicsOutputEditVars,new ZonedType(2, 0, false));
	private final Elementary wsEditAlphanumeric2 = new Elementary(cicsOutputEditVars,new AlphanumericType(2));
	
	/**
	 * ****************************************************************
	 * File and data Handling
	 * ****************************************************************
	 */
	private final Group wsTableReadFlags = new Group(root);
	private final Elementary wsTrantypeMasterReadFlag = new Elementary(wsTableReadFlags,new AlphanumericType(1));
	private final ConditionName foundTrantypeInTable=new ConditionName(wsTrantypeMasterReadFlag,"1");
	
	/**
	 * Alpha variables for editing numerics
	 * 
	 */
	private final Group ttypUpdateRecord = new Group(root);
	
	/**
	 * ****************************************************************
	 * Data-structure for  TRANSACTION TYPE (RECLN 60)
	 * ****************************************************************
	 */
	private final Elementary ttupUpdateTtypType = new Elementary(ttypUpdateRecord,new AlphanumericType(2));
	private final Elementary ttupUpdateTtypTypeDesc = new Elementary(ttypUpdateRecord,new AlphanumericType(50));
	@SuppressWarnings("unused")
	private final Filler filler5 = new Filler(ttypUpdateRecord,new AlphanumericType(8));
	
	/**
	 * ****************************************************************
	 * Output Message Construction
	 * ****************************************************************
	 */
	private final Elementary wsInfoMsg = new Elementary(root,new AlphanumericType(40));
	private final ConditionName wsNoInfoMessage=new ConditionName(wsInfoMsg," ",
	Record.LOW_VALUES);
	private final ConditionName foundTrantypeData=new ConditionName(wsInfoMsg,"Selected transaction type shown above");
	private final ConditionName promptForSearchKeys=new ConditionName(wsInfoMsg,"Enter transaction type to be maintained");
	private final ConditionName promptCreateNewRecord=new ConditionName(wsInfoMsg,"Press F05 to add. F12 to cancel");
	private final ConditionName promptDeleteConfirm=new ConditionName(wsInfoMsg,"Delete this record ? Press F4 to confirm");
	private final ConditionName confirmDeleteSuccess=new ConditionName(wsInfoMsg,"Delete successful.");
	private final ConditionName promptForChanges=new ConditionName(wsInfoMsg,"Update transaction type details shown.");
	private final ConditionName promptForNewdata=new ConditionName(wsInfoMsg,"Enter new transaction type details.");
	private final ConditionName promptForConfirmation=new ConditionName(wsInfoMsg,"Changes validated.Press F5 to save");
	private final ConditionName confirmUpdateSuccess=new ConditionName(wsInfoMsg,"Changes committed to database");
	private final ConditionName informFailure=new ConditionName(wsInfoMsg,"Changes unsuccessful");
	private final Elementary wsReturnMsg = new Elementary(root,new AlphanumericType(75));
	private final ConditionName wsReturnMsgOff=new ConditionName(wsReturnMsg," ");
	private final ConditionName wsExitMessage=new ConditionName(wsReturnMsg,"PF03 pressed.Exiting              ");
	private final ConditionName wsInvalidKey=new ConditionName(wsReturnMsg,"Invalid Key pressed. ");
	private final ConditionName wsNameMustBeAlpha=new ConditionName(wsReturnMsg,"Name can only contain alphabets and spaces");
	private final ConditionName wsRecordNotFound=new ConditionName(wsReturnMsg,"No record found for this key in database");
	private final ConditionName noSearchCriteriaReceived=new ConditionName(wsReturnMsg,"No input received");
	private final ConditionName noChangesDetected=new ConditionName(wsReturnMsg,"No change detected with respect to values fetched.");
	private final ConditionName couldNotLockRecForUpdate=new ConditionName(wsReturnMsg,"Could not lock record for update");
	private final ConditionName dataWasChangedBeforeUpdate=new ConditionName(wsReturnMsg,"Record changed by some one else. Please review");
	private final ConditionName wsUpdateWasCancelled=new ConditionName(wsReturnMsg,"Update was cancelled");
	private final ConditionName tableUpdateFailed=new ConditionName(wsReturnMsg,"Update of record failed");
	private final ConditionName recordDeleteFailed=new ConditionName(wsReturnMsg,"Delete of record failed");
	private final ConditionName wsDeleteWasCancelled=new ConditionName(wsReturnMsg,"Delete was cancelled");
	private final ConditionName wsInvalidKeyPressed=new ConditionName(wsReturnMsg,"Invalid key pressed");
	private final ConditionName codingToBeDone=new ConditionName(wsReturnMsg,"Looks Good.... so far");
	
	/**
	 * Instantiate a new WsMiscStorage with a default record.
	 * @param configuration the configuration
	 */
	public WsMiscStorage(Configuration configuration) {
		super(configuration);
		setupRoot(root);
	}

	/**
	 * Instantiate a new WsMiscStorage bound to the provided record.
	 * @param configuration the configuration
	 * @param record the existing record to bind
	 */
	public WsMiscStorage(Configuration configuration, RecordAdaptable record) {
		super(configuration);
		setupRoot(root, record);
	}

	
	/**
	 * Gets the reference for attribute wsCicsProcessngVars.
	 * @return the wsCicsProcessngVars attribute reference
	 */
	public RangeReference getWsCicsProcessngVarsReference() {
		return wsCicsProcessngVars.getReference();
	}	
				
	/**
	 * Setter for wsCicsProcessngVars .
	 */
   	public void setWsCicsProcessngVars(RangeReference reference) {
       	wsCicsProcessngVars.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute wsRespCd.
	 * @return the wsRespCd attribute reference
	 */
	public ElementaryRangeReference getWsRespCdReference() {
		return wsRespCd.getReference();
	}

	/**
	 * Getter for wsRespCd attribute.
	 * @return wsRespCd attribute
	 */
	public int getWsRespCd() {
		return wsRespCd.getValue();
	}

	/**
	 * Setter for wsRespCd attribute.
	 * @param wsRespCd the new value of wsRespCd
	 */
	public void setWsRespCd(int wsRespCd) {
		this.wsRespCd.setValue(wsRespCd);
	}
	/**
	 * Gets the reference for attribute wsReasCd.
	 * @return the wsReasCd attribute reference
	 */
	public ElementaryRangeReference getWsReasCdReference() {
		return wsReasCd.getReference();
	}

	/**
	 * Getter for wsReasCd attribute.
	 * @return wsReasCd attribute
	 */
	public int getWsReasCd() {
		return wsReasCd.getValue();
	}

	/**
	 * Setter for wsReasCd attribute.
	 * @param wsReasCd the new value of wsReasCd
	 */
	public void setWsReasCd(int wsReasCd) {
		this.wsReasCd.setValue(wsReasCd);
	}
	/**
	 * Gets the reference for attribute wsTranid.
	 * @return the wsTranid attribute reference
	 */
	public ElementaryRangeReference getWsTranidReference() {
		return wsTranid.getReference();
	}

	/**
	 * Getter for wsTranid attribute.
	 * @return wsTranid attribute
	 */
	public String getWsTranid() {
		return wsTranid.getValue();
	}

	/**
	 * Setter for wsTranid attribute.
	 * @param wsTranid the new value of wsTranid
	 */
	public void setWsTranid(String wsTranid) {
		this.wsTranid.setValue(wsTranid);
	}
	/**
	 * Gets the reference for attribute wsUctrans.
	 * @return the wsUctrans attribute reference
	 */
	public ElementaryRangeReference getWsUctransReference() {
		return wsUctrans.getReference();
	}

	/**
	 * Getter for wsUctrans attribute.
	 * @return wsUctrans attribute
	 */
	public String getWsUctrans() {
		return wsUctrans.getValue();
	}

	/**
	 * Setter for wsUctrans attribute.
	 * @param wsUctrans the new value of wsUctrans
	 */
	public void setWsUctrans(String wsUctrans) {
		this.wsUctrans.setValue(wsUctrans);
	}
	
	/**
	 * Gets the reference for attribute wsGenericEdits.
	 * @return the wsGenericEdits attribute reference
	 */
	public RangeReference getWsGenericEditsReference() {
		return wsGenericEdits.getReference();
	}	
				
	/**
	 * Setter for wsGenericEdits .
	 */
   	public void setWsGenericEdits(RangeReference reference) {
       	wsGenericEdits.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute wsEditVariableName.
	 * @return the wsEditVariableName attribute reference
	 */
	public ElementaryRangeReference getWsEditVariableNameReference() {
		return wsEditVariableName.getReference();
	}

	/**
	 * Getter for wsEditVariableName attribute.
	 * @return wsEditVariableName attribute
	 */
	public String getWsEditVariableName() {
		return wsEditVariableName.getValue();
	}

	/**
	 * Setter for wsEditVariableName attribute.
	 * @param wsEditVariableName the new value of wsEditVariableName
	 */
	public void setWsEditVariableName(String wsEditVariableName) {
		this.wsEditVariableName.setValue(wsEditVariableName);
	}
	/**
	 * Gets the reference for attribute wsEditAlphanumOnly.
	 * @return the wsEditAlphanumOnly attribute reference
	 */
	public ElementaryRangeReference getWsEditAlphanumOnlyReference() {
		return wsEditAlphanumOnly.getReference();
	}

	/**
	 * Getter for wsEditAlphanumOnly attribute.
	 * @return wsEditAlphanumOnly attribute
	 */
	public String getWsEditAlphanumOnly() {
		return wsEditAlphanumOnly.getValue();
	}

	/**
	 * Setter for wsEditAlphanumOnly attribute.
	 * @param wsEditAlphanumOnly the new value of wsEditAlphanumOnly
	 */
	public void setWsEditAlphanumOnly(String wsEditAlphanumOnly) {
		this.wsEditAlphanumOnly.setValue(wsEditAlphanumOnly);
	}
	/**
	 * Gets the reference for attribute wsEditAlphanumLength.
	 * @return the wsEditAlphanumLength attribute reference
	 */
	public ElementaryRangeReference getWsEditAlphanumLengthReference() {
		return wsEditAlphanumLength.getReference();
	}

	/**
	 * Getter for wsEditAlphanumLength attribute.
	 * @return wsEditAlphanumLength attribute
	 */
	public int getWsEditAlphanumLength() {
		return wsEditAlphanumLength.getValue();
	}

	/**
	 * Setter for wsEditAlphanumLength attribute.
	 * @param wsEditAlphanumLength the new value of wsEditAlphanumLength
	 */
	public void setWsEditAlphanumLength(int wsEditAlphanumLength) {
		this.wsEditAlphanumLength.setValue(wsEditAlphanumLength);
	}
	/**
	 * Gets the reference for attribute wsEditAlphanumOnlyFlags.
	 * @return the wsEditAlphanumOnlyFlags attribute reference
	 */
	public ElementaryRangeReference getWsEditAlphanumOnlyFlagsReference() {
		return wsEditAlphanumOnlyFlags.getReference();
	}

	/**
	 * Getter for wsEditAlphanumOnlyFlags attribute.
	 * @return wsEditAlphanumOnlyFlags attribute
	 */
	public String getWsEditAlphanumOnlyFlags() {
		return wsEditAlphanumOnlyFlags.getValue();
	}

	/**
	 * Setter for wsEditAlphanumOnlyFlags attribute.
	 * @param wsEditAlphanumOnlyFlags the new value of wsEditAlphanumOnlyFlags
	 */
	public void setWsEditAlphanumOnlyFlags(String wsEditAlphanumOnlyFlags) {
		this.wsEditAlphanumOnlyFlags.setValue(wsEditAlphanumOnlyFlags);
	}
	/**
	 * Gets the reference for attribute flgAlphnanumIsvalid.
	 * @return the flgAlphnanumIsvalid attribute reference
	 */
	public ConditionReference getFlgAlphnanumIsvalidReference() {
		return wsEditAlphanumOnlyFlags.getCondition(flgAlphnanumIsvalid);	
	}

	/**
	 * Getter for flgAlphnanumIsvalid attribute.
	 * @return flgAlphnanumIsvalid attribute
	 */
	public boolean isFlgAlphnanumIsvalid() {
		return getFlgAlphnanumIsvalidReference().getValue();	
	}

	/**
	 * Setter for flgAlphnanumIsvalid attribute.
	 * @param flgAlphnanumIsvalid the new value of flgAlphnanumIsvalid
	 */
	public void setFlgAlphnanumIsvalid(boolean flgAlphnanumIsvalid) {
		getFlgAlphnanumIsvalidReference().setValue(flgAlphnanumIsvalid);	
	}
	/**
	 * Gets the reference for attribute flgAlphnanumNotOk.
	 * @return the flgAlphnanumNotOk attribute reference
	 */
	public ConditionReference getFlgAlphnanumNotOkReference() {
		return wsEditAlphanumOnlyFlags.getCondition(flgAlphnanumNotOk);	
	}

	/**
	 * Getter for flgAlphnanumNotOk attribute.
	 * @return flgAlphnanumNotOk attribute
	 */
	public boolean isFlgAlphnanumNotOk() {
		return getFlgAlphnanumNotOkReference().getValue();	
	}

	/**
	 * Setter for flgAlphnanumNotOk attribute.
	 * @param flgAlphnanumNotOk the new value of flgAlphnanumNotOk
	 */
	public void setFlgAlphnanumNotOk(boolean flgAlphnanumNotOk) {
		getFlgAlphnanumNotOkReference().setValue(flgAlphnanumNotOk);	
	}
	/**
	 * Gets the reference for attribute flgAlphnanumBlank.
	 * @return the flgAlphnanumBlank attribute reference
	 */
	public ConditionReference getFlgAlphnanumBlankReference() {
		return wsEditAlphanumOnlyFlags.getCondition(flgAlphnanumBlank);	
	}

	/**
	 * Getter for flgAlphnanumBlank attribute.
	 * @return flgAlphnanumBlank attribute
	 */
	public boolean isFlgAlphnanumBlank() {
		return getFlgAlphnanumBlankReference().getValue();	
	}

	/**
	 * Setter for flgAlphnanumBlank attribute.
	 * @param flgAlphnanumBlank the new value of flgAlphnanumBlank
	 */
	public void setFlgAlphnanumBlank(boolean flgAlphnanumBlank) {
		getFlgAlphnanumBlankReference().setValue(flgAlphnanumBlank);	
	}
	
	/**
	 * Gets the reference for attribute wsMiscVars.
	 * @return the wsMiscVars attribute reference
	 */
	public RangeReference getWsMiscVarsReference() {
		return wsMiscVars.getReference();
	}	
				
	/**
	 * Setter for wsMiscVars .
	 */
   	public void setWsMiscVars(RangeReference reference) {
       	wsMiscVars.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute wsDispSqlcode.
	 * @return the wsDispSqlcode attribute reference
	 */
	public ElementaryRangeReference getWsDispSqlcodeReference() {
		return wsDispSqlcode.getReference();
	}

	/**
	 * Getter for wsDispSqlcode attribute.
	 * @return wsDispSqlcode attribute
	 */
	public String getWsDispSqlcode() {
		return wsDispSqlcode.getValue();
	}

	/**
	 * Setter for wsDispSqlcode attribute.
	 * @param wsDispSqlcode the new value of wsDispSqlcode
	 */
	public void setWsDispSqlcode(String wsDispSqlcode) {
		this.wsDispSqlcode.setValue(wsDispSqlcode);
	}
	/**
	 * Gets the reference for attribute wsStringMid.
	 * @return the wsStringMid attribute reference
	 */
	public ElementaryRangeReference getWsStringMidReference() {
		return wsStringMid.getReference();
	}

	/**
	 * Getter for wsStringMid attribute.
	 * @return wsStringMid attribute
	 */
	public int getWsStringMid() {
		return wsStringMid.getValue();
	}

	/**
	 * Setter for wsStringMid attribute.
	 * @param wsStringMid the new value of wsStringMid
	 */
	public void setWsStringMid(int wsStringMid) {
		this.wsStringMid.setValue(wsStringMid);
	}
	/**
	 * Gets the reference for attribute wsStringLen.
	 * @return the wsStringLen attribute reference
	 */
	public ElementaryRangeReference getWsStringLenReference() {
		return wsStringLen.getReference();
	}

	/**
	 * Getter for wsStringLen attribute.
	 * @return wsStringLen attribute
	 */
	public int getWsStringLen() {
		return wsStringLen.getValue();
	}

	/**
	 * Setter for wsStringLen attribute.
	 * @param wsStringLen the new value of wsStringLen
	 */
	public void setWsStringLen(int wsStringLen) {
		this.wsStringLen.setValue(wsStringLen);
	}
	/**
	 * Gets the reference for attribute wsStringOut.
	 * @return the wsStringOut attribute reference
	 */
	public ElementaryRangeReference getWsStringOutReference() {
		return wsStringOut.getReference();
	}

	/**
	 * Getter for wsStringOut attribute.
	 * @return wsStringOut attribute
	 */
	public String getWsStringOut() {
		return wsStringOut.getValue();
	}

	/**
	 * Setter for wsStringOut attribute.
	 * @param wsStringOut the new value of wsStringOut
	 */
	public void setWsStringOut(String wsStringOut) {
		this.wsStringOut.setValue(wsStringOut);
	}
	/**
	 * Gets the reference for attribute wsDatachangedFlag.
	 * @return the wsDatachangedFlag attribute reference
	 */
	public ElementaryRangeReference getWsDatachangedFlagReference() {
		return wsDatachangedFlag.getReference();
	}

	/**
	 * Getter for wsDatachangedFlag attribute.
	 * @return wsDatachangedFlag attribute
	 */
	public String getWsDatachangedFlag() {
		return wsDatachangedFlag.getValue();
	}

	/**
	 * Setter for wsDatachangedFlag attribute.
	 * @param wsDatachangedFlag the new value of wsDatachangedFlag
	 */
	public void setWsDatachangedFlag(String wsDatachangedFlag) {
		this.wsDatachangedFlag.setValue(wsDatachangedFlag);
	}
	/**
	 * Gets the reference for attribute noChangesFound.
	 * @return the noChangesFound attribute reference
	 */
	public ConditionReference getNoChangesFoundReference() {
		return wsDatachangedFlag.getCondition(noChangesFound);	
	}

	/**
	 * Getter for noChangesFound attribute.
	 * @return noChangesFound attribute
	 */
	public boolean isNoChangesFound() {
		return getNoChangesFoundReference().getValue();	
	}

	/**
	 * Setter for noChangesFound attribute.
	 * @param noChangesFound the new value of noChangesFound
	 */
	public void setNoChangesFound(boolean noChangesFound) {
		getNoChangesFoundReference().setValue(noChangesFound);	
	}
	/**
	 * Gets the reference for attribute changeHasOccurred.
	 * @return the changeHasOccurred attribute reference
	 */
	public ConditionReference getChangeHasOccurredReference() {
		return wsDatachangedFlag.getCondition(changeHasOccurred);	
	}

	/**
	 * Getter for changeHasOccurred attribute.
	 * @return changeHasOccurred attribute
	 */
	public boolean isChangeHasOccurred() {
		return getChangeHasOccurredReference().getValue();	
	}

	/**
	 * Setter for changeHasOccurred attribute.
	 * @param changeHasOccurred the new value of changeHasOccurred
	 */
	public void setChangeHasOccurred(boolean changeHasOccurred) {
		getChangeHasOccurredReference().setValue(changeHasOccurred);	
	}
	/**
	 * Gets the reference for attribute wsInputFlag.
	 * @return the wsInputFlag attribute reference
	 */
	public ElementaryRangeReference getWsInputFlagReference() {
		return wsInputFlag.getReference();
	}

	/**
	 * Getter for wsInputFlag attribute.
	 * @return wsInputFlag attribute
	 */
	public String getWsInputFlag() {
		return wsInputFlag.getValue();
	}

	/**
	 * Setter for wsInputFlag attribute.
	 * @param wsInputFlag the new value of wsInputFlag
	 */
	public void setWsInputFlag(String wsInputFlag) {
		this.wsInputFlag.setValue(wsInputFlag);
	}
	/**
	 * Gets the reference for attribute inputOk.
	 * @return the inputOk attribute reference
	 */
	public ConditionReference getInputOkReference() {
		return wsInputFlag.getCondition(inputOk);	
	}

	/**
	 * Getter for inputOk attribute.
	 * @return inputOk attribute
	 */
	public boolean isInputOk() {
		return getInputOkReference().getValue();	
	}

	/**
	 * Setter for inputOk attribute.
	 * @param inputOk the new value of inputOk
	 */
	public void setInputOk(boolean inputOk) {
		getInputOkReference().setValue(inputOk);	
	}
	/**
	 * Gets the reference for attribute inputError.
	 * @return the inputError attribute reference
	 */
	public ConditionReference getInputErrorReference() {
		return wsInputFlag.getCondition(inputError);	
	}

	/**
	 * Getter for inputError attribute.
	 * @return inputError attribute
	 */
	public boolean isInputError() {
		return getInputErrorReference().getValue();	
	}

	/**
	 * Setter for inputError attribute.
	 * @param inputError the new value of inputError
	 */
	public void setInputError(boolean inputError) {
		getInputErrorReference().setValue(inputError);	
	}
	/**
	 * Gets the reference for attribute inputPending.
	 * @return the inputPending attribute reference
	 */
	public ConditionReference getInputPendingReference() {
		return wsInputFlag.getCondition(inputPending);	
	}

	/**
	 * Getter for inputPending attribute.
	 * @return inputPending attribute
	 */
	public boolean isInputPending() {
		return getInputPendingReference().getValue();	
	}

	/**
	 * Setter for inputPending attribute.
	 * @param inputPending the new value of inputPending
	 */
	public void setInputPending(boolean inputPending) {
		getInputPendingReference().setValue(inputPending);	
	}
	/**
	 * Gets the reference for attribute wsReturnFlag.
	 * @return the wsReturnFlag attribute reference
	 */
	public ElementaryRangeReference getWsReturnFlagReference() {
		return wsReturnFlag.getReference();
	}

	/**
	 * Getter for wsReturnFlag attribute.
	 * @return wsReturnFlag attribute
	 */
	public String getWsReturnFlag() {
		return wsReturnFlag.getValue();
	}

	/**
	 * Setter for wsReturnFlag attribute.
	 * @param wsReturnFlag the new value of wsReturnFlag
	 */
	public void setWsReturnFlag(String wsReturnFlag) {
		this.wsReturnFlag.setValue(wsReturnFlag);
	}
	/**
	 * Gets the reference for attribute wsReturnFlagOff.
	 * @return the wsReturnFlagOff attribute reference
	 */
	public ConditionReference getWsReturnFlagOffReference() {
		return wsReturnFlag.getCondition(wsReturnFlagOff);	
	}

	/**
	 * Getter for wsReturnFlagOff attribute.
	 * @return wsReturnFlagOff attribute
	 */
	public boolean isWsReturnFlagOff() {
		return getWsReturnFlagOffReference().getValue();	
	}

	/**
	 * Setter for wsReturnFlagOff attribute.
	 * @param wsReturnFlagOff the new value of wsReturnFlagOff
	 */
	public void setWsReturnFlagOff(boolean wsReturnFlagOff) {
		getWsReturnFlagOffReference().setValue(wsReturnFlagOff);	
	}
	/**
	 * Gets the reference for attribute wsReturnFlagOn.
	 * @return the wsReturnFlagOn attribute reference
	 */
	public ConditionReference getWsReturnFlagOnReference() {
		return wsReturnFlag.getCondition(wsReturnFlagOn);	
	}

	/**
	 * Getter for wsReturnFlagOn attribute.
	 * @return wsReturnFlagOn attribute
	 */
	public boolean isWsReturnFlagOn() {
		return getWsReturnFlagOnReference().getValue();	
	}

	/**
	 * Setter for wsReturnFlagOn attribute.
	 * @param wsReturnFlagOn the new value of wsReturnFlagOn
	 */
	public void setWsReturnFlagOn(boolean wsReturnFlagOn) {
		getWsReturnFlagOnReference().setValue(wsReturnFlagOn);	
	}
	/**
	 * Gets the reference for attribute wsPfkFlag.
	 * @return the wsPfkFlag attribute reference
	 */
	public ElementaryRangeReference getWsPfkFlagReference() {
		return wsPfkFlag.getReference();
	}

	/**
	 * Getter for wsPfkFlag attribute.
	 * @return wsPfkFlag attribute
	 */
	public String getWsPfkFlag() {
		return wsPfkFlag.getValue();
	}

	/**
	 * Setter for wsPfkFlag attribute.
	 * @param wsPfkFlag the new value of wsPfkFlag
	 */
	public void setWsPfkFlag(String wsPfkFlag) {
		this.wsPfkFlag.setValue(wsPfkFlag);
	}
	/**
	 * Gets the reference for attribute pfkValid.
	 * @return the pfkValid attribute reference
	 */
	public ConditionReference getPfkValidReference() {
		return wsPfkFlag.getCondition(pfkValid);	
	}

	/**
	 * Getter for pfkValid attribute.
	 * @return pfkValid attribute
	 */
	public boolean isPfkValid() {
		return getPfkValidReference().getValue();	
	}

	/**
	 * Setter for pfkValid attribute.
	 * @param pfkValid the new value of pfkValid
	 */
	public void setPfkValid(boolean pfkValid) {
		getPfkValidReference().setValue(pfkValid);	
	}
	/**
	 * Gets the reference for attribute pfkInvalid.
	 * @return the pfkInvalid attribute reference
	 */
	public ConditionReference getPfkInvalidReference() {
		return wsPfkFlag.getCondition(pfkInvalid);	
	}

	/**
	 * Getter for pfkInvalid attribute.
	 * @return pfkInvalid attribute
	 */
	public boolean isPfkInvalid() {
		return getPfkInvalidReference().getValue();	
	}

	/**
	 * Setter for pfkInvalid attribute.
	 * @param pfkInvalid the new value of pfkInvalid
	 */
	public void setPfkInvalid(boolean pfkInvalid) {
		getPfkInvalidReference().setValue(pfkInvalid);	
	}
	/**
	 * Gets the reference for attribute wsEditTtypFlag.
	 * @return the wsEditTtypFlag attribute reference
	 */
	public ElementaryRangeReference getWsEditTtypFlagReference() {
		return wsEditTtypFlag.getReference();
	}

	/**
	 * Getter for wsEditTtypFlag attribute.
	 * @return wsEditTtypFlag attribute
	 */
	public String getWsEditTtypFlag() {
		return wsEditTtypFlag.getValue();
	}

	/**
	 * Setter for wsEditTtypFlag attribute.
	 * @param wsEditTtypFlag the new value of wsEditTtypFlag
	 */
	public void setWsEditTtypFlag(String wsEditTtypFlag) {
		this.wsEditTtypFlag.setValue(wsEditTtypFlag);
	}
	/**
	 * Gets the reference for attribute flgTranfilterIsvalid.
	 * @return the flgTranfilterIsvalid attribute reference
	 */
	public ConditionReference getFlgTranfilterIsvalidReference() {
		return wsEditTtypFlag.getCondition(flgTranfilterIsvalid);	
	}

	/**
	 * Getter for flgTranfilterIsvalid attribute.
	 * @return flgTranfilterIsvalid attribute
	 */
	public boolean isFlgTranfilterIsvalid() {
		return getFlgTranfilterIsvalidReference().getValue();	
	}

	/**
	 * Setter for flgTranfilterIsvalid attribute.
	 * @param flgTranfilterIsvalid the new value of flgTranfilterIsvalid
	 */
	public void setFlgTranfilterIsvalid(boolean flgTranfilterIsvalid) {
		getFlgTranfilterIsvalidReference().setValue(flgTranfilterIsvalid);	
	}
	/**
	 * Gets the reference for attribute flgTranfilterNotOk.
	 * @return the flgTranfilterNotOk attribute reference
	 */
	public ConditionReference getFlgTranfilterNotOkReference() {
		return wsEditTtypFlag.getCondition(flgTranfilterNotOk);	
	}

	/**
	 * Getter for flgTranfilterNotOk attribute.
	 * @return flgTranfilterNotOk attribute
	 */
	public boolean isFlgTranfilterNotOk() {
		return getFlgTranfilterNotOkReference().getValue();	
	}

	/**
	 * Setter for flgTranfilterNotOk attribute.
	 * @param flgTranfilterNotOk the new value of flgTranfilterNotOk
	 */
	public void setFlgTranfilterNotOk(boolean flgTranfilterNotOk) {
		getFlgTranfilterNotOkReference().setValue(flgTranfilterNotOk);	
	}
	/**
	 * Gets the reference for attribute flgTranfilterBlank.
	 * @return the flgTranfilterBlank attribute reference
	 */
	public ConditionReference getFlgTranfilterBlankReference() {
		return wsEditTtypFlag.getCondition(flgTranfilterBlank);	
	}

	/**
	 * Getter for flgTranfilterBlank attribute.
	 * @return flgTranfilterBlank attribute
	 */
	public boolean isFlgTranfilterBlank() {
		return getFlgTranfilterBlankReference().getValue();	
	}

	/**
	 * Setter for flgTranfilterBlank attribute.
	 * @param flgTranfilterBlank the new value of flgTranfilterBlank
	 */
	public void setFlgTranfilterBlank(boolean flgTranfilterBlank) {
		getFlgTranfilterBlankReference().setValue(flgTranfilterBlank);	
	}
	
	/**
	 * Gets the reference for attribute wsNonKeyFlags.
	 * @return the wsNonKeyFlags attribute reference
	 */
	public RangeReference getWsNonKeyFlagsReference() {
		return wsNonKeyFlags.getReference();
	}	
				
	/**
	 * Setter for wsNonKeyFlags .
	 */
   	public void setWsNonKeyFlags(RangeReference reference) {
       	wsNonKeyFlags.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute wsEditDescFlags.
	 * @return the wsEditDescFlags attribute reference
	 */
	public ElementaryRangeReference getWsEditDescFlagsReference() {
		return wsEditDescFlags.getReference();
	}

	/**
	 * Getter for wsEditDescFlags attribute.
	 * @return wsEditDescFlags attribute
	 */
	public String getWsEditDescFlags() {
		return wsEditDescFlags.getValue();
	}

	/**
	 * Setter for wsEditDescFlags attribute.
	 * @param wsEditDescFlags the new value of wsEditDescFlags
	 */
	public void setWsEditDescFlags(String wsEditDescFlags) {
		this.wsEditDescFlags.setValue(wsEditDescFlags);
	}
	/**
	 * Gets the reference for attribute flgDescriptionIsvalid.
	 * @return the flgDescriptionIsvalid attribute reference
	 */
	public ConditionReference getFlgDescriptionIsvalidReference() {
		return wsEditDescFlags.getCondition(flgDescriptionIsvalid);	
	}

	/**
	 * Getter for flgDescriptionIsvalid attribute.
	 * @return flgDescriptionIsvalid attribute
	 */
	public boolean isFlgDescriptionIsvalid() {
		return getFlgDescriptionIsvalidReference().getValue();	
	}

	/**
	 * Setter for flgDescriptionIsvalid attribute.
	 * @param flgDescriptionIsvalid the new value of flgDescriptionIsvalid
	 */
	public void setFlgDescriptionIsvalid(boolean flgDescriptionIsvalid) {
		getFlgDescriptionIsvalidReference().setValue(flgDescriptionIsvalid);	
	}
	/**
	 * Gets the reference for attribute flgDescriptionNotOk.
	 * @return the flgDescriptionNotOk attribute reference
	 */
	public ConditionReference getFlgDescriptionNotOkReference() {
		return wsEditDescFlags.getCondition(flgDescriptionNotOk);	
	}

	/**
	 * Getter for flgDescriptionNotOk attribute.
	 * @return flgDescriptionNotOk attribute
	 */
	public boolean isFlgDescriptionNotOk() {
		return getFlgDescriptionNotOkReference().getValue();	
	}

	/**
	 * Setter for flgDescriptionNotOk attribute.
	 * @param flgDescriptionNotOk the new value of flgDescriptionNotOk
	 */
	public void setFlgDescriptionNotOk(boolean flgDescriptionNotOk) {
		getFlgDescriptionNotOkReference().setValue(flgDescriptionNotOk);	
	}
	/**
	 * Gets the reference for attribute flgDescriptionBlank.
	 * @return the flgDescriptionBlank attribute reference
	 */
	public ConditionReference getFlgDescriptionBlankReference() {
		return wsEditDescFlags.getCondition(flgDescriptionBlank);	
	}

	/**
	 * Getter for flgDescriptionBlank attribute.
	 * @return flgDescriptionBlank attribute
	 */
	public boolean isFlgDescriptionBlank() {
		return getFlgDescriptionBlankReference().getValue();	
	}

	/**
	 * Setter for flgDescriptionBlank attribute.
	 * @param flgDescriptionBlank the new value of flgDescriptionBlank
	 */
	public void setFlgDescriptionBlank(boolean flgDescriptionBlank) {
		getFlgDescriptionBlankReference().setValue(flgDescriptionBlank);	
	}
	
	/**
	 * Gets the reference for attribute cicsOutputEditVars.
	 * @return the cicsOutputEditVars attribute reference
	 */
	public RangeReference getCicsOutputEditVarsReference() {
		return cicsOutputEditVars.getReference();
	}	
				
	/**
	 * Setter for cicsOutputEditVars .
	 */
   	public void setCicsOutputEditVars(RangeReference reference) {
       	cicsOutputEditVars.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute wsEditDateXYear.
	 * @return the wsEditDateXYear attribute reference
	 */
	public ElementaryRangeReference getWsEditDateXYearReference() {
		return wsEditDateXYear.getReference();
	}

	/**
	 * Getter for wsEditDateXYear attribute.
	 * @return wsEditDateXYear attribute
	 */
	public String getWsEditDateXYear() {
		return wsEditDateXYear.getValue();
	}

	/**
	 * Setter for wsEditDateXYear attribute.
	 * @param wsEditDateXYear the new value of wsEditDateXYear
	 */
	public void setWsEditDateXYear(String wsEditDateXYear) {
		this.wsEditDateXYear.setValue(wsEditDateXYear);
	}
	/**
	 * Gets the reference for attribute wsEditDateMonth.
	 * @return the wsEditDateMonth attribute reference
	 */
	public ElementaryRangeReference getWsEditDateMonthReference() {
		return wsEditDateMonth.getReference();
	}

	/**
	 * Getter for wsEditDateMonth attribute.
	 * @return wsEditDateMonth attribute
	 */
	public String getWsEditDateMonth() {
		return wsEditDateMonth.getValue();
	}

	/**
	 * Setter for wsEditDateMonth attribute.
	 * @param wsEditDateMonth the new value of wsEditDateMonth
	 */
	public void setWsEditDateMonth(String wsEditDateMonth) {
		this.wsEditDateMonth.setValue(wsEditDateMonth);
	}
	/**
	 * Gets the reference for attribute wsEditDateDay.
	 * @return the wsEditDateDay attribute reference
	 */
	public ElementaryRangeReference getWsEditDateDayReference() {
		return wsEditDateDay.getReference();
	}

	/**
	 * Getter for wsEditDateDay attribute.
	 * @return wsEditDateDay attribute
	 */
	public String getWsEditDateDay() {
		return wsEditDateDay.getValue();
	}

	/**
	 * Setter for wsEditDateDay attribute.
	 * @param wsEditDateDay the new value of wsEditDateDay
	 */
	public void setWsEditDateDay(String wsEditDateDay) {
		this.wsEditDateDay.setValue(wsEditDateDay);
	}
	/**
	 * Gets the reference for attribute wsEditCurrency92.
	 * @return the wsEditCurrency92 attribute reference
	 */
	public ElementaryRangeReference getWsEditCurrency92Reference() {
		return wsEditCurrency92.getReference();
	}

	/**
	 * Getter for wsEditCurrency92 attribute.
	 * @return wsEditCurrency92 attribute
	 */
	public String getWsEditCurrency92() {
		return wsEditCurrency92.getValue();
	}

	/**
	 * Setter for wsEditCurrency92 attribute.
	 * @param wsEditCurrency92 the new value of wsEditCurrency92
	 */
	public void setWsEditCurrency92(String wsEditCurrency92) {
		this.wsEditCurrency92.setValue(wsEditCurrency92);
	}
	/**
	 * Gets the reference for attribute wsEditCurrency92F.
	 * @return the wsEditCurrency92F attribute reference
	 */
	public ElementaryRangeReference getWsEditCurrency92FReference() {
		return wsEditCurrency92F.getReference();
	}

	/**
	 * Getter for wsEditCurrency92F attribute.
	 * @return wsEditCurrency92F attribute
	 */
	public String getWsEditCurrency92F() {
		return wsEditCurrency92F.getValue();
	}

	/**
	 * Setter for wsEditCurrency92F attribute.
	 * @param wsEditCurrency92F the new value of wsEditCurrency92F
	 */
	public void setWsEditCurrency92F(String wsEditCurrency92F) {
		this.wsEditCurrency92F.setValue(wsEditCurrency92F);
	}
	/**
	 * Gets the reference for attribute wsEditNumeric2.
	 * @return the wsEditNumeric2 attribute reference
	 */
	public ElementaryRangeReference getWsEditNumeric2Reference() {
		return wsEditNumeric2.getReference();
	}

	/**
	 * Getter for wsEditNumeric2 attribute.
	 * @return wsEditNumeric2 attribute
	 */
	public int getWsEditNumeric2() {
		return wsEditNumeric2.getValue();
	}

	/**
	 * Setter for wsEditNumeric2 attribute.
	 * @param wsEditNumeric2 the new value of wsEditNumeric2
	 */
	public void setWsEditNumeric2(int wsEditNumeric2) {
		this.wsEditNumeric2.setValue(wsEditNumeric2);
	}
	/**
	 * Gets the reference for attribute wsEditAlphanumeric2.
	 * @return the wsEditAlphanumeric2 attribute reference
	 */
	public ElementaryRangeReference getWsEditAlphanumeric2Reference() {
		return wsEditAlphanumeric2.getReference();
	}

	/**
	 * Getter for wsEditAlphanumeric2 attribute.
	 * @return wsEditAlphanumeric2 attribute
	 */
	public String getWsEditAlphanumeric2() {
		return wsEditAlphanumeric2.getValue();
	}

	/**
	 * Setter for wsEditAlphanumeric2 attribute.
	 * @param wsEditAlphanumeric2 the new value of wsEditAlphanumeric2
	 */
	public void setWsEditAlphanumeric2(String wsEditAlphanumeric2) {
		this.wsEditAlphanumeric2.setValue(wsEditAlphanumeric2);
	}
	
	/**
	 * Gets the reference for attribute wsTableReadFlags.
	 * @return the wsTableReadFlags attribute reference
	 */
	public RangeReference getWsTableReadFlagsReference() {
		return wsTableReadFlags.getReference();
	}	
				
	/**
	 * Setter for wsTableReadFlags .
	 */
   	public void setWsTableReadFlags(RangeReference reference) {
       	wsTableReadFlags.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute wsTrantypeMasterReadFlag.
	 * @return the wsTrantypeMasterReadFlag attribute reference
	 */
	public ElementaryRangeReference getWsTrantypeMasterReadFlagReference() {
		return wsTrantypeMasterReadFlag.getReference();
	}

	/**
	 * Getter for wsTrantypeMasterReadFlag attribute.
	 * @return wsTrantypeMasterReadFlag attribute
	 */
	public String getWsTrantypeMasterReadFlag() {
		return wsTrantypeMasterReadFlag.getValue();
	}

	/**
	 * Setter for wsTrantypeMasterReadFlag attribute.
	 * @param wsTrantypeMasterReadFlag the new value of wsTrantypeMasterReadFlag
	 */
	public void setWsTrantypeMasterReadFlag(String wsTrantypeMasterReadFlag) {
		this.wsTrantypeMasterReadFlag.setValue(wsTrantypeMasterReadFlag);
	}
	/**
	 * Gets the reference for attribute foundTrantypeInTable.
	 * @return the foundTrantypeInTable attribute reference
	 */
	public ConditionReference getFoundTrantypeInTableReference() {
		return wsTrantypeMasterReadFlag.getCondition(foundTrantypeInTable);	
	}

	/**
	 * Getter for foundTrantypeInTable attribute.
	 * @return foundTrantypeInTable attribute
	 */
	public boolean isFoundTrantypeInTable() {
		return getFoundTrantypeInTableReference().getValue();	
	}

	/**
	 * Setter for foundTrantypeInTable attribute.
	 * @param foundTrantypeInTable the new value of foundTrantypeInTable
	 */
	public void setFoundTrantypeInTable(boolean foundTrantypeInTable) {
		getFoundTrantypeInTableReference().setValue(foundTrantypeInTable);	
	}
	
	/**
	 * Gets the reference for attribute ttypUpdateRecord.
	 * @return the ttypUpdateRecord attribute reference
	 */
	public RangeReference getTtypUpdateRecordReference() {
		return ttypUpdateRecord.getReference();
	}	
				
	/**
	 * Setter for ttypUpdateRecord .
	 */
   	public void setTtypUpdateRecord(RangeReference reference) {
       	ttypUpdateRecord.getReference().setBytes(reference.getBytes());
   	}
 
	/**
	 * Gets the reference for attribute ttupUpdateTtypType.
	 * @return the ttupUpdateTtypType attribute reference
	 */
	public ElementaryRangeReference getTtupUpdateTtypTypeReference() {
		return ttupUpdateTtypType.getReference();
	}

	/**
	 * Getter for ttupUpdateTtypType attribute.
	 * @return ttupUpdateTtypType attribute
	 */
	public String getTtupUpdateTtypType() {
		return ttupUpdateTtypType.getValue();
	}

	/**
	 * Setter for ttupUpdateTtypType attribute.
	 * @param ttupUpdateTtypType the new value of ttupUpdateTtypType
	 */
	public void setTtupUpdateTtypType(String ttupUpdateTtypType) {
		this.ttupUpdateTtypType.setValue(ttupUpdateTtypType);
	}
	/**
	 * Gets the reference for attribute ttupUpdateTtypTypeDesc.
	 * @return the ttupUpdateTtypTypeDesc attribute reference
	 */
	public ElementaryRangeReference getTtupUpdateTtypTypeDescReference() {
		return ttupUpdateTtypTypeDesc.getReference();
	}

	/**
	 * Getter for ttupUpdateTtypTypeDesc attribute.
	 * @return ttupUpdateTtypTypeDesc attribute
	 */
	public String getTtupUpdateTtypTypeDesc() {
		return ttupUpdateTtypTypeDesc.getValue();
	}

	/**
	 * Setter for ttupUpdateTtypTypeDesc attribute.
	 * @param ttupUpdateTtypTypeDesc the new value of ttupUpdateTtypTypeDesc
	 */
	public void setTtupUpdateTtypTypeDesc(String ttupUpdateTtypTypeDesc) {
		this.ttupUpdateTtypTypeDesc.setValue(ttupUpdateTtypTypeDesc);
	}
	/**
	 * Gets the reference for attribute wsInfoMsg.
	 * @return the wsInfoMsg attribute reference
	 */
	public ElementaryRangeReference getWsInfoMsgReference() {
		return wsInfoMsg.getReference();
	}

	/**
	 * Getter for wsInfoMsg attribute.
	 * @return wsInfoMsg attribute
	 */
	public String getWsInfoMsg() {
		return wsInfoMsg.getValue();
	}

	/**
	 * Setter for wsInfoMsg attribute.
	 * @param wsInfoMsg the new value of wsInfoMsg
	 */
	public void setWsInfoMsg(String wsInfoMsg) {
		this.wsInfoMsg.setValue(wsInfoMsg);
	}
	/**
	 * Gets the reference for attribute wsNoInfoMessage.
	 * @return the wsNoInfoMessage attribute reference
	 */
	public ConditionReference getWsNoInfoMessageReference() {
		return wsInfoMsg.getCondition(wsNoInfoMessage);	
	}

	/**
	 * Getter for wsNoInfoMessage attribute.
	 * @return wsNoInfoMessage attribute
	 */
	public boolean isWsNoInfoMessage() {
		return getWsNoInfoMessageReference().getValue();	
	}

	/**
	 * Setter for wsNoInfoMessage attribute.
	 * @param wsNoInfoMessage the new value of wsNoInfoMessage
	 */
	public void setWsNoInfoMessage(boolean wsNoInfoMessage) {
		getWsNoInfoMessageReference().setValue(wsNoInfoMessage);	
	}
	/**
	 * Gets the reference for attribute foundTrantypeData.
	 * @return the foundTrantypeData attribute reference
	 */
	public ConditionReference getFoundTrantypeDataReference() {
		return wsInfoMsg.getCondition(foundTrantypeData);	
	}

	/**
	 * Getter for foundTrantypeData attribute.
	 * @return foundTrantypeData attribute
	 */
	public boolean isFoundTrantypeData() {
		return getFoundTrantypeDataReference().getValue();	
	}

	/**
	 * Setter for foundTrantypeData attribute.
	 * @param foundTrantypeData the new value of foundTrantypeData
	 */
	public void setFoundTrantypeData(boolean foundTrantypeData) {
		getFoundTrantypeDataReference().setValue(foundTrantypeData);	
	}
	/**
	 * Gets the reference for attribute promptForSearchKeys.
	 * @return the promptForSearchKeys attribute reference
	 */
	public ConditionReference getPromptForSearchKeysReference() {
		return wsInfoMsg.getCondition(promptForSearchKeys);	
	}

	/**
	 * Getter for promptForSearchKeys attribute.
	 * @return promptForSearchKeys attribute
	 */
	public boolean isPromptForSearchKeys() {
		return getPromptForSearchKeysReference().getValue();	
	}

	/**
	 * Setter for promptForSearchKeys attribute.
	 * @param promptForSearchKeys the new value of promptForSearchKeys
	 */
	public void setPromptForSearchKeys(boolean promptForSearchKeys) {
		getPromptForSearchKeysReference().setValue(promptForSearchKeys);	
	}
	/**
	 * Gets the reference for attribute promptCreateNewRecord.
	 * @return the promptCreateNewRecord attribute reference
	 */
	public ConditionReference getPromptCreateNewRecordReference() {
		return wsInfoMsg.getCondition(promptCreateNewRecord);	
	}

	/**
	 * Getter for promptCreateNewRecord attribute.
	 * @return promptCreateNewRecord attribute
	 */
	public boolean isPromptCreateNewRecord() {
		return getPromptCreateNewRecordReference().getValue();	
	}

	/**
	 * Setter for promptCreateNewRecord attribute.
	 * @param promptCreateNewRecord the new value of promptCreateNewRecord
	 */
	public void setPromptCreateNewRecord(boolean promptCreateNewRecord) {
		getPromptCreateNewRecordReference().setValue(promptCreateNewRecord);	
	}
	/**
	 * Gets the reference for attribute promptDeleteConfirm.
	 * @return the promptDeleteConfirm attribute reference
	 */
	public ConditionReference getPromptDeleteConfirmReference() {
		return wsInfoMsg.getCondition(promptDeleteConfirm);	
	}

	/**
	 * Getter for promptDeleteConfirm attribute.
	 * @return promptDeleteConfirm attribute
	 */
	public boolean isPromptDeleteConfirm() {
		return getPromptDeleteConfirmReference().getValue();	
	}

	/**
	 * Setter for promptDeleteConfirm attribute.
	 * @param promptDeleteConfirm the new value of promptDeleteConfirm
	 */
	public void setPromptDeleteConfirm(boolean promptDeleteConfirm) {
		getPromptDeleteConfirmReference().setValue(promptDeleteConfirm);	
	}
	/**
	 * Gets the reference for attribute confirmDeleteSuccess.
	 * @return the confirmDeleteSuccess attribute reference
	 */
	public ConditionReference getConfirmDeleteSuccessReference() {
		return wsInfoMsg.getCondition(confirmDeleteSuccess);	
	}

	/**
	 * Getter for confirmDeleteSuccess attribute.
	 * @return confirmDeleteSuccess attribute
	 */
	public boolean isConfirmDeleteSuccess() {
		return getConfirmDeleteSuccessReference().getValue();	
	}

	/**
	 * Setter for confirmDeleteSuccess attribute.
	 * @param confirmDeleteSuccess the new value of confirmDeleteSuccess
	 */
	public void setConfirmDeleteSuccess(boolean confirmDeleteSuccess) {
		getConfirmDeleteSuccessReference().setValue(confirmDeleteSuccess);	
	}
	/**
	 * Gets the reference for attribute promptForChanges.
	 * @return the promptForChanges attribute reference
	 */
	public ConditionReference getPromptForChangesReference() {
		return wsInfoMsg.getCondition(promptForChanges);	
	}

	/**
	 * Getter for promptForChanges attribute.
	 * @return promptForChanges attribute
	 */
	public boolean isPromptForChanges() {
		return getPromptForChangesReference().getValue();	
	}

	/**
	 * Setter for promptForChanges attribute.
	 * @param promptForChanges the new value of promptForChanges
	 */
	public void setPromptForChanges(boolean promptForChanges) {
		getPromptForChangesReference().setValue(promptForChanges);	
	}
	/**
	 * Gets the reference for attribute promptForNewdata.
	 * @return the promptForNewdata attribute reference
	 */
	public ConditionReference getPromptForNewdataReference() {
		return wsInfoMsg.getCondition(promptForNewdata);	
	}

	/**
	 * Getter for promptForNewdata attribute.
	 * @return promptForNewdata attribute
	 */
	public boolean isPromptForNewdata() {
		return getPromptForNewdataReference().getValue();	
	}

	/**
	 * Setter for promptForNewdata attribute.
	 * @param promptForNewdata the new value of promptForNewdata
	 */
	public void setPromptForNewdata(boolean promptForNewdata) {
		getPromptForNewdataReference().setValue(promptForNewdata);	
	}
	/**
	 * Gets the reference for attribute promptForConfirmation.
	 * @return the promptForConfirmation attribute reference
	 */
	public ConditionReference getPromptForConfirmationReference() {
		return wsInfoMsg.getCondition(promptForConfirmation);	
	}

	/**
	 * Getter for promptForConfirmation attribute.
	 * @return promptForConfirmation attribute
	 */
	public boolean isPromptForConfirmation() {
		return getPromptForConfirmationReference().getValue();	
	}

	/**
	 * Setter for promptForConfirmation attribute.
	 * @param promptForConfirmation the new value of promptForConfirmation
	 */
	public void setPromptForConfirmation(boolean promptForConfirmation) {
		getPromptForConfirmationReference().setValue(promptForConfirmation);	
	}
	/**
	 * Gets the reference for attribute confirmUpdateSuccess.
	 * @return the confirmUpdateSuccess attribute reference
	 */
	public ConditionReference getConfirmUpdateSuccessReference() {
		return wsInfoMsg.getCondition(confirmUpdateSuccess);	
	}

	/**
	 * Getter for confirmUpdateSuccess attribute.
	 * @return confirmUpdateSuccess attribute
	 */
	public boolean isConfirmUpdateSuccess() {
		return getConfirmUpdateSuccessReference().getValue();	
	}

	/**
	 * Setter for confirmUpdateSuccess attribute.
	 * @param confirmUpdateSuccess the new value of confirmUpdateSuccess
	 */
	public void setConfirmUpdateSuccess(boolean confirmUpdateSuccess) {
		getConfirmUpdateSuccessReference().setValue(confirmUpdateSuccess);	
	}
	/**
	 * Gets the reference for attribute informFailure.
	 * @return the informFailure attribute reference
	 */
	public ConditionReference getInformFailureReference() {
		return wsInfoMsg.getCondition(informFailure);	
	}

	/**
	 * Getter for informFailure attribute.
	 * @return informFailure attribute
	 */
	public boolean isInformFailure() {
		return getInformFailureReference().getValue();	
	}

	/**
	 * Setter for informFailure attribute.
	 * @param informFailure the new value of informFailure
	 */
	public void setInformFailure(boolean informFailure) {
		getInformFailureReference().setValue(informFailure);	
	}
	/**
	 * Gets the reference for attribute wsReturnMsg.
	 * @return the wsReturnMsg attribute reference
	 */
	public ElementaryRangeReference getWsReturnMsgReference() {
		return wsReturnMsg.getReference();
	}

	/**
	 * Getter for wsReturnMsg attribute.
	 * @return wsReturnMsg attribute
	 */
	public String getWsReturnMsg() {
		return wsReturnMsg.getValue();
	}

	/**
	 * Setter for wsReturnMsg attribute.
	 * @param wsReturnMsg the new value of wsReturnMsg
	 */
	public void setWsReturnMsg(String wsReturnMsg) {
		this.wsReturnMsg.setValue(wsReturnMsg);
	}
	/**
	 * Gets the reference for attribute wsReturnMsgOff.
	 * @return the wsReturnMsgOff attribute reference
	 */
	public ConditionReference getWsReturnMsgOffReference() {
		return wsReturnMsg.getCondition(wsReturnMsgOff);	
	}

	/**
	 * Getter for wsReturnMsgOff attribute.
	 * @return wsReturnMsgOff attribute
	 */
	public boolean isWsReturnMsgOff() {
		return getWsReturnMsgOffReference().getValue();	
	}

	/**
	 * Setter for wsReturnMsgOff attribute.
	 * @param wsReturnMsgOff the new value of wsReturnMsgOff
	 */
	public void setWsReturnMsgOff(boolean wsReturnMsgOff) {
		getWsReturnMsgOffReference().setValue(wsReturnMsgOff);	
	}
	/**
	 * Gets the reference for attribute wsExitMessage.
	 * @return the wsExitMessage attribute reference
	 */
	public ConditionReference getWsExitMessageReference() {
		return wsReturnMsg.getCondition(wsExitMessage);	
	}

	/**
	 * Getter for wsExitMessage attribute.
	 * @return wsExitMessage attribute
	 */
	public boolean isWsExitMessage() {
		return getWsExitMessageReference().getValue();	
	}

	/**
	 * Setter for wsExitMessage attribute.
	 * @param wsExitMessage the new value of wsExitMessage
	 */
	public void setWsExitMessage(boolean wsExitMessage) {
		getWsExitMessageReference().setValue(wsExitMessage);	
	}
	/**
	 * Gets the reference for attribute wsInvalidKey.
	 * @return the wsInvalidKey attribute reference
	 */
	public ConditionReference getWsInvalidKeyReference() {
		return wsReturnMsg.getCondition(wsInvalidKey);	
	}

	/**
	 * Getter for wsInvalidKey attribute.
	 * @return wsInvalidKey attribute
	 */
	public boolean isWsInvalidKey() {
		return getWsInvalidKeyReference().getValue();	
	}

	/**
	 * Setter for wsInvalidKey attribute.
	 * @param wsInvalidKey the new value of wsInvalidKey
	 */
	public void setWsInvalidKey(boolean wsInvalidKey) {
		getWsInvalidKeyReference().setValue(wsInvalidKey);	
	}
	/**
	 * Gets the reference for attribute wsNameMustBeAlpha.
	 * @return the wsNameMustBeAlpha attribute reference
	 */
	public ConditionReference getWsNameMustBeAlphaReference() {
		return wsReturnMsg.getCondition(wsNameMustBeAlpha);	
	}

	/**
	 * Getter for wsNameMustBeAlpha attribute.
	 * @return wsNameMustBeAlpha attribute
	 */
	public boolean isWsNameMustBeAlpha() {
		return getWsNameMustBeAlphaReference().getValue();	
	}

	/**
	 * Setter for wsNameMustBeAlpha attribute.
	 * @param wsNameMustBeAlpha the new value of wsNameMustBeAlpha
	 */
	public void setWsNameMustBeAlpha(boolean wsNameMustBeAlpha) {
		getWsNameMustBeAlphaReference().setValue(wsNameMustBeAlpha);	
	}
	/**
	 * Gets the reference for attribute wsRecordNotFound.
	 * @return the wsRecordNotFound attribute reference
	 */
	public ConditionReference getWsRecordNotFoundReference() {
		return wsReturnMsg.getCondition(wsRecordNotFound);	
	}

	/**
	 * Getter for wsRecordNotFound attribute.
	 * @return wsRecordNotFound attribute
	 */
	public boolean isWsRecordNotFound() {
		return getWsRecordNotFoundReference().getValue();	
	}

	/**
	 * Setter for wsRecordNotFound attribute.
	 * @param wsRecordNotFound the new value of wsRecordNotFound
	 */
	public void setWsRecordNotFound(boolean wsRecordNotFound) {
		getWsRecordNotFoundReference().setValue(wsRecordNotFound);	
	}
	/**
	 * Gets the reference for attribute noSearchCriteriaReceived.
	 * @return the noSearchCriteriaReceived attribute reference
	 */
	public ConditionReference getNoSearchCriteriaReceivedReference() {
		return wsReturnMsg.getCondition(noSearchCriteriaReceived);	
	}

	/**
	 * Getter for noSearchCriteriaReceived attribute.
	 * @return noSearchCriteriaReceived attribute
	 */
	public boolean isNoSearchCriteriaReceived() {
		return getNoSearchCriteriaReceivedReference().getValue();	
	}

	/**
	 * Setter for noSearchCriteriaReceived attribute.
	 * @param noSearchCriteriaReceived the new value of noSearchCriteriaReceived
	 */
	public void setNoSearchCriteriaReceived(boolean noSearchCriteriaReceived) {
		getNoSearchCriteriaReceivedReference().setValue(noSearchCriteriaReceived);	
	}
	/**
	 * Gets the reference for attribute noChangesDetected.
	 * @return the noChangesDetected attribute reference
	 */
	public ConditionReference getNoChangesDetectedReference() {
		return wsReturnMsg.getCondition(noChangesDetected);	
	}

	/**
	 * Getter for noChangesDetected attribute.
	 * @return noChangesDetected attribute
	 */
	public boolean isNoChangesDetected() {
		return getNoChangesDetectedReference().getValue();	
	}

	/**
	 * Setter for noChangesDetected attribute.
	 * @param noChangesDetected the new value of noChangesDetected
	 */
	public void setNoChangesDetected(boolean noChangesDetected) {
		getNoChangesDetectedReference().setValue(noChangesDetected);	
	}
	/**
	 * Gets the reference for attribute couldNotLockRecForUpdate.
	 * @return the couldNotLockRecForUpdate attribute reference
	 */
	public ConditionReference getCouldNotLockRecForUpdateReference() {
		return wsReturnMsg.getCondition(couldNotLockRecForUpdate);	
	}

	/**
	 * Getter for couldNotLockRecForUpdate attribute.
	 * @return couldNotLockRecForUpdate attribute
	 */
	public boolean isCouldNotLockRecForUpdate() {
		return getCouldNotLockRecForUpdateReference().getValue();	
	}

	/**
	 * Setter for couldNotLockRecForUpdate attribute.
	 * @param couldNotLockRecForUpdate the new value of couldNotLockRecForUpdate
	 */
	public void setCouldNotLockRecForUpdate(boolean couldNotLockRecForUpdate) {
		getCouldNotLockRecForUpdateReference().setValue(couldNotLockRecForUpdate);	
	}
	/**
	 * Gets the reference for attribute dataWasChangedBeforeUpdate.
	 * @return the dataWasChangedBeforeUpdate attribute reference
	 */
	public ConditionReference getDataWasChangedBeforeUpdateReference() {
		return wsReturnMsg.getCondition(dataWasChangedBeforeUpdate);	
	}

	/**
	 * Getter for dataWasChangedBeforeUpdate attribute.
	 * @return dataWasChangedBeforeUpdate attribute
	 */
	public boolean isDataWasChangedBeforeUpdate() {
		return getDataWasChangedBeforeUpdateReference().getValue();	
	}

	/**
	 * Setter for dataWasChangedBeforeUpdate attribute.
	 * @param dataWasChangedBeforeUpdate the new value of dataWasChangedBeforeUpdate
	 */
	public void setDataWasChangedBeforeUpdate(boolean dataWasChangedBeforeUpdate) {
		getDataWasChangedBeforeUpdateReference().setValue(dataWasChangedBeforeUpdate);	
	}
	/**
	 * Gets the reference for attribute wsUpdateWasCancelled.
	 * @return the wsUpdateWasCancelled attribute reference
	 */
	public ConditionReference getWsUpdateWasCancelledReference() {
		return wsReturnMsg.getCondition(wsUpdateWasCancelled);	
	}

	/**
	 * Getter for wsUpdateWasCancelled attribute.
	 * @return wsUpdateWasCancelled attribute
	 */
	public boolean isWsUpdateWasCancelled() {
		return getWsUpdateWasCancelledReference().getValue();	
	}

	/**
	 * Setter for wsUpdateWasCancelled attribute.
	 * @param wsUpdateWasCancelled the new value of wsUpdateWasCancelled
	 */
	public void setWsUpdateWasCancelled(boolean wsUpdateWasCancelled) {
		getWsUpdateWasCancelledReference().setValue(wsUpdateWasCancelled);	
	}
	/**
	 * Gets the reference for attribute tableUpdateFailed.
	 * @return the tableUpdateFailed attribute reference
	 */
	public ConditionReference getTableUpdateFailedReference() {
		return wsReturnMsg.getCondition(tableUpdateFailed);	
	}

	/**
	 * Getter for tableUpdateFailed attribute.
	 * @return tableUpdateFailed attribute
	 */
	public boolean isTableUpdateFailed() {
		return getTableUpdateFailedReference().getValue();	
	}

	/**
	 * Setter for tableUpdateFailed attribute.
	 * @param tableUpdateFailed the new value of tableUpdateFailed
	 */
	public void setTableUpdateFailed(boolean tableUpdateFailed) {
		getTableUpdateFailedReference().setValue(tableUpdateFailed);	
	}
	/**
	 * Gets the reference for attribute recordDeleteFailed.
	 * @return the recordDeleteFailed attribute reference
	 */
	public ConditionReference getRecordDeleteFailedReference() {
		return wsReturnMsg.getCondition(recordDeleteFailed);	
	}

	/**
	 * Getter for recordDeleteFailed attribute.
	 * @return recordDeleteFailed attribute
	 */
	public boolean isRecordDeleteFailed() {
		return getRecordDeleteFailedReference().getValue();	
	}

	/**
	 * Setter for recordDeleteFailed attribute.
	 * @param recordDeleteFailed the new value of recordDeleteFailed
	 */
	public void setRecordDeleteFailed(boolean recordDeleteFailed) {
		getRecordDeleteFailedReference().setValue(recordDeleteFailed);	
	}
	/**
	 * Gets the reference for attribute wsDeleteWasCancelled.
	 * @return the wsDeleteWasCancelled attribute reference
	 */
	public ConditionReference getWsDeleteWasCancelledReference() {
		return wsReturnMsg.getCondition(wsDeleteWasCancelled);	
	}

	/**
	 * Getter for wsDeleteWasCancelled attribute.
	 * @return wsDeleteWasCancelled attribute
	 */
	public boolean isWsDeleteWasCancelled() {
		return getWsDeleteWasCancelledReference().getValue();	
	}

	/**
	 * Setter for wsDeleteWasCancelled attribute.
	 * @param wsDeleteWasCancelled the new value of wsDeleteWasCancelled
	 */
	public void setWsDeleteWasCancelled(boolean wsDeleteWasCancelled) {
		getWsDeleteWasCancelledReference().setValue(wsDeleteWasCancelled);	
	}
	/**
	 * Gets the reference for attribute wsInvalidKeyPressed.
	 * @return the wsInvalidKeyPressed attribute reference
	 */
	public ConditionReference getWsInvalidKeyPressedReference() {
		return wsReturnMsg.getCondition(wsInvalidKeyPressed);	
	}

	/**
	 * Getter for wsInvalidKeyPressed attribute.
	 * @return wsInvalidKeyPressed attribute
	 */
	public boolean isWsInvalidKeyPressed() {
		return getWsInvalidKeyPressedReference().getValue();	
	}

	/**
	 * Setter for wsInvalidKeyPressed attribute.
	 * @param wsInvalidKeyPressed the new value of wsInvalidKeyPressed
	 */
	public void setWsInvalidKeyPressed(boolean wsInvalidKeyPressed) {
		getWsInvalidKeyPressedReference().setValue(wsInvalidKeyPressed);	
	}
	/**
	 * Gets the reference for attribute codingToBeDone.
	 * @return the codingToBeDone attribute reference
	 */
	public ConditionReference getCodingToBeDoneReference() {
		return wsReturnMsg.getCondition(codingToBeDone);	
	}

	/**
	 * Getter for codingToBeDone attribute.
	 * @return codingToBeDone attribute
	 */
	public boolean isCodingToBeDone() {
		return getCodingToBeDoneReference().getValue();	
	}

	/**
	 * Setter for codingToBeDone attribute.
	 * @param codingToBeDone the new value of codingToBeDone
	 */
	public void setCodingToBeDone(boolean codingToBeDone) {
		getCodingToBeDoneReference().setValue(codingToBeDone);	
	}
}
