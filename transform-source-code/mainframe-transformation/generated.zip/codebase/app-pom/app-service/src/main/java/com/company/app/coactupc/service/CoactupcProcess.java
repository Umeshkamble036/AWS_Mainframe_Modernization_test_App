package com.company.app.coactupc.service;

import com.company.app.coactupc.business.context.CoactupcContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface CoactupcProcess.
 * 
 * Defines application services for CoactupcProcess
 */
public interface CoactupcProcess {

	/**
	 * Process operation coactupc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void coactupc(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation commonReturn.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void commonReturn(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000ProcessInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000ProcessInputs(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1100ReceiveMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1100ReceiveMap(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1200EditMapInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1200EditMapInputs(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1205CompareOldNew.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1205CompareOldNew(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1210EditAccount.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1210EditAccount(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1215EditMandatory.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1215EditMandatory(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1220EditYesno.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1220EditYesno(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1225EditAlphaReqd.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1225EditAlphaReqd(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1230EditAlphanumReqd.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1230EditAlphanumReqd(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1235EditAlphaOpt.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1235EditAlphaOpt(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1240EditAlphanumOpt.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1240EditAlphanumOpt(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1245EditNumReqd.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1245EditNumReqd(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1250EditSigned9v2.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1250EditSigned9v2(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1260EditUsPhoneNum.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1260EditUsPhoneNum(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation editAreaCode.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void editAreaCode(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation editAreaCode1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void editAreaCode1(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation editAreaCode2.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void editAreaCode2(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1265EditUsSsn.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1265EditUsSsn(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1270EditUsStateCd.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1270EditUsStateCd(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1275EditFicoScore.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1275EditFicoScore(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1280EditUsStateZipCd.
	 * 
	 * A crude zip code edit based on data from USPS web site
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1280EditUsStateZipCd(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3000SendMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000SendMap(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3100ScreenInit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3100ScreenInit(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3200SetupScreenVars.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3200SetupScreenVars(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3201ShowInitialValues.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3201ShowInitialValues(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3202ShowOriginalValues.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3202ShowOriginalValues(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3203ShowUpdatedValues.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3203ShowUpdatedValues(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3250SetupInfomsg.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3250SetupInfomsg(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3300SetupScreenAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3300SetupScreenAttrs(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3310ProtectAllAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3310ProtectAllAttrs(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3320UnprotectFewAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3320UnprotectFewAttrs(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3390SetupInfomsgAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3390SetupInfomsgAttrs(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3400SendScreen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3400SendScreen(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9000ReadAcct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9000ReadAcct(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9200GetcardxrefByacct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9200GetcardxrefByacct(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9300GetacctdataByacct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9300GetacctdataByacct(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9400GetcustdataBycust.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9400GetcustdataBycust(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9500StoreFetchedData.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9500StoreFetchedData(final CoactupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation abendRoutine.
	 * 
	 * ****************************************************************
	 * Common code to store PFKey
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void abendRoutine(final CoactupcContext ctx, final ExecutionController ctrl);

}
