// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "DUSRSECJ"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//*****************************************************************
	// Copyright Amazon.com, Inc. or its affiliates.                   
	// All Rights Reserved.                                            
	//                                                                 
	// Licensed under the Apache License, Version 2.0 (the "License"). 
	// You may not use this file except in compliance with the License.
	// You may obtain a copy of the License at                         
	//                                                                 
	//    http://www.apache.org/licenses/LICENSE-2.0                   
	//                                                                 
	// Unless required by applicable law or agreed to in writing,      
	// software distributed under the License is distributed on an     
	// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,    
	// either express or implied. See the License for the specific     
	// language governing permissions and limitations under the License
	//*****************************************************************
	//-------------------------------------------------------------------*
	// PRE DELETE STEP
	//-------------------------------------------------------------------*
	//
	lastProgramResult = stepPREDEL(shell, params, programResults)
	//
	//-------------------------------------------------------------------*
	// CREATE USER SECURITY FILE (PS) FROM IN-STREAM DATA
	//-------------------------------------------------------------------*
	//
	lastProgramResult = stepSTEP01(shell, params, programResults)
	//
	//-------------------------------------------------------------------*
	// DEFINE VSAM FILE FOR USER SECURITY
	//-------------------------------------------------------------------*
	//
	lastProgramResult = stepSTEP02(shell, params, programResults)
	//
	//-------------------------------------------------------------------*
	// COPY USER SECURITY DATA FROM PS TO VSAM FILE
	//-------------------------------------------------------------------*
	//
	lastProgramResult = stepSTEP03(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult") // End of job statement.
	//
	// Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:23:06 CDT
	//
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP PREDEL - PGM - IEFBR14****************************************************
def stepPREDEL(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("PREDEL", "IEFBR14", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.bluesam("DD01")
						.dataset("AWS.M2.CARDDEMO.USRSEC.PS")
						.disposition("MOD")
						.normalTermination("DELETE")
						.abnormalTermination("DELETE")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IEFBR14")
				})
		}
	}
}
// STEP STEP01 - PGM - IEBGENER***************************************************
def stepSTEP01(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP01", "IEBGENER", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.fileSystem("SYSUT1")
						.stream(
"""ADMIN001MARGARET            GOLD                PASSWORDA
ADMIN002RUSSELL             RUSSELL             PASSWORDA
ADMIN003RAYMOND             WHITMORE            PASSWORDA
ADMIN004EMMANUEL            CASGRAIN            PASSWORDA
ADMIN005GRANVILLE           LACHAPELLE          PASSWORDA
USER0001LAWRENCE            THOMAS              PASSWORDU
USER0002AJITH               KUMAR               PASSWORDU
USER0003LAURITZ             ALME                PASSWORDU
USER0004AVERARDO            MAZZI               PASSWORDU
USER0005LEE                 TING                PASSWORDU""", getEncoding())
						.build()
						.bluesam("SYSUT2")
						.dataset("AWS.M2.CARDDEMO.USRSEC.PS")
						.disposition("NEW")
						.normalTermination("CATLG")
						.abnormalTermination("DELETE")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.dummy("SYSIN")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IEBGENER")
				})
		}
	}
}
// STEP STEP02 - PGM - IDCAMS*****************************************************
def stepSTEP02(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP02", "IDCAMS", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSIN")
						.stream(
""" DELETE                  AWS.M2.CARDDEMO.USRSEC.VSAM.KSDS
 SET       MAXCC = 0
 DEFINE    CLUSTER (NAME(AWS.M2.CARDDEMO.USRSEC.VSAM.KSDS)    -
                    KEYS(8,0)                                 -
                    RECORDSIZE(80,80)                         -
                    REUSE                                     -
                    INDEXED                                   -
                    TRACKS(45,15)                             -
                    FREESPACE(10,15)                          -
                    CISZ(8192))                               -
           DATA    (NAME(AWS.M2.CARDDEMO.USRSEC.VSAM.KSDS.DAT)) -
           INDEX   (NAME(AWS.M2.CARDDEMO.USRSEC.VSAM.KSDS.IDX))""", getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IDCAMS")
				})
		}
	}
}
// STEP STEP03 - PGM - IDCAMS*****************************************************
def stepSTEP03(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP03", "IDCAMS", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.bluesam("IN")
						.dataset("AWS.M2.CARDDEMO.USRSEC.PS")
						.disposition("SHR")
						.build()
						.bluesam("OUT")
						.dataset("AWS.M2.CARDDEMO.USRSEC.VSAM.KSDS")
						.disposition("SHR")
						.build()
						.systemOut("SYSOUT")
						.output("*")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSIN")
						.stream("  REPRO INFILE(IN) OUTFILE(OUT)", getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IDCAMS")
				})
		}
	}
}
