
package com.company.app.coadm01c.statemachine;

import com.company.app.coadm01c.business.context.Coadm01cContext;
import com.company.app.coadm01c.service.Coadm01cProcess;
import com.company.app.coadm01c.statemachine.Coadm01cProcedureDivisionStateMachineController.Events;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.control.HandleConditionBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.statemachine.StateMachineController;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Service class containing states process used to drive state machine "Coadm01cProcedureDivisionStateMachine".
 */
@Service("com.company.app.coadm01c.statemachine.Coadm01cProcedureDivisionStateMachineService")
@Lazy
public class Coadm01cProcedureDivisionStateMachineService {
	
	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Coadm01cProcedureDivisionStateMachineService.class);

	/**
	 * The associated state machine controller.
	 */
	@Autowired
	@Qualifier("com.company.app.coadm01c.statemachine.Coadm01cProcedureDivisionStateMachineController")	
	private StateMachineController<Events> instanceStateMachineController;
	
	
	/**
	 * Service used by the state machine.
	 */
	@Autowired
	@Qualifier("com.company.app.coadm01c.service.Coadm01cProcess")
	private Coadm01cProcess instanceCoadm01cProcess;
	
	
	

	/**
	 * State process operation mainPara.
	 * 
	 * PROGRAM-ID.COADM01C.
	 *  AUTHOR.     AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void mainPara(Coadm01cContext ctx, ExecutionController ctrl) {
		instanceStateMachineController.registerSignalHandler(Events.TO_PGMIDERR_ERR_PARA, ctx, "CONDITION_PGMIDERR_1_VIRTUAL_SIGNAL");
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		*****************************************************************
		Program     : COADM01C.CBL
		Application : CardDemo
		Type        : CICS COBOL Program
		Function    : Admin Menu for Admin users
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		----------------------------------------------------------------*
		WORKING STORAGE SECTION
		----------------------------------------------------------------*
		No background transparency
		----------------------------------------------------------------*
		LINKAGE SECTION
		----------------------------------------------------------------*
		----------------------------------------------------------------*
		PROCEDURE DIVISION
		----------------------------------------------------------------* */
		ctx.getSignalHandlersController().activateSignalHandler("CONDITION_PGMIDERR_1_VIRTUAL_SIGNAL","!CONDITION_PGMIDERR");
		HandleConditionBuilder.newInstance(ctx.getJicsEiblk(), ctx).enable(ResponseCode.PGMIDERR).execute().handleException();
		ctx.getWsVariables().setErrFlgOff(true);
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		FIXME: ERRMSGO OF COADM1AO */
		BluageUtils.unsupported();
		if (ctx.getDfheiblk().getEibcalen() == 0) {
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			instanceCoadm01cProcess.returnToSignonScreen(ctx, ctrl);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			if (!(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-PGM-REENTER */
				BluageUtils.unsupported();
				
				/* 
				FIXME: COADM1AO */
				BluageUtils.unsupported();
				instanceCoadm01cProcess.sendMenuScreen(ctx, ctrl);
			} else {
				instanceCoadm01cProcess.receiveMenuScreen(ctx, ctrl);
				if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) == 0) {
					instanceCoadm01cProcess.processEnterKey(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf3Reference()) == 0) {
					
					/* 
					FIXME: CDEMO-TO-PROGRAM */
					BluageUtils.unsupported();
					instanceCoadm01cProcess.returnToSignonScreen(ctx, ctrl);
				} else {
					ctx.getWsVariables().setWsErrFlg("Y");
					ctx.getWsVariables().setWsMessage(BluageUtils.unsupported());
					instanceCoadm01cProcess.sendMenuScreen(ctx, ctrl);
				}
			}
		}
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsVariables().getWsTranid())
		.withCommarea(BluageUtils.unsupported())
		.execute()
		.handleException();

	}
	/**
	 * State process operation pgmiderrErrPara.
	 * 
	 * ----------------------------------------------------------------*
	 *       PGMIDERROR     HANDLE-MISSING MENU OPTIONS
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void pgmiderrErrPara(Coadm01cContext ctx, ExecutionController ctrl) {
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		FIXME: ERRMSGC  OF COADM1AO */
		BluageUtils.unsupported();
		StringConcatenationBuilder.newInstance(ctx.getWsVariables().getWsMessageReference())
			.addDelimitedBySize("This option ")
			.addDelimitedBySize("is not installed ...")
			.end();
		instanceCoadm01cProcess.sendMenuScreen(ctx, ctrl);
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsVariables().getWsTranid())
		.withCommarea(BluageUtils.unsupported())
		.execute()
		.handleException();
		
		/* 
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:32 CDT */

	}
}
