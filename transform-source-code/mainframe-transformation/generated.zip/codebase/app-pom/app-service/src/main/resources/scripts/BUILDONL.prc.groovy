// 'MEM'='null'
// 'HLQ'='null'
// 'COBLIB'='IGY.SIGYCOMP.V63'
// 'DFHLOAD'='OEM.CICSTS.V05R06M0.CICS.SDFHLOAD'
// 'DFHCOB'='OEM.CICSTS.V05R06M0.CICS.SDFHCOB'
// 'DFHSAMP'='OEM.CICSTS.V05R06M0.CICS.SDFHSAMP'
// 'CPYBKS'='&HLQ..CARDDEMO.CPY'
// 'SOURCE'='&HLQ..CARDDEMO.CBL'
// 'LOADLIB'='&HLQ..CARDDEMO.LOADLIB'
// 'LISTING'='&HLQ..CARDDEMO.LST'
// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
binding.setVariable("fcmap", fcmap)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//********************************************************************
//  THIS PROC IS USED TO COMPILE CICS PGMS
//********************************************************************
// Copyright Amazon.com, Inc. or its affiliates.                   
// All Rights Reserved.                                            
//                                                                 
// Licensed under the Apache License, Version 2.0 (the "License"). 
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at                         
//                                                                 
//    http://www.apache.org/licenses/LICENSE-2.0                   
//                                                                 
// Unless required by applicable law or agreed to in writing,      
// software distributed under the License is distributed on an     
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,    
// either express or implied. See the License for the specific     
// language governing permissions and limitations under the License
//********************************************************************
//***  Sample CICS COBOL Compile PROC                           ****** 
//***  Run after related BMS is compiled                        ****** 
//***  Check with your Administrator for                        ****** 
//***  JCL suitable to your environment                         ******
//********************************************************************
//
//*********************************************************************
//*                             PROC                                  *
//*********************************************************************
shell.with {
	def procName = "BLDONL"
	mpr.setJobContext(jobContext)
	def jobName = "" + jobContext.getJobName() + "-" + procName
	displayStartProc(procName)
	mpr.withSchenv(jobContext.getSchenv())
	def lastProgramResult
	//
	//  ---------------------------
	//  COBOL PROGRAM COMPILE STEP
	//  ---------------------------
	lastProgramResult = stepCOB(shell, params, programResults)
	//  *********************************
	//      REPLICATE LISTING ON SYSOUT
	//  *********************************
	lastProgramResult = stepDISPLIST(shell, params, programResults)
	//  *********************************
	//        COPY LINK STEP
	//  *********************************
	lastProgramResult = stepCOPYLINK(shell, params, programResults)
	//
	//  *********************************
	//        LINK-EDIT (BINDER) STEP
	//  *********************************
	lastProgramResult = stepLKED(shell, params, programResults)
	displayEndProc(procName)
	return programResults
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP COB - PGM - IGYCRCTL******************************************************
def stepCOB(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("COB", "IGYCRCTL", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.concatenation("STEPLIB")
						.path("&COBLIB")
						.disposition("SHR")
						.path("&DFHLOAD")
						.disposition("SHR")
						.build()
						.concatenation("SYSLIB")
						.path("&CPYBKS")
						.disposition("SHR")
						.path("&DFHCOB")
						.disposition("SHR")
						.path("CEE.SCEESAMP")
						.disposition("SHR")
						.build()
						.getFileConfigurations(fcmap))
					.withArguments(getParm("CICS,NODYNAM,RENT,NOSEQ"))
					.withParameters(params)
					.runProgram("IGYCRCTL")
				})
		}
	}
}
// STEP DISPLIST - PGM - IEBGENER*************************************************
def stepDISPLIST(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("DISPLIST", "IEBGENER", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.getFileConfigurations(fcmap))
					.withParameters(params)
					.runProgram("IEBGENER")
				})
		}
	}
}
// STEP COPYLINK - PGM - IEBGENER*************************************************
def stepCOPYLINK(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("COPYLINK", "IEBGENER", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSUT1")
						.path("&DFHSAMP(DFHEILID)")
						.disposition("SHR")
						.build()
						.bluesam("SYSUT2")
						.dataset("&&COPYLINK")
						.disposition("NEW")
						.normalTermination("PASS")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.dummy("SYSIN")
						.build()
						.getFileConfigurations(fcmap))
					.withParameters(params)
					.runProgram("IEBGENER")
				})
		}
	}
}
// STEP LKED - PGM - HEWL*********************************************************
def stepLKED(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("LKED", "HEWL", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.concatenation("SYSLIB")
						.path("&DFHLOAD")
						.disposition("SHR")
						.path("SYS1.LINKLIB")
						.disposition("SHR")
						.path("CSF.SCSFMOD0")
						.disposition("SHR")
						.path("CEE.SCEELKED")
						.disposition("SHR")
						.path("CEE.SCEELKEX")
						.disposition("SHR")
						.path("&LOADLIB")
						.disposition("SHR")
						.build()
						.concatenation("SYSLIN")
						.path("&&LOADSET").temporary()
						.disposition("OLD")
						.normalTermination("DELETE")
						.path("&&COPYLINK").temporary()
						.disposition("OLD")
						.normalTermination("DELETE")
						.build()
						.getFileConfigurations(fcmap))
					.withArguments(getParm("LIST,XREF,LET,MAP,AMODE(31),                                   RMODE(ANY)"))
					.withParameters(params)
					.runProgram("HEWL")
				})
		}
	}
}
