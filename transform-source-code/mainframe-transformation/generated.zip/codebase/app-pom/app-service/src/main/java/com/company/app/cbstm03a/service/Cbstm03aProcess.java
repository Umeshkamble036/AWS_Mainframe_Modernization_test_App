package com.company.app.cbstm03a.service;

import com.company.app.cbstm03a.business.context.Cbstm03aContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface Cbstm03aProcess.
 * 
 * Defines application services for Cbstm03aProcess
 */
public interface Cbstm03aProcess {

	/**
	 * Process operation cbstm03a.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void cbstm03a(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9999Goback.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9999Goback(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000XreffileGetNext.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000XreffileGetNext(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2000CustfileGet.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000CustfileGet(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3000AcctfileGet.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000AcctfileGet(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _4000TrnxfileGet.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4000TrnxfileGet(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _5000CreateStatement.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5000CreateStatement(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _5100WriteHtmlHeader.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5100WriteHtmlHeader(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _5200WriteHtmlNmadbs.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5200WriteHtmlNmadbs(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _6000WriteTrans.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _6000WriteTrans(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _8100TrnxfileOpen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8100TrnxfileOpen(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _8200XreffileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8200XreffileOpen(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _8300CustfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8300CustfileOpen(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _8400AcctfileOpen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8400AcctfileOpen(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _8400AcctfileOpen1.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8400AcctfileOpen1(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _8500ReadtrnxRead.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8500ReadtrnxRead(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _8599Exit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8599Exit(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9100TrnxfileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9100TrnxfileClose(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9200XreffileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9200XreffileClose(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9300CustfileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9300CustfileClose(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9400AcctfileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9400AcctfileClose(final Cbstm03aContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9999AbendProgram.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9999AbendProgram(final Cbstm03aContext ctx, final ExecutionController ctrl);

}
