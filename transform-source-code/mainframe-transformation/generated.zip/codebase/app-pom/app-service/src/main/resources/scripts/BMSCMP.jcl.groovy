// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "CBLDBMS"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//-------> TO DO ID : CCLIBS [Line : 36] *****************************************
	mapTransfo['HLQ'] = 'AWS.M2' 
	stepSTEP1(shell, jobName, params, programResults)
	//********************************************************************
	//***  CICS commands in batch to Execute NEWCOPY                ******
	//********************************************************************
	lastProgramResult = stepSDSF1(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP STEP1 - PROC - BUILDBMS***************************************************
def stepSTEP1(Object shell, String jobName, Map params, Map programResults) {
	shell.with{
		if (checkValidProgramResults(programResults)) {
			def stepName = 'STEP1'
			execStepSimple(stepName, programResults, {
				def procName = 'BUILDBMS'
				TreeMap mapTransfo = new TreeMap(params["MapTransfo"])
				mapTransfo['MAPNAME'] = 'CICSMAP'
				mapTransfo['HLQ'] = '&HLQ'
				File procFile = ScriptRegistry.getScript(procName);
				File resolvedProcFile = buildResolvedFile(jobName,stepName,procName)
				GroovyUtils.processGroovyParams(procFile, resolvedProcFile, mapTransfo, programResults)
				return execGroovy(applicationContext, mapTransfo, resolvedProcFile, jobContext)
			})
		}
	}
}
// STEP SDSF1 - PGM - SDSF********************************************************
def stepSDSF1(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("SDSF1", "SDSF", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("ISFOUT")
						.output("*")
						.build()
						.systemOut("CMDOUT")
						.output("*")
						.build()
						.fileSystem("ISFIN")
						.stream(" /MODIFY CICSAWSA,'CEMT SET PROG(CICSMAP) NEWCOPY'", getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("SDSF")
				})
		}
	}
}
