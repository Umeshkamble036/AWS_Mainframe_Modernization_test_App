
package com.company.app.cbstm03a.statemachine;

import com.company.app.cbstm03a.business.context.Cbstm03aContext;
import com.company.app.cbstm03a.service.Cbstm03aProcess;
import com.company.app.cbstm03a.statemachine.Cbstm03aProceduredivisionStateMachineController.Events;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.io.OpenMode;
import com.netfective.bluage.gapwalk.rt.io.SequentialFile;
import com.netfective.bluage.gapwalk.rt.statemachine.StateMachineController;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Service class containing states process used to drive state machine "Cbstm03aProceduredivisionStateMachine".
 */
@Service("com.company.app.cbstm03a.statemachine.Cbstm03aProceduredivisionStateMachineService")
@Lazy
public class Cbstm03aProceduredivisionStateMachineService {
	
	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Cbstm03aProceduredivisionStateMachineService.class);

	/**
	 * The associated state machine controller.
	 */
	@Autowired
	@Qualifier("com.company.app.cbstm03a.statemachine.Cbstm03aProceduredivisionStateMachineController")	
	private StateMachineController<Events> instanceStateMachineController;
	
	
	/**
	 * Service used by the state machine.
	 */
	@Autowired
	@Qualifier("com.company.app.cbstm03a.service.Cbstm03aProcess")
	private Cbstm03aProcess instanceCbstm03aProcess;
	
	
	

	/**
	 * State process operation proceduredivision.
	 * 
	 * PROGRAM-ID.CBSTM03A.
	 *  AUTHOR.        AWS.
	 * *****************************************************************
	 *  Program     : CBSTM03A.CBL
	 *  Application : CardDemo
	 *  Type        : BATCH COBOL Program
	 *  Function    : Print Account Statements from Transaction data
	 *                in two formats : 1/plain text and 2/HTML
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 *  This program is to create statement based on the data in
	 *  transaction file. The following features are excercised
	 *  to help create excercise modernization tooling
	 * *****************************************************************
	 *   1. Mainframe Control block addressing
	 *   2. Alter and GO TO statements
	 *   3. COMP and COMP-3 variables
	 *   4. 2 dimensional array
	 *   5. Call to Subroutine
	 * *****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void proceduredivision(Cbstm03aContext ctx, ExecutionController ctrl) {
				SequentialFile htmlFile = ctx.getHtmlFileHandler(ctrl.getExecutionContext()); 
				SequentialFile stmtFile = ctx.getStmtFileHandler(ctrl.getExecutionContext()); 
		
		/* 
		****************************************************************
		Check Unit Control blocks                                  *
		****************************************************************
		**************************************************************** */
		ctx.getPsaBlock().bind(ctrl.getExecutionContext().getRecord(ctx.getPsaptr().getPsaptr()));
		ctx.getTcbBlock().bind(ctrl.getExecutionContext().getRecord(ctx.getPsaBlock().getTcbPoint()));
		ctx.getTiotBlock().bind(ctrl.getExecutionContext().getRecord(ctx.getTcbBlock().getTiotPoint()));
		ctx.getGroup1().getTiotIndexReference().setValue(ctx.getTcbBlock().getTiotPointReference());
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "Running JCL : " , ctx.getTiotBlock().getTiotnjob() , " Step " , ctx.getTiotBlock().getTiotjstp());
		ctx.getGroup1().setBumpTiot(ctx.getGroup1().getBumpTiot() + ctx.getTiotBlock().getSize());
		ctx.getTiotEntry().bind(ctrl.getExecutionContext().getRecord(ctx.getGroup1().getTiotIndex()));
		DisplayUtils.display(ctx, ctrl, LOGGER, "DD Names from TIOT: ");
		while (!(ctx.getTiotEntry().isEndOfTiot() || DataUtils.isLowValue(ctx.getTiotEntry().getTioLenReference()))) {
			if (!(ctx.getTiotEntry().isNullUcb())) {
				DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}" , ": " , ctx.getTiotEntry().getTiocddnm() , " -- valid UCB");
			} else {
				DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}" , ": " , ctx.getTiotEntry().getTiocddnm() , " --  null UCB");
			}
			ctx.getGroup1().setBumpTiot(ctx.getGroup1().getBumpTiot() + ctx.getTiotEntry().getTiotSegReference().getSize());
			ctx.getTiotEntry().bind(ctrl.getExecutionContext().getRecord(ctx.getGroup1().getTiotIndex()));
		}
		if (!(ctx.getTiotEntry().isNullUcb())) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}" , ": " , ctx.getTiotEntry().getTiocddnm() , " -- valid UCB");
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}" , ": " , ctx.getTiotEntry().getTiocddnm() , " -- null  UCB");
		}
		stmtFile.open(OpenMode.OUTPUT);
		htmlFile.open(OpenMode.OUTPUT);
		ctx.getWsTrnxTable().getField().initialize();
		ctx.getWsTrnTblCntr().getField().initialize();
		instanceStateMachineController.sendEvent(Events.TO__0000_START);

	}
	/**
	 * State process operation _0000Start.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000Start(Cbstm03aContext ctx, ExecutionController ctrl) {
		while (true) {
			if (DataUtils.compare(ctx.getMiscVariables().getWsFlDdReference(), "TRNXFILE") == 0) {
				ctx.set_8100FileOpenTarget(1);
				instanceStateMachineController.sendEvent(Events.TO__8100_FILE_OPEN);
				return;
			} else if (DataUtils.compare(ctx.getMiscVariables().getWsFlDdReference(), "XREFFILE") == 0) {
				ctx.set_8100FileOpenTarget(2);
				instanceStateMachineController.sendEvent(Events.TO__8100_FILE_OPEN);
				return;
			} else if (DataUtils.compare(ctx.getMiscVariables().getWsFlDdReference(), "CUSTFILE") == 0) {
				ctx.set_8100FileOpenTarget(3);
				instanceStateMachineController.sendEvent(Events.TO__8100_FILE_OPEN);
				return;
			} else if (DataUtils.compare(ctx.getMiscVariables().getWsFlDdReference(), "ACCTFILE") == 0) {
				ctx.set_8100FileOpenTarget(4);
				instanceStateMachineController.sendEvent(Events.TO__8100_FILE_OPEN);
				return;
			} else if (DataUtils.compare(ctx.getMiscVariables().getWsFlDdReference(), "READTRNX") == 0) {
				instanceCbstm03aProcess._8500ReadtrnxRead(ctx, ctrl);
				continue;
			} else {
				instanceCbstm03aProcess._9999Goback(ctx, ctrl);
				instanceStateMachineController.sendEvent(Events.TO_FINAL);
				return;
			}
		}

	}
	/**
	 * State process operation _8100FileOpen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8100FileOpen(Cbstm03aContext ctx, ExecutionController ctrl) {
		if (ctx.get_8100FileOpenTarget() == 1) {
			instanceCbstm03aProcess._8100TrnxfileOpen(ctx, ctrl);
			instanceStateMachineController.sendEvent(Events.TO__0000_START);
			return;
		} else if (ctx.get_8100FileOpenTarget() == 2) {
			instanceCbstm03aProcess._8200XreffileOpen(ctx, ctrl);
			instanceStateMachineController.sendEvent(Events.TO__0000_START);
			return;
		} else if (ctx.get_8100FileOpenTarget() == 3) {
			instanceCbstm03aProcess._8300CustfileOpen(ctx, ctrl);
			instanceStateMachineController.sendEvent(Events.TO__0000_START);
			return;
		} else if (ctx.get_8100FileOpenTarget() == 4) {
			instanceCbstm03aProcess._8400AcctfileOpen(ctx, ctrl);
			instanceCbstm03aProcess._9999Goback(ctx, ctrl);
			instanceStateMachineController.sendEvent(Events.TO_FINAL);
			return;
		} else {
			
			/* 
			---------------------------------------------------------------* */
			instanceCbstm03aProcess._8100TrnxfileOpen(ctx, ctrl);
			instanceStateMachineController.sendEvent(Events.TO__0000_START);
		}

	}
}
