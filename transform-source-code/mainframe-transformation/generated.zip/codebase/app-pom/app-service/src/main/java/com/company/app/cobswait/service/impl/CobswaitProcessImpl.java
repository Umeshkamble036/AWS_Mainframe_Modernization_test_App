
package com.company.app.cobswait.service.impl;

import com.company.app.cobswait.business.context.CobswaitContext;
import com.company.app.cobswait.service.CobswaitProcess;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class CobswaitProcessImpl
 * 
 * Defines application services for CobswaitProcess
 * @see CobswaitProcess
 */
@Service("com.company.app.cobswait.service.CobswaitProcess")
@Lazy

public class CobswaitProcessImpl implements CobswaitProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(CobswaitProcessImpl.class);

	/**
	 * Process operation procedureDivision.
	 * 
	 * PROGRAM-ID.COBSWAIT.
	 * *****************************************************************
	 *  PROGRAM     : COBSWAIT.CBL
	 *  Application : CardDemo
	 *  Type        : BATCH COBOL Program
	 *  FUNCTION    : UTILITY PROGRAM TO WAIT (PARM IN CENTISECONDS)
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void procedureDivision(final CobswaitContext ctx, final ExecutionController ctrl) {
	}

}
