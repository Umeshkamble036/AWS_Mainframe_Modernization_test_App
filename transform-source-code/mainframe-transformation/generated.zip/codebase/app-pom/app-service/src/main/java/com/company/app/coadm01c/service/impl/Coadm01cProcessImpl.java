
package com.company.app.coadm01c.service.impl;

import com.company.app.coadm01c.business.context.Coadm01cContext;
import com.company.app.coadm01c.service.Coadm01cProcess;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Coadm01cProcessImpl
 * 
 * Defines application services for Coadm01cProcess
 * @see Coadm01cProcess
 */
@Service("com.company.app.coadm01c.service.Coadm01cProcess")
@Import({
com.company.app.coadm01c.statemachine.Coadm01cProcedureDivisionStateMachineController.class 
}) 	
@Lazy

public class Coadm01cProcessImpl implements Coadm01cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Coadm01cProcessImpl.class);

	/**
	 * Process operation coadm01c.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void coadm01c(final Coadm01cContext ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation processEnterKey.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-ENTER-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processEnterKey(final Coadm01cContext ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation returnToSignonScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RETURN-TO-SIGNON-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void returnToSignonScreen(final Coadm01cContext ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation sendMenuScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       SEND-MENU-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendMenuScreen(final Coadm01cContext ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation receiveMenuScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RECEIVE-MENU-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void receiveMenuScreen(final Coadm01cContext ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation populateHeaderInfo.
	 * 
	 * ----------------------------------------------------------------*
	 *                       POPULATE-HEADER-INFO
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void populateHeaderInfo(final Coadm01cContext ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation buildMenuOptions.
	 * 
	 * ----------------------------------------------------------------*
	 *                       BUILD-MENU-OPTIONS
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void buildMenuOptions(final Coadm01cContext ctx, final ExecutionController ctrl) {
	}

}
