
package com.company.app.cotrn01c.service.impl;

import com.company.app.core.helper.BluageUtils;
import com.company.app.cotrn01c.business.context.Cotrn01cContext;
import com.company.app.cotrn01c.service.Cotrn01cProcess;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.bms.ReceiveMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.jics.io.JicsIsolationLevel;
import com.netfective.bluage.gapwalk.rt.jics.io.internal.JicsFileBuilder;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Cotrn01cProcessImpl
 * 
 * Defines application services for Cotrn01cProcess
 * @see Cotrn01cProcess
 */
@Service("com.company.app.cotrn01c.service.Cotrn01cProcess")
@Lazy

public class Cotrn01cProcessImpl implements Cotrn01cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Cotrn01cProcessImpl.class);


	/**
	 * Process operation mainPara.
	 * 
	 * PROGRAM-ID.COTRN01C.
	 *  AUTHOR.     AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void mainPara(final Cotrn01cContext ctx, final ExecutionController ctrl) {
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		*****************************************************************
		Program     : COTRN01C.CBL
		Application : CardDemo
		Type        : CICS COBOL Program
		Function    : View a Transaction from TRANSACT file
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		----------------------------------------------------------------*
		WORKING STORAGE SECTION
		----------------------------------------------------------------*
		No background transparency
		----------------------------------------------------------------*
		LINKAGE SECTION
		----------------------------------------------------------------*
		----------------------------------------------------------------*
		PROCEDURE DIVISION
		----------------------------------------------------------------* */
		ctx.getWsVariables().setErrFlgOff(true);
		ctx.getWsVariables().setUsrModifiedNo(true);
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		FIXME: ERRMSGO OF COTRN1AO */
		BluageUtils.unsupported();
		if (ctx.getDfheiblk().getEibcalen() == 0) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
			returnToPrevScreen(ctx, ctrl);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			if (!(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-PGM-REENTER */
				BluageUtils.unsupported();
				
				/* 
				FIXME: COTRN1AO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: TRNIDINL OF COTRN1AI */
				BluageUtils.unsupported();
				if (!(DataUtils.isBlank(ctx.getWsVariables().getCdemoCt01TrnSelectedReference())) && !(DataUtils.isLowValue(ctx.getWsVariables().getCdemoCt01TrnSelectedReference()))) {
					
					/* 
					FIXME: TRNIDINI OF COTRN1AI */
					BluageUtils.unsupported();
					processEnterKey(ctx, ctrl);
				} 
				sendTrnviewScreen(ctx, ctrl);
			} else {
				receiveTrnviewScreen(ctx, ctrl);
				if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) == 0) {
					processEnterKey(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf3Reference()) == 0) {
					if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
						
						/* 
						FIXME: CDEMO-TO-PROGRAM */
						BluageUtils.unsupported();
					} else {
						
						/* 
						FIXME: CDEMO-TO-PROGRAM */
						BluageUtils.unsupported();
					}
					returnToPrevScreen(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf4Reference()) == 0) {
					clearCurrentScreen(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf5Reference()) == 0) {
					
					/* 
					FIXME: CDEMO-TO-PROGRAM */
					BluageUtils.unsupported();
					returnToPrevScreen(ctx, ctrl);
				} else {
					ctx.getWsVariables().setWsErrFlg("Y");
					ctx.getWsVariables().setWsMessage(BluageUtils.unsupported());
					sendTrnviewScreen(ctx, ctrl);
				}
			}
		}
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsVariables().getWsTranid())
		.withCommarea(BluageUtils.unsupported())
		.execute()
		.handleException();
	}

	/**
	 * Process operation processEnterKey.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-ENTER-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processEnterKey(final Cotrn01cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Tran ID can NOT be empty...");
			
			/* 
			FIXME: TRNIDINL OF COTRN1AI */
			BluageUtils.unsupported();
			sendTrnviewScreen(ctx, ctrl);
		} else {
			
			/* 
			FIXME: TRNIDINL OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			Do nothing */
		}
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			
			/* 
			FIXME: TRNIDI   OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CARDNUMI OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TTYPCDI  OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TCATCDI  OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TRNSRCI  OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TRNAMTI  OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESCI   OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TORIGDTI OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TPROCDTI OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MIDI     OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MNAMEI   OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MCITYI   OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MZIPI    OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TRAN-ID */
			BluageUtils.unsupported();
			readTransactFile(ctx, ctrl);
		} 
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			ctx.getWsVariables().setWsTranAmt(BluageUtils.unsupported());
			
			/* 
			FIXME: TRNIDI    OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CARDNUMI    OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TTYPCDI   OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TCATCDI   OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TRNSRCI  OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TRNAMTI    OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESCI    OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TORIGDTI   OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TPROCDTI  OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MIDI  OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MNAMEI  OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MCITYI  OF COTRN1AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MZIPI  OF COTRN1AI */
			BluageUtils.unsupported();
			sendTrnviewScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation returnToPrevScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RETURN-TO-PREV-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void returnToPrevScreen(final Cotrn01cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
		} 
		
		/* 
		FIXME: CDEMO-FROM-TRANID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-FROM-PROGRAM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-PGM-CONTEXT */
		BluageUtils.unsupported();
		XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
	}

	/**
	 * Process operation sendTrnviewScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       SEND-TRNVIEW-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendTrnviewScreen(final Cotrn01cContext ctx, final ExecutionController ctrl) {
		populateHeaderInfo(ctx, ctrl);
		
		/* 
		FIXME: ERRMSGO OF COTRN1AO */
		BluageUtils.unsupported();
		SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withMap("COTRN1A")
		.withMapset("COTRN01")
		.withData(BluageUtils.unsupported())
		.withErase()
		.withCursor()
		.execute()
		.handleException();
	}

	/**
	 * Process operation receiveTrnviewScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RECEIVE-TRNVIEW-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void receiveTrnviewScreen(final Cotrn01cContext ctx, final ExecutionController ctrl) {
		ReceiveMapBuilder.newInstance(ctx.getJicsEiblk(), ctrl.getExecutionContext(), ctx)
		.withMap("COTRN1A")
		.withMapset("COTRN01")
		.into(BluageUtils.unsupported())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
	}

	/**
	 * Process operation populateHeaderInfo.
	 * 
	 * ----------------------------------------------------------------*
	 *                       POPULATE-HEADER-INFO
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void populateHeaderInfo(final Cotrn01cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE01O OF COTRN1AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE02O OF COTRN1AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNNAMEO OF COTRN1AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PGMNAMEO OF COTRN1AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURDATEO OF COTRN1AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-HH */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-SS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURTIMEO OF COTRN1AO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation readTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       READ-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readTransactFile(final Cotrn01cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.setIsolationLevel(JicsIsolationLevel.UPDATE)
		.updateNoToken()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Transaction ID NOT found...");
			
			/* 
			FIXME: TRNIDINL OF COTRN1AI */
			BluageUtils.unsupported();
			sendTrnviewScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup Transaction...");
			
			/* 
			FIXME: TRNIDINL OF COTRN1AI */
			BluageUtils.unsupported();
			sendTrnviewScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation clearCurrentScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       CLEAR-CURRENT-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void clearCurrentScreen(final Cotrn01cContext ctx, final ExecutionController ctrl) {
		initializeAllFields(ctx, ctrl);
		sendTrnviewScreen(ctx, ctrl);
	}

	/**
	 * Process operation initializeAllFields.
	 * 
	 * ----------------------------------------------------------------*
	 *                       INITIALIZE-ALL-FIELDS
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void initializeAllFields(final Cotrn01cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: TRNIDINL OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNIDINI OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNIDI   OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CARDNUMI OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TTYPCDI  OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TCATCDI  OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNSRCI  OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNAMTI  OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TDESCI   OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TORIGDTI OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TPROCDTI OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: MIDI     OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: MNAMEI   OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: MCITYI   OF COTRN1AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: MZIPI    OF COTRN1AI */
		BluageUtils.unsupported();
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:34 CDT */
		return;
	}

}
