
package com.company.app.cousr00c.service.impl;

import com.company.app.core.helper.BluageUtils;
import com.company.app.cousr00c.business.context.Cousr00cContext;
import com.company.app.cousr00c.service.Cousr00cProcess;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.NumberUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.bms.ReceiveMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.jics.io.internal.JicsFileBuilder;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Cousr00cProcessImpl
 * 
 * Defines application services for Cousr00cProcess
 * @see Cousr00cProcess
 */
@Service("com.company.app.cousr00c.service.Cousr00cProcess")
@Lazy

public class Cousr00cProcessImpl implements Cousr00cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Cousr00cProcessImpl.class);


	/**
	 * Process operation mainPara.
	 * 
	 * PROGRAM-ID.COUSR00C.
	 *  AUTHOR.     AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void mainPara(final Cousr00cContext ctx, final ExecutionController ctrl) {
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		*****************************************************************
		Program     : COUSR00C.CBL
		Application : CardDemo
		Type        : CICS COBOL Program
		Function    : List all users from USRSEC file
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		----------------------------------------------------------------*
		WORKING STORAGE SECTION
		----------------------------------------------------------------*
		No background transparency
		----------------------------------------------------------------*
		LINKAGE SECTION
		----------------------------------------------------------------*
		----------------------------------------------------------------*
		PROCEDURE DIVISION
		----------------------------------------------------------------* */
		ctx.getWsVariables().setErrFlgOff(true);
		ctx.getWsVariables().setUserSecNotEof(true);
		ctx.getWsUserData().setNextPageNo(true);
		ctx.getWsVariables().setSendEraseYes(true);
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		FIXME: ERRMSGO OF COUSR0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: USRIDINL OF COUSR0AI */
		BluageUtils.unsupported();
		if (ctx.getDfheiblk().getEibcalen() == 0) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
			returnToPrevScreen(ctx, ctrl);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			if (!(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-PGM-REENTER */
				BluageUtils.unsupported();
				
				/* 
				FIXME: COUSR0AO */
				BluageUtils.unsupported();
				processEnterKey(ctx, ctrl);
				sendUsrlstScreen(ctx, ctrl);
			} else {
				receiveUsrlstScreen(ctx, ctrl);
				if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) == 0) {
					processEnterKey(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf3Reference()) == 0) {
					
					/* 
					FIXME: CDEMO-TO-PROGRAM */
					BluageUtils.unsupported();
					returnToPrevScreen(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf7Reference()) == 0) {
					processPf7Key(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf8Reference()) == 0) {
					processPf8Key(ctx, ctrl);
				} else {
					ctx.getWsVariables().setWsErrFlg("Y");
					
					/* 
					FIXME: USRIDINL OF COUSR0AI */
					BluageUtils.unsupported();
					ctx.getWsVariables().setWsMessage(BluageUtils.unsupported());
					sendUsrlstScreen(ctx, ctrl);
				}
			}
		}
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsVariables().getWsTranid())
		.withCommarea(BluageUtils.unsupported())
		.execute()
		.handleException();
	}

	/**
	 * Process operation processEnterKey.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-ENTER-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processEnterKey(final Cousr00cContext ctx, final ExecutionController ctrl) {
		if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsUserData().setCdemoCu00UsrSelFlg(BluageUtils.unsupported());
			ctx.getWsUserData().setCdemoCu00UsrSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsUserData().setCdemoCu00UsrSelFlg(BluageUtils.unsupported());
			ctx.getWsUserData().setCdemoCu00UsrSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsUserData().setCdemoCu00UsrSelFlg(BluageUtils.unsupported());
			ctx.getWsUserData().setCdemoCu00UsrSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsUserData().setCdemoCu00UsrSelFlg(BluageUtils.unsupported());
			ctx.getWsUserData().setCdemoCu00UsrSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsUserData().setCdemoCu00UsrSelFlg(BluageUtils.unsupported());
			ctx.getWsUserData().setCdemoCu00UsrSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsUserData().setCdemoCu00UsrSelFlg(BluageUtils.unsupported());
			ctx.getWsUserData().setCdemoCu00UsrSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsUserData().setCdemoCu00UsrSelFlg(BluageUtils.unsupported());
			ctx.getWsUserData().setCdemoCu00UsrSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsUserData().setCdemoCu00UsrSelFlg(BluageUtils.unsupported());
			ctx.getWsUserData().setCdemoCu00UsrSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsUserData().setCdemoCu00UsrSelFlg(BluageUtils.unsupported());
			ctx.getWsUserData().setCdemoCu00UsrSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsUserData().setCdemoCu00UsrSelFlg(BluageUtils.unsupported());
			ctx.getWsUserData().setCdemoCu00UsrSelected(BluageUtils.unsupported());
		} else {
			DataUtils.setToBlank(ctx.getWsUserData().getCdemoCu00UsrSelFlgReference());
			DataUtils.setToBlank(ctx.getWsUserData().getCdemoCu00UsrSelectedReference());
		}
		if (!(DataUtils.isBlank(ctx.getWsUserData().getCdemoCu00UsrSelFlgReference())) && !(DataUtils.isLowValue(ctx.getWsUserData().getCdemoCu00UsrSelFlgReference())) && !(DataUtils.isBlank(ctx.getWsUserData().getCdemoCu00UsrSelectedReference())) && !(DataUtils.isLowValue(ctx.getWsUserData().getCdemoCu00UsrSelectedReference()))) {
			if (DataUtils.compare(ctx.getWsUserData().getCdemoCu00UsrSelFlgReference(), "U") == 0 || DataUtils.compare(ctx.getWsUserData().getCdemoCu00UsrSelFlgReference(), "u") == 0) {
				
				/* 
				FIXME: CDEMO-TO-PROGRAM */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-FROM-TRANID */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-FROM-PROGRAM */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-PGM-CONTEXT */
				BluageUtils.unsupported();
				XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
			} else if (DataUtils.compare(ctx.getWsUserData().getCdemoCu00UsrSelFlgReference(), "D") == 0 || DataUtils.compare(ctx.getWsUserData().getCdemoCu00UsrSelFlgReference(), "d") == 0) {
				
				/* 
				FIXME: CDEMO-TO-PROGRAM */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-FROM-TRANID */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-FROM-PROGRAM */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-PGM-CONTEXT */
				BluageUtils.unsupported();
				XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
			} else {
				ctx.getWsVariables().setWsMessage("Invalid selection. Valid values are U and D");
				
				/* 
				FIXME: USRIDINL OF COUSR0AI */
				BluageUtils.unsupported();
			}
		} 
		if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			
			/* 
			FIXME: SEC-USR-ID */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: SEC-USR-ID */
			BluageUtils.unsupported();
		}
		
		/* 
		FIXME: USRIDINL OF COUSR0AI */
		BluageUtils.unsupported();
		ctx.getWsUserData().setCdemoCu00PageNum(0);
		processPageForward(ctx, ctrl);
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			
			/* 
			FIXME: USRIDINO  OF COUSR0AO */
			BluageUtils.unsupported();
		}
	}

	/**
	 * Process operation processPf7Key.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-PF7-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processPf7Key(final Cousr00cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isBlank(ctx.getWsUserData().getCdemoCu00UsridFirstReference()) || DataUtils.isLowValue(ctx.getWsUserData().getCdemoCu00UsridFirstReference())) {
			
			/* 
			FIXME: SEC-USR-ID */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: SEC-USR-ID */
			BluageUtils.unsupported();
		}
		ctx.getWsUserData().setNextPageYes(true);
		
		/* 
		FIXME: USRIDINL OF COUSR0AI */
		BluageUtils.unsupported();
		if (NumberUtils.gt(ctx.getWsUserData().getCdemoCu00PageNumReference(), 1)) {
			processPageBackward(ctx, ctrl);
		} else {
			ctx.getWsVariables().setWsMessage("You are already at the top of the page...");
			ctx.getWsVariables().setSendEraseNo(true);
			sendUsrlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation processPf8Key.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-PF8-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processPf8Key(final Cousr00cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isBlank(ctx.getWsUserData().getCdemoCu00UsridLastReference()) || DataUtils.isLowValue(ctx.getWsUserData().getCdemoCu00UsridLastReference())) {
			
			/* 
			FIXME: SEC-USR-ID */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: SEC-USR-ID */
			BluageUtils.unsupported();
		}
		
		/* 
		FIXME: USRIDINL OF COUSR0AI */
		BluageUtils.unsupported();
		if (ctx.getWsUserData().isNextPageYes()) {
			processPageForward(ctx, ctrl);
		} else {
			ctx.getWsVariables().setWsMessage("You are already at the bottom of the page...");
			ctx.getWsVariables().setSendEraseNo(true);
			sendUsrlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation processPageForward.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-PAGE-FORWARD
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processPageForward(final Cousr00cContext ctx, final ExecutionController ctrl) {
		startbrUserSecFile(ctx, ctrl);
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) != 0 && DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf7Reference()) != 0 && DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf3Reference()) != 0) {
				readnextUserSecFile(ctx, ctrl);
			} 
			if (ctx.getWsVariables().isUserSecNotEof() && ctx.getWsVariables().isErrFlgOff()) {
				ctx.getWsVariables().setWsIdx(1);
				while (ctx.getWsVariables().getWsIdx() <= 10) {
					initializeUserData(ctx, ctrl);
					ctx.getWsVariables().setWsIdx(ctx.getWsVariables().getWsIdx() + 1);
				}
			} 
			ctx.getWsVariables().setWsIdx(1);
			while (!(ctx.getWsVariables().getWsIdx() >= 11 || ctx.getWsVariables().isUserSecEof() || ctx.getWsVariables().isErrFlgOn())) {
				readnextUserSecFile(ctx, ctrl);
				if (ctx.getWsVariables().isUserSecNotEof() && ctx.getWsVariables().isErrFlgOff()) {
					populateUserData(ctx, ctrl);
					ctx.getWsVariables().setWsIdx(ctx.getWsVariables().getWsIdx() + 1);
				} 
			}
			if (ctx.getWsVariables().isUserSecNotEof() && ctx.getWsVariables().isErrFlgOff()) {
				ctx.getWsUserData().setCdemoCu00PageNum(ctx.getWsUserData().getCdemoCu00PageNum() + 1);
				readnextUserSecFile(ctx, ctrl);
				if (ctx.getWsVariables().isUserSecNotEof() && ctx.getWsVariables().isErrFlgOff()) {
					ctx.getWsUserData().setNextPageYes(true);
				} else {
					ctx.getWsUserData().setNextPageNo(true);
				}
			} else {
				ctx.getWsUserData().setNextPageNo(true);
				if (ctx.getWsVariables().getWsIdx() > 1) {
					ctx.getWsUserData().setCdemoCu00PageNum(ctx.getWsUserData().getCdemoCu00PageNum() + 1);
				} 
			}
			endbrUserSecFile(ctx, ctrl);
			
			/* 
			FIXME: PAGENUMI  OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: USRIDINO  OF COUSR0AO */
			BluageUtils.unsupported();
			sendUsrlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation processPageBackward.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-PAGE-BACKWARD
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processPageBackward(final Cousr00cContext ctx, final ExecutionController ctrl) {
		startbrUserSecFile(ctx, ctrl);
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) != 0 && DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf8Reference()) != 0) {
				readprevUserSecFile(ctx, ctrl);
			} 
			if (ctx.getWsVariables().isUserSecNotEof() && ctx.getWsVariables().isErrFlgOff()) {
				ctx.getWsVariables().setWsIdx(1);
				while (ctx.getWsVariables().getWsIdx() <= 10) {
					initializeUserData(ctx, ctrl);
					ctx.getWsVariables().setWsIdx(ctx.getWsVariables().getWsIdx() + 1);
				}
			} 
			ctx.getWsVariables().setWsIdx(10);
			while (!(ctx.getWsVariables().getWsIdx() <= 0 || ctx.getWsVariables().isUserSecEof() || ctx.getWsVariables().isErrFlgOn())) {
				readprevUserSecFile(ctx, ctrl);
				if (ctx.getWsVariables().isUserSecNotEof() && ctx.getWsVariables().isErrFlgOff()) {
					populateUserData(ctx, ctrl);
					ctx.getWsVariables().setWsIdx(ctx.getWsVariables().getWsIdx() - 1);
				} 
			}
			if (ctx.getWsVariables().isUserSecNotEof() && ctx.getWsVariables().isErrFlgOff()) {
				readprevUserSecFile(ctx, ctrl);
				if (ctx.getWsUserData().isNextPageYes()) {
					if (ctx.getWsVariables().isUserSecNotEof() && ctx.getWsVariables().isErrFlgOff() && NumberUtils.gt(ctx.getWsUserData().getCdemoCu00PageNumReference(), 1)) {
						ctx.getWsUserData().setCdemoCu00PageNum(ctx.getWsUserData().getCdemoCu00PageNum() - 1);
					} else {
						ctx.getWsUserData().setCdemoCu00PageNum(1);
					}
				} 
			} 
			endbrUserSecFile(ctx, ctrl);
			
			/* 
			FIXME: PAGENUMI  OF COUSR0AI */
			BluageUtils.unsupported();
			sendUsrlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation populateUserData.
	 * 
	 * ----------------------------------------------------------------*
	 *                       POPULATE-USER-DATA
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void populateUserData(final Cousr00cContext ctx, final ExecutionController ctrl) {
		if (ctx.getWsVariables().getWsIdx() == 1) {
			
			/* 
			FIXME: USRID01I OF COUSR0AI */
			BluageUtils.unsupported();
			ctx.getWsUserData().setCdemoCu00UsridFirst(BluageUtils.unsupported());
			
			/* 
			FIXME: FNAME01I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME01I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE01I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 2) {
			
			/* 
			FIXME: USRID02I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME02I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME02I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE02I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 3) {
			
			/* 
			FIXME: USRID03I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME03I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME03I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE03I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 4) {
			
			/* 
			FIXME: USRID04I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME04I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME04I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE04I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 5) {
			
			/* 
			FIXME: USRID05I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME05I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME05I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE05I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 6) {
			
			/* 
			FIXME: USRID06I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME06I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME06I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE06I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 7) {
			
			/* 
			FIXME: USRID07I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME07I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME07I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE07I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 8) {
			
			/* 
			FIXME: USRID08I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME08I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME08I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE08I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 9) {
			
			/* 
			FIXME: USRID09I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME09I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME09I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE09I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 10) {
			
			/* 
			FIXME: USRID10I OF COUSR0AI */
			BluageUtils.unsupported();
			ctx.getWsUserData().setCdemoCu00UsridLast(BluageUtils.unsupported());
			
			/* 
			FIXME: FNAME10I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME10I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE10I OF COUSR0AI */
			BluageUtils.unsupported();
		} else {
			
			/* 
			Do nothing */
		}
	}

	/**
	 * Process operation initializeUserData.
	 * 
	 * ----------------------------------------------------------------*
	 *                       INITIALIZE-USER-DATA
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void initializeUserData(final Cousr00cContext ctx, final ExecutionController ctrl) {
		if (ctx.getWsVariables().getWsIdx() == 1) {
			
			/* 
			FIXME: USRID01I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME01I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME01I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE01I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 2) {
			
			/* 
			FIXME: USRID02I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME02I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME02I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE02I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 3) {
			
			/* 
			FIXME: USRID03I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME03I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME03I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE03I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 4) {
			
			/* 
			FIXME: USRID04I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME04I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME04I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE04I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 5) {
			
			/* 
			FIXME: USRID05I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME05I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME05I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE05I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 6) {
			
			/* 
			FIXME: USRID06I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME06I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME06I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE06I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 7) {
			
			/* 
			FIXME: USRID07I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME07I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME07I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE07I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 8) {
			
			/* 
			FIXME: USRID08I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME08I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME08I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE08I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 9) {
			
			/* 
			FIXME: USRID09I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME09I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME09I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE09I OF COUSR0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 10) {
			
			/* 
			FIXME: USRID10I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FNAME10I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAME10I OF COUSR0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: UTYPE10I OF COUSR0AI */
			BluageUtils.unsupported();
		} else {
			
			/* 
			Do nothing */
		}
	}

	/**
	 * Process operation returnToPrevScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RETURN-TO-PREV-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void returnToPrevScreen(final Cousr00cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
		} 
		
		/* 
		FIXME: CDEMO-FROM-TRANID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-FROM-PROGRAM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-PGM-CONTEXT */
		BluageUtils.unsupported();
		XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
	}

	/**
	 * Process operation sendUsrlstScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       SEND-USRLST-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendUsrlstScreen(final Cousr00cContext ctx, final ExecutionController ctrl) {
		populateHeaderInfo(ctx, ctrl);
		
		/* 
		FIXME: ERRMSGO OF COUSR0AO */
		BluageUtils.unsupported();
		if (ctx.getWsVariables().isSendEraseYes()) {
			SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
			.withMap("COUSR0A")
			.withMapset("COUSR00")
			.withData(BluageUtils.unsupported())
			.withErase()
			.withCursor()
			.execute()
			.handleException();
		} else {
			SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
			.withMap("COUSR0A")
			.withMapset("COUSR00")
			.withData(BluageUtils.unsupported())
			.withCursor()
			.execute()
			.handleException();
		}
	}

	/**
	 * Process operation receiveUsrlstScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RECEIVE-USRLST-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void receiveUsrlstScreen(final Cousr00cContext ctx, final ExecutionController ctrl) {
		ReceiveMapBuilder.newInstance(ctx.getJicsEiblk(), ctrl.getExecutionContext(), ctx)
		.withMap("COUSR0A")
		.withMapset("COUSR00")
		.into(BluageUtils.unsupported())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
	}

	/**
	 * Process operation populateHeaderInfo.
	 * 
	 * ----------------------------------------------------------------*
	 *                       POPULATE-HEADER-INFO
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void populateHeaderInfo(final Cousr00cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE01O OF COUSR0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE02O OF COUSR0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNNAMEO OF COUSR0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PGMNAMEO OF COUSR0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURDATEO OF COUSR0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-HH */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-SS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURTIMEO OF COUSR0AO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation startbrUserSecFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       STARTBR-USER-SEC-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void startbrUserSecFile(final Cousr00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsUsrsecFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.startBrowse()
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			
			/* 
			Do nothing */
			ctx.getWsVariables().setUserSecEof(true);
			ctx.getWsVariables().setWsMessage("You are at the top of the page...");
			
			/* 
			FIXME: USRIDINL OF COUSR0AI */
			BluageUtils.unsupported();
			sendUsrlstScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup User...");
			
			/* 
			FIXME: USRIDINL OF COUSR0AI */
			BluageUtils.unsupported();
			sendUsrlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation readnextUserSecFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       READNEXT-USER-SEC-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readnextUserSecFile(final Cousr00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsUsrsecFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.readNext()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.ENDFILE.getIntValue()) {
			
			/* 
			Do nothing */
			ctx.getWsVariables().setUserSecEof(true);
			ctx.getWsVariables().setWsMessage("You have reached the bottom of the page...");
			
			/* 
			FIXME: USRIDINL OF COUSR0AI */
			BluageUtils.unsupported();
			sendUsrlstScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup User...");
			
			/* 
			FIXME: USRIDINL OF COUSR0AI */
			BluageUtils.unsupported();
			sendUsrlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation readprevUserSecFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       READPREV-USER-SEC-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readprevUserSecFile(final Cousr00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsUsrsecFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.readPrev()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.ENDFILE.getIntValue()) {
			
			/* 
			Do nothing */
			ctx.getWsVariables().setUserSecEof(true);
			ctx.getWsVariables().setWsMessage("You have reached the top of the page...");
			
			/* 
			FIXME: USRIDINL OF COUSR0AI */
			BluageUtils.unsupported();
			sendUsrlstScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup User...");
			
			/* 
			FIXME: USRIDINL OF COUSR0AI */
			BluageUtils.unsupported();
			sendUsrlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation endbrUserSecFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       ENDBR-USER-SEC-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void endbrUserSecFile(final Cousr00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsUsrsecFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.endBrowse()
		.execute()
		.handleException();
		
		/* 
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:34 CDT */
		return;
	}

}
