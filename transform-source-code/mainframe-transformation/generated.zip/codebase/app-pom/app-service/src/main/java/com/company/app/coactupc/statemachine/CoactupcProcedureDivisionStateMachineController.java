package com.company.app.coactupc.statemachine;

import com.company.app.coactupc.business.context.CoactupcContext;
import com.company.app.coactupc.statemachine.CoactupcProcedureDivisionStateMachineController.Events;
import com.company.app.coactupc.statemachine.CoactupcProcedureDivisionStateMachineController.States;
import com.company.app.coactupc.statemachine.CoactupcProcedureDivisionStateMachineService;
import com.github.oxo42.stateless4j.StateMachineConfig;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.context.RuntimeContext;
import com.netfective.bluage.gapwalk.rt.statemachine.MultipleActiveContinuationController;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Controller managing the state machine "CoactupcProcedureDivisionStateMachine" execution.
 */
@Component("com.company.app.coactupc.statemachine.CoactupcProcedureDivisionStateMachineController")
@Import({
com.company.app.coactupc.statemachine.CoactupcProcedureDivisionStateMachineService.class
})
@Lazy
public class CoactupcProcedureDivisionStateMachineController extends MultipleActiveContinuationController<States, Events> {
	
	/**
	 * State machine states.
	 */
	public enum States {
		_0000_MAIN_1, _0000_MAIN, _2000_DECIDE_ACTION, _9600_WRITE_PROCESSING, _9600_WRITE_PROCESSING_EXIT, _9700_CHECK_CHANGE_IN_REC, _9700_CHECK_CHANGE_IN_REC_EXIT, ABEND_ROUTINE, _0000_MAIN_CASEBRANCH, _2000_DECIDE_ACTION_POSTIF, _2000_DECIDE_ACTION_CASEBRANCH, _2000_DECIDE_ACTION_CASEBRANCH_1, _0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT, _2000_DECIDE_ACTION_POST__9600WRITEPROCESSING_THRU__9600WRITEPROCESSINGEXIT, _9600_WRITE_PROCESSING_POST__9700CHECKCHANGEINREC_THRU__9700CHECKCHANGEINRECEXIT, FINAL, LOCAL_FINAL
	}

	/**
	 * State machine events.
	 */
	public enum Events {
		TO__0000_MAIN_1, TO__0000_MAIN, TO__2000_DECIDE_ACTION, TO__9600_WRITE_PROCESSING, TO__9600_WRITE_PROCESSING_EXIT, TO__9700_CHECK_CHANGE_IN_REC, TO__9700_CHECK_CHANGE_IN_REC_EXIT, TO_ABEND_ROUTINE, TO__0000_MAIN_CASEBRANCH, TO__2000_DECIDE_ACTION_POSTIF, TO__2000_DECIDE_ACTION_CASEBRANCH, TO__2000_DECIDE_ACTION_CASEBRANCH_1, TO__0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT, TO__2000_DECIDE_ACTION_POST__9600WRITEPROCESSING_THRU__9600WRITEPROCESSINGEXIT, TO__9600_WRITE_PROCESSING_POST__9700CHECKCHANGEINREC_THRU__9700CHECKCHANGEINRECEXIT, TO_FINAL, TO_LOCAL_FINAL
	}

	/**
	 * State machine state process service provider.
	 */
	@Autowired
	@Lazy
	private CoactupcProcedureDivisionStateMachineService stateProcess;
	
	/**
	 * State machine controller initialization.
	 */
	@PostConstruct
	private void init(){
		initStateMachineController();
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine() throws Exception {
		throw new UnsupportedOperationException("Please use the two arguments configureStateMachine method instead: configureStateMachine(RuntimeContext ctx, ExecutionController ctrl)");
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine(RuntimeContext ctx, ExecutionController ctrl) throws Exception {
		
		StateMachineConfig<States, Events> configurer = new StateMachineConfig<>();
		configureInitialEnd(States._0000_MAIN_1,States.FINAL);
		CoactupcContext lctx = (CoactupcContext) ctx;

		configurer.configure(States._0000_MAIN).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._0000Main(lctx, ctrl);}))
		.permit(Events.TO__0000_MAIN_CASEBRANCH, States._0000_MAIN_CASEBRANCH)
		;	
		configurer.configure(States._2000_DECIDE_ACTION).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideAction(lctx, ctrl);}))
		.permit(Events.TO__2000_DECIDE_ACTION_CASEBRANCH, States._2000_DECIDE_ACTION_CASEBRANCH)
		.permit(Events.TO__2000_DECIDE_ACTION_CASEBRANCH_1, States._2000_DECIDE_ACTION_CASEBRANCH_1)
		.permit(Events.TO__2000_DECIDE_ACTION_POSTIF, States._2000_DECIDE_ACTION_POSTIF)
		;	
		configurer.configure(States._9600_WRITE_PROCESSING).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._9600WriteProcessing(lctx, ctrl);}))
		.permit(Events.TO__9600_WRITE_PROCESSING_EXIT, States._9600_WRITE_PROCESSING_EXIT)
		.permit(Events.TO__9700_CHECK_CHANGE_IN_REC, States._9700_CHECK_CHANGE_IN_REC)
		;	
		configurer.configure(States._9600_WRITE_PROCESSING_EXIT).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._9600WriteProcessingExit(lctx, ctrl);}))
		.permit(Events.TO__2000_DECIDE_ACTION_POST__9600WRITEPROCESSING_THRU__9600WRITEPROCESSINGEXIT, States._2000_DECIDE_ACTION_POST__9600WRITEPROCESSING_THRU__9600WRITEPROCESSINGEXIT)
		;	
		configurer.configure(States._9700_CHECK_CHANGE_IN_REC).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._9700CheckChangeInRec(lctx, ctrl);}))
		.permit(Events.TO__9600_WRITE_PROCESSING_EXIT, States._9600_WRITE_PROCESSING_EXIT)
		.permit(Events.TO__9700_CHECK_CHANGE_IN_REC_EXIT, States._9700_CHECK_CHANGE_IN_REC_EXIT)
		;	
		configurer.configure(States._9700_CHECK_CHANGE_IN_REC_EXIT).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._9700CheckChangeInRecExit(lctx, ctrl);}))
		.permit(Events.TO__9600_WRITE_PROCESSING_POST__9700CHECKCHANGEINREC_THRU__9700CHECKCHANGEINRECEXIT, States._9600_WRITE_PROCESSING_POST__9700CHECKCHANGEINREC_THRU__9700CHECKCHANGEINRECEXIT)
		;	
		configurer.configure(States.ABEND_ROUTINE).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess.abendRoutine(lctx, ctrl);}))
		.permit(Events.TO_FINAL, States.FINAL)
		.permit(Events.TO__2000_DECIDE_ACTION_POSTIF, States._2000_DECIDE_ACTION_POSTIF)
		;	
		configurer.configure(States._0000_MAIN_CASEBRANCH).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._0000MainCasebranch(lctx, ctrl);}))
		.permit(Events.TO__2000_DECIDE_ACTION, States._2000_DECIDE_ACTION)
		;	
		configurer.configure(States._2000_DECIDE_ACTION_POSTIF).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideActionPostif(lctx, ctrl);}))
		.permit(Events.TO__0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT, States._0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT)
		;	
		configurer.configure(States._2000_DECIDE_ACTION_CASEBRANCH).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideActionCasebranch(lctx, ctrl);}))
		.permit(Events.TO__9600_WRITE_PROCESSING, States._9600_WRITE_PROCESSING)
		;	
		configurer.configure(States._2000_DECIDE_ACTION_CASEBRANCH_1).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideActionCasebranch1(lctx, ctrl);}))
		.permit(Events.TO_ABEND_ROUTINE, States.ABEND_ROUTINE)
		;	
		configurer.configure(States._0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._0000MainPost2000decideactionThru2000decideactionexit(lctx, ctrl);}))
		;	
		configurer.configure(States._2000_DECIDE_ACTION_POST__9600WRITEPROCESSING_THRU__9600WRITEPROCESSINGEXIT).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideActionPost9600writeprocessingThru9600writeprocessingexit(lctx, ctrl);}))
		.permit(Events.TO__2000_DECIDE_ACTION_POSTIF, States._2000_DECIDE_ACTION_POSTIF)
		;	
		configurer.configure(States._9600_WRITE_PROCESSING_POST__9700CHECKCHANGEINREC_THRU__9700CHECKCHANGEINRECEXIT).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._9600WriteProcessingPost9700checkchangeinrecThru9700checkchangeinrecexit(lctx, ctrl);}))
		.permit(Events.TO__9600_WRITE_PROCESSING_EXIT, States._9600_WRITE_PROCESSING_EXIT)
		;	
		
		configurer.configure(States._0000_MAIN_1)
		.onEntry(()->{runSubStateMachine(Events.TO__0000_MAIN);})
		.permit(Events.TO__0000_MAIN, States._0000_MAIN)
		.permit(Events.TO_FINAL, States.FINAL)
		.permitInternal(Events.TO_ABEND_ROUTINE, buildRunAction(() -> {stateProcess.abendRoutine(lctx, ctrl);}))
		;	
		
		return configurer;
	}
	
}
