// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "TRANEXTR"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	mapTransfo['HLQ'] = 'AWS.M2.CARDDEMO' 
	//********************************************************************
	//***  Db2 Unload using DSNTIAUL utility                        ******
	//********************************************************************
	//**   STEP 10 : BACKUP THE PREVIOUS VERSION OF TRANTYPE FILE TO GDG
	//********************************************************************
	lastProgramResult = stepSTEP10(shell, params, programResults)
	//********************************************************************
	//**   STEP 20 : BACKUP THE PREVIOUS VERSION OF TRANCATG FILE TO GDG
	//********************************************************************
	lastProgramResult = stepSTEP20(shell, params, programResults)
	//********************************************************************
	//***  STEP 30 : DELETE FILES FROM PREVIOUS RUN                 ******
	//********************************************************************
	lastProgramResult = stepSTEP30(shell, params, programResults)
	//********************************************************************
	//***  STEP 40 : EXTRACT DATA FROM TRANSACTION TYPE TABLE       ******
	//********************************************************************
	lastProgramResult = stepSTEP40(shell, params, programResults)
	//********************************************************************
	//***  STEP 50 : EXTRACT DATA FROM TRANSACTION TYPE TABLE       ******
	//********************************************************************
	lastProgramResult = stepSTEP50(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP STEP10 - PGM - IEBGENER***************************************************
def stepSTEP10(Object shell, Map params, Map programResults){
	mapTransfo['HLQ'] = 'AWS.M2.CARDDEMO' 
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP10", "IEBGENER", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.dummy("SYSIN")
						.build()
						.bluesam("SYSUT1")
						.dataset("&HLQ..TRANTYPE.PS")
						.disposition("SHR")
						.build()
						.gdgSupport("SYSUT2")
						.name(params["MapTransfo"]['HLQ'] + ".TRANTYPE.BKUP").ownerPath(".").relativeGeneration(1).storageProvider("filesystem").recordSize(60)
						.disposition("NEW")
						.normalTermination("CATLG")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IEBGENER")
				})
		}
	}
}
// STEP STEP20 - PGM - IEBGENER***************************************************
def stepSTEP20(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("STEP20", "IEBGENER", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.dummy("SYSIN")
							.build()
							.bluesam("SYSUT1")
							.dataset("&HLQ..TRANCATG.PS")
							.disposition("SHR")
							.build()
							.gdgSupport("SYSUT2")
							.name(params["MapTransfo"]['HLQ'] + ".TRANCATG.PS.BKUP").ownerPath(".").relativeGeneration(1).storageProvider("filesystem").recordSize(60)
							.disposition("NEW")
							.normalTermination("CATLG")
							.build()
							.getFileConfigurations())
						.withParameters(params)
						.runProgram("IEBGENER")
					})
			}
		}
	}
}
// STEP STEP30 - PGM - IEFBR14****************************************************
def stepSTEP30(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("STEP30", "IEFBR14", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.bluesam("DD01")
							.dataset("&HLQ..TRANTYPE.PS")
							.disposition("MOD")
							.normalTermination("DELETE")
							.abnormalTermination("DELETE")
							.build()
							.bluesam("DD02")
							.dataset("&HLQ..TRANCATG.PS")
							.disposition("MOD")
							.normalTermination("DELETE")
							.abnormalTermination("DELETE")
							.build()
							.getFileConfigurations())
						.withParameters(params)
						.runProgram("IEFBR14")
					})
			}
		}
	}
}
// STEP STEP40 - PGM - IKJEFT01***************************************************
def stepSTEP40(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("STEP40", "IKJEFT01", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.concatenation("STEPLIB")
							.path("OEM.DB2.DAZ1.RUNLIB.LOAD")
							.disposition("SHR")
							.path("OEMA.DB2.VERSIONA.SDSNLOAD")
							.disposition("SHR")
							.build()
							.systemOut("SYSTSPRT")
							.output("*")
							.build()
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.systemOut("SYSUDUMP")
							.output("*")
							.build()
							.dummy("SYSPUNCH")
							.build()
							.bluesam("SYSREC00")
							.dataset("&HLQ..TRANTYPE.PS")
							.disposition("NEW")
							.normalTermination("CATLG")
							.abnormalTermination("DELETE")
							.build()
							.fileSystem("SYSIN")
							.stream(
""" SELECT CAST(CONCAT(CONCAT(
   TR_TYPE
  ,CAST(TR_DESCRIPTION AS CHAR(50))
   )
  ,REPEAT('0',8)
 ) AS CHAR(60))
  FROM
  CARDDEMO.TRANSACTION_TYPE
  ORDER BY TR_TYPE;""", getEncoding())
							.build()
							.fileSystem("SYSTSIN")
							.stream(
"""  DSN SYSTEM(DAZ1)
  RUN PROGRAM(DSNTIAUL) -
  PLAN(DSNTIAUL) -
  PARMS('SQL')""", getEncoding())
							.build()
							.getFileConfigurations())
						.withParameters(params)
						.runProgram("IKJEFT01")
					})
			}
		}
	}
}
// STEP STEP50 - PGM - IKJEFT01***************************************************
def stepSTEP50(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'LT', 4)) {
				return execStep("STEP50", "IKJEFT01", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.concatenation("STEPLIB")
							.path("OEM.DB2.DAZ1.RUNLIB.LOAD")
							.disposition("SHR")
							.path("OEMA.DB2.VERSIONA.SDSNLOAD")
							.disposition("SHR")
							.build()
							.systemOut("SYSTSPRT")
							.output("*")
							.build()
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.systemOut("SYSUDUMP")
							.output("*")
							.build()
							.dummy("SYSPUNCH")
							.build()
							.bluesam("SYSREC00")
							.dataset("&HLQ..TRANCATG.PS")
							.disposition("NEW")
							.normalTermination("CATLG")
							.abnormalTermination("DELETE")
							.build()
							.fileSystem("SYSIN")
							.stream(
"""  SELECT CAST(
        TRC_TYPE_CODE
     || TRC_TYPE_CATEGORY
     || CAST(TRC_CAT_DATA AS CHAR(50))
     || REPEAT('0',4)
                      AS CHAR(60))
  FROM  CARDDEMO.TRANSACTION_TYPE_CATEGORY
  ORDER BY
        TRC_TYPE_CODE
      , TRC_TYPE_CATEGORY;""", getEncoding())
							.build()
							.fileSystem("SYSTSIN")
							.stream(
"""  DSN SYSTEM(DAZ1)
  RUN PROGRAM(DSNTIAUL) -
  PLAN(DSNTIAUL) -
  PARMS('SQL')""", getEncoding())
							.build()
							.getFileConfigurations())
						.withParameters(params)
						.runProgram("IKJEFT01")
					})
			}
		}
	}
}
