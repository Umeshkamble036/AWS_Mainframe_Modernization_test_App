package com.company.app.csutldtc.service;

import com.company.app.csutldtc.business.context.CsutldtcContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface CsutldtcProcess.
 * 
 * Defines application services for CsutldtcProcess
 */
public interface CsutldtcProcess {

	/**
	 * Process operation procedureDivision.
	 * 
	 * PROGRAM-ID.CSUTLDTC.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void procedureDivision(final CsutldtcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation a000Main.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void a000Main(final CsutldtcContext ctx, final ExecutionController ctrl);

}
