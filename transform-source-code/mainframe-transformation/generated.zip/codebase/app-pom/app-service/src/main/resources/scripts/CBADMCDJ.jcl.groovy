// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "CBADMCDJ"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	mapTransfo['HLQ'] = 'AWS.M2.CARDDEMO' 
	//
	lastProgramResult = stepSTEP1(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult") // End of job statement.
	//
	// Ver: CardDemo_v1.0-70-g193b394-123 Date: 2022-08-22 17:02:44 CDT
	//
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP STEP1 - PGM - DFHCSDUP****************************************************
def stepSTEP1(Object shell, Map params, Map programResults){
	mapTransfo['HLQ'] = 'AWS.M2.CARDDEMO' 
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP1", "DFHCSDUP", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.bluesam("STEPLIB")
						.dataset("OEM.CICSTS.V05R06M0.CICS.SDFHLOAD")
						.disposition("SHR")
						.build()
						.bluesam("DFHCSD")
						.dataset("OEM.CICSTS.DFHCSD")
						.disposition("SHR")
						.build()
						.systemOut("OUTDD")
						.output("*")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSIN")
						.stream("", getEncoding())
						.build()
						.fileSystem("SYSIN")
						.stream(
"""*/********************************************************************/
*/*  CARDDEMO CICS DEFINITIONS                                       */
*/********************************************************************/
* NOTE: INSTALL GROUP(CARDDEMO) - CEDA IN G(CARDDEMO)                *
*     IF YOU ARE RERUNNING THIS, UNCOMMENT THE DELETE COMMAND. *
*
* START CARDDEMO RESOURCES:
*
* DELETE GROUP(CARDDEMO)

  DEFINE LIBRARY(COM2DOLL) GROUP(CARDDEMO)
                DSNAME01(&HLQ..LOADLIB)

* DEFINE TDQUEUE(CSSD) GROUP(CARDDEMO) TYPE(INTRA)
* DEFINE TDQUEUE(IRDC) GROUP(CARDDEMO) TYPE(INTRA)

  DEFINE MAPSET(COSGN00M)   GROUP(CARDDEMO)
         DESCRIPTION(LOGIN SCREEN)

  DEFINE MAPSET(COSGN00M)   GROUP(CARDDEMO)
         DESCRIPTION(LOGIN SCREEN)

  DEFINE MAPSET(COACT00S)   GROUP(CARDDEMO)
         DESCRIPTION(ACCOUNT MENU)
  DEFINE MAPSET(COACTVWS)   GROUP(CARDDEMO)
         DESCRIPTION(VIEW ACCOUNT)
  DEFINE MAPSET(COACTUPS)   GROUP(CARDDEMO)
         DESCRIPTION(UPDATE ACCOUNT)
  DEFINE MAPSET(COACTDES)   GROUP(CARDDEMO)
         DESCRIPTION(DEACTIVATE ACCOUNT)

  DEFINE MAPSET(COACT00S)   GROUP(CARDDEMO)
         DESCRIPTION(CARD MENU)
  DEFINE MAPSET(COACTVWS)   GROUP(CARDDEMO)
         DESCRIPTION(VIEW CARD)
  DEFINE MAPSET(COACTUPS)   GROUP(CARDDEMO)
         DESCRIPTION(UPDATE CARD)
  DEFINE MAPSET(COACTDES)   GROUP(CARDDEMO)
         DESCRIPTION(DEACTIVATE CARD)

  DEFINE MAPSET(COTRN00S)   GROUP(CARDDEMO)
         DESCRIPTION(TRANSACTION)
  DEFINE MAPSET(COTRNVWS)   GROUP(CARDDEMO)
         DESCRIPTION(TRANSACTION REPORT)
  DEFINE MAPSET(COTRNVDS)   GROUP(CARDDEMO)
         DESCRIPTION(TRANSACTION DETAILS)
  DEFINE MAPSET(COTRNATS)   GROUP(CARDDEMO)
         DESCRIPTION(ADD TRANSACTIONS)

  DEFINE MAPSET(COBIL00S)   GROUP(CARDDEMO)
         DESCRIPTION(BILL PAY SETUP)

  DEFINE MAPSET(COADM00S)   GROUP(CARDDEMO)
         DESCRIPTION(ADMIN MENU)

  DEFINE MAPSET(COTSTP1S)   GROUP(CARDDEMO)
         DESCRIPTION(PGM1 TEST)
  DEFINE MAPSET(COTSTP2S)   GROUP(CARDDEMO)
         DESCRIPTION(PGM2 TEST)
  DEFINE MAPSET(COTSTP3S)   GROUP(CARDDEMO)
         DESCRIPTION(PGM3 TEST)
  DEFINE MAPSET(COTSTP4S)   GROUP(CARDDEMO)
         DESCRIPTION(PGM4 TEST)

  DEFINE PROGRAM(COSGN00C) GROUP(CARDDEMO) DA(ANY) TRANSID(CC00)
         DESCRIPTION(LOGIN)

  DEFINE PROGRAM(COACT00C) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(ACCOUNT MAIN MENU)
  DEFINE PROGRAM(COACTVWC) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(VIEW ACCOUNT)
  DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(UPDATE ACCOUNT)
  DEFINE PROGRAM(COACTDEC) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(DEACTIVATE ACCOUNT)

  DEFINE PROGRAM(COACT00C) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(CARD MENU)
  DEFINE PROGRAM(COACTVWC) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(VIEW CARD)
  DEFINE PROGRAM(COACTUPC) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(UPDATE CARD)
  DEFINE PROGRAM(COACTDEC) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(DEACTIVATE CARD)
  DEFINE PROGRAM(COTRN00C) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(TRANSACTION)
  DEFINE PROGRAM(COTRNVWC) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(TRANSACTION REPORT)
  DEFINE PROGRAM(COTRNVDC) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(TRANSACTION DETAILS)
  DEFINE PROGRAM(COTRNATC) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(ADD TRANSACTIONS)

  DEFINE PROGRAM(COBIL00C) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(BILL PAY)

  DEFINE PROGRAM(COADM00C) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(ADMIN MENU)
         TRANSID(CCAD)

  DEFINE PROGRAM(COTSTP1C) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(PGM1 TEST)
         TRANSID(CCT1)
  DEFINE PROGRAM(COTSTP2C) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(PGM2 TEST)
         TRANSID(CCT2)
  DEFINE PROGRAM(COTSTP3C) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(PGM1 TEST)
         TRANSID(CCT3)
  DEFINE PROGRAM(COTSTP4C) GROUP(CARDDEMO) DA(ANY)
         DESCRIPTION(PGM4 TEST)
         TRANSID(CCT4)

  DEFINE TRANSACTION(CCDM) GROUP(CARDDEMO)
                PROGRAM(COADM00C) TASKDATAL(ANY)

  DEFINE TRANSACTION(CCT1) GROUP(CARDDEMO)
                PROGRAM(COTSTP1C) TASKDATAL(ANY)
  DEFINE TRANSACTION(CCT2) GROUP(CARDDEMO)
                PROGRAM(COTSTP2C) TASKDATAL(ANY)
  DEFINE TRANSACTION(CCT3) GROUP(CARDDEMO)
                PROGRAM(COTSTP3C) TASKDATAL(ANY)
  DEFINE TRANSACTION(CCT4) GROUP(CARDDEMO)
                PROGRAM(COTSTP4C) TASKDATAL(ANY)

  LIST   GROUP(CARDDEMO)
*
* END CARDDEMO RESOURCES
*""", getEncoding())
						.build()
						.getFileConfigurations())
					.withArguments(getParm("CSD(READWRITE),PAGESIZE(60),NOCOMPAT"))
					.withParameters(params)
					.runProgram("DFHCSDUP")
				})
		}
	}
}
