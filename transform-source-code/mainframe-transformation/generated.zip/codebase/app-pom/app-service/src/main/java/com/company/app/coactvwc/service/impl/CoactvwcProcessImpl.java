
package com.company.app.coactvwc.service.impl;

import com.company.app.coactvwc.business.context.CoactvwcContext;
import com.company.app.coactvwc.service.CoactvwcProcess;
import com.company.app.coactvwc.statemachine.CoactvwcProcedureDivisionStateMachineController;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.bms.ReceiveMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendTextBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.jics.io.internal.JicsFileBuilder;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class CoactvwcProcessImpl
 * 
 * Defines application services for CoactvwcProcess
 * @see CoactvwcProcess
 */
@Service("com.company.app.coactvwc.service.CoactvwcProcess")
@Import({
com.company.app.coactvwc.statemachine.CoactvwcProcedureDivisionStateMachineController.class 
}) 	
@Lazy

public class CoactvwcProcessImpl implements CoactvwcProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(CoactvwcProcessImpl.class);

	@Autowired
	private CoactvwcProcedureDivisionStateMachineController coactvwcProcedureDivisionStateMachineRunner;


	/**
	 * Process operation coactvwc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void coactvwc(final CoactvwcContext ctx, final ExecutionController ctrl) {
		coactvwcProcedureDivisionStateMachineRunner.run(ctx,ctrl);
	}

	/**
	 * Process operation commonReturn.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void commonReturn(final CoactvwcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CCARD-ERROR-MSG */
		BluageUtils.unsupported();
		ctx.getWsCommarea().setWsCommarea(BluageUtils.unsupported());
		int idx = BluageUtils.unsupported().length() + 1 - 1;
		int len = ctx.getWsThisProgcommarea().getSize();
		ctx.getWsCommarea().getWsCommareaReference().setBytes(ctx.getWsThisProgcommarea().getBytes(), idx, len);
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsLiterals().getLitThistranid())
		.withCommarea(ctx.getWsCommarea().getWsCommareaReference())
		.withLength(ctx.getWsCommarea().getWsCommareaReference().getRecord().getSize())
		.execute()
		.handleException();
	}

	/**
	 * Process operation _1000SendMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1000SendMap(final CoactvwcContext ctx, final ExecutionController ctrl) {
		_1100ScreenInit(ctx, ctrl);
		_1200SetupScreenVars(ctx, ctrl);
		_1300SetupScreenAttrs(ctx, ctrl);
		_1400SendScreen(ctx, ctrl);
	}

	/**
	 * Process operation _1100ScreenInit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1100ScreenInit(final CoactvwcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CACTVWAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE01O OF CACTVWAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE02O OF CACTVWAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNNAMEO OF CACTVWAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PGMNAMEO OF CACTVWAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURDATEO OF CACTVWAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-HH */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-SS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURTIMEO OF CACTVWAO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation _1200SetupScreenVars.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1200SetupScreenVars(final CoactvwcContext ctx, final ExecutionController ctrl) {
		/* 
		INITIALIZE SEARCH CRITERIA */
		if (ctx.getDfheiblk().getEibcalen() == 0) {
			ctx.getWsMiscStorage().setWsPromptForInput(true);
		} else {
			if (ctx.getWsMiscStorage().isFlgAcctfilterBlank()) {
				
				/* 
				FIXME: ACCTSIDO OF CACTVWAO */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: ACCTSIDO OF CACTVWAO */
				BluageUtils.unsupported();
			}
			if (ctx.getWsMiscStorage().isFoundAcctInMaster() || ctx.getWsMiscStorage().isFoundCustInMaster()) {
				
				/* 
				FIXME: ACSTTUSO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACURBALO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACRDLIMO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSHLIMO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACRCYCRO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACRCYDBO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ADTOPENO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: AEXPDTO  OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: AREISDTO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: AADDGRPO OF CACTVWAO */
				BluageUtils.unsupported();
			} 
			if (ctx.getWsMiscStorage().isFoundCustInMaster()) {
				
				/* 
				FIXME: ACSTNUMO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				MOVE CUST-SSN             TO ACSTSSNO OF CACTVWAO */
				StringConcatenationBuilder.newInstance(BluageUtils.unsupported())
					.addDelimitedBySize(BluageUtils.unsupported())
					.addDelimitedBySize("-")
					.addDelimitedBySize(BluageUtils.unsupported())
					.addDelimitedBySize("-")
					.addDelimitedBySize(BluageUtils.unsupported())
					.end();
				
				/* 
				FIXME: ACSTFCOO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSTDOBO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSFNAMO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSMNAMO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSLNAMO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSADL1O OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSADL2O OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSCITYO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSSTTEO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSZIPCO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSCTRYO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSPHN1O OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSPHN2O OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSGOVTO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSEFTCO OF CACTVWAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACSPFLGO OF CACTVWAO */
				BluageUtils.unsupported();
			} 
		}
		
		/* 
		SETUP MESSAGE */
		if (ctx.getWsMiscStorage().isWsNoInfoMessage()) {
			ctx.getWsMiscStorage().setWsPromptForInput(true);
		} 
		
		/* 
		FIXME: ERRMSGO OF CACTVWAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: INFOMSGO OF CACTVWAO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation _1300SetupScreenAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1300SetupScreenAttrs(final CoactvwcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: ACCTSIDA OF CACTVWAI
		PROTECT OR UNPROTECT BASED ON CONTEXT */
		BluageUtils.unsupported();
		
		/* 
		POSITION CURSOR */
		if (ctx.getWsMiscStorage().isFlgAcctfilterNotOk() || ctx.getWsMiscStorage().isFlgAcctfilterBlank()) {
			
			/* 
			FIXME: ACCTSIDL OF CACTVWAI */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: ACCTSIDL OF CACTVWAI */
			BluageUtils.unsupported();
		}
		
		/* 
		FIXME: ACCTSIDC OF CACTVWAO
		SETUP COLOR */
		BluageUtils.unsupported();
		if (ctx.getWsMiscStorage().isFlgAcctfilterNotOk()) {
			
			/* 
			FIXME: ACCTSIDC OF CACTVWAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgAcctfilterBlank() && BluageUtils.unsupported()) {
			
			/* 
			FIXME: ACCTSIDO OF CACTVWAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACCTSIDC OF CACTVWAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isWsNoInfoMessage()) {
			
			/* 
			FIXME: INFOMSGC OF CACTVWAO */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: INFOMSGC OF CACTVWAO */
			BluageUtils.unsupported();
		}
	}

	/**
	 * Process operation _1400SendScreen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1400SendScreen(final CoactvwcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CCARD-NEXT-MAPSET */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CCARD-NEXT-MAP */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-PGM-REENTER */
		BluageUtils.unsupported();
		SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withMap(BluageUtils.unsupported())
		.withMapset(BluageUtils.unsupported())
		.withData(BluageUtils.unsupported())
		.withCursor()
		.withErase()
		.withFreeKB()
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
	}

	/**
	 * Process operation _2000ProcessInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2000ProcessInputs(final CoactvwcContext ctx, final ExecutionController ctrl) {
		_2100ReceiveMap(ctx, ctrl);
		_2200EditMapInputs(ctx, ctrl);
		
		/* 
		FIXME: CCARD-ERROR-MSG */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CCARD-NEXT-PROG */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CCARD-NEXT-MAPSET */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CCARD-NEXT-MAP */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation _2100ReceiveMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2100ReceiveMap(final CoactvwcContext ctx, final ExecutionController ctrl) {
		ReceiveMapBuilder.newInstance(ctx.getJicsEiblk(), ctrl.getExecutionContext(), ctx)
		.withMap(ctx.getWsLiterals().getLitThismapReference())
		.withMapset(ctx.getWsLiterals().getLitThismapsetReference())
		.into(BluageUtils.unsupported())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
	}

	/**
	 * Process operation _2200EditMapInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2200EditMapInputs(final CoactvwcContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setInputOk(true);
		ctx.getWsMiscStorage().setFlgAcctfilterIsvalid(true);
		
		/* 
		REPLACE * WITH LOW-VALUES */
		if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CC-ACCT-ID */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: CC-ACCT-ID */
			BluageUtils.unsupported();
		}
		
		/* 
		INDIVIDUAL FIELD EDITS */
		_2210EditAccount(ctx, ctrl);
		
		/* 
		CROSS FIELD EDITS */
		if (ctx.getWsMiscStorage().isFlgAcctfilterBlank()) {
			ctx.getWsMiscStorage().setNoSearchCriteriaReceived(true);
		}
	}

	/**
	 * Process operation _2210EditAccount.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2210EditAccount(final CoactvwcContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
		
		/* 
		Not supplied */
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAcctfilterBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setWsPromptForAcct(true);
			} 
			
			/* 
			FIXME: CDEMO-ACCT-ID */
			BluageUtils.unsupported();
			return;
		} else {
			
			/* 
			Not numeric
			Not 11 characters */
			if (!(DataUtils.isNumeric(BluageUtils.unsupported())) || DataUtils.isZero(BluageUtils.unsupported())) {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					ctx.getWsMiscStorage().setWsReturnMsg("Account Filter must  be a non-zero 11 digit number");
				} 
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				BluageUtils.unsupported();
				return;
			} else {
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				BluageUtils.unsupported();
				ctx.getWsMiscStorage().setFlgAcctfilterIsvalid(true);
				return;
			}
		}
	}

	/**
	 * Process operation _9000ReadAcct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9000ReadAcct(final CoactvwcContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setWsNoInfoMessage(true);
		ctx.getWsMiscStorage().setWsCardRidAcctId(BluageUtils.unsupported());
		_9200GetcardxrefByacct(ctx, ctrl);
		
		/* 
		IF DID-NOT-FIND-ACCT-IN-CARDXREF */
		if (ctx.getWsMiscStorage().isFlgAcctfilterNotOk()) {
			return;
		} else {
			_9300GetacctdataByacct(ctx, ctrl);
			if (ctx.getWsMiscStorage().isDidNotFindAcctInAcctdat()) {
				return;
			} else {
				ctx.getWsMiscStorage().setWsCardRidCustId(BluageUtils.unsupported());
				_9400GetcustdataBycust(ctx, ctrl);
				if (ctx.getWsMiscStorage().isDidNotFindCustInCustdat()) {
					return;
				} else {
					return;
				}
			}
		}
	}

	/**
	 * Process operation _9200GetcardxrefByacct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9200GetcardxrefByacct(final CoactvwcContext ctx, final ExecutionController ctrl) {
		/* 
		Read the Card file. Access via alternate index ACCTID */
		JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitCardxrefnameAcctPathReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference())
		.keyLength(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference().getRecord().getSize(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			FIXME: CDEMO-CUST-ID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-CARD-NUM */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
				ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize("Account:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference().getBytes())
					.addDelimitedBySize(" not found in")
					.addDelimitedBySize(" Cross ref file.  Resp:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getErrorRespReference().getBytes())
					.addDelimitedBySize(" Reas:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getErrorResp2Reference().getBytes())
					.end();
			} 
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
			ctx.getWsMiscStorage().setErrorOpname("READ");
			ctx.getWsMiscStorage().setErrorFile(ctx.getWsLiterals().getLitCardxrefnameAcctPath());
			ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
			ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
			ctx.getWsMiscStorage().getWsReturnMsgReference().setBytes(ctx.getWsMiscStorage().getWsFileErrorMessageReference().getBytes());
			
			/* 
			WS-LONG-MSG
			PERFORM SEND-LONG-TEXT */
		}
	}

	/**
	 * Process operation _9300GetacctdataByacct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9300GetacctdataByacct(final CoactvwcContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitAcctfilenameReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference())
		.keyLength(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference().getRecord().getSize(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			ctx.getWsMiscStorage().setFoundAcctInMaster(true);
		} else if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
			
			/* 
			SET DID-NOT-FIND-ACCT-IN-ACCTDAT TO TRUE */
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
				ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize("Account:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference().getBytes())
					.addDelimitedBySize(" not found in")
					.addDelimitedBySize(" Acct Master file.Resp:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getErrorRespReference().getBytes())
					.addDelimitedBySize(" Reas:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getErrorResp2Reference().getBytes())
					.end();
			} 
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
			ctx.getWsMiscStorage().setErrorOpname("READ");
			ctx.getWsMiscStorage().setErrorFile(ctx.getWsLiterals().getLitAcctfilename());
			ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
			ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
			ctx.getWsMiscStorage().getWsReturnMsgReference().setBytes(ctx.getWsMiscStorage().getWsFileErrorMessageReference().getBytes());
			
			/* 
			WS-LONG-MSG
			PERFORM SEND-LONG-TEXT */
		}
	}

	/**
	 * Process operation _9400GetcustdataBycust.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9400GetcustdataBycust(final CoactvwcContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitCustfilenameReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidCustIdXReference())
		.keyLength(ctx.getWsMiscStorage().getWsCardRidCustIdXReference().getRecord().getSize(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			ctx.getWsMiscStorage().setFoundCustInMaster(true);
		} else if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgCustfilterNotOk(true);
			
			/* 
			SET DID-NOT-FIND-CUST-IN-CUSTDAT TO TRUE */
			ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
			ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize("CustId:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsCardRidCustIdXReference().getBytes())
					.addDelimitedBySize(" not found")
					.addDelimitedBySize(" in customer master.Resp: ")
					.addDelimitedBySize(ctx.getWsMiscStorage().getErrorRespReference().getBytes())
					.addDelimitedBySize(" REAS:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getErrorResp2Reference().getBytes())
					.end();
			} 
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgCustfilterNotOk(true);
			ctx.getWsMiscStorage().setErrorOpname("READ");
			ctx.getWsMiscStorage().setErrorFile(ctx.getWsLiterals().getLitCustfilename());
			ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
			ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
			ctx.getWsMiscStorage().getWsReturnMsgReference().setBytes(ctx.getWsMiscStorage().getWsFileErrorMessageReference().getBytes());
			
			/* 
			WS-LONG-MSG
			PERFORM SEND-LONG-TEXT */
		}
	}

	/**
	 * Process operation sendPlainText.
	 * 
	 * ****************************************************************
	 *  Plain text exit - Dont use in production                      *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendPlainText(final CoactvwcContext ctx, final ExecutionController ctrl) {
		SendTextBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withData(ctx.getWsMiscStorage().getWsReturnMsgReference())
		.withLength(ctx.getWsMiscStorage().getWsReturnMsgReference().getRecord().getSize())
		.withErase()
		.withFreeKB()
		.execute()
		.handleException();
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.execute()
		.handleException();
	}

	/**
	 * Process operation sendLongText.
	 * 
	 * ****************************************************************
	 *  Display Long text and exit                                    *
	 *  This is primarily for debugging and should not be used in     *
	 *  regular course                                                *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendLongText(final CoactvwcContext ctx, final ExecutionController ctrl) {
		SendTextBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withData(ctx.getWsMiscStorage().getWsLongMsgReference())
		.withLength(ctx.getWsMiscStorage().getWsLongMsgReference().getRecord().getSize())
		.withErase()
		.withFreeKB()
		.execute()
		.handleException();
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.execute()
		.handleException();
	}

}
