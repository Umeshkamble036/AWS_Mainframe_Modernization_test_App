
package com.company.app.comen01c.service.impl;

import com.company.app.comen01c.business.context.Comen01cContext;
import com.company.app.comen01c.service.Comen01cProcess;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.NumberUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.bms.ReceiveMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.jics.internal.JicsProgramInquireBuilder;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.statements.InspectBuilder;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Comen01cProcessImpl
 * 
 * Defines application services for Comen01cProcess
 * @see Comen01cProcess
 */
@Service("com.company.app.comen01c.service.Comen01cProcess")
@Lazy

public class Comen01cProcessImpl implements Comen01cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Comen01cProcessImpl.class);


	/**
	 * Process operation mainPara.
	 * 
	 * PROGRAM-ID.COMEN01C.
	 *  AUTHOR.     AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void mainPara(final Comen01cContext ctx, final ExecutionController ctrl) {
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		*****************************************************************
		Program     : COMEN01C.CBL
		Application : CardDemo
		Type        : CICS COBOL Program
		Function    : Main Menu for the Regular users
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		----------------------------------------------------------------*
		WORKING STORAGE SECTION
		----------------------------------------------------------------*
		No background transparency
		----------------------------------------------------------------*
		LINKAGE SECTION
		----------------------------------------------------------------*
		----------------------------------------------------------------*
		PROCEDURE DIVISION
		----------------------------------------------------------------* */
		ctx.getWsVariables().setErrFlgOff(true);
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		FIXME: ERRMSGO OF COMEN1AO */
		BluageUtils.unsupported();
		if (ctx.getDfheiblk().getEibcalen() == 0) {
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			returnToSignonScreen(ctx, ctrl);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			if (!(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-PGM-REENTER */
				BluageUtils.unsupported();
				
				/* 
				FIXME: COMEN1AO */
				BluageUtils.unsupported();
				sendMenuScreen(ctx, ctrl);
			} else {
				receiveMenuScreen(ctx, ctrl);
				if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) == 0) {
					processEnterKey(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf3Reference()) == 0) {
					
					/* 
					FIXME: CDEMO-TO-PROGRAM */
					BluageUtils.unsupported();
					returnToSignonScreen(ctx, ctrl);
				} else {
					ctx.getWsVariables().setWsErrFlg("Y");
					ctx.getWsVariables().setWsMessage(BluageUtils.unsupported());
					sendMenuScreen(ctx, ctrl);
				}
			}
		}
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsVariables().getWsTranid())
		.withCommarea(BluageUtils.unsupported())
		.execute()
		.handleException();
	}

	/**
	 * Process operation processEnterKey.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-ENTER-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processEnterKey(final Comen01cContext ctx, final ExecutionController ctrl) {
		ctx.getWsVariables().setWsIdx(BluageUtils.unsupported().length());
		while (!(!(DataUtils.isBlank(BluageUtils.unsupported())) || ctx.getWsVariables().getWsIdx() == 1)) {
			ctx.getWsVariables().setWsIdx(ctx.getWsVariables().getWsIdx() + -1);
		}
		ctx.getWsVariables().setWsOptionX(BluageUtils.unsupported());
		InspectBuilder.newInstance(ctx.getWsVariables().getWsOptionXReference())
			.replace()
			.all(" ")
			.by("0")
			.apply();
		ctx.getWsVariables().setWsOption(NumberUtils.convert(ctx.getWsVariables().getWsOptionX()).intValue());
		
		/* 
		FIXME: OPTIONO OF COMEN1AO */
		BluageUtils.unsupported();
		if (!(DataUtils.isNumeric(ctx.getWsVariables().getWsOptionReference())) || DataUtils.compare(ctx.getWsVariables().getWsOptionReference(), BluageUtils.unsupported()) > 0 || NumberUtils.eq(ctx.getWsVariables().getWsOptionReference(), 0)) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Please enter a valid option number...");
			sendMenuScreen(ctx, ctrl);
		} 
		if (BluageUtils.unsupported() && DataUtils.compare("A", BluageUtils.unsupported()) == 0) {
			ctx.getWsVariables().setErrFlgOn(true);
			DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
			ctx.getWsVariables().setWsMessage("No access - Admin Only option... ");
			sendMenuScreen(ctx, ctrl);
		} 
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			if (DataUtils.compare("COPAUS0C", BluageUtils.unsupported()) == 0) {
				
				/* 
				FIXME: CDEMO-MENU-OPT-PGMNAME(WS-OPTION) */
				JicsProgramInquireBuilder.newInstance(ctx.getJicsEiblk(), ctx, ctrl)
				.withProgramName(BluageUtils.unsupported())
				.execute();
				if (ctx.getDfheiblk().getEibresp() == ResponseCode.NORMAL.getIntValue()) {
					
					/* 
					FIXME: CDEMO-FROM-TRANID */
					BluageUtils.unsupported();
					
					/* 
					FIXME: CDEMO-FROM-PROGRAM */
					BluageUtils.unsupported();
					
					/* 
					FIXME: CDEMO-PGM-CONTEXT */
					BluageUtils.unsupported();
					XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
				} else {
					DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
					
					/* 
					FIXME: ERRMSGC  OF COMEN1AO */
					BluageUtils.unsupported();
					StringConcatenationBuilder.newInstance(ctx.getWsVariables().getWsMessageReference())
						.addDelimitedBySize("This option ")
						.addDelimitedByLiteral(BluageUtils.unsupported(),"  ")
						.addDelimitedBySize(" is not installed...")
						.end();
				}
			} else if (DataUtils.compare("DUMMY", BluageUtils.unsupported()) == 0) {
				
				/* 
				FIXME: CDEMO-MENU-OPT-PGMNAME(WS-OPTION)(1:5) */
				DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
				
				/* 
				FIXME: ERRMSGC  OF COMEN1AO */
				BluageUtils.unsupported();
				StringConcatenationBuilder.newInstance(ctx.getWsVariables().getWsMessageReference())
					.addDelimitedBySize("This option ")
					.addDelimitedByLiteral(BluageUtils.unsupported()," ")
					.addDelimitedBySize("is coming soon ...")
					.end();
			} else {
				
				/* 
				FIXME: CDEMO-FROM-TRANID */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-FROM-PROGRAM */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-FROM-PROGRAM */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-PGM-CONTEXT
				MOVE WS-USER-ID   TO CDEMO-USER-ID
				MOVE SEC-USR-TYPE TO CDEMO-USER-TYPE */
				BluageUtils.unsupported();
				XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
			}
			sendMenuScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation returnToSignonScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RETURN-TO-SIGNON-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void returnToSignonScreen(final Comen01cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
		} 
		XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).execute().handleException();
	}

	/**
	 * Process operation sendMenuScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       SEND-MENU-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendMenuScreen(final Comen01cContext ctx, final ExecutionController ctrl) {
		populateHeaderInfo(ctx, ctrl);
		buildMenuOptions(ctx, ctrl);
		
		/* 
		FIXME: ERRMSGO OF COMEN1AO */
		BluageUtils.unsupported();
		SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withMap("COMEN1A")
		.withMapset("COMEN01")
		.withData(BluageUtils.unsupported())
		.withErase()
		.execute()
		.handleException();
	}

	/**
	 * Process operation receiveMenuScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RECEIVE-MENU-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void receiveMenuScreen(final Comen01cContext ctx, final ExecutionController ctrl) {
		ReceiveMapBuilder.newInstance(ctx.getJicsEiblk(), ctrl.getExecutionContext(), ctx)
		.withMap("COMEN1A")
		.withMapset("COMEN01")
		.into(BluageUtils.unsupported())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
	}

	/**
	 * Process operation populateHeaderInfo.
	 * 
	 * ----------------------------------------------------------------*
	 *                       POPULATE-HEADER-INFO
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void populateHeaderInfo(final Comen01cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE01O OF COMEN1AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE02O OF COMEN1AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNNAMEO OF COMEN1AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PGMNAMEO OF COMEN1AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURDATEO OF COMEN1AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-HH */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-SS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURTIMEO OF COMEN1AO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation buildMenuOptions.
	 * 
	 * ----------------------------------------------------------------*
	 *                       BUILD-MENU-OPTIONS
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void buildMenuOptions(final Comen01cContext ctx, final ExecutionController ctrl) {
		ctx.getWsVariables().setWsIdx(1);
		
		/* 
		FIXME: CDEMO-MENU-OPT-COUNT */
		while (DataUtils.compare(ctx.getWsVariables().getWsIdxReference(), BluageUtils.unsupported()) <= 0) {
			DataUtils.setToBlank(ctx.getWsVariables().getWsMenuOptTxtReference());
			StringConcatenationBuilder.newInstance(ctx.getWsVariables().getWsMenuOptTxtReference())
				.addDelimitedBySize(BluageUtils.unsupported())
				.addDelimitedBySize(". ")
				.addDelimitedBySize(BluageUtils.unsupported())
				.end();
			if (ctx.getWsVariables().getWsIdx() == 1) {
				
				/* 
				FIXME: OPTN001O */
				BluageUtils.unsupported();
			} else if (ctx.getWsVariables().getWsIdx() == 2) {
				
				/* 
				FIXME: OPTN002O */
				BluageUtils.unsupported();
			} else if (ctx.getWsVariables().getWsIdx() == 3) {
				
				/* 
				FIXME: OPTN003O */
				BluageUtils.unsupported();
			} else if (ctx.getWsVariables().getWsIdx() == 4) {
				
				/* 
				FIXME: OPTN004O */
				BluageUtils.unsupported();
			} else if (ctx.getWsVariables().getWsIdx() == 5) {
				
				/* 
				FIXME: OPTN005O */
				BluageUtils.unsupported();
			} else if (ctx.getWsVariables().getWsIdx() == 6) {
				
				/* 
				FIXME: OPTN006O */
				BluageUtils.unsupported();
			} else if (ctx.getWsVariables().getWsIdx() == 7) {
				
				/* 
				FIXME: OPTN007O */
				BluageUtils.unsupported();
			} else if (ctx.getWsVariables().getWsIdx() == 8) {
				
				/* 
				FIXME: OPTN008O */
				BluageUtils.unsupported();
			} else if (ctx.getWsVariables().getWsIdx() == 9) {
				
				/* 
				FIXME: OPTN009O */
				BluageUtils.unsupported();
			} else if (ctx.getWsVariables().getWsIdx() == 10) {
				
				/* 
				FIXME: OPTN010O */
				BluageUtils.unsupported();
			} else if (ctx.getWsVariables().getWsIdx() == 11) {
				
				/* 
				FIXME: OPTN011O */
				BluageUtils.unsupported();
			} else if (ctx.getWsVariables().getWsIdx() == 12) {
				
				/* 
				FIXME: OPTN012O */
				BluageUtils.unsupported();
			} else {
				
				/* 
				Do nothing */
			}
			ctx.getWsVariables().setWsIdx(ctx.getWsVariables().getWsIdx() + 1);
		}
		
		/* 
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:33 CDT */
		return;
	}

}
