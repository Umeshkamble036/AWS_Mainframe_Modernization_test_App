package com.company.app.cbact01c.service;

import com.company.app.cbact01c.business.context.Cbact01cContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface Cbact01cProcess.
 * 
 * Defines application services for Cbact01cProcess
 */
public interface Cbact01cProcess {

	/**
	 * Process operation procedureDivision.
	 * 
	 * PROGRAM-ID.CBACT01C.
	 *  AUTHOR.        AWS.
	 * *****************************************************************
	 *  PROGRAM     : CBACT01C.CBL
	 *  Application : CardDemo
	 *  Type        : BATCH COBOL Program
	 *  FUNCTION    : READ THE ACCOUNT FILE AND WRITE INTO FILES.
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void procedureDivision(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000AcctfileGetNext.
	 * 
	 * ****************************************************************
	 *  I/O ROUTINES TO ACCESS A KSDS, VSAM DATA SET...               *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000AcctfileGetNext(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1100DisplayAcctRecord.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1100DisplayAcctRecord(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1300PopulAcctRecord.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1300PopulAcctRecord(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1350WriteAcctRecord.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1350WriteAcctRecord(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1400PopulArrayRecord.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1400PopulArrayRecord(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1450WriteArryRecord.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1450WriteArryRecord(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1500PopulVbrcRecord.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1500PopulVbrcRecord(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1550WriteVb1Record.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1550WriteVb1Record(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1575WriteVb2Record.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1575WriteVb2Record(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0000AcctfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000AcctfileOpen(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2000OutfileOpen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000OutfileOpen(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3000ArrfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000ArrfileOpen(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _4000VbrfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4000VbrfileOpen(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9000AcctfileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9000AcctfileClose(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9999AbendProgram.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9999AbendProgram(final Cbact01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9910DisplayIoStatus.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9910DisplayIoStatus(final Cbact01cContext ctx, final ExecutionController ctrl);

}
