package com.company.app.cocrdlic.service;

import com.company.app.cocrdlic.business.context.CocrdlicContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface CocrdlicProcess.
 * 
 * Defines application services for CocrdlicProcess
 */
public interface CocrdlicProcess {

	/**
	 * Process operation _0000Main.
	 * 
	 * PROGRAM-ID.COCRDLIC.
	 *  DATE-WRITTEN.
	 *      April 2022.
	 *  DATE-COMPILED.
	 *      Today.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000Main(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0000Main1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000Main1(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000SendMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000SendMap(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1100ScreenInit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1100ScreenInit(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1200ScreenArrayInit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1200ScreenArrayInit(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1250SetupArrayAttribs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1250SetupArrayAttribs(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1300SetupScreenAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1300SetupScreenAttrs(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1400SetupMessage.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1400SetupMessage(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1500SendScreen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1500SendScreen(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2000ReceiveMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000ReceiveMap(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2100ReceiveScreen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2100ReceiveScreen(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2200EditInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2200EditInputs(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2210EditAccount.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2210EditAccount(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2220EditCard.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2220EditCard(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2250EditArray.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2250EditArray(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9000ReadForward.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9000ReadForward(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9100ReadBackwards.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9100ReadBackwards(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9100ReadBackwards1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9100ReadBackwards1(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9500FilterRecords.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9500FilterRecords(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation sendPlainText.
	 * 
	 * ****************************************************************
	 * Common code to store PFKey
	 * ****************************************************************
	 * ****************************************************************
	 *  Plain text exit - Dont use in production                      *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void sendPlainText(final CocrdlicContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation sendLongText.
	 * 
	 * ****************************************************************
	 *  Display Long text and exit                                    *
	 *  This is primarily for debugging and should not be used in     *
	 *  regular course                                                *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void sendLongText(final CocrdlicContext ctx, final ExecutionController ctrl);

}
