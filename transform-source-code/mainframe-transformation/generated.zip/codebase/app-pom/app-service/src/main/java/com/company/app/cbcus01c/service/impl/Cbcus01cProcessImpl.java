
package com.company.app.cbcus01c.service.impl;

import com.company.app.cbcus01c.business.context.Cbcus01cContext;
import com.company.app.cbcus01c.service.Cbcus01cProcess;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.io.IndexedFile;
import com.netfective.bluage.gapwalk.rt.io.OpenMode;
import com.netfective.bluage.gapwalk.runtime.statements.CallBuilder;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Cbcus01cProcessImpl
 * 
 * Defines application services for Cbcus01cProcess
 * @see Cbcus01cProcess
 */
@Service("com.company.app.cbcus01c.service.Cbcus01cProcess")
@Lazy

public class Cbcus01cProcessImpl implements Cbcus01cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Cbcus01cProcessImpl.class);


	/**
	 * Process operation procedureDivision.
	 * 
	 * PROGRAM-ID.CBCUS01C.
	 *  AUTHOR.        AWS.
	 * *****************************************************************
	 *  Program     : CBCUS01C.CBL
	 *  Application : CardDemo
	 *  Type        : BATCH COBOL Program
	 *  Function    : Read and print customer data file.
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void procedureDivision(final Cbcus01cContext ctx, final ExecutionController ctrl) {
		/* 
		**************************************************************** */
		DisplayUtils.display(ctx, ctrl, LOGGER, "START OF EXECUTION OF PROGRAM CBCUS01C");
		_0000CustfileOpen(ctx, ctrl);
		while (DataUtils.compare(ctx.getEndOfFile().getEndOfFileReference(), "Y") != 0) {
			if (DataUtils.compare(ctx.getEndOfFile().getEndOfFileReference(), "N") == 0) {
				_1000CustfileGetNext(ctx, ctrl);
				if (DataUtils.compare(ctx.getEndOfFile().getEndOfFileReference(), "N") == 0) {
					// FIXME An error occured while generating Java from BAGS (@LoggerUtils.info(@BluageUtils.unsupported("CUSTOMER-RECORD")))
					BluageUtils.unsupported();
				} 
			} 
		}
		_9000CustfileClose(ctx, ctrl);
		DisplayUtils.display(ctx, ctrl, LOGGER, "END OF EXECUTION OF PROGRAM CBCUS01C");
		if (ctx.isMainProgram()) {
			ctrl.stopRunUnit();
		}
	}

	/**
	 * Process operation _1000CustfileGetNext.
	 * 
	 * ****************************************************************
	 *  I/O ROUTINES TO ACCESS A KSDS, VSAM DATA SET...               *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1000CustfileGetNext(final Cbcus01cContext ctx, final ExecutionController ctrl) {
		IndexedFile custfileFile = ctx.getCustfileFileHandler(ctrl.getExecutionContext()); 
		boolean result = false; 
		result = custfileFile.read();
		if (result) {
			
			/* 
			FIXME: CUSTOMER-RECORD */
			BluageUtils.unsupported();
		} 
		if (DataUtils.compare("00", ctx.getCustfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
			// FIXME An error occured while generating Java from BAGS (@LoggerUtils.info(@BluageUtils.unsupported("CUSTOMER-RECORD")))
			BluageUtils.unsupported();
		} else {
			if (DataUtils.compare("10", ctx.getCustfileStatus()) == 0) {
				ctx.getApplResult().setApplResult(16);
			} else {
				ctx.getApplResult().setApplResult(12);
			}
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			if (ctx.getApplResult().isApplEof()) {
				ctx.getEndOfFile().setEndOfFile("Y");
			} else {
				DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR READING CUSTOMER FILE");
				ctx.getIoStatus().setBytes(ctx.getCustfileStatus().getBytes());
				zDisplayIoStatus(ctx, ctrl);
				zAbendProgram(ctx, ctrl);
			}
		}
	}

	/**
	 * Process operation _0000CustfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0000CustfileOpen(final Cbcus01cContext ctx, final ExecutionController ctrl) {
		IndexedFile custfileFile = ctx.getCustfileFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		custfileFile.open(OpenMode.INPUT);
		if (DataUtils.compare("00", ctx.getCustfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR OPENING CUSTFILE");
			ctx.getIoStatus().setBytes(ctx.getCustfileStatus().getBytes());
			zDisplayIoStatus(ctx, ctrl);
			zAbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _9000CustfileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9000CustfileClose(final Cbcus01cContext ctx, final ExecutionController ctrl) {
		IndexedFile custfileFile = ctx.getCustfileFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		custfileFile.close();
		if (DataUtils.compare("00", ctx.getCustfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(ctx.getApplResult().getApplResult() - ctx.getApplResult().getApplResult());
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR CLOSING CUSTOMER FILE");
			ctx.getIoStatus().setBytes(ctx.getCustfileStatus().getBytes());
			zDisplayIoStatus(ctx, ctrl);
			zAbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation zAbendProgram.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void zAbendProgram(final Cbcus01cContext ctx, final ExecutionController ctrl) {
		DisplayUtils.display(ctx, ctrl, LOGGER, "ABENDING PROGRAM");
		ctx.getTiming().setTiming(0);
		ctx.getAbcode().setAbcode(999);
		ctrl.callSubProgram("CEE3ABD", CallBuilder.newInstance()
			.byReference(ctx.getAbcode().getAbcodeReference())
			.byReference(ctx.getTiming().getTimingReference())
			.getArguments(), ctx);
	}

	/**
	 * Process operation zDisplayIoStatus.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void zDisplayIoStatus(final Cbcus01cContext ctx, final ExecutionController ctrl) {
		if (!(DataUtils.isNumeric(ctx.getIoStatus())) || DataUtils.compare(ctx.getIoStatus().getIoStat1Reference(), "9") == 0) {
			ctx.getIoStatus04().setBytes(ctx.getIoStatus().getIoStat1Reference().getBytes(), 0, 1);
			ctx.getGroup1().setTwoBytesBinary(0);
			ctx.getGroup1().getTwoBytesRightReference().setValue(ctx.getIoStatus().getIoStat2Reference());
			ctx.getIoStatus04().setIoStatus0403(ctx.getGroup1().getTwoBytesBinary());
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "FILE STATUS IS: NNNN" , DataUtils.toString(ctx.getIoStatus04().getBytes()));
		} else {
			ctx.getIoStatus04().setBytes(DataUtils.getBytes("0000"));
			ctx.getIoStatus04().setBytes(ctx.getIoStatus().getBytes(), 2, 2);
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "FILE STATUS IS: NNNN" , DataUtils.toString(ctx.getIoStatus04().getBytes()));
		}
		
		/* 
		Ver: CardDemo_v2.0-25-gdb72e6b-235 Date: 2025-04-29 11:01:28 CDT */
		return;
	}

}
