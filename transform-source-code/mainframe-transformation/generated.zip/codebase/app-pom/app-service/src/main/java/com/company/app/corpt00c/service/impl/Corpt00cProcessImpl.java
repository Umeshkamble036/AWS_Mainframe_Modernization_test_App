
package com.company.app.corpt00c.service.impl;

import com.company.app.core.helper.BluageUtils;
import com.company.app.corpt00c.business.context.Corpt00cContext;
import com.company.app.corpt00c.service.Corpt00cProcess;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.NumberUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.bms.ReceiveMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.jics.internal.JicsTDQueueBuilder;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.statements.CallBuilder;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Corpt00cProcessImpl
 * 
 * Defines application services for Corpt00cProcess
 * @see Corpt00cProcess
 */
@Service("com.company.app.corpt00c.service.Corpt00cProcess")
@Lazy

public class Corpt00cProcessImpl implements Corpt00cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Corpt00cProcessImpl.class);


	/**
	 * Process operation mainPara.
	 * 
	 * PROGRAM-ID.CORPT00C.
	 *  AUTHOR.     AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void mainPara(final Corpt00cContext ctx, final ExecutionController ctrl) {
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		*****************************************************************
		Program     : CORPT00C.CBL
		Application : CardDemo
		Type        : CICS COBOL Program
		Function    : Print Transaction reports by submitting batch
		job from online using extra partition TDQ.
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		----------------------------------------------------------------*
		WORKING STORAGE SECTION
		----------------------------------------------------------------*
		No background transparency
		----------------------------------------------------------------*
		LINKAGE SECTION
		----------------------------------------------------------------*
		----------------------------------------------------------------*
		PROCEDURE DIVISION
		----------------------------------------------------------------* */
		ctx.getWsVariables().setErrFlgOff(true);
		ctx.getWsVariables().setTransactNotEof(true);
		ctx.getWsVariables().setSendEraseYes(true);
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		FIXME: ERRMSGO OF CORPT0AO */
		BluageUtils.unsupported();
		if (ctx.getDfheiblk().getEibcalen() == 0) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
			returnToPrevScreen(ctx, ctrl);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			if (!(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-PGM-REENTER */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CORPT0AO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: MONTHLYL OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} else {
				receiveTrnrptScreen(ctx, ctrl);
				if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) == 0) {
					processEnterKey(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf3Reference()) == 0) {
					
					/* 
					FIXME: CDEMO-TO-PROGRAM */
					BluageUtils.unsupported();
					returnToPrevScreen(ctx, ctrl);
				} else {
					ctx.getWsVariables().setWsErrFlg("Y");
					
					/* 
					FIXME: MONTHLYL OF CORPT0AI */
					BluageUtils.unsupported();
					ctx.getWsVariables().setWsMessage(BluageUtils.unsupported());
					sendTrnrptScreen(ctx, ctrl);
				}
			}
		}
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsVariables().getWsTranid())
		.withCommarea(BluageUtils.unsupported())
		.execute()
		.handleException();
	}

	/**
	 * Process operation processEnterKey.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-ENTER-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processEnterKey(final Corpt00cContext ctx, final ExecutionController ctrl) {
		DisplayUtils.display(ctx, ctrl, LOGGER, "PROCESS ENTER KEY");
		if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setWsReportName("Monthly");
			
			/* 
			FIXME: WS-CURDATE-DATA */
			BluageUtils.unsupported();
			ctx.getWsVariables().setWsStartDateYyyy(BluageUtils.unsupported());
			ctx.getWsVariables().setWsStartDateMm(BluageUtils.unsupported());
			ctx.getWsVariables().setWsStartDateDd("01");
			ctx.getJobData().getParmStartDate1Reference().setBytes(ctx.getWsVariables().getWsStartDateReference().getBytes());
			ctx.getJobData().getParmStartDate2Reference().setBytes(ctx.getWsVariables().getWsStartDateReference().getBytes());
			
			/* 
			FIXME: WS-CURDATE-DAY */
			BluageUtils.unsupported();
			
			/* 
			FIXME: WS-CURDATE-MONTH */
			BluageUtils.unsupported();
			if (DataUtils.compare(BluageUtils.unsupported(), "12") > 0) {
				
				/* 
				FIXME: WS-CURDATE-YEAR */
				BluageUtils.unsupported();
				
				/* 
				FIXME: WS-CURDATE-MONTH */
				BluageUtils.unsupported();
			} 
			
			/* 
			FIXME: WS-CURDATE-N */
			BluageUtils.unsupported();
			ctx.getWsVariables().setWsEndDateYyyy(BluageUtils.unsupported());
			ctx.getWsVariables().setWsEndDateMm(BluageUtils.unsupported());
			ctx.getWsVariables().setWsEndDateDd(BluageUtils.unsupported());
			ctx.getJobData().getParmEndDate1Reference().setBytes(ctx.getWsVariables().getWsEndDateReference().getBytes());
			ctx.getJobData().getParmEndDate2Reference().setBytes(ctx.getWsVariables().getWsEndDateReference().getBytes());
			submitJobToIntrdr(ctx, ctrl);
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setWsReportName("Yearly");
			
			/* 
			FIXME: WS-CURDATE-DATA */
			BluageUtils.unsupported();
			ctx.getWsVariables().setWsStartDateYyyy(BluageUtils.unsupported());
			ctx.getWsVariables().setWsEndDateYyyy(BluageUtils.unsupported());
			ctx.getWsVariables().setWsStartDateMm("01");
			ctx.getWsVariables().setWsStartDateDd("01");
			ctx.getJobData().getParmStartDate1Reference().setBytes(ctx.getWsVariables().getWsStartDateReference().getBytes());
			ctx.getJobData().getParmStartDate2Reference().setBytes(ctx.getWsVariables().getWsStartDateReference().getBytes());
			ctx.getWsVariables().setWsEndDateMm("12");
			ctx.getWsVariables().setWsEndDateDd("31");
			ctx.getJobData().getParmEndDate1Reference().setBytes(ctx.getWsVariables().getWsEndDateReference().getBytes());
			ctx.getJobData().getParmEndDate2Reference().setBytes(ctx.getWsVariables().getWsEndDateReference().getBytes());
			submitJobToIntrdr(ctx, ctrl);
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
				ctx.getWsVariables().setWsMessage("Start Date - Month can NOT be empty...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: SDTMML OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
				ctx.getWsVariables().setWsMessage("Start Date - Day can NOT be empty...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: SDTDDL OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
				ctx.getWsVariables().setWsMessage("Start Date - Year can NOT be empty...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: SDTYYYYL OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
				ctx.getWsVariables().setWsMessage("End Date - Month can NOT be empty...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: EDTMML OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
				ctx.getWsVariables().setWsMessage("End Date - Day can NOT be empty...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: EDTDDL OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
				ctx.getWsVariables().setWsMessage("End Date - Year can NOT be empty...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: EDTYYYYL OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} else {
				
				/* 
				Do nothing */
			}
			ctx.getWsVariables().setWsNum99(NumberUtils.convert(BluageUtils.unsupported()).intValue());
			
			/* 
			FIXME: SDTMMI OF CORPT0AI */
			BluageUtils.unsupported();
			ctx.getWsVariables().setWsNum99(NumberUtils.convert(BluageUtils.unsupported()).intValue());
			
			/* 
			FIXME: SDTDDI OF CORPT0AI */
			BluageUtils.unsupported();
			ctx.getWsVariables().setWsNum9999(NumberUtils.convert(BluageUtils.unsupported()).intValue());
			
			/* 
			FIXME: SDTYYYYI OF CORPT0AI */
			BluageUtils.unsupported();
			ctx.getWsVariables().setWsNum99(NumberUtils.convert(BluageUtils.unsupported()).intValue());
			
			/* 
			FIXME: EDTMMI OF CORPT0AI */
			BluageUtils.unsupported();
			ctx.getWsVariables().setWsNum99(NumberUtils.convert(BluageUtils.unsupported()).intValue());
			
			/* 
			FIXME: EDTDDI OF CORPT0AI */
			BluageUtils.unsupported();
			ctx.getWsVariables().setWsNum9999(NumberUtils.convert(BluageUtils.unsupported()).intValue());
			
			/* 
			FIXME: EDTYYYYI OF CORPT0AI */
			BluageUtils.unsupported();
			if (!(DataUtils.isNumeric(BluageUtils.unsupported())) || DataUtils.compare(BluageUtils.unsupported(), "12") > 0) {
				ctx.getWsVariables().setWsMessage("Start Date - Not a valid Month...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: SDTMML OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} 
			if (!(DataUtils.isNumeric(BluageUtils.unsupported())) || DataUtils.compare(BluageUtils.unsupported(), "31") > 0) {
				ctx.getWsVariables().setWsMessage("Start Date - Not a valid Day...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: SDTDDL OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} 
			if (!(DataUtils.isNumeric(BluageUtils.unsupported()))) {
				ctx.getWsVariables().setWsMessage("Start Date - Not a valid Year...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: SDTYYYYL OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} 
			if (!(DataUtils.isNumeric(BluageUtils.unsupported())) || DataUtils.compare(BluageUtils.unsupported(), "12") > 0) {
				ctx.getWsVariables().setWsMessage("End Date - Not a valid Month...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: EDTMML OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} 
			if (!(DataUtils.isNumeric(BluageUtils.unsupported())) || DataUtils.compare(BluageUtils.unsupported(), "31") > 0) {
				ctx.getWsVariables().setWsMessage("End Date - Not a valid Day...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: EDTDDL OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} 
			if (!(DataUtils.isNumeric(BluageUtils.unsupported()))) {
				ctx.getWsVariables().setWsMessage("End Date - Not a valid Year...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: EDTYYYYL OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			} 
			ctx.getWsVariables().setWsStartDateYyyy(BluageUtils.unsupported());
			ctx.getWsVariables().setWsStartDateMm(BluageUtils.unsupported());
			ctx.getWsVariables().setWsStartDateDd(BluageUtils.unsupported());
			ctx.getWsVariables().setWsEndDateYyyy(BluageUtils.unsupported());
			ctx.getWsVariables().setWsEndDateMm(BluageUtils.unsupported());
			ctx.getWsVariables().setWsEndDateDd(BluageUtils.unsupported());
			ctx.getCsutldtcParm().getCsutldtcDateReference().setBytes(ctx.getWsVariables().getWsStartDateReference().getBytes());
			ctx.getCsutldtcParm().getCsutldtcDateFormatReference().setValue(ctx.getWsVariables().getWsDateFormatReference());
			DataUtils.setToBlank(ctx.getCsutldtcParm().getCsutldtcResultReference());
			ctrl.callSubProgram("CSUTLDTC", CallBuilder.newInstance()
				.byReference(ctx.getCsutldtcParm().getCsutldtcDateReference())
				.byReference(ctx.getCsutldtcParm().getCsutldtcDateFormatReference())
				.byReference(ctx.getCsutldtcParm().getCsutldtcResultReference())
				.getArguments(), ctx);
			if (DataUtils.compare(ctx.getCsutldtcParm().getCsutldtcResultSevCdReference(), "0000") == 0) {
				
				/* 
				Do nothing */
			} else {
				if (DataUtils.compare(ctx.getCsutldtcParm().getCsutldtcResultMsgNumReference(), "2513") != 0) {
					ctx.getWsVariables().setWsMessage("Start Date - Not a valid date...");
					ctx.getWsVariables().setWsErrFlg("Y");
					
					/* 
					FIXME: SDTMML OF CORPT0AI */
					BluageUtils.unsupported();
					sendTrnrptScreen(ctx, ctrl);
				} 
			}
			ctx.getCsutldtcParm().getCsutldtcDateReference().setBytes(ctx.getWsVariables().getWsEndDateReference().getBytes());
			ctx.getCsutldtcParm().getCsutldtcDateFormatReference().setValue(ctx.getWsVariables().getWsDateFormatReference());
			DataUtils.setToBlank(ctx.getCsutldtcParm().getCsutldtcResultReference());
			ctrl.callSubProgram("CSUTLDTC", CallBuilder.newInstance()
				.byReference(ctx.getCsutldtcParm().getCsutldtcDateReference())
				.byReference(ctx.getCsutldtcParm().getCsutldtcDateFormatReference())
				.byReference(ctx.getCsutldtcParm().getCsutldtcResultReference())
				.getArguments(), ctx);
			if (DataUtils.compare(ctx.getCsutldtcParm().getCsutldtcResultSevCdReference(), "0000") == 0) {
				
				/* 
				Do nothing */
			} else {
				if (DataUtils.compare(ctx.getCsutldtcParm().getCsutldtcResultMsgNumReference(), "2513") != 0) {
					ctx.getWsVariables().setWsMessage("End Date - Not a valid date...");
					ctx.getWsVariables().setWsErrFlg("Y");
					
					/* 
					FIXME: EDTMML OF CORPT0AI */
					BluageUtils.unsupported();
					sendTrnrptScreen(ctx, ctrl);
				} 
			}
			ctx.getJobData().getParmStartDate1Reference().setBytes(ctx.getWsVariables().getWsStartDateReference().getBytes());
			ctx.getJobData().getParmStartDate2Reference().setBytes(ctx.getWsVariables().getWsStartDateReference().getBytes());
			ctx.getJobData().getParmEndDate1Reference().setBytes(ctx.getWsVariables().getWsEndDateReference().getBytes());
			ctx.getJobData().getParmEndDate2Reference().setBytes(ctx.getWsVariables().getWsEndDateReference().getBytes());
			ctx.getWsVariables().setWsReportName("Custom");
			if (!(ctx.getWsVariables().isErrFlgOn())) {
				submitJobToIntrdr(ctx, ctrl);
			} 
		} else {
			ctx.getWsVariables().setWsMessage("Select a report type to print report...");
			ctx.getWsVariables().setWsErrFlg("Y");
			
			/* 
			FIXME: MONTHLYL OF CORPT0AI */
			BluageUtils.unsupported();
			sendTrnrptScreen(ctx, ctrl);
		}
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			initializeAllFields(ctx, ctrl);
			
			/* 
			FIXME: ERRMSGC  OF CORPT0AO */
			BluageUtils.unsupported();
			StringConcatenationBuilder.newInstance(ctx.getWsVariables().getWsMessageReference())
				.addDelimitedByLiteral(ctx.getWsVariables().getWsReportName()," ")
				.addDelimitedBySize(" report submitted for printing ...")
				.end();
			
			/* 
			FIXME: MONTHLYL OF CORPT0AI */
			BluageUtils.unsupported();
			sendTrnrptScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation submitJobToIntrdr.
	 * 
	 * ----------------------------------------------------------------*
	 *                       SUBMIT-JOB-TO-INTRDR
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void submitJobToIntrdr(final Corpt00cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			StringConcatenationBuilder.newInstance(ctx.getWsVariables().getWsMessageReference())
				.addDelimitedBySize("Please confirm to print the ")
				.addDelimitedByLiteral(ctx.getWsVariables().getWsReportName()," ")
				.addDelimitedBySize(" report...")
				.end();
			ctx.getWsVariables().setWsErrFlg("Y");
			
			/* 
			FIXME: CONFIRML OF CORPT0AI */
			BluageUtils.unsupported();
			sendTrnrptScreen(ctx, ctrl);
		} 
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			if (DataUtils.compare("Y", BluageUtils.unsupported()) == 0 || DataUtils.compare("y", BluageUtils.unsupported()) == 0) {
				
				/* 
				FIXME: CONFIRMI OF CORPT0AIFIXME: CONFIRMI OF CORPT0AI
				Do nothing */
			} else if (DataUtils.compare("N", BluageUtils.unsupported()) == 0 || DataUtils.compare("n", BluageUtils.unsupported()) == 0) {
				
				/* 
				FIXME: CONFIRMI OF CORPT0AIFIXME: CONFIRMI OF CORPT0AI */
				initializeAllFields(ctx, ctrl);
				ctx.getWsVariables().setWsErrFlg("Y");
				sendTrnrptScreen(ctx, ctrl);
			} else {
				StringConcatenationBuilder.newInstance(ctx.getWsVariables().getWsMessageReference())
					.addDelimitedBySize("\"")
					.addDelimitedByLiteral(BluageUtils.unsupported()," ")
					.addDelimitedBySize("\" is not a valid value to confirm...")
					.end();
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: CONFIRML OF CORPT0AI */
				BluageUtils.unsupported();
				sendTrnrptScreen(ctx, ctrl);
			}
			ctx.getWsVariables().setEndLoopNo(true);
			ctx.getWsVariables().setWsIdx(1);
			while (!(ctx.getWsVariables().getWsIdx() > 1000 || ctx.getWsVariables().isEndLoopYes() || ctx.getWsVariables().isErrFlgOn())) {
				ctx.getWsVariables().setJclRecord(ctx.getJobData().getItemFromJobLines(ctx.getWsVariables().getWsIdx() - 1));
				if (DataUtils.compare(ctx.getWsVariables().getJclRecordReference(), "/*EOF") == 0 || DataUtils.isBlank(ctx.getWsVariables().getJclRecordReference()) || DataUtils.isLowValue(ctx.getWsVariables().getJclRecordReference())) {
					ctx.getWsVariables().setEndLoopYes(true);
				} 
				wirteJobsubTdq(ctx, ctrl);
				ctx.getWsVariables().setWsIdx(ctx.getWsVariables().getWsIdx() + 1);
			}
		}
	}

	/**
	 * Process operation wirteJobsubTdq.
	 * 
	 * ----------------------------------------------------------------*
	 *                       WIRTE-JOBSUB-TDQ
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void wirteJobsubTdq(final Corpt00cContext ctx, final ExecutionController ctrl) {
		JicsTDQueueBuilder.newInstance("JOBS", ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.writeQ()
		.from(ctx.getWsVariables().getJclRecordReference())
		.length(ctx.getWsVariables().getJclRecordReference().getRecord().getSize())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to Write TDQ (JOBS)...");
			
			/* 
			FIXME: MONTHLYL OF CORPT0AI */
			BluageUtils.unsupported();
			sendTrnrptScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation returnToPrevScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RETURN-TO-PREV-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void returnToPrevScreen(final Corpt00cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
		} 
		
		/* 
		FIXME: CDEMO-FROM-TRANID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-FROM-PROGRAM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-PGM-CONTEXT */
		BluageUtils.unsupported();
		XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
	}

	/**
	 * Process operation sendTrnrptScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       SEND-TRNRPT-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendTrnrptScreen(final Corpt00cContext ctx, final ExecutionController ctrl) {
		populateHeaderInfo(ctx, ctrl);
		
		/* 
		FIXME: ERRMSGO OF CORPT0AO */
		BluageUtils.unsupported();
		if (ctx.getWsVariables().isSendEraseYes()) {
			SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
			.withMap("CORPT0A")
			.withMapset("CORPT00")
			.withData(BluageUtils.unsupported())
			.withErase()
			.withCursor()
			.execute()
			.handleException();
		} else {
			SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
			.withMap("CORPT0A")
			.withMapset("CORPT00")
			.withData(BluageUtils.unsupported())
			.withCursor()
			.execute()
			.handleException();
		}
		returnToCics(ctx, ctrl);
	}

	/**
	 * Process operation returnToCics.
	 * 
	 * ----------------------------------------------------------------*
	 *                          RETURN-TO-CICS
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void returnToCics(final Corpt00cContext ctx, final ExecutionController ctrl) {
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsVariables().getWsTranid())
		.withCommarea(BluageUtils.unsupported())
		.execute()
		.handleException();
	}

	/**
	 * Process operation receiveTrnrptScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RECEIVE-TRNRPT-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void receiveTrnrptScreen(final Corpt00cContext ctx, final ExecutionController ctrl) {
		ReceiveMapBuilder.newInstance(ctx.getJicsEiblk(), ctrl.getExecutionContext(), ctx)
		.withMap("CORPT0A")
		.withMapset("CORPT00")
		.into(BluageUtils.unsupported())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
	}

	/**
	 * Process operation populateHeaderInfo.
	 * 
	 * ----------------------------------------------------------------*
	 *                       POPULATE-HEADER-INFO
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void populateHeaderInfo(final Corpt00cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE01O OF CORPT0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE02O OF CORPT0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNNAMEO OF CORPT0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PGMNAMEO OF CORPT0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURDATEO OF CORPT0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-HH */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-SS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURTIMEO OF CORPT0AO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation initializeAllFields.
	 * 
	 * ----------------------------------------------------------------*
	 *                       INITIALIZE-ALL-FIELDS
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void initializeAllFields(final Corpt00cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: MONTHLYL OF CORPT0AI */
		BluageUtils.unsupported();
		DataUtils.initialize(BluageUtils.unsupported());
		DataUtils.initialize(BluageUtils.unsupported());
		DataUtils.initialize(BluageUtils.unsupported());
		DataUtils.initialize(BluageUtils.unsupported());
		DataUtils.initialize(BluageUtils.unsupported());
		DataUtils.initialize(BluageUtils.unsupported());
		DataUtils.initialize(BluageUtils.unsupported());
		DataUtils.initialize(BluageUtils.unsupported());
		DataUtils.initialize(BluageUtils.unsupported());
		DataUtils.initialize(BluageUtils.unsupported());
		DataUtils.initialize(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:33 CDT */
		return;
	}

}
