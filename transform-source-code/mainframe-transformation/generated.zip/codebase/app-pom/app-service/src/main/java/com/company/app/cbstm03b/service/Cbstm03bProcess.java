package com.company.app.cbstm03b.service;

import com.company.app.cbstm03b.business.context.Cbstm03bContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface Cbstm03bProcess.
 * 
 * Defines application services for Cbstm03bProcess
 */
public interface Cbstm03bProcess {

	/**
	 * Process operation _0000Start.
	 * 
	 * PROGRAM-ID.CBSTM03B.
	 *  AUTHOR.        AWS.
	 * *****************************************************************
	 *  Program     : CBSTM03B.CBL
	 *  Application : CardDemo
	 *  Type        : BATCH COBOL Subroutine
	 *  Function    : Does file processing related to Transact Report
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 *  This program is to called by the statement create program
	 *  It does file handling
	 * *****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000Start(final Cbstm03bContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0000Start1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000Start1(final Cbstm03bContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000TrnxfileProc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000TrnxfileProc(final Cbstm03bContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000TrnxfileProc1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000TrnxfileProc1(final Cbstm03bContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2000XreffileProc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000XreffileProc(final Cbstm03bContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2000XreffileProc1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000XreffileProc1(final Cbstm03bContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3000CustfileProc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000CustfileProc(final Cbstm03bContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3000CustfileProc1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000CustfileProc1(final Cbstm03bContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _4000AcctfileProc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4000AcctfileProc(final Cbstm03bContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _4000AcctfileProc1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4000AcctfileProc1(final Cbstm03bContext ctx, final ExecutionController ctrl);

}
