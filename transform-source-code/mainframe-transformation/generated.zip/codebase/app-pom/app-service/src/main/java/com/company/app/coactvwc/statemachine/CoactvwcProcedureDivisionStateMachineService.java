
package com.company.app.coactvwc.statemachine;

import com.company.app.coactvwc.business.context.CoactvwcContext;
import com.company.app.coactvwc.service.CoactvwcProcess;
import com.company.app.coactvwc.statemachine.CoactvwcProcedureDivisionStateMachineController.Events;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendTextBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.AbendBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.HandleAbendBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.statemachine.StateMachineController;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Service class containing states process used to drive state machine "CoactvwcProcedureDivisionStateMachine".
 */
@Service("com.company.app.coactvwc.statemachine.CoactvwcProcedureDivisionStateMachineService")
@Lazy
public class CoactvwcProcedureDivisionStateMachineService {
	
	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(CoactvwcProcedureDivisionStateMachineService.class);

	/**
	 * The associated state machine controller.
	 */
	@Autowired
	@Qualifier("com.company.app.coactvwc.statemachine.CoactvwcProcedureDivisionStateMachineController")	
	private StateMachineController<Events> instanceStateMachineController;
	
	
	/**
	 * Service used by the state machine.
	 */
	@Autowired
	@Qualifier("com.company.app.coactvwc.service.CoactvwcProcess")
	private CoactvwcProcess instanceCoactvwcProcess;
	
	
	

	/**
	 * State process operation _0000Main.
	 * 
	 * PROGRAM-ID.COACTVWC.
	 *  DATE-WRITTEN.
	 *      May 2022.
	 *  DATE-COMPILED.
	 *      Today.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000Main(CoactvwcContext ctx, ExecutionController ctrl) {
		instanceStateMachineController.registerSignalHandler(Events.TO_ABEND_ROUTINE, ctx, "ABEND_1_VIRTUAL_SIGNAL");
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		****************************************************************
		Program:     COACTVWC.CBL                                     *
		Layer:       Business logic                                   *
		Function:    Accept and process Account View request          *
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		COMMON COPYBOOKS
		Screen Titles
		BMS Copybook
		Current Date
		Common Messages
		Abend Variables
		Signed on user data
		ACCOUNT RECORD LAYOUT
		CUSTOMER RECORD LAYOUT
		CARD XREF LAYOUT
		CUSTOMER LAYOUT */
		ctx.getSignalHandlersController().activateSignalHandler("ABEND_1_VIRTUAL_SIGNAL","!ABEND");
		HandleAbendBuilder.newInstance(ctx.getJicsEiblk(), ctx).execute().handleException();
		DataUtils.initialize(BluageUtils.unsupported());
		ctx.getWsMiscStorage().getField().initialize();
		DataUtils.initialize(ctx.getWsCommarea().getWsCommareaReference());
		
		/* 
		****************************************************************
		Store our context
		**************************************************************** */
		ctx.getWsMiscStorage().getWsTranidReference().setValue(ctx.getWsLiterals().getLitThistranidReference());
		
		/* 
		****************************************************************
		Ensure error message is cleared                               *
		**************************************************************** */
		ctx.getWsMiscStorage().setWsReturnMsgOff(true);
		
		/* 
		****************************************************************
		Store passed data if  any                *
		**************************************************************** */
		if (ctx.getDfheiblk().getEibcalen() == 0 || (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitMenupgmReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), BluageUtils.unsupported()) != 0)) {
			DataUtils.initialize(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().getField().initialize();
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			int idx = BluageUtils.unsupported().length() + 1 - 1;
			int len = ctx.getWsThisProgcommarea().getSize();
			ctx.getWsThisProgcommarea().setBytes(ctx.getDfhcommarea().getBytes(idx, len));
		}
		
		/* 
		FIXME:PERFORM YYYY-STORE-PFKEY
		THRU YYYY-STORE-PFKEY-EXIT
		****************************************************************
		Remap PFkeys as needed.
		Store the Mapped PF Key
		**************************************************************** */
		BluageUtils.unsupported();
		
		/* 
		****************************************************************
		Check the AID to see if its valid at this point               *
		F3 - Exit
		Enter show screen again
		**************************************************************** */
		ctx.getWsMiscStorage().setPfkInvalid(true);
		if (BluageUtils.unsupported() || BluageUtils.unsupported()) {
			ctx.getWsMiscStorage().setPfkValid(true);
		} 
		if (ctx.getWsMiscStorage().isPfkInvalid()) {
			
			/* 
			FIXME: CCARD-AID-ENTER */
			BluageUtils.unsupported();
		} 
		
		/* 
		****************************************************************
		Decide what to do based on inputs received
		****************************************************************
		****************************************************************
		****************************************************************
		Decide what to do based on inputs received
		**************************************************************** */
		if (BluageUtils.unsupported()) {
			
			/* 
			FIXME: CCARD-AID-PFK03 */
			
			/* 
			****************************************************************
			XCTL TO CALLING PROGRAM OR MAIN MENU
			**************************************************************** */
			if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-TO-TRANID */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: CDEMO-TO-TRANID */
				BluageUtils.unsupported();
			}
			if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-TO-PROGRAM */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: CDEMO-TO-PROGRAM */
				BluageUtils.unsupported();
			}
			
			/* 
			FIXME: CDEMO-FROM-TRANID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-USRTYP-USER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAP */
			BluageUtils.unsupported();
			XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
		} else if (BluageUtils.unsupported()) {
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			
			/* 
			****************************************************************
			COMING FROM SOME OTHER CONTEXT
			SELECTION CRITERIA TO BE GATHERED
			**************************************************************** */
			instanceCoactvwcProcess._1000SendMap(ctx, ctrl);
			instanceCoactvwcProcess.commonReturn(ctx, ctrl);
		} else if (BluageUtils.unsupported()) {
			
			/* 
			FIXME: CDEMO-PGM-REENTER */
			instanceCoactvwcProcess._2000ProcessInputs(ctx, ctrl);
			if (ctx.getWsMiscStorage().isInputError()) {
				instanceCoactvwcProcess._1000SendMap(ctx, ctrl);
				instanceCoactvwcProcess.commonReturn(ctx, ctrl);
			} else {
				instanceCoactvwcProcess._9000ReadAcct(ctx, ctrl);
				instanceCoactvwcProcess._1000SendMap(ctx, ctrl);
				instanceCoactvwcProcess.commonReturn(ctx, ctrl);
			}
		} else {
			
			/* 
			FIXME: ABEND-CULPRIT */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ABEND-CODE */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ABEND-REASON */
			BluageUtils.unsupported();
			ctx.getWsMiscStorage().setWsReturnMsg("UNEXPECTED DATA SCENARIO");
			instanceCoactvwcProcess.sendPlainText(ctx, ctrl);
		}
		
		/* 
		If we had an error setup error message that slipped through
		Display and return */
		if (ctx.getWsMiscStorage().isInputError()) {
			
			/* 
			FIXME: CCARD-ERROR-MSG */
			BluageUtils.unsupported();
			instanceCoactvwcProcess._1000SendMap(ctx, ctrl);
			instanceCoactvwcProcess.commonReturn(ctx, ctrl);
		} 

	}
	/**
	 * State process operation abendRoutine.
	 * 
	 * ****************************************************************
	 * Common code to store PFKey
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void abendRoutine(CoactvwcContext ctx, ExecutionController ctrl) {
		if (DataUtils.isLowValue(BluageUtils.unsupported())) {
			
			/* 
			FIXME: ABEND-MSG */
			BluageUtils.unsupported();
		} 
		
		/* 
		FIXME: ABEND-CULPRIT */
		BluageUtils.unsupported();
		SendTextBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withData(BluageUtils.unsupported())
		.withLength(BluageUtils.unsupported().length())
		.execute();
		HandleAbendBuilder.newInstance(ctx.getJicsEiblk(), ctx).cancel().execute().handleException();
		AbendBuilder.newInstance(ctx.getJicsEiblk(), ctx).withAbendCode("9999").execute().handleException();
		
		/* 
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:32 CDT */
		instanceStateMachineController.sendEvent(Events.TO_FINAL);

	}
}
