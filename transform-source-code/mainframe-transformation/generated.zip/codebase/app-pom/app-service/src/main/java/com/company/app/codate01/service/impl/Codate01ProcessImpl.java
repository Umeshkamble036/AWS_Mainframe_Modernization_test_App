
package com.company.app.codate01.service.impl;

import com.company.app.codate01.business.context.Codate01Context;
import com.company.app.codate01.service.Codate01Process;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Codate01ProcessImpl
 * 
 * Defines application services for Codate01Process
 * @see Codate01Process
 */
@Service("com.company.app.codate01.service.Codate01Process")
@Import({
com.company.app.codate01.statemachine.Codate01ProcedureDivisionStateMachineController.class 
}) 	
@Lazy

public class Codate01ProcessImpl implements Codate01Process {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Codate01ProcessImpl.class);

	/**
	 * Process operation codate01.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void codate01(final Codate01Context ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation _8000TerminationPostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _8000TerminationPostif(final Codate01Context ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation _8000TerminationPostif1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _8000TerminationPostif1(final Codate01Context ctx, final ExecutionController ctrl) {
	}

}
