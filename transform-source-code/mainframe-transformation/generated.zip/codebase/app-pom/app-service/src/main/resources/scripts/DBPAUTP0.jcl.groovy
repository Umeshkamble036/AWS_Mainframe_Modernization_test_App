// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "DBPAUTP0"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//                                                                     
	//*********************************************************************
	//  DELETE OUTPUT DATASET                                              
	//*********************************************************************
	lastProgramResult = stepSTEPDEL(shell, params, programResults)
	//                                                                     
	//*********************************************************************
	//  DOWNLOAD DBD DBPAUTP0                                              
	//*********************************************************************
	lastProgramResult = stepUNLOAD(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP STEPDEL - PGM - IEFBR14***************************************************
def stepSTEPDEL(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEPDEL", "IEFBR14", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.bluesam("SYSUT1")
						.dataset("AWS.M2.CARDDEMO.IMSDATA.DBPAUTP0")
						.disposition("MOD")
						.normalTermination("DELETE")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IEFBR14")
				})
		}
	}
}
// STEP UNLOAD - PGM - DFSRRC00***************************************************
def stepUNLOAD(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("UNLOAD", "DFSRRC00", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.concatenation("STEPLIB")
						.path("OEMA.IMS.IMSP.SDFSRESL")
						.disposition("SHR")
						.path("AWS.M2.CARDDEMO.LOADLIB")
						.disposition("SHR")
						.build()
						.bluesam("DFSRESLB")
						.dataset("OEMA.IMS.IMSP.SDFSRESL")
						.disposition("SHR")
						.build()
						.concatenation("IMS")
						.path("OEM.IMS.IMSP.PSBLIB")
						.disposition("SHR")
						.path("OEM.IMS.IMSP.DBDLIB")
						.disposition("SHR")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.bluesam("DFSURGU1")
						.dataset("AWS.M2.CARDDEMO.IMSDATA.DBPAUTP0")
						.bdw(true)
						.rdw(true)
						.normalTermination("CATLG")
						.abnormalTermination("DELETE")
						.build()
						.bluesam("DDPAUTP0")
						.dataset("OEM.IMS.IMSP.PAUTHDB")
						.disposition("SHR")
						.build()
						.bluesam("DDPAUTX0")
						.dataset("OEM.IMS.IMSP.PAUTHDBX")
						.disposition("SHR")
						.build()
						.fileSystem("DFSVSAMP")
						.path("OEMPP.IMS.V15R01MB.PROCLIB(DFSVSMDB)")
						.disposition("SHR")
						.build()
						.fileSystem("DFSCTL")
						.stream("SBPARM ACTIV=COND                                                               ", getEncoding())
						.build()
						.systemOut("SYSUDUMP")
						.output("*")
						.build()
						.bluesam("RECON1")
						.dataset("OEM.IMS.IMSP.RECON1")
						.disposition("SHR")
						.build()
						.bluesam("RECON2")
						.dataset("OEM.IMS.IMSP.RECON2")
						.disposition("SHR")
						.build()
						.bluesam("RECON3")
						.dataset("OEM.IMS.IMSP.RECON3")
						.disposition("SHR")
						.build()
						.dummy("DFSWRK01")
						.build()
						.dummy("DFSSRT01")
						.build()
						.getFileConfigurations())
					.withArguments(getParm("ULU,DFSURGU0,DBPAUTP0"))
					.withParameters(params)
					.runProgram("DFSRRC00")
				})
		}
	}
}
