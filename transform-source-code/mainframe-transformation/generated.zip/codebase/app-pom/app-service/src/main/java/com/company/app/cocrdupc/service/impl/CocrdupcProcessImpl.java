
package com.company.app.cocrdupc.service.impl;

import com.company.app.cocrdupc.business.context.CocrdupcContext;
import com.company.app.cocrdupc.service.CocrdupcProcess;
import com.company.app.cocrdupc.statemachine.CocrdupcProcedureDivisionStateMachineController;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.data.Record;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.StringUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.bms.ReceiveMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.AbendBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.HandleAbendBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.jics.io.internal.JicsFileBuilder;
import com.netfective.bluage.gapwalk.runtime.statements.InspectBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class CocrdupcProcessImpl
 * 
 * Defines application services for CocrdupcProcess
 * @see CocrdupcProcess
 */
@Service("com.company.app.cocrdupc.service.CocrdupcProcess")
@Import({
com.company.app.cocrdupc.statemachine.CocrdupcProcedureDivisionStateMachineController.class 
}) 	
@Lazy

public class CocrdupcProcessImpl implements CocrdupcProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(CocrdupcProcessImpl.class);

	@Autowired
	private CocrdupcProcedureDivisionStateMachineController cocrdupcProcedureDivisionStateMachineRunner;


	/**
	 * Process operation cocrdupc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void cocrdupc(final CocrdupcContext ctx, final ExecutionController ctrl) {
		cocrdupcProcedureDivisionStateMachineRunner.run(ctx,ctrl);
	}

	/**
	 * Process operation commonReturn.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void commonReturn(final CocrdupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CCARD-ERROR-MSG */
		BluageUtils.unsupported();
		ctx.getWsCommarea().setWsCommarea(BluageUtils.unsupported());
		int idx = BluageUtils.unsupported().length() + 1 - 1;
		int len = ctx.getWsThisProgcommarea().getSize();
		ctx.getWsCommarea().getWsCommareaReference().setBytes(ctx.getWsThisProgcommarea().getBytes(), idx, len);
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsLiterals().getLitThistranid())
		.withCommarea(ctx.getWsCommarea().getWsCommareaReference())
		.withLength(ctx.getWsCommarea().getWsCommareaReference().getRecord().getSize())
		.execute()
		.handleException();
	}

	/**
	 * Process operation _1000ProcessInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1000ProcessInputs(final CocrdupcContext ctx, final ExecutionController ctrl) {
		_1100ReceiveMap(ctx, ctrl);
		_1200EditMapInputs(ctx, ctrl);
		
		/* 
		FIXME: CCARD-ERROR-MSG */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CCARD-NEXT-PROG */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CCARD-NEXT-MAPSET */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CCARD-NEXT-MAP */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation _1100ReceiveMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1100ReceiveMap(final CocrdupcContext ctx, final ExecutionController ctrl) {
		ReceiveMapBuilder.newInstance(ctx.getJicsEiblk(), ctrl.getExecutionContext(), ctx)
		.withMap(ctx.getWsLiterals().getLitThismapReference())
		.withMapset(ctx.getWsLiterals().getLitThismapsetReference())
		.into(BluageUtils.unsupported())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		ctx.getWsThisProgcommarea().getCcupNewDetailsReference().getField().initialize();
		
		/* 
		REPLACE * WITH LOW-VALUES */
		if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CC-ACCT-ID */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().getCcupNewAcctidReference().setBytes(Record.LOW_VALUES);
		} else {
			
			/* 
			FIXME: CC-ACCT-ID */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setCcupNewAcctid(BluageUtils.unsupported());
		}
		if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CC-CARD-NUM */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().getCcupNewCardidReference().setBytes(Record.LOW_VALUES);
		} else {
			
			/* 
			FIXME: CC-CARD-NUM */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setCcupNewCardid(BluageUtils.unsupported());
		}
		if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
			ctx.getWsThisProgcommarea().getCcupNewCrdnameReference().setBytes(Record.LOW_VALUES);
		} else {
			ctx.getWsThisProgcommarea().setCcupNewCrdname(BluageUtils.unsupported());
		}
		if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
			ctx.getWsThisProgcommarea().getCcupNewCrdstcdReference().setBytes(Record.LOW_VALUES);
		} else {
			ctx.getWsThisProgcommarea().setCcupNewCrdstcd(BluageUtils.unsupported());
		}
		ctx.getWsThisProgcommarea().setCcupNewExpday(BluageUtils.unsupported());
		if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
			ctx.getWsThisProgcommarea().getCcupNewExpmonReference().setBytes(Record.LOW_VALUES);
		} else {
			ctx.getWsThisProgcommarea().setCcupNewExpmon(BluageUtils.unsupported());
		}
		if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
			ctx.getWsThisProgcommarea().getCcupNewExpyearReference().setBytes(Record.LOW_VALUES);
		} else {
			ctx.getWsThisProgcommarea().setCcupNewExpyear(BluageUtils.unsupported());
		}
	}

	/**
	 * Process operation _1200EditMapInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1200EditMapInputs(final CocrdupcContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setInputOk(true);
		if (ctx.getWsThisProgcommarea().isCcupDetailsNotFetched()) {
			
			/* 
			VALIDATE THE SEARCH KEYS */
			_1210EditAccount(ctx, ctrl);
			_1220EditCard(ctx, ctrl);
			ctx.getWsThisProgcommarea().getCcupNewCarddataReference().setBytes(Record.LOW_VALUES);
			
			/* 
			IF THE SEARCH CONDITIONS HAVE PROBLEMS SKIP OTHER EDITS */
			if (ctx.getWsMiscStorage().isFlgAcctfilterBlank() && ctx.getWsMiscStorage().isFlgCardfilterBlank()) {
				ctx.getWsMiscStorage().setNoSearchCriteriaReceived(true);
			} 
			return;
		} else {
			
			/* 
			SEARCH KEYS ALREADY VALIDATED AND DATA FETCHED
			Do nothing */
			ctx.getWsMiscStorage().setFoundCardsForAccount(true);
			ctx.getWsMiscStorage().setFlgAcctfilterIsvalid(true);
			ctx.getWsMiscStorage().setFlgCardfilterIsvalid(true);
			
			/* 
			FIXME: CDEMO-ACCT-ID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-CARD-NUM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CARD-EMBOSSED-NAME */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CARD-ACTIVE-STATUS */
			BluageUtils.unsupported();
			ctx.getWsMiscStorage().getCardExpiryDayReference().setValue(ctx.getWsThisProgcommarea().getCcupOldExpdayReference());
			ctx.getWsMiscStorage().getCardExpiryMonthReference().setValue(ctx.getWsThisProgcommarea().getCcupOldExpmonReference());
			ctx.getWsMiscStorage().getCardExpiryYearReference().setValue(ctx.getWsThisProgcommarea().getCcupOldExpyearReference());
			
			/* 
			NEW DATA IS SAME AS OLD DATA */
			if (DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getCcupNewCarddataReference().getBytes()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getCcupOldCarddataReference().getBytes())) == 0) {
				ctx.getWsMiscStorage().setNoChangesDetected(true);
			} 
			if (ctx.getWsMiscStorage().isNoChangesDetected() || ctx.getWsThisProgcommarea().isCcupChangesOkNotConfirmed() || ctx.getWsThisProgcommarea().isCcupChangesOkayedAndDone()) {
				ctx.getWsMiscStorage().setFlgCardnameIsvalid(true);
				ctx.getWsMiscStorage().setFlgCardstatusIsvalid(true);
				ctx.getWsMiscStorage().setFlgCardexpmonIsvalid(true);
				ctx.getWsMiscStorage().setFlgCardexpyearIsvalid(true);
				return;
			} else {
				ctx.getWsThisProgcommarea().setCcupChangesNotOk(true);
				_1230EditName(ctx, ctrl);
				_1240EditCardstatus(ctx, ctrl);
				_1250EditExpiryMon(ctx, ctrl);
				_1260EditExpiryYear(ctx, ctrl);
				if (ctx.getWsMiscStorage().isInputError()) {
					
					/* 
					Do nothing */
				} else {
					ctx.getWsThisProgcommarea().setCcupChangesOkNotConfirmed(true);
				}
			}
		}
	}

	/**
	 * Process operation _1210EditAccount.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1210EditAccount(final CocrdupcContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
		
		/* 
		Not supplied */
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isZero(BluageUtils.unsupported())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAcctfilterBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setWsPromptForAcct(true);
			} 
			
			/* 
			FIXME: CDEMO-ACCT-ID */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().getCcupNewAcctidReference().setBytes(Record.LOW_VALUES);
			return;
		} else {
			
			/* 
			Not numeric
			Not 11 characters */
			if (!(DataUtils.isNumeric(BluageUtils.unsupported()))) {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					ctx.getWsMiscStorage().setWsReturnMsg("ACCOUNT FILTER,IF SUPPLIED MUST BE A 11 DIGIT NUMBER");
				} 
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				BluageUtils.unsupported();
				ctx.getWsThisProgcommarea().getCcupNewAcctidReference().setBytes(Record.LOW_VALUES);
				return;
			} else {
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				BluageUtils.unsupported();
				ctx.getWsThisProgcommarea().setCcupNewAcctid(BluageUtils.unsupported());
				ctx.getWsMiscStorage().setFlgAcctfilterIsvalid(true);
				return;
			}
		}
	}

	/**
	 * Process operation _1220EditCard.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1220EditCard(final CocrdupcContext ctx, final ExecutionController ctrl) {
		/* 
		Not numeric
		Not 16 characters */
		ctx.getWsMiscStorage().setFlgCardfilterNotOk(true);
		
		/* 
		Not supplied */
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isZero(BluageUtils.unsupported())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgCardfilterBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setWsPromptForCard(true);
			} 
			
			/* 
			FIXME: CDEMO-CARD-NUM */
			BluageUtils.unsupported();
			DataUtils.setToZeroes(ctx.getWsThisProgcommarea().getCcupNewCardidReference());
			return;
		} else {
			
			/* 
			Not numeric
			Not 16 characters */
			if (!(DataUtils.isNumeric(BluageUtils.unsupported()))) {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgCardfilterNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					ctx.getWsMiscStorage().setWsReturnMsg("CARD ID FILTER,IF SUPPLIED MUST BE A 16 DIGIT NUMBER");
				} 
				
				/* 
				FIXME: CDEMO-CARD-NUM */
				BluageUtils.unsupported();
				ctx.getWsThisProgcommarea().getCcupNewCardidReference().setBytes(Record.LOW_VALUES);
				return;
			} else {
				
				/* 
				FIXME: CDEMO-CARD-NUM */
				BluageUtils.unsupported();
				ctx.getWsThisProgcommarea().setCcupNewCardid(BluageUtils.unsupported());
				ctx.getWsMiscStorage().setFlgCardfilterIsvalid(true);
				return;
			}
		}
	}

	/**
	 * Process operation _1230EditName.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1230EditName(final CocrdupcContext ctx, final ExecutionController ctrl) {
		/* 
		Not BLANK */
		ctx.getWsMiscStorage().setFlgCardnameNotOk(true);
		
		/* 
		Not supplied */
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getCcupNewCrdnameReference()) || DataUtils.isBlank(ctx.getWsThisProgcommarea().getCcupNewCrdnameReference()) || DataUtils.isZero(ctx.getWsThisProgcommarea().getCcupNewCrdnameReference())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgCardnameBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setWsPromptForName(true);
			} 
			return;
		} else {
			
			/* 
			Only Alphabets and space allowed */
			ctx.getWsMiscStorage().getCardNameCheckReference().setValue(ctx.getWsThisProgcommarea().getCcupNewCrdnameReference());
			InspectBuilder.newInstance(ctx.getWsMiscStorage().getCardNameCheckReference())
				.convert(ctx.getWsLiterals().getLitAllAlphaFromReference())
				.to(ctx.getWsLiterals().getLitAllSpacesToReference())
				.apply();
			if (ctx.getWsMiscStorage().getCardNameCheck().trim().length() == 0) {
				
				/* 
				Do nothing */
				ctx.getWsMiscStorage().setFlgCardnameIsvalid(true);
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgCardnameNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					ctx.getWsMiscStorage().setWsNameMustBeAlpha(true);
				} 
				return;
			}
		}
	}

	/**
	 * Process operation _1240EditCardstatus.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1240EditCardstatus(final CocrdupcContext ctx, final ExecutionController ctrl) {
		/* 
		Must be Y or N */
		ctx.getWsMiscStorage().setFlgCardstatusNotOk(true);
		
		/* 
		Not supplied */
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getCcupNewCrdstcdReference()) || DataUtils.isBlank(ctx.getWsThisProgcommarea().getCcupNewCrdstcdReference()) || DataUtils.isZero(ctx.getWsThisProgcommarea().getCcupNewCrdstcdReference())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgCardstatusBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setCardStatusMustBeYesNo(true);
			} 
			return;
		} else {
			ctx.getWsMiscStorage().getFlgYesNoCheckReference().setValue(ctx.getWsThisProgcommarea().getCcupNewCrdstcdReference());
			if (ctx.getWsMiscStorage().isFlgYesNoValid()) {
				ctx.getWsMiscStorage().setFlgCardstatusIsvalid(true);
				return;
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgCardstatusNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					ctx.getWsMiscStorage().setCardStatusMustBeYesNo(true);
				} 
				return;
			}
		}
	}

	/**
	 * Process operation _1250EditExpiryMon.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1250EditExpiryMon(final CocrdupcContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setFlgCardexpmonNotOk(true);
		
		/* 
		Not supplied */
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getCcupNewExpmonReference()) || DataUtils.isBlank(ctx.getWsThisProgcommarea().getCcupNewExpmonReference()) || DataUtils.isZero(ctx.getWsThisProgcommarea().getCcupNewExpmonReference())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgCardexpmonBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setCardExpiryMonthNotValid(true);
			} 
			return;
		} else {
			
			/* 
			Must be numeric
			Must be 1 to 12 */
			ctx.getWsMiscStorage().getCardMonthCheckReference().setValue(ctx.getWsThisProgcommarea().getCcupNewExpmonReference());
			if (ctx.getWsMiscStorage().isValidMonth()) {
				ctx.getWsMiscStorage().setFlgCardexpmonIsvalid(true);
				return;
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgCardexpmonNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					ctx.getWsMiscStorage().setCardExpiryMonthNotValid(true);
				} 
				return;
			}
		}
	}

	/**
	 * Process operation _1260EditExpiryYear.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1260EditExpiryYear(final CocrdupcContext ctx, final ExecutionController ctrl) {
		/* 
		Not supplied */
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getCcupNewExpyearReference()) || DataUtils.isBlank(ctx.getWsThisProgcommarea().getCcupNewExpyearReference()) || DataUtils.isZero(ctx.getWsThisProgcommarea().getCcupNewExpyearReference())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgCardexpyearBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setCardExpiryYearNotValid(true);
			} 
			return;
		} else {
			
			/* 
			Must be numeric
			Must be 1 to 12 */
			ctx.getWsMiscStorage().setFlgCardexpyearNotOk(true);
			ctx.getWsMiscStorage().getCardYearCheckReference().setValue(ctx.getWsThisProgcommarea().getCcupNewExpyearReference());
			if (ctx.getWsMiscStorage().isValidYear()) {
				ctx.getWsMiscStorage().setFlgCardexpyearIsvalid(true);
				return;
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgCardexpyearNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					ctx.getWsMiscStorage().setCardExpiryYearNotValid(true);
				} 
				return;
			}
		}
	}

	/**
	 * Process operation _3000SendMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3000SendMap(final CocrdupcContext ctx, final ExecutionController ctrl) {
		_3100ScreenInit(ctx, ctrl);
		_3200SetupScreenVars(ctx, ctrl);
		_3250SetupInfomsg(ctx, ctrl);
		_3300SetupScreenAttrs(ctx, ctrl);
		_3400SendScreen(ctx, ctrl);
	}

	/**
	 * Process operation _3100ScreenInit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3100ScreenInit(final CocrdupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CCRDUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE01O OF CCRDUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE02O OF CCRDUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNNAMEO OF CCRDUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PGMNAMEO OF CCRDUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURDATEO OF CCRDUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-HH */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-SS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURTIMEO OF CCRDUPAO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation _3200SetupScreenVars.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3200SetupScreenVars(final CocrdupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CDEMO-PGM-ENTER
		INITIALIZE SEARCH CRITERIA */
		if (BluageUtils.unsupported()) {
			
			/* 
			Do nothing */
		} else {
			if (DataUtils.compare("0", BluageUtils.unsupported()) == 0) {
				
				/* 
				FIXME: ACCTSIDO OF CCRDUPAO */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: ACCTSIDO OF CCRDUPAO */
				BluageUtils.unsupported();
			}
			if (DataUtils.compare("0", BluageUtils.unsupported()) == 0) {
				
				/* 
				FIXME: CARDSIDO OF CCRDUPAO */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: CARDSIDO OF CCRDUPAO */
				BluageUtils.unsupported();
			}
			if (ctx.getWsThisProgcommarea().isCcupDetailsNotFetched()) {
				
				/* 
				FIXME: CRDNAMEO OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CRDNAMEO OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CRDSTCDO OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: EXPDAYO  OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: EXPMONO  OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: EXPYEARO OF CCRDUPAO */
				BluageUtils.unsupported();
			} else if (ctx.getWsThisProgcommarea().isCcupShowDetails()) {
				
				/* 
				FIXME: CRDNAMEO OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CRDSTCDO OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: EXPDAYO  OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: EXPMONO  OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: EXPYEARO OF CCRDUPAO */
				BluageUtils.unsupported();
			} else if (ctx.getWsThisProgcommarea().isCcupChangesMade()) {
				
				/* 
				FIXME: CRDNAMEO OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CRDSTCDO OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: EXPMONO  OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: EXPYEARO OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: EXPDAYO  OF CCRDUPAO
				****************************************************************
				MOVE OLD VALUES TO NON-DISPLAY FIELDS
				THAT WE ARE NOT ALLOWING USER TO CHANGE(FOR NOW)
				****************************************************************
				MOVE CCUP-NEW-EXPDAY     TO EXPDAYO  OF CCRDUPAO */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: CRDNAMEO OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CRDSTCDO OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: EXPDAYO  OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: EXPMONO  OF CCRDUPAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: EXPYEARO OF CCRDUPAO */
				BluageUtils.unsupported();
			}
		}
	}

	/**
	 * Process operation _3250SetupInfomsg.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3250SetupInfomsg(final CocrdupcContext ctx, final ExecutionController ctrl) {
		/* 
		SETUP INFORMATION MESSAGE */
		if (BluageUtils.unsupported()) {
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			ctx.getWsMiscStorage().setPromptForSearchKeys(true);
		} else if (ctx.getWsThisProgcommarea().isCcupDetailsNotFetched()) {
			ctx.getWsMiscStorage().setPromptForSearchKeys(true);
		} else if (ctx.getWsThisProgcommarea().isCcupShowDetails()) {
			ctx.getWsMiscStorage().setFoundCardsForAccount(true);
		} else if (ctx.getWsThisProgcommarea().isCcupChangesNotOk()) {
			ctx.getWsMiscStorage().setPromptForChanges(true);
		} else if (ctx.getWsThisProgcommarea().isCcupChangesOkNotConfirmed()) {
			ctx.getWsMiscStorage().setPromptForConfirmation(true);
		} else if (ctx.getWsThisProgcommarea().isCcupChangesOkayedAndDone()) {
			ctx.getWsMiscStorage().setConfirmUpdateSuccess(true);
		} else if (ctx.getWsThisProgcommarea().isCcupChangesOkayedLockError()) {
			ctx.getWsMiscStorage().setInformFailure(true);
		} else if (ctx.getWsThisProgcommarea().isCcupChangesOkayedButFailed()) {
			ctx.getWsMiscStorage().setInformFailure(true);
		} else if (ctx.getWsMiscStorage().isWsNoInfoMessage()) {
			ctx.getWsMiscStorage().setPromptForSearchKeys(true);
		} 
		
		/* 
		FIXME: INFOMSGO OF CCRDUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ERRMSGO OF CCRDUPAO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation _3300SetupScreenAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3300SetupScreenAttrs(final CocrdupcContext ctx, final ExecutionController ctrl) {
		/* 
		PROTECT OR UNPROTECT BASED ON CONTEXT */
		if (ctx.getWsThisProgcommarea().isCcupDetailsNotFetched()) {
			
			/* 
			FIXME: ACCTSIDA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CARDSIDA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDNAMEA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDSTCDA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPMONA  OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPYEARA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			EXPDAYA  OF CCRDUPAI */
		} else if (ctx.getWsThisProgcommarea().isCcupShowDetails() || ctx.getWsThisProgcommarea().isCcupChangesNotOk()) {
			
			/* 
			FIXME: ACCTSIDA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CARDSIDA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDNAMEA OF CCRDUPAI
			EXPDAYA  OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDSTCDA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPMONA  OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPYEARA OF CCRDUPAI */
			BluageUtils.unsupported();
		} else if (ctx.getWsThisProgcommarea().isCcupChangesOkNotConfirmed() || ctx.getWsThisProgcommarea().isCcupChangesOkayedAndDone()) {
			
			/* 
			FIXME: ACCTSIDA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CARDSIDA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDNAMEA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDSTCDA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPMONA  OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPYEARA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			EXPDAYA  OF CCRDUPAI */
		} else {
			
			/* 
			FIXME: ACCTSIDA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CARDSIDA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDNAMEA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDSTCDA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPMONA  OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPYEARA OF CCRDUPAI */
			BluageUtils.unsupported();
			
			/* 
			EXPDAYA  OF CCRDUPAI */
		}
		
		/* 
		POSITION CURSOR */
		if (ctx.getWsMiscStorage().isFoundCardsForAccount() || ctx.getWsMiscStorage().isNoChangesDetected()) {
			
			/* 
			FIXME: CRDNAMEL OF CCRDUPAI */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().isFlgAcctfilterNotOk() || ctx.getWsMiscStorage().isFlgAcctfilterBlank()) {
			
			/* 
			FIXME: ACCTSIDL OF CCRDUPAI */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().isFlgCardfilterNotOk() || ctx.getWsMiscStorage().isFlgCardfilterBlank()) {
			
			/* 
			FIXME: CARDSIDL OF CCRDUPAI */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().isFlgCardnameNotOk() || ctx.getWsMiscStorage().isFlgCardnameBlank()) {
			
			/* 
			FIXME: CRDNAMEL OF  CCRDUPAI */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().isFlgCardstatusNotOk() || ctx.getWsMiscStorage().isFlgCardstatusBlank()) {
			
			/* 
			FIXME: CRDSTCDL OF  CCRDUPAI */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().isFlgCardexpmonNotOk() || ctx.getWsMiscStorage().isFlgCardexpmonBlank()) {
			
			/* 
			FIXME: EXPMONL  OF  CCRDUPAI */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().isFlgCardexpyearNotOk() || ctx.getWsMiscStorage().isFlgCardexpyearBlank()) {
			
			/* 
			FIXME: EXPYEARL OF  CCRDUPAI */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: ACCTSIDL OF CCRDUPAI */
			BluageUtils.unsupported();
		}
		
		/* 
		SETUP COLOR */
		if (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitCclistmapsetReference()) == 0) {
			
			/* 
			FIXME: ACCTSIDC OF CCRDUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CARDSIDC OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgAcctfilterNotOk()) {
			
			/* 
			FIXME: ACCTSIDC OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgAcctfilterBlank() && BluageUtils.unsupported()) {
			
			/* 
			FIXME: ACCTSIDO OF CCRDUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACCTSIDC OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgCardfilterNotOk()) {
			
			/* 
			FIXME: CARDSIDC OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgCardfilterBlank() && BluageUtils.unsupported()) {
			
			/* 
			FIXME: CARDSIDO OF CCRDUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CARDSIDC OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgCardnameNotOk() && ctx.getWsThisProgcommarea().isCcupChangesNotOk()) {
			
			/* 
			FIXME: CRDNAMEC OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgCardnameBlank() && ctx.getWsThisProgcommarea().isCcupChangesNotOk()) {
			
			/* 
			FIXME: CRDNAMEO OF CCRDUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDNAMEC OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgCardstatusNotOk() && ctx.getWsThisProgcommarea().isCcupChangesNotOk()) {
			
			/* 
			FIXME: CRDSTCDC OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgCardstatusBlank() && ctx.getWsThisProgcommarea().isCcupChangesNotOk()) {
			
			/* 
			FIXME: CRDSTCDO OF CCRDUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDSTCDC OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		
		/* 
		FIXME: EXPDAYC  OF CCRDUPAO */
		BluageUtils.unsupported();
		if (ctx.getWsMiscStorage().isFlgCardexpmonNotOk() && ctx.getWsThisProgcommarea().isCcupChangesNotOk()) {
			
			/* 
			FIXME: EXPMONC  OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgCardexpmonBlank() && ctx.getWsThisProgcommarea().isCcupChangesNotOk()) {
			
			/* 
			FIXME: EXPMONO  OF CCRDUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPMONC  OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgCardexpyearNotOk() && ctx.getWsThisProgcommarea().isCcupChangesNotOk()) {
			
			/* 
			FIXME: EXPYEARC OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgCardexpyearBlank() && ctx.getWsThisProgcommarea().isCcupChangesNotOk()) {
			
			/* 
			FIXME: EXPYEARO OF CCRDUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPYEARC OF CCRDUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isWsNoInfoMessage()) {
			
			/* 
			FIXME: INFOMSGA OF CCRDUPAI */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: INFOMSGA OF CCRDUPAI */
			BluageUtils.unsupported();
		}
		if (ctx.getWsMiscStorage().isPromptForConfirmation()) {
			
			/* 
			FIXME: FKEYSCA  OF CCRDUPAI */
			BluageUtils.unsupported();
		}
	}

	/**
	 * Process operation _3400SendScreen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3400SendScreen(final CocrdupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CCARD-NEXT-MAPSET */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CCARD-NEXT-MAP */
		BluageUtils.unsupported();
		SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withMap(BluageUtils.unsupported())
		.withMapset(BluageUtils.unsupported())
		.withData(BluageUtils.unsupported())
		.withCursor()
		.withErase()
		.withFreeKB()
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
	}

	/**
	 * Process operation _9000ReadData.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9000ReadData(final CocrdupcContext ctx, final ExecutionController ctrl) {
		ctx.getWsThisProgcommarea().getCcupOldDetailsReference().getField().initialize();
		ctx.getWsThisProgcommarea().setCcupOldAcctid(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setCcupOldCardid(BluageUtils.unsupported());
		_9100GetcardByacctcard(ctx, ctrl);
		if (ctx.getWsMiscStorage().isFoundCardsForAccount()) {
			ctx.getWsThisProgcommarea().setCcupOldCvvCd(BluageUtils.unsupported());
			InspectBuilder.newInstance(BluageUtils.unsupported(), ctx.getConfiguration())
				.convert(ctx.getWsLiterals().getLitLowerReference())
				.to(ctx.getWsLiterals().getLitUpperReference())
				.apply();
			ctx.getWsThisProgcommarea().setCcupOldCrdname(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().setCcupOldExpyear(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().setCcupOldExpmon(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().setCcupOldExpday(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().setCcupOldCrdstcd(BluageUtils.unsupported());
		}
	}

	/**
	 * Process operation _9100GetcardByacctcard.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9100GetcardByacctcard(final CocrdupcContext ctx, final ExecutionController ctrl) {
		/* 
		Read the Card file
		MOVE CC-ACCT-ID-N            TO WS-CARD-RID-ACCT-ID */
		ctx.getWsMiscStorage().setWsCardRidCardnum(BluageUtils.unsupported());
		JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitCardfilenameReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidCardnumReference())
		.keyLength(ctx.getWsMiscStorage().getWsCardRidCardnumReference().getRecord().getSize(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			ctx.getWsMiscStorage().setFoundCardsForAccount(true);
		} else if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
			ctx.getWsMiscStorage().setFlgCardfilterNotOk(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setDidNotFindAcctcardCombo(true);
			} 
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
			} 
			ctx.getWsMiscStorage().setErrorOpname("READ");
			ctx.getWsMiscStorage().setErrorFile(ctx.getWsLiterals().getLitCardfilename());
			ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
			ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
			ctx.getWsMiscStorage().getWsReturnMsgReference().setBytes(ctx.getWsMiscStorage().getWsFileErrorMessageReference().getBytes());
		}
	}

	/**
	 * Process operation abendRoutine.
	 * 
	 * ****************************************************************
	 * Common code to store PFKey
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void abendRoutine(final CocrdupcContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isLowValue(BluageUtils.unsupported())) {
			
			/* 
			FIXME: ABEND-MSG */
			BluageUtils.unsupported();
		} 
		
		/* 
		FIXME: ABEND-CULPRIT */
		BluageUtils.unsupported();
		
		/* 
		Ignored CICS Command SEND */
		HandleAbendBuilder.newInstance(ctx.getJicsEiblk(), ctx).cancel().execute().handleException();
		AbendBuilder.newInstance(ctx.getJicsEiblk(), ctx).withAbendCode("9999").execute().handleException();
		
		/* 
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:33 CDT */
		return;
	}

}
