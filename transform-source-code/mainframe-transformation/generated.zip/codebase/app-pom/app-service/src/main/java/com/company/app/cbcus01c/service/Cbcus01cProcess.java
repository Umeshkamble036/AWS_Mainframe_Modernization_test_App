package com.company.app.cbcus01c.service;

import com.company.app.cbcus01c.business.context.Cbcus01cContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface Cbcus01cProcess.
 * 
 * Defines application services for Cbcus01cProcess
 */
public interface Cbcus01cProcess {

	/**
	 * Process operation procedureDivision.
	 * 
	 * PROGRAM-ID.CBCUS01C.
	 *  AUTHOR.        AWS.
	 * *****************************************************************
	 *  Program     : CBCUS01C.CBL
	 *  Application : CardDemo
	 *  Type        : BATCH COBOL Program
	 *  Function    : Read and print customer data file.
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void procedureDivision(final Cbcus01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000CustfileGetNext.
	 * 
	 * ****************************************************************
	 *  I/O ROUTINES TO ACCESS A KSDS, VSAM DATA SET...               *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000CustfileGetNext(final Cbcus01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0000CustfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000CustfileOpen(final Cbcus01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9000CustfileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9000CustfileClose(final Cbcus01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation zAbendProgram.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void zAbendProgram(final Cbcus01cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation zDisplayIoStatus.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void zDisplayIoStatus(final Cbcus01cContext ctx, final ExecutionController ctrl);

}
