// 'MEMNAME'='null'
// 'HLQ'='null'
// 'SSID'='null'
// 'PLAN'='null'
// 'SDSNEXIT'='OEM.DB2.&SSID..SDSNEXIT'
// 'SDSNLOAD'='OEM.DB2.&SSID..SDSNLOAD'
// 'SDFHLOAD'='OEM.CICSTS.V05R06M0.CICS.SDFHLOAD'
// 'SDFHCOB'='OEM.CICSTS.V05R06M0.CICS.SDFHCOB'
// 'SDFHMAC'='OEM.CICSTS.V05R06M0.CICS.SDFHMAC'
// 'DBRMLIB'='&HLQ..DBRMLIB'
// 'LIBPRFX'='CEE'
// 'COBLIB'='IGY.SIGYCOMP.V63'
// 'CPYBKS'='&HLQ..CPY'
// 'SRCLIB'='&HLQ..CBL'
// 'LOADLIB'='&HLQ..LOADLIB'
// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
binding.setVariable("fcmap", fcmap)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//********************************************************************
//  THIS PROC IS USED TO COMPILE CICS + DB2 PROGRAMS
//********************************************************************
// Copyright Amazon.com, Inc. or its affiliates.
// All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License").
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
// either express or implied. See the License for the specific
// language governing permissions and limitations under the License
//********************************************************************
//***  Sample CICS COBOL Db2 compile proc                       ******
//***  Run after related BMS is compiled                        ******
//***  Check with your Administrator for                        ******
//***  JCL suitable to your environment                         ******
//********************************************************************
//
//*********************************************************************
//*                             PROC                                  *
//*********************************************************************
shell.with {
	def procName = "BLDONL"
	mpr.setJobContext(jobContext)
	def jobName = "" + jobContext.getJobName() + "-" + procName
	displayStartProc(procName)
	mpr.withSchenv(jobContext.getSchenv())
	def lastProgramResult
	//           LISTING=&HLQ..LST
	//
	//********************************************************
	//       Db2 Precompile the Cobol Program
	//       Draw all SQL statements out into DBRMLIB
	//********************************************************
	lastProgramResult = stepPRECMP(shell, params, programResults)
	//
	//********************************************************
	//       Perform CICS translation
	//       Replace CICS command blocks with call statements
	//********************************************************
	lastProgramResult = stepTRN(shell, params, programResults)
	//********************************************************
	//       Perform COBOL Compilation
	//********************************************************
	lastProgramResult = stepCOBOL(shell, params, programResults)
	if (getReturnCode(programResults) == 0) {
		//********************************************************
		//       Link Edit
		//       Combine all the object modules to a single module
		//********************************************************
		lastProgramResult = stepLKED(shell, params, programResults)
		//********************************************************************
		//       Bind all DBRMs into a single collection
		//********************************************************************
		lastProgramResult = stepBINDPK(shell, params, programResults)
		//********************************************************************
		//       Bind Package to CardDemo Plan
		//       This plan must match with what we have defined in DB2ENTRY
		//********************************************************************
		lastProgramResult = stepBINDPL(shell, params, programResults)
	}
	displayEndProc(procName)
	return programResults
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP PRECMP - PGM - DSNHPC*****************************************************
def stepPRECMP(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("PRECMP", "DSNHPC", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.concatenation("STEPLIB")
						.path("&SDSNEXIT")
						.disposition("SHR")
						.path("&SDSNLOAD")
						.disposition("SHR")
						.build()
						.getFileConfigurations(fcmap))
					.withArguments(getParm("HOST(IBMCOB),XREF,SOURCE,FLAG(I),APOST"))
					.withParameters(params)
					.runProgram("DSNHPC")
				})
		}
	}
}
// STEP TRN - PGM - DFHECP1$******************************************************
def stepTRN(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (programResults.containsKey('PRECMP') && programResults['PRECMP'].getReturnCode() == 0) {
				return execStep("TRN", "DFHECP1$", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.bluesam("STEPLIB")
							.dataset("&SDFHLOAD")
							.disposition("SHR")
							.build()
							.bluesam("SYSIN")
							.dataset("&&DSNHOUT")
							.disposition("OLD")
							.normalTermination("DELETE")
							.build()
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.bluesam("SYSPUNCH")
							.dataset("&&SYSCIN")
							.normalTermination("PASS")
							.build()
							.getFileConfigurations(fcmap))
						.withArguments(getParm("NOSEQ"))
						.withParameters(params)
						.runProgram("DFHECP1$")
					})
			}
		}
	}
}
// STEP COBOL - PGM - IGYCRCTL****************************************************
def stepCOBOL(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("COBOL", "IGYCRCTL", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.bluesam("STEPLIB")
							.dataset("&COBLIB")
							.disposition("SHR")
							.build()
							.concatenation("SYSLIB")
							.path("&DCLLIB")
							.disposition("SHR")
							.path("&COPYLIB")
							.disposition("SHR")
							.path("&CPYBKS")
							.disposition("SHR")
							.path("&SDFHCOB")
							.disposition("SHR")
							.path("&SDFHMAC")
							.disposition("SHR")
							.build()
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.bluesam("SYSIN")
							.dataset("&&SYSCIN")
							.disposition("OLD")
							.normalTermination("DELETE")
							.build()
							.bluesam("SYSLIN")
							.dataset("&&LOADSET")
							.disposition("MOD")
							.normalTermination("PASS")
							.build()
							.bluesam("SYSUT1")
							.dataset("&&SYSUT1")
							.build()
							.bluesam("SYSUT2")
							.dataset("&&SYSUT2")
							.build()
							.bluesam("SYSUT3")
							.dataset("&&SYSUT3")
							.build()
							.bluesam("SYSUT4")
							.dataset("&&SYSUT4")
							.build()
							.bluesam("SYSUT5")
							.dataset("&&SYSUT5")
							.build()
							.bluesam("SYSUT6")
							.dataset("&&SYSUT6")
							.build()
							.bluesam("SYSUT7")
							.dataset("&&SYSUT7")
							.build()
							.bluesam("SYSUT8")
							.dataset("&&SYSUT8")
							.build()
							.bluesam("SYSUT9")
							.dataset("&&SYSUT9")
							.build()
							.bluesam("SYSUT10")
							.dataset("&&SYSUT10")
							.build()
							.bluesam("SYSUT11")
							.dataset("&&SYSUT11")
							.build()
							.bluesam("SYSUT12")
							.dataset("&&SYSUT12")
							.build()
							.bluesam("SYSUT13")
							.dataset("&&SYSUT13")
							.build()
							.bluesam("SYSUT14")
							.dataset("&&SYSUT14")
							.build()
							.bluesam("SYSUT15")
							.dataset("&&SYSUT15")
							.build()
							.bluesam("SYSMDECK")
							.dataset("&&SYSMDECK")
							.build()
							.getFileConfigurations(fcmap))
						.withArguments(getParm("RENT,NODYNAM,NOSEQ"))
						.withParameters(params)
						.runProgram("IGYCRCTL")
					})
			}
		}
	}
}
// STEP LKED - PGM - HEWL*********************************************************
def stepLKED(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("LKED", "HEWL", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.concatenation("SYSLIB")
							.path("&LIBPRFX..SCEELKEX")
							.disposition("SHR")
							.path("&LIBPRFX..SCEELKED")
							.disposition("SHR")
							.path("&SDFHLOAD")
							.disposition("SHR")
							.path("&SDFHCOB")
							.disposition("SHR")
							.path("&SDSNLOAD")
							.disposition("SHR")
							.path("ISP.SISPLOAD")
							.disposition("SHR")
							.path("GDDM.SADMMOD")
							.disposition("SHR")
							.path("&LOADLIB")
							.disposition("SHR")
							.build()
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.concatenation("SYSLIN")
							.path("&SDFHCOB(DFHEILIC)")
							.disposition("SHR")
							.path("&&LOADSET").temporary()
							.disposition("OLD")
							.normalTermination("DELETE")
							.ddname("SYSIN")
							.build()
							.getFileConfigurations(fcmap))
						.withParameters(params)
						.runProgram("HEWL")
					})
			}
		}
	}
}
// STEP BINDPK - PGM - IKJEFT01***************************************************
def stepBINDPK(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("BINDPK", "IKJEFT01", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.concatenation("STEPLIB")
							.path("OEM.DB2.DAZ1.SDSNEXIT")
							.disposition("SHR")
							.path("OEMA.DB2.VERSIONA.SDSNLOAD")
							.disposition("SHR")
							.build()
							.getFileConfigurations(fcmap))
						.withParameters(params)
						.runProgram("IKJEFT01")
					})
			}
		}
	}
}
// STEP BINDPL - PGM - IKJEFT01***************************************************
def stepBINDPL(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (programResults.containsKey('BINDPK') && programResults['BINDPK'].getReturnCode() <= 4) {
				return execStep("BINDPL", "IKJEFT01", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.concatenation("STEPLIB")
							.path("OEM.DB2.DAZ1.SDSNEXIT")
							.disposition("SHR")
							.path("OEMA.DB2.VERSIONA.SDSNLOAD")
							.disposition("SHR")
							.build()
							.getFileConfigurations(fcmap))
						.withParameters(params)
						.runProgram("IKJEFT01")
					})
			}
		}
	}
}
