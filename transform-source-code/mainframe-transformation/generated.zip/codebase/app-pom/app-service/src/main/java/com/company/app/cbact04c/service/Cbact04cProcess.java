package com.company.app.cbact04c.service;

import com.company.app.cbact04c.business.context.Cbact04cContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface Cbact04cProcess.
 * 
 * Defines application services for Cbact04cProcess
 */
public interface Cbact04cProcess {

	/**
	 * Process operation procedureDivision.
	 * 
	 * PROGRAM-ID.CBACT04C.
	 *  AUTHOR.        AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void procedureDivision(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0000TcatbalfOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000TcatbalfOpen(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0100XreffileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0100XreffileOpen(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0200DiscgrpOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0200DiscgrpOpen(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0300AcctfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0300AcctfileOpen(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0400TranfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0400TranfileOpen(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000TcatbalfGetNext.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000TcatbalfGetNext(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1050UpdateAccount.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1050UpdateAccount(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1100GetAcctData.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1100GetAcctData(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1110GetXrefData.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1110GetXrefData(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1200GetInterestRate.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1200GetInterestRate(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1200AGetDefaultIntRate.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1200AGetDefaultIntRate(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1300ComputeInterest.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1300ComputeInterest(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1300BWriteTx.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1300BWriteTx(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9000TcatbalfClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9000TcatbalfClose(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9100XreffileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9100XreffileClose(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9200DiscgrpClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9200DiscgrpClose(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9300AcctfileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9300AcctfileClose(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9400TranfileClose.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9400TranfileClose(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation zGetDb2FormatTimestamp.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void zGetDb2FormatTimestamp(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9999AbendProgram.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9999AbendProgram(final Cbact04cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9910DisplayIoStatus.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9910DisplayIoStatus(final Cbact04cContext ctx, final ExecutionController ctrl);

}
