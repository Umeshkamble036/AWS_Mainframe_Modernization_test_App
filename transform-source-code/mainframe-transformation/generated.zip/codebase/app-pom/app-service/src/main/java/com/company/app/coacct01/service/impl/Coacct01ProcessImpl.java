
package com.company.app.coacct01.service.impl;

import com.company.app.coacct01.business.context.Coacct01Context;
import com.company.app.coacct01.service.Coacct01Process;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Coacct01ProcessImpl
 * 
 * Defines application services for Coacct01Process
 * @see Coacct01Process
 */
@Service("com.company.app.coacct01.service.Coacct01Process")
@Import({
com.company.app.coacct01.statemachine.Coacct01ProcedureDivisionStateMachineController.class 
}) 	
@Lazy

public class Coacct01ProcessImpl implements Coacct01Process {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Coacct01ProcessImpl.class);

	/**
	 * Process operation coacct01.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void coacct01(final Coacct01Context ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation _8000TerminationPostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _8000TerminationPostif(final Coacct01Context ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation _8000TerminationPostif1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _8000TerminationPostif1(final Coacct01Context ctx, final ExecutionController ctrl) {
	}

}
