// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
binding.setVariable("fcmap", fcmap)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//  ---------------------------                                        
//  BATCH COMPILER JCL 
//  ---------------------------                                        
//         
//*********************************************************************
//*                       IN-STREAM PROC                              *
//*********************************************************************
// This is an in-stream procedure defined and used only by job 'COMPILEC'
shell.with {
	def jobName = 'COMPILEC'
	def procName = "BLDBAT"
	displayStartProc(procName)
	mpr.withSchenv(jobContext.getSchenv())
	Map programResults = [:]
	def lastProgramResult
	lastProgramResult = stepCOMPILE(shell, params, programResults)
	//                                                                     
	//  *********************************                                  
	//        COPY THE LISTING TO SYSOUT                                   
	//  *********************************                                  
	lastProgramResult = stepCBLPRINT(shell, params, programResults)
	//                                                                     
	//  *********************************                                  
	//        LINK-EDIT (BINDER) STEP                                      
	//  *********************************                                  
	//                                                                     
	lastProgramResult = stepLKED(shell, params, programResults)
	displayEndProc(procName)
	return programResults
}
//*********************************************************************
//*                      IN-STREAM PROC STEPS                         *
//*********************************************************************
// STEP COMPILE - PGM - IGYCRCTL**************************************************
def stepCOMPILE(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("COMPILE", "IGYCRCTL", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.bluesam("STEPLIB")
						.dataset("IGY.SIGYCOMP.V63")
						.disposition("SHR")
						.build()
						.fileSystem("SYSIN")
						.path("AWS.M2.CARDDEMO.CBL(&MEM)")
						.disposition("SHR")
						.build()
						.bluesam("SYSLIB")
						.dataset("AWS.M2.CARDDEMO.CPY")
						.disposition("SHR")
						.build()
						.fileSystem("SYSPRINT")
						.path("AWS.M2.CARDDEMO.LISTING(&MEM)")
						.disposition("SHR")
						.build()
						.bluesam("SYSLIN")
						.dataset("&&LOADSET")
						.disposition("MOD")
						.normalTermination("PASS")
						.build()
						.bluesam("SYSUT1")
						.dataset("&&SYSUT1")
						.build()
						.bluesam("SYSUT2")
						.dataset("&&SYSUT2")
						.build()
						.bluesam("SYSUT3")
						.dataset("&&SYSUT3")
						.build()
						.bluesam("SYSUT4")
						.dataset("&&SYSUT4")
						.build()
						.bluesam("SYSUT5")
						.dataset("&&SYSUT5")
						.build()
						.bluesam("SYSUT6")
						.dataset("&&SYSUT6")
						.build()
						.bluesam("SYSUT7")
						.dataset("&&SYSUT7")
						.build()
						.bluesam("SYSUT8")
						.dataset("&&SYSUT8")
						.build()
						.bluesam("SYSUT9")
						.dataset("&&SYSUT9")
						.build()
						.bluesam("SYSUT10")
						.dataset("&&SYSUT10")
						.build()
						.bluesam("SYSUT11")
						.dataset("&&SYSUT11")
						.build()
						.bluesam("SYSUT12")
						.dataset("&&SYSUT12")
						.build()
						.bluesam("SYSUT13")
						.dataset("&&SYSUT13")
						.build()
						.bluesam("SYSUT14")
						.dataset("&&SYSUT14")
						.build()
						.bluesam("SYSUT15")
						.dataset("&&SYSUT15")
						.build()
						.bluesam("SYSMDECK")
						.dataset("&&SYSMDECK")
						.build()
						.getFileConfigurations())
					.withArguments(getParm("APOST,LIST,MAP,NUMBER"))
					.withParameters(params)
					.runProgram("IGYCRCTL")
				})
		}
	}
}
// STEP CBLPRINT - PGM - IEBGENER*************************************************
def stepCBLPRINT(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("CBLPRINT", "IEBGENER", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSUT1")
						.path("AWS.M2.CARDDEMO.LISTING(&MEM)")
						.disposition("SHR")
						.build()
						.systemOut("SYSUT2")
						.output("*")
						.build()
						.dummy("SYSIN")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IEBGENER")
				})
		}
	}
}
// STEP LKED - PGM - HEWL*********************************************************
def stepLKED(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("LKED", "HEWL", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.concatenation("SYSLIB")
						.path("SYS1.LINKLIB")
						.disposition("SHR")
						.path("CSF.SCSFMOD0")
						.disposition("SHR")
						.path("CEE.SCEELKED")
						.disposition("SHR")
						.path("CEE.SCEELKEX")
						.disposition("SHR")
						.path("AWS.M2.CARDDEMO.LOADLIB")
						.disposition("SHR")
						.build()
						.bluesam("SYSLIN")
						.dataset("&&LOADSET")
						.disposition("OLD")
						.normalTermination("DELETE")
						.build()
						.fileSystem("SYSLMOD")
						.path("AWS.M2.CARDDEMO.LOADLIB(&MEM)")
						.disposition("SHR")
						.build()
						.bluesam("SYSUT1")
						.dataset("&&SYSUT1")
						.build()
						.getFileConfigurations())
					.withArguments(getParm("LIST,XREF"))
					.withParameters(params)
					.runProgram("HEWL")
				})
		}
	}
}
