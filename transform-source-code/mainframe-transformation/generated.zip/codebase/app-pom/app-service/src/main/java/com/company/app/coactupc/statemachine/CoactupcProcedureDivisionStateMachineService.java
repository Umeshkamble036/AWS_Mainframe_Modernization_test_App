
package com.company.app.coactupc.statemachine;

import com.company.app.coactupc.business.context.CoactupcContext;
import com.company.app.coactupc.service.CoactupcProcess;
import com.company.app.coactupc.statemachine.CoactupcProcedureDivisionStateMachineController.Events;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.StringUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.control.HandleAbendBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.jics.internal.JicsSyncpointBuilder;
import com.netfective.bluage.gapwalk.rt.jics.io.JicsIsolationLevel;
import com.netfective.bluage.gapwalk.rt.jics.io.internal.JicsFileBuilder;
import com.netfective.bluage.gapwalk.rt.statemachine.StateMachineControllerWithContinuation;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Service class containing states process used to drive state machine "CoactupcProcedureDivisionStateMachine".
 */
@Service("com.company.app.coactupc.statemachine.CoactupcProcedureDivisionStateMachineService")
@Lazy
public class CoactupcProcedureDivisionStateMachineService {
	
	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(CoactupcProcedureDivisionStateMachineService.class);

	/**
	 * The associated state machine controller.
	 */
	@Autowired
	@Qualifier("com.company.app.coactupc.statemachine.CoactupcProcedureDivisionStateMachineController")	
	private StateMachineControllerWithContinuation<Events> instanceStateMachineController;
	
	
	/**
	 * Service used by the state machine.
	 */
	@Autowired
	@Qualifier("com.company.app.coactupc.service.CoactupcProcess")
	private CoactupcProcess instanceCoactupcProcess;
	
	
	

	/**
	 * State process operation _0000Main.
	 * 
	 * PROGRAM-ID.COACTUPC.
	 *  DATE-WRITTEN.
	 *      July 2022.
	 *  DATE-COMPILED.
	 *      Today.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000Main(CoactupcContext ctx, ExecutionController ctrl) {
		instanceStateMachineController.registerSignalHandler(Events.TO_ABEND_ROUTINE, ctx, "ABEND_1_VIRTUAL_SIGNAL");
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		*************************************** *************************
		Program:     COACTUPC.CBL                                     *
		Layer:       Business logic                                   *
		Function:    Accept and process ACCOUNT UPDATE                *
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		***************************************************************** */
		ctx.getSignalHandlersController().activateSignalHandler("ABEND_1_VIRTUAL_SIGNAL","!ABEND");
		HandleAbendBuilder.newInstance(ctx.getJicsEiblk(), ctx).execute().handleException();
		DataUtils.initialize(BluageUtils.unsupported());
		ctx.getWsMiscStorage().getField().initialize();
		DataUtils.initialize(ctx.getWsCommarea().getWsCommareaReference());
		
		/* 
		****************************************************************
		Store our context
		**************************************************************** */
		ctx.getWsMiscStorage().getWsTranidReference().setValue(ctx.getWsLiterals().getLitThistranidReference());
		
		/* 
		****************************************************************
		Ensure error message is cleared                               *
		**************************************************************** */
		ctx.getWsMiscStorage().setWsReturnMsgOff(true);
		
		/* 
		****************************************************************
		Store passed data if  any                *
		**************************************************************** */
		if (ctx.getDfheiblk().getEibcalen() == 0 || (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitMenupgmReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), BluageUtils.unsupported()) != 0)) {
			DataUtils.initialize(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().getField().initialize();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setAcupDetailsNotFetched(true);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			int idx = BluageUtils.unsupported().length() + 1 - 1;
			int len = ctx.getWsThisProgcommarea().getSize();
			ctx.getWsThisProgcommarea().setBytes(ctx.getDfhcommarea().getBytes(idx, len));
		}
		
		/* 
		FIXME:PERFORM YYYY-STORE-PFKEY
		THRU YYYY-STORE-PFKEY-EXIT
		****************************************************************
		Remap PFkeys as needed.
		Store the Mapped PF Key
		**************************************************************** */
		BluageUtils.unsupported();
		
		/* 
		****************************************************************
		Check the AID to see if its valid at this point               *
		F3 - Exit
		Enter show screen again
		**************************************************************** */
		ctx.getWsMiscStorage().setPfkInvalid(true);
		if (BluageUtils.unsupported() || BluageUtils.unsupported() || (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isAcupChangesOkNotConfirmed()) || (BluageUtils.unsupported() && !(ctx.getWsThisProgcommarea().isAcupDetailsNotFetched()))) {
			ctx.getWsMiscStorage().setPfkValid(true);
		} 
		if (ctx.getWsMiscStorage().isPfkInvalid()) {
			
			/* 
			FIXME: CCARD-AID-ENTER */
			BluageUtils.unsupported();
		} 
		
		/* 
		****************************************************************
		Decide what to do based on inputs received
		**************************************************************** */
		if (BluageUtils.unsupported()) {
			
			/* 
			FIXME: CCARD-AID-PFK03 */
			
			/* 
			FIXME: CCARD-AID-PFK03
			****************************************************************
			USER PRESSES PF03 TO EXIT
			OR   USER IS DONE WITH UPDATE
			XCTL TO CALLING PROGRAM OR MAIN MENU
			**************************************************************** */
			BluageUtils.unsupported();
			if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-TO-TRANID */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: CDEMO-TO-TRANID */
				BluageUtils.unsupported();
			}
			if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-TO-PROGRAM */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: CDEMO-TO-PROGRAM */
				BluageUtils.unsupported();
			}
			
			/* 
			FIXME: CDEMO-FROM-TRANID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-USRTYP-USER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAP */
			BluageUtils.unsupported();
			JicsSyncpointBuilder.newInstance(ctx.getJicsEiblk(), ctx)
			.commit()
			.execute()
			.handleException();
			XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
		} else if ((ctx.getWsThisProgcommarea().isAcupDetailsNotFetched() && BluageUtils.unsupported()) || (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitMenupgmReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), BluageUtils.unsupported()) != 0)) {
			
			/* 
			FIXME: CDEMO-PGM-ENTERFIXME: CDEMO-FROM-PROGRAMFIXME: CDEMO-FROM-PROGRAMFIXME: CDEMO-PGM-REENTER */
			ctx.getWsThisProgcommarea().getField().initialize();
			instanceCoactupcProcess._3000SendMap(ctx, ctrl);
			
			/* 
			FIXME: CDEMO-PGM-REENTER */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setAcupDetailsNotFetched(true);
			instanceCoactupcProcess.commonReturn(ctx, ctrl);
		} else if (ctx.getWsThisProgcommarea().isAcupChangesOkayedAndDone() || ctx.getWsThisProgcommarea().isAcupChangesFailed()) {
			ctx.getWsThisProgcommarea().getField().initialize();
			ctx.getWsMiscStorage().getField().initialize();
			DataUtils.initialize(BluageUtils.unsupported());
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			instanceCoactupcProcess._3000SendMap(ctx, ctrl);
			
			/* 
			FIXME: CDEMO-PGM-REENTER */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setAcupDetailsNotFetched(true);
			instanceCoactupcProcess.commonReturn(ctx, ctrl);
		} else {
			instanceStateMachineController.sendEvent(Events.TO__0000_MAIN_CASEBRANCH);
			return;
		}

	}
	/**
	 * State process operation _2000DecideAction.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideAction(CoactupcContext ctx, ExecutionController ctrl) {
		if (ctx.getWsThisProgcommarea().isAcupDetailsNotFetched() || BluageUtils.unsupported()) {
			
			/* 
			FIXME: CCARD-AID-PFK12 */
			
			/* 
			****************************************************************
			NO DETAILS SHOWN.
			SO GET THEM AND SETUP DETAIL EDIT SCREEN
			**************************************************************** */
			if (ctx.getWsMiscStorage().isFlgAcctfilterIsvalid()) {
				ctx.getWsMiscStorage().setWsReturnMsgOff(true);
				instanceCoactupcProcess._9000ReadAcct(ctx, ctrl);
				if (ctx.getWsMiscStorage().isFoundCustInMaster()) {
					ctx.getWsThisProgcommarea().setAcupShowDetails(true);
				} 
			} 
			
			/* 
			****************************************************************
			DETAILS SHOWN
			CHECK CHANGES AND ASK CONFIRMATION IF GOOD
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isAcupShowDetails()) {
			if (ctx.getWsMiscStorage().isInputError() || ctx.getWsMiscStorage().isNoChangesDetected()) {
				
				/* 
				Do nothing */
			} else {
				ctx.getWsThisProgcommarea().setAcupChangesOkNotConfirmed(true);
			}
			
			/* 
			****************************************************************
			DETAILS SHOWN
			BUT INPUT EDIT ERRORS FOUND
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isAcupChangesNotOk()) {
			
			/* 
			Do nothing
			****************************************************************
			DETAILS EDITED , FOUND OK, CONFIRM SAVE REQUESTED
			CONFIRMATION GIVEN.SO SAVE THE CHANGES
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isAcupChangesOkNotConfirmed() && BluageUtils.unsupported()) {
			
			/* 
			FIXME: CCARD-AID-PFK05 */
			instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION_CASEBRANCH);
			return;
		} else if (ctx.getWsThisProgcommarea().isAcupChangesOkNotConfirmed()) {
			
			/* 
			Do nothing
			****************************************************************
			SHOW CONFIRMATION. GO BACK TO SQUARE 1
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isAcupChangesOkayedAndDone()) {
			ctx.getWsThisProgcommarea().setAcupShowDetails(true);
			if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-CARD-NUM */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-ACCT-STATUS */
				BluageUtils.unsupported();
			} 
		} else {
			instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION_CASEBRANCH_1);
			return;
		}
		instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION_POSTIF);

	}
	/**
	 * State process operation _9600WriteProcessing.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9600WriteProcessing(CoactupcContext ctx, ExecutionController ctrl) {
		
		/* 
		Read the account file for update */
		ctx.getWsMiscStorage().setWsCardRidAcctId(BluageUtils.unsupported());
		JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitAcctfilenameReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.setIsolationLevel(JicsIsolationLevel.UPDATE)
		.updateNoToken()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference())
		.keyLength(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference().getRecord().getSize(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		
		/* 
		****************************************************************
		Could we lock the account record ?
		**************************************************************** */
		if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Read the customer file for update
			Do nothing */
			ctx.getWsMiscStorage().setWsCardRidCustId(BluageUtils.unsupported());
			JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitCustfilenameReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
			.read()
			.setIsolationLevel(JicsIsolationLevel.UPDATE)
			.updateNoToken()
			.into(BluageUtils.unsupported())
			.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
			.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidCustIdXReference())
			.keyLength(ctx.getWsMiscStorage().getWsCardRidCustIdXReference().getRecord().getSize(),false)
			.execute();
			
			/* 
			WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
			ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
			
			/* 
			WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
			ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
			
			/* 
			****************************************************************
			Could we lock the customer record ?
			**************************************************************** */
			if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
				
				/* 
				****************************************************************
				Did someone change the record while we were out ?
				****************************************************************
				Do nothing */
				instanceStateMachineController.addContinuationEvent(Events.TO__9600_WRITE_PROCESSING_POST__9700CHECKCHANGEINREC_THRU__9700CHECKCHANGEINRECEXIT, "END_OF__9700_CHECK_CHANGE_IN_REC_EXIT");
				instanceStateMachineController.sendEvent(Events.TO__9700_CHECK_CHANGE_IN_REC);
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					ctx.getWsMiscStorage().setCouldNotLockCustForUpdate(true);
				} 
				instanceStateMachineController.sendEvent(Events.TO__9600_WRITE_PROCESSING_EXIT);
				return;
			}
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setCouldNotLockAcctForUpdate(true);
			} 
			instanceStateMachineController.sendEvent(Events.TO__9600_WRITE_PROCESSING_EXIT);
			return;
		}

	}
	/**
	 * State process operation _9600WriteProcessingExit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9600WriteProcessingExit(CoactupcContext ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__9600_WRITE_PROCESSING_EXIT");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation _9700CheckChangeInRec.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9700CheckChangeInRec(CoactupcContext ctx, ExecutionController ctrl) {
		
		/* 
		****************************************************************
		Account Master data
		**************************************************************** */
		if (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldActiveStatusReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCurrBalNReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCreditLimitNReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCashCreditLimitNReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCurrCycCreditNReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCurrCycDebitNReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldOpenYearReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldOpenMonReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldOpenDayReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldExpYearReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldExpMonReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldExpDayReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldReissueYearReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldReissueMonReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldReissueDayReference()) == 0 && DataUtils.compare(StringUtils.lowerCase(BluageUtils.unsupported()), StringUtils.lowerCase(ctx.getWsThisProgcommarea().getAcupOldGroupId())) == 0) {
			
			/* 
			****************************************************************
			Customer  data - Split into 2 IFs for easier reading
			And maybe put logic to update only 1 file if only date
			pertaining to one of them is updated
			****************************************************************
			Current Balance
			Credit Limit
			Cash Limit
			Current Cycle Credit
			Current Cycle Debit
			Open date
			Expiry date
			Reissue date
			Account Group
			Do nothing */
			if (DataUtils.compare(StringUtils.upperCase(BluageUtils.unsupported()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustFirstName())) == 0 && DataUtils.compare(StringUtils.upperCase(BluageUtils.unsupported()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustMiddleName())) == 0 && DataUtils.compare(StringUtils.upperCase(BluageUtils.unsupported()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustLastName())) == 0 && DataUtils.compare(StringUtils.upperCase(BluageUtils.unsupported()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustAddrLine1())) == 0 && DataUtils.compare(StringUtils.upperCase(BluageUtils.unsupported()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustAddrLine2())) == 0 && DataUtils.compare(StringUtils.upperCase(BluageUtils.unsupported()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustAddrLine3())) == 0 && DataUtils.compare(StringUtils.upperCase(BluageUtils.unsupported()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustAddrStateCd())) == 0 && DataUtils.compare(StringUtils.upperCase(BluageUtils.unsupported()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustAddrCountryCd())) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCustAddrZipReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCustPhoneNum1Reference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCustPhoneNum2Reference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCustSsnReference()) == 0 && DataUtils.compare(StringUtils.upperCase(BluageUtils.unsupported()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustGovtIssuedId())) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCustDobYyyyMmDdReference().getBytes(0, 4)) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCustDobYyyyMmDdReference().getBytes(4, 2)) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCustDobYyyyMmDdReference().getBytes(6, 2)) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCustEftAccountIdReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCustPriHolderIndReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getAcupOldCustFicoScoreReference()) == 0) {
				
				/* 
				Do nothing */
				instanceStateMachineController.sendEvent(Events.TO__9700_CHECK_CHANGE_IN_REC_EXIT);
			} else {
				ctx.getWsMiscStorage().setDataWasChangedBeforeUpdate(true);
				instanceStateMachineController.sendEvent(Events.TO__9600_WRITE_PROCESSING_EXIT);
				return;
			}
		} else {
			ctx.getWsMiscStorage().setDataWasChangedBeforeUpdate(true);
			instanceStateMachineController.sendEvent(Events.TO__9600_WRITE_PROCESSING_EXIT);
			return;
		}

	}
	/**
	 * State process operation _9700CheckChangeInRecExit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9700CheckChangeInRecExit(CoactupcContext ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__9700_CHECK_CHANGE_IN_REC_EXIT");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation abendRoutine.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void abendRoutine(CoactupcContext ctx, ExecutionController ctrl) {
				boolean res = false; 
		instanceCoactupcProcess.abendRoutine(ctx, ctrl);
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF_ABEND_ROUTINE");
		if (res) {
			return;
		} else {
			instanceStateMachineController.sendEvent(Events.TO_FINAL);
		}

	}
	/**
	 * State process operation _0000MainCasebranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000MainCasebranch(CoactupcContext ctx, ExecutionController ctrl) {
		instanceCoactupcProcess._1000ProcessInputs(ctx, ctrl);
		instanceStateMachineController.addContinuationEvent(Events.TO__0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT, "END_OF__2000_DECIDE_ACTION_POSTIF");
		instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION);

	}
	/**
	 * State process operation _2000DecideActionPostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideActionPostif(CoactupcContext ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__2000_DECIDE_ACTION_POSTIF");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation _2000DecideActionCasebranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideActionCasebranch(CoactupcContext ctx, ExecutionController ctrl) {
		instanceStateMachineController.addContinuationEvent(Events.TO__2000_DECIDE_ACTION_POST__9600WRITEPROCESSING_THRU__9600WRITEPROCESSINGEXIT, "END_OF__9600_WRITE_PROCESSING_EXIT");
		instanceStateMachineController.sendEvent(Events.TO__9600_WRITE_PROCESSING);

	}
	/**
	 * State process operation _2000DecideActionCasebranch1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideActionCasebranch1(CoactupcContext ctx, ExecutionController ctrl) {
		
		/* 
		FIXME: ABEND-CULPRIT */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ABEND-CODE */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ABEND-REASON */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ABEND-MSG */
		BluageUtils.unsupported();
		instanceStateMachineController.addContinuationEvent(Events.TO__2000_DECIDE_ACTION_POSTIF, "END_OF_ABEND_ROUTINE");
		instanceStateMachineController.sendEvent(Events.TO_ABEND_ROUTINE);

	}
	/**
	 * State process operation _0000MainPost2000decideactionThru2000decideactionexit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000MainPost2000decideactionThru2000decideactionexit(CoactupcContext ctx, ExecutionController ctrl) {
		instanceCoactupcProcess._3000SendMap(ctx, ctrl);
		instanceCoactupcProcess.commonReturn(ctx, ctrl);

	}
	/**
	 * State process operation _2000DecideActionPost9600writeprocessingThru9600writeprocessingexit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideActionPost9600writeprocessingThru9600writeprocessingexit(CoactupcContext ctx, ExecutionController ctrl) {
		if (ctx.getWsMiscStorage().isCouldNotLockAcctForUpdate()) {
			ctx.getWsThisProgcommarea().setAcupChangesOkayedLockError(true);
		} else if (ctx.getWsMiscStorage().isLockedButUpdateFailed()) {
			ctx.getWsThisProgcommarea().setAcupChangesOkayedButFailed(true);
		} else if (ctx.getWsMiscStorage().isDataWasChangedBeforeUpdate()) {
			ctx.getWsThisProgcommarea().setAcupShowDetails(true);
		} else {
			ctx.getWsThisProgcommarea().setAcupChangesOkayedAndDone(true);
		}
		
		/* 
		****************************************************************
		DETAILS EDITED , FOUND OK, CONFIRM SAVE REQUESTED
		CONFIRMATION NOT GIVEN. SO SHOW DETAILS AGAIN
		**************************************************************** */
		instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION_POSTIF);

	}
	/**
	 * State process operation _9600WriteProcessingPost9700checkchangeinrecThru9700checkchangeinrecexit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9600WriteProcessingPost9700checkchangeinrecThru9700checkchangeinrecexit(CoactupcContext ctx, ExecutionController ctrl) {
		if (ctx.getWsMiscStorage().isDataWasChangedBeforeUpdate()) {
			instanceStateMachineController.sendEvent(Events.TO__9600_WRITE_PROCESSING_EXIT);
			return;
		} else {
			
			/* 
			****************************************************************
			Prepare the update
			**************************************************************** */
			ctx.getWsMiscStorage().getAcctUpdateRecordReference().getField().initialize();
			
			/* 
			****************************************************************
			Account Master data
			**************************************************************** */
			ctx.getWsMiscStorage().setAcctUpdateId(ctx.getWsThisProgcommarea().getAcupNewAcctId());
			
			/* 
			Active Status */
			ctx.getWsMiscStorage().getAcctUpdateActiveStatusReference().setValue(ctx.getWsThisProgcommarea().getAcupNewActiveStatusReference());
			
			/* 
			Current Balance */
			ctx.getWsMiscStorage().setAcctUpdateCurrBal(ctx.getWsThisProgcommarea().getAcupNewCurrBalN());
			
			/* 
			Credit Limit */
			ctx.getWsMiscStorage().setAcctUpdateCreditLimit(ctx.getWsThisProgcommarea().getAcupNewCreditLimitN());
			
			/* 
			Cash Limit */
			ctx.getWsMiscStorage().setAcctUpdateCashCreditLimit(ctx.getWsThisProgcommarea().getAcupNewCashCreditLimitN());
			
			/* 
			Current Cycle Credit */
			ctx.getWsMiscStorage().setAcctUpdateCurrCycCredit(ctx.getWsThisProgcommarea().getAcupNewCurrCycCreditN());
			
			/* 
			Current Cycle Debit */
			ctx.getWsMiscStorage().setAcctUpdateCurrCycDebit(ctx.getWsThisProgcommarea().getAcupNewCurrCycDebitN());
			
			/* 
			Open date */
			StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getAcctUpdateOpenDateReference())
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewOpenYearReference().getBytes())
				.addDelimitedBySize("-")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewOpenMonReference().getBytes())
				.addDelimitedBySize("-")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewOpenDayReference().getBytes())
				.end();
			
			/* 
			Expiry date */
			StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getAcctUpdateExpiraionDateReference())
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewExpYearReference().getBytes())
				.addDelimitedBySize("-")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewExpMonReference().getBytes())
				.addDelimitedBySize("-")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewExpDayReference().getBytes())
				.end();
			
			/* 
			Reissue date */
			ctx.getWsMiscStorage().setAcctUpdateReissueDate(BluageUtils.unsupported());
			StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getAcctUpdateReissueDateReference())
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewReissueYearReference().getBytes())
				.addDelimitedBySize("-")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewReissueMonReference().getBytes())
				.addDelimitedBySize("-")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewReissueDayReference().getBytes())
				.end();
			
			/* 
			Account Group */
			ctx.getWsMiscStorage().getAcctUpdateGroupIdReference().setValue(ctx.getWsThisProgcommarea().getAcupNewGroupIdReference());
			
			/* 
			****************************************************************
			Customer data
			**************************************************************** */
			ctx.getWsMiscStorage().getCustUpdateRecordReference().getField().initialize();
			ctx.getWsMiscStorage().setCustUpdateId(ctx.getWsThisProgcommarea().getAcupNewCustId());
			ctx.getWsMiscStorage().getCustUpdateFirstNameReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustFirstNameReference());
			ctx.getWsMiscStorage().getCustUpdateMiddleNameReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustMiddleNameReference());
			ctx.getWsMiscStorage().getCustUpdateLastNameReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustLastNameReference());
			ctx.getWsMiscStorage().getCustUpdateAddrLine1Reference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustAddrLine1Reference());
			ctx.getWsMiscStorage().getCustUpdateAddrLine2Reference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustAddrLine2Reference());
			ctx.getWsMiscStorage().getCustUpdateAddrLine3Reference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustAddrLine3Reference());
			ctx.getWsMiscStorage().getCustUpdateAddrStateCdReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustAddrStateCdReference());
			ctx.getWsMiscStorage().getCustUpdateAddrCountryCdReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustAddrCountryCdReference());
			ctx.getWsMiscStorage().getCustUpdateAddrZipReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustAddrZipReference());
			StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getCustUpdatePhoneNum1Reference())
				.addDelimitedBySize("(")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum1aReference().getBytes())
				.addDelimitedBySize(")")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum1bReference().getBytes())
				.addDelimitedBySize("-")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum1cReference().getBytes())
				.end();
			StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getCustUpdatePhoneNum2Reference())
				.addDelimitedBySize("(")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum2aReference().getBytes())
				.addDelimitedBySize(")")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum2bReference().getBytes())
				.addDelimitedBySize("-")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum2cReference().getBytes())
				.end();
			ctx.getWsMiscStorage().setCustUpdateSsn(ctx.getWsThisProgcommarea().getAcupNewCustSsn());
			ctx.getWsMiscStorage().getCustUpdateGovtIssuedIdReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustGovtIssuedIdReference());
			StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getCustUpdateDobYyyyMmDdReference())
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewCustDobYearReference().getBytes())
				.addDelimitedBySize("-")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewCustDobMonReference().getBytes())
				.addDelimitedBySize("-")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewCustDobDayReference().getBytes())
				.end();
			ctx.getWsMiscStorage().getCustUpdateEftAccountIdReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustEftAccountIdReference());
			ctx.getWsMiscStorage().getCustUpdatePriCardIndReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustPriHolderIndReference());
			ctx.getWsMiscStorage().setCustUpdateFicoCreditScore(ctx.getWsThisProgcommarea().getAcupNewCustFicoScore());
			
			/* 
			****************************************************************
			Update account *
			**************************************************************** */
			JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitAcctfilenameReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
			.rewrite()
			.from(ctx.getWsMiscStorage().getAcctUpdateRecordReference())
			.length(ctx.getWsMiscStorage().getAcctUpdateRecordReference().getSize())
			.execute();
			
			/* 
			WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
			ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
			
			/* 
			WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
			ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
			
			/* 
			****************************************************************
			Did account update succeed ?  *
			**************************************************************** */
			if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
				
				/* 
				****************************************************************
				Update customer *
				****************************************************************
				Do nothing */
				JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitCustfilenameReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
				.rewrite()
				.from(ctx.getWsMiscStorage().getCustUpdateRecordReference())
				.length(ctx.getWsMiscStorage().getCustUpdateRecordReference().getSize())
				.execute();
				
				/* 
				WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
				ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
				
				/* 
				WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
				ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
				
				/* 
				****************************************************************
				Did customer update succeed ? *
				**************************************************************** */
				if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
					
					/* 
					Do nothing */
					instanceStateMachineController.sendEvent(Events.TO__9600_WRITE_PROCESSING_EXIT);
				} else {
					ctx.getWsMiscStorage().setLockedButUpdateFailed(true);
					JicsSyncpointBuilder.newInstance(ctx.getJicsEiblk(), ctx)
					.rollback()
					.execute()
					.handleException();
					instanceStateMachineController.sendEvent(Events.TO__9600_WRITE_PROCESSING_EXIT);
					return;
				}
			} else {
				ctx.getWsMiscStorage().setLockedButUpdateFailed(true);
				instanceStateMachineController.sendEvent(Events.TO__9600_WRITE_PROCESSING_EXIT);
				return;
			}
		}

	}
}
