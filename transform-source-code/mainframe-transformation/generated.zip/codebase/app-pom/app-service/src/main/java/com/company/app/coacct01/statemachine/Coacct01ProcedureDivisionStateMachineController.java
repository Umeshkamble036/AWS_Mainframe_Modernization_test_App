package com.company.app.coacct01.statemachine;

import com.company.app.coacct01.business.context.Coacct01Context;
import com.company.app.coacct01.statemachine.Coacct01ProcedureDivisionStateMachineController.Events;
import com.company.app.coacct01.statemachine.Coacct01ProcedureDivisionStateMachineController.States;
import com.company.app.coacct01.statemachine.Coacct01ProcedureDivisionStateMachineService;
import com.github.oxo42.stateless4j.StateMachineConfig;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.context.RuntimeContext;
import com.netfective.bluage.gapwalk.rt.statemachine.MultipleActiveContinuationController;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Controller managing the state machine "Coacct01ProcedureDivisionStateMachine" execution.
 */
@Component("com.company.app.coacct01.statemachine.Coacct01ProcedureDivisionStateMachineController")
@Import({
com.company.app.coacct01.statemachine.Coacct01ProcedureDivisionStateMachineService.class
})
@Lazy
public class Coacct01ProcedureDivisionStateMachineController extends MultipleActiveContinuationController<States, Events> {
	
	/**
	 * State machine states.
	 */
	public enum States {
		_1000_CONTROL, _2300_OPEN_INPUT_QUEUE, _2400_OPEN_OUTPUT_QUEUE, _2100_OPEN_ERROR_QUEUE, _4000_MAIN_PROCESS, _3000_GET_REQUEST, _4000_PROCESS_REQUEST_REPLY, _4100_PUT_REPLY, _9000_ERROR, _8000_TERMINATION, _5000_CLOSE_INPUT_QUEUE, _5100_CLOSE_OUTPUT_QUEUE, _5200_CLOSE_ERROR_QUEUE, _1000_CONTROL_POSTIF, _1000_CONTROL_ELSEBRANCH, _1000_CONTROL_LOOP, _2300_OPEN_INPUT_QUEUE_POSTIF, _2300_OPEN_INPUT_QUEUE_CASEBRANCH, _2400_OPEN_OUTPUT_QUEUE_POSTIF, _2400_OPEN_OUTPUT_QUEUE_CASEBRANCH, _3000_GET_REQUEST_POSTIF, _3000_GET_REQUEST_THENBRANCH, _3000_GET_REQUEST_ELSEBRANCH, _3000_GET_REQUEST_ELSEBRANCH_1, _4000_PROCESS_REQUEST_REPLY_POSTIF, _4000_PROCESS_REQUEST_REPLY_THENBRANCH, _4000_PROCESS_REQUEST_REPLY_ELSEBRANCH, _4000_PROCESS_REQUEST_REPLY_CASEBRANCH, _4000_PROCESS_REQUEST_REPLY_CASEBRANCH_1, _4000_PROCESS_REQUEST_REPLY_CASEBRANCH_2, _4100_PUT_REPLY_POSTIF, _4100_PUT_REPLY_CASEBRANCH, _8000_TERMINATION_POSTIF, _8000_TERMINATION_THENBRANCH, _8000_TERMINATION_POSTIF_1, _8000_TERMINATION_THENBRANCH_1, _5200_CLOSE_ERROR_QUEUE_POSTIF, _5200_CLOSE_ERROR_QUEUE_CASEBRANCH, _1000_CONTROL_POST__2100OPENERRORQUEUE, _1000_CONTROL_POST__2300OPENINPUTQUEUE, _1000_CONTROL_POST__2400OPENOUTPUTQUEUE, _4000_MAIN_PROCESS_POST__3000GETREQUEST, _3000_GET_REQUEST_POST__4000PROCESSREQUESTREPLY, _8000_TERMINATION_POST__5200CLOSEERRORQUEUE, FINAL
	}

	/**
	 * State machine events.
	 */
	public enum Events {
		TO__1000_CONTROL, TO__2300_OPEN_INPUT_QUEUE, TO__2400_OPEN_OUTPUT_QUEUE, TO__2100_OPEN_ERROR_QUEUE, TO__4000_MAIN_PROCESS, TO__3000_GET_REQUEST, TO__4000_PROCESS_REQUEST_REPLY, TO__4100_PUT_REPLY, TO__9000_ERROR, TO__8000_TERMINATION, TO__5000_CLOSE_INPUT_QUEUE, TO__5100_CLOSE_OUTPUT_QUEUE, TO__5200_CLOSE_ERROR_QUEUE, TO__1000_CONTROL_POSTIF, TO__1000_CONTROL_ELSEBRANCH, TO__1000_CONTROL_LOOP, TO__2300_OPEN_INPUT_QUEUE_POSTIF, TO__2300_OPEN_INPUT_QUEUE_CASEBRANCH, TO__2400_OPEN_OUTPUT_QUEUE_POSTIF, TO__2400_OPEN_OUTPUT_QUEUE_CASEBRANCH, TO__3000_GET_REQUEST_POSTIF, TO__3000_GET_REQUEST_THENBRANCH, TO__3000_GET_REQUEST_ELSEBRANCH, TO__3000_GET_REQUEST_ELSEBRANCH_1, TO__4000_PROCESS_REQUEST_REPLY_POSTIF, TO__4000_PROCESS_REQUEST_REPLY_THENBRANCH, TO__4000_PROCESS_REQUEST_REPLY_ELSEBRANCH, TO__4000_PROCESS_REQUEST_REPLY_CASEBRANCH, TO__4000_PROCESS_REQUEST_REPLY_CASEBRANCH_1, TO__4000_PROCESS_REQUEST_REPLY_CASEBRANCH_2, TO__4100_PUT_REPLY_POSTIF, TO__4100_PUT_REPLY_CASEBRANCH, TO__8000_TERMINATION_POSTIF, TO__8000_TERMINATION_THENBRANCH, TO__8000_TERMINATION_POSTIF_1, TO__8000_TERMINATION_THENBRANCH_1, TO__5200_CLOSE_ERROR_QUEUE_POSTIF, TO__5200_CLOSE_ERROR_QUEUE_CASEBRANCH, TO__1000_CONTROL_POST__2100OPENERRORQUEUE, TO__1000_CONTROL_POST__2300OPENINPUTQUEUE, TO__1000_CONTROL_POST__2400OPENOUTPUTQUEUE, TO__4000_MAIN_PROCESS_POST__3000GETREQUEST, TO__3000_GET_REQUEST_POST__4000PROCESSREQUESTREPLY, TO__8000_TERMINATION_POST__5200CLOSEERRORQUEUE, TO_FINAL
	}

	/**
	 * State machine state process service provider.
	 */
	@Autowired
	@Lazy
	private Coacct01ProcedureDivisionStateMachineService stateProcess;
	
	/**
	 * State machine controller initialization.
	 */
	@PostConstruct
	private void init(){
		initStateMachineController();
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine() throws Exception {
		throw new UnsupportedOperationException("Please use the two arguments configureStateMachine method instead: configureStateMachine(RuntimeContext ctx, ExecutionController ctrl)");
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine(RuntimeContext ctx, ExecutionController ctrl) throws Exception {
		
		StateMachineConfig<States, Events> configurer = new StateMachineConfig<>();
		configureInitialEnd(States._1000_CONTROL,States.FINAL);
		Coacct01Context lctx = (Coacct01Context) ctx;
		configurer.configure(States._1000_CONTROL).onEntry(buildRunAction(() -> {stateProcess._1000Control(lctx, ctrl);}))
		.permit(Events.TO__2100_OPEN_ERROR_QUEUE, States._2100_OPEN_ERROR_QUEUE)
		;	
		configurer.configure(States._2300_OPEN_INPUT_QUEUE).onEntry(buildRunAction(() -> {stateProcess._2300OpenInputQueue(lctx, ctrl);}))
		.permit(Events.TO__2300_OPEN_INPUT_QUEUE_CASEBRANCH, States._2300_OPEN_INPUT_QUEUE_CASEBRANCH)
		.permit(Events.TO__2300_OPEN_INPUT_QUEUE_POSTIF, States._2300_OPEN_INPUT_QUEUE_POSTIF)
		;	
		configurer.configure(States._2400_OPEN_OUTPUT_QUEUE).onEntry(buildRunAction(() -> {stateProcess._2400OpenOutputQueue(lctx, ctrl);}))
		.permit(Events.TO__2400_OPEN_OUTPUT_QUEUE_CASEBRANCH, States._2400_OPEN_OUTPUT_QUEUE_CASEBRANCH)
		.permit(Events.TO__2400_OPEN_OUTPUT_QUEUE_POSTIF, States._2400_OPEN_OUTPUT_QUEUE_POSTIF)
		;	
		configurer.configure(States._2100_OPEN_ERROR_QUEUE).onEntry(buildRunAction(() -> {stateProcess._2100OpenErrorQueue(lctx, ctrl);}))
		.permit(Events.TO__8000_TERMINATION, States._8000_TERMINATION)
		.permit(Events.TO__1000_CONTROL_POST__2100OPENERRORQUEUE, States._1000_CONTROL_POST__2100OPENERRORQUEUE)
		;	
		configurer.configure(States._4000_MAIN_PROCESS).onEntry(buildRunAction(() -> {stateProcess._4000MainProcess(lctx, ctrl);}))
		.permit(Events.TO__3000_GET_REQUEST, States._3000_GET_REQUEST)
		;	
		configurer.configure(States._3000_GET_REQUEST).onEntry(buildRunAction(() -> {stateProcess._3000GetRequest(lctx, ctrl);}))
		.permit(Events.TO__3000_GET_REQUEST_THENBRANCH, States._3000_GET_REQUEST_THENBRANCH)
		.permit(Events.TO__3000_GET_REQUEST_ELSEBRANCH, States._3000_GET_REQUEST_ELSEBRANCH)
		;	
		configurer.configure(States._4000_PROCESS_REQUEST_REPLY).onEntry(buildRunAction(() -> {stateProcess._4000ProcessRequestReply(lctx, ctrl);}))
		.permit(Events.TO__4000_PROCESS_REQUEST_REPLY_THENBRANCH, States._4000_PROCESS_REQUEST_REPLY_THENBRANCH)
		.permit(Events.TO__4000_PROCESS_REQUEST_REPLY_ELSEBRANCH, States._4000_PROCESS_REQUEST_REPLY_ELSEBRANCH)
		;	
		configurer.configure(States._4100_PUT_REPLY).onEntry(buildRunAction(() -> {stateProcess._4100PutReply(lctx, ctrl);}))
		.permit(Events.TO__4100_PUT_REPLY_CASEBRANCH, States._4100_PUT_REPLY_CASEBRANCH)
		.permit(Events.TO__4100_PUT_REPLY_POSTIF, States._4100_PUT_REPLY_POSTIF)
		;	
		configurer.configure(States._9000_ERROR).onEntry(buildRunAction(() -> {stateProcess._9000Error(lctx, ctrl);}))
		.permit(Events.TO__8000_TERMINATION, States._8000_TERMINATION)
		;	
		configurer.configure(States._8000_TERMINATION).onEntry(buildRunAction(() -> {stateProcess._8000Termination(lctx, ctrl);}))
		.permit(Events.TO__8000_TERMINATION_THENBRANCH, States._8000_TERMINATION_THENBRANCH)
		.permit(Events.TO__8000_TERMINATION_POSTIF, States._8000_TERMINATION_POSTIF)
		;	
		configurer.configure(States._5000_CLOSE_INPUT_QUEUE).onEntry(buildRunAction(() -> {stateProcess._5000CloseInputQueue(lctx, ctrl);}))
		.permit(Events.TO__8000_TERMINATION, States._8000_TERMINATION)
		.permit(Events.TO__8000_TERMINATION_POSTIF, States._8000_TERMINATION_POSTIF)
		;	
		configurer.configure(States._5100_CLOSE_OUTPUT_QUEUE).onEntry(buildRunAction(() -> {stateProcess._5100CloseOutputQueue(lctx, ctrl);}))
		.permit(Events.TO__8000_TERMINATION, States._8000_TERMINATION)
		.permit(Events.TO__8000_TERMINATION_POSTIF_1, States._8000_TERMINATION_POSTIF_1)
		;	
		configurer.configure(States._5200_CLOSE_ERROR_QUEUE).onEntry(buildRunAction(() -> {stateProcess._5200CloseErrorQueue(lctx, ctrl);}))
		.permit(Events.TO__5200_CLOSE_ERROR_QUEUE_CASEBRANCH, States._5200_CLOSE_ERROR_QUEUE_CASEBRANCH)
		.permit(Events.TO__5200_CLOSE_ERROR_QUEUE_POSTIF, States._5200_CLOSE_ERROR_QUEUE_POSTIF)
		;	
		configurer.configure(States._1000_CONTROL_POSTIF).onEntry(buildRunAction(() -> {stateProcess._1000ControlPostif(lctx, ctrl);}))
		.permit(Events.TO__2300_OPEN_INPUT_QUEUE, States._2300_OPEN_INPUT_QUEUE)
		;	
		configurer.configure(States._1000_CONTROL_ELSEBRANCH).onEntry(buildRunAction(() -> {stateProcess._1000ControlElsebranch(lctx, ctrl);}))
		.permit(Events.TO__9000_ERROR, States._9000_ERROR)
		;	
		configurer.configure(States._1000_CONTROL_LOOP).onEntry(buildRunAction(() -> {stateProcess._1000ControlLoop(lctx, ctrl);}))
		.permit(Events.TO__8000_TERMINATION, States._8000_TERMINATION)
		.permit(Events.TO__4000_MAIN_PROCESS, States._4000_MAIN_PROCESS)
		;	
		configurer.configure(States._2300_OPEN_INPUT_QUEUE_POSTIF).onEntry(buildRunAction(() -> {stateProcess._2300OpenInputQueuePostif(lctx, ctrl);}))
		.permit(Events.TO__1000_CONTROL_POST__2300OPENINPUTQUEUE, States._1000_CONTROL_POST__2300OPENINPUTQUEUE)
		;	
		configurer.configure(States._2300_OPEN_INPUT_QUEUE_CASEBRANCH).onEntry(buildRunAction(() -> {stateProcess._2300OpenInputQueueCasebranch(lctx, ctrl);}))
		.permit(Events.TO__9000_ERROR, States._9000_ERROR)
		;	
		configurer.configure(States._2400_OPEN_OUTPUT_QUEUE_POSTIF).onEntry(buildRunAction(() -> {stateProcess._2400OpenOutputQueuePostif(lctx, ctrl);}))
		.permit(Events.TO__1000_CONTROL_POST__2400OPENOUTPUTQUEUE, States._1000_CONTROL_POST__2400OPENOUTPUTQUEUE)
		;	
		configurer.configure(States._2400_OPEN_OUTPUT_QUEUE_CASEBRANCH).onEntry(buildRunAction(() -> {stateProcess._2400OpenOutputQueueCasebranch(lctx, ctrl);}))
		.permit(Events.TO__9000_ERROR, States._9000_ERROR)
		;	
		configurer.configure(States._3000_GET_REQUEST_POSTIF).onEntry(buildRunAction(() -> {stateProcess._3000GetRequestPostif(lctx, ctrl);}))
		.permit(Events.TO__1000_CONTROL_LOOP, States._1000_CONTROL_LOOP)
		.permit(Events.TO__4000_MAIN_PROCESS_POST__3000GETREQUEST, States._4000_MAIN_PROCESS_POST__3000GETREQUEST)
		;	
		configurer.configure(States._3000_GET_REQUEST_THENBRANCH).onEntry(buildRunAction(() -> {stateProcess._3000GetRequestThenbranch(lctx, ctrl);}))
		.permit(Events.TO__4000_PROCESS_REQUEST_REPLY, States._4000_PROCESS_REQUEST_REPLY)
		;	
		configurer.configure(States._3000_GET_REQUEST_ELSEBRANCH).onEntry(buildRunAction(() -> {stateProcess._3000GetRequestElsebranch(lctx, ctrl);}))
		.permit(Events.TO__3000_GET_REQUEST_ELSEBRANCH_1, States._3000_GET_REQUEST_ELSEBRANCH_1)
		.permit(Events.TO__3000_GET_REQUEST_POSTIF, States._3000_GET_REQUEST_POSTIF)
		;	
		configurer.configure(States._3000_GET_REQUEST_ELSEBRANCH_1).onEntry(buildRunAction(() -> {stateProcess._3000GetRequestElsebranch1(lctx, ctrl);}))
		.permit(Events.TO__9000_ERROR, States._9000_ERROR)
		;	
		configurer.configure(States._4000_PROCESS_REQUEST_REPLY_POSTIF).onEntry(buildRunAction(() -> {stateProcess._4000ProcessRequestReplyPostif(lctx, ctrl);}))
		.permit(Events.TO__3000_GET_REQUEST_POST__4000PROCESSREQUESTREPLY, States._3000_GET_REQUEST_POST__4000PROCESSREQUESTREPLY)
		;	
		configurer.configure(States._4000_PROCESS_REQUEST_REPLY_THENBRANCH).onEntry(buildRunAction(() -> {stateProcess._4000ProcessRequestReplyThenbranch(lctx, ctrl);}))
		.permit(Events.TO__4000_PROCESS_REQUEST_REPLY_CASEBRANCH, States._4000_PROCESS_REQUEST_REPLY_CASEBRANCH)
		.permit(Events.TO__4000_PROCESS_REQUEST_REPLY_CASEBRANCH_1, States._4000_PROCESS_REQUEST_REPLY_CASEBRANCH_1)
		.permit(Events.TO__4000_PROCESS_REQUEST_REPLY_CASEBRANCH_2, States._4000_PROCESS_REQUEST_REPLY_CASEBRANCH_2)
		;	
		configurer.configure(States._4000_PROCESS_REQUEST_REPLY_ELSEBRANCH).onEntry(buildRunAction(() -> {stateProcess._4000ProcessRequestReplyElsebranch(lctx, ctrl);}))
		.permit(Events.TO__4100_PUT_REPLY, States._4100_PUT_REPLY)
		;	
		configurer.configure(States._4000_PROCESS_REQUEST_REPLY_CASEBRANCH).onEntry(buildRunAction(() -> {stateProcess._4000ProcessRequestReplyCasebranch(lctx, ctrl);}))
		.permit(Events.TO__4100_PUT_REPLY, States._4100_PUT_REPLY)
		;	
		configurer.configure(States._4000_PROCESS_REQUEST_REPLY_CASEBRANCH_1).onEntry(buildRunAction(() -> {stateProcess._4000ProcessRequestReplyCasebranch1(lctx, ctrl);}))
		.permit(Events.TO__4100_PUT_REPLY, States._4100_PUT_REPLY)
		;	
		configurer.configure(States._4000_PROCESS_REQUEST_REPLY_CASEBRANCH_2).onEntry(buildRunAction(() -> {stateProcess._4000ProcessRequestReplyCasebranch2(lctx, ctrl);}))
		.permit(Events.TO__9000_ERROR, States._9000_ERROR)
		;	
		configurer.configure(States._4100_PUT_REPLY_POSTIF).onEntry(buildRunAction(() -> {stateProcess._4100PutReplyPostif(lctx, ctrl);}))
		.permit(Events.TO__4000_PROCESS_REQUEST_REPLY_POSTIF, States._4000_PROCESS_REQUEST_REPLY_POSTIF)
		;	
		configurer.configure(States._4100_PUT_REPLY_CASEBRANCH).onEntry(buildRunAction(() -> {stateProcess._4100PutReplyCasebranch(lctx, ctrl);}))
		.permit(Events.TO__9000_ERROR, States._9000_ERROR)
		;	
		configurer.configure(States._8000_TERMINATION_POSTIF).onEntry(buildRunAction(() -> {stateProcess._8000TerminationPostif(lctx, ctrl);}))
		.permit(Events.TO__8000_TERMINATION_THENBRANCH_1, States._8000_TERMINATION_THENBRANCH_1)
		.permit(Events.TO__8000_TERMINATION_POSTIF_1, States._8000_TERMINATION_POSTIF_1)
		;	
		configurer.configure(States._8000_TERMINATION_THENBRANCH).onEntry(buildRunAction(() -> {stateProcess._8000TerminationThenbranch(lctx, ctrl);}))
		.permit(Events.TO__5000_CLOSE_INPUT_QUEUE, States._5000_CLOSE_INPUT_QUEUE)
		;	
		configurer.configure(States._8000_TERMINATION_POSTIF_1).onEntry(buildRunAction(() -> {stateProcess._8000TerminationPostif1(lctx, ctrl);}))
		.permit(Events.TO__5200_CLOSE_ERROR_QUEUE, States._5200_CLOSE_ERROR_QUEUE)
		;	
		configurer.configure(States._8000_TERMINATION_THENBRANCH_1).onEntry(buildRunAction(() -> {stateProcess._8000TerminationThenbranch1(lctx, ctrl);}))
		.permit(Events.TO__5100_CLOSE_OUTPUT_QUEUE, States._5100_CLOSE_OUTPUT_QUEUE)
		;	
		configurer.configure(States._5200_CLOSE_ERROR_QUEUE_POSTIF).onEntry(buildRunAction(() -> {stateProcess._5200CloseErrorQueuePostif(lctx, ctrl);}))
		.permit(Events.TO__8000_TERMINATION_POST__5200CLOSEERRORQUEUE, States._8000_TERMINATION_POST__5200CLOSEERRORQUEUE)
		;	
		configurer.configure(States._5200_CLOSE_ERROR_QUEUE_CASEBRANCH).onEntry(buildRunAction(() -> {stateProcess._5200CloseErrorQueueCasebranch(lctx, ctrl);}))
		.permit(Events.TO__9000_ERROR, States._9000_ERROR)
		;	
		configurer.configure(States._1000_CONTROL_POST__2100OPENERRORQUEUE).onEntry(buildRunAction(() -> {stateProcess._1000ControlPost2100openerrorqueue(lctx, ctrl);}))
		.permit(Events.TO__1000_CONTROL_ELSEBRANCH, States._1000_CONTROL_ELSEBRANCH)
		.permit(Events.TO__1000_CONTROL_POSTIF, States._1000_CONTROL_POSTIF)
		;	
		configurer.configure(States._1000_CONTROL_POST__2300OPENINPUTQUEUE).onEntry(buildRunAction(() -> {stateProcess._1000ControlPost2300openinputqueue(lctx, ctrl);}))
		.permit(Events.TO__2400_OPEN_OUTPUT_QUEUE, States._2400_OPEN_OUTPUT_QUEUE)
		;	
		configurer.configure(States._1000_CONTROL_POST__2400OPENOUTPUTQUEUE).onEntry(buildRunAction(() -> {stateProcess._1000ControlPost2400openoutputqueue(lctx, ctrl);}))
		.permit(Events.TO__3000_GET_REQUEST, States._3000_GET_REQUEST)
		;	
		configurer.configure(States._4000_MAIN_PROCESS_POST__3000GETREQUEST).onEntry(buildRunAction(() -> {stateProcess._4000MainProcessPost3000getrequest(lctx, ctrl);}))
		.permit(Events.TO__1000_CONTROL_LOOP, States._1000_CONTROL_LOOP)
		;	
		configurer.configure(States._3000_GET_REQUEST_POST__4000PROCESSREQUESTREPLY).onEntry(buildRunAction(() -> {stateProcess._3000GetRequestPost4000processrequestreply(lctx, ctrl);}))
		.permit(Events.TO__3000_GET_REQUEST_POSTIF, States._3000_GET_REQUEST_POSTIF)
		;	
		configurer.configure(States._8000_TERMINATION_POST__5200CLOSEERRORQUEUE).onEntry(buildRunAction(() -> {stateProcess._8000TerminationPost5200closeerrorqueue(lctx, ctrl);}))
		;	
		return configurer;
	}
	
}
