
package com.company.app.cocrdupc.statemachine;

import com.company.app.cocrdupc.business.context.CocrdupcContext;
import com.company.app.cocrdupc.service.CocrdupcProcess;
import com.company.app.cocrdupc.statemachine.CocrdupcProcedureDivisionStateMachineController.Events;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.control.HandleAbendBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.jics.internal.JicsSyncpointBuilder;
import com.netfective.bluage.gapwalk.rt.jics.io.JicsIsolationLevel;
import com.netfective.bluage.gapwalk.rt.jics.io.internal.JicsFileBuilder;
import com.netfective.bluage.gapwalk.rt.statemachine.StateMachineControllerWithContinuation;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.statements.InspectBuilder;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Service class containing states process used to drive state machine "CocrdupcProcedureDivisionStateMachine".
 */
@Service("com.company.app.cocrdupc.statemachine.CocrdupcProcedureDivisionStateMachineService")
@Lazy
public class CocrdupcProcedureDivisionStateMachineService {
	
	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(CocrdupcProcedureDivisionStateMachineService.class);

	/**
	 * The associated state machine controller.
	 */
	@Autowired
	@Qualifier("com.company.app.cocrdupc.statemachine.CocrdupcProcedureDivisionStateMachineController")	
	private StateMachineControllerWithContinuation<Events> instanceStateMachineController;
	
	
	/**
	 * Service used by the state machine.
	 */
	@Autowired
	@Qualifier("com.company.app.cocrdupc.service.CocrdupcProcess")
	private CocrdupcProcess instanceCocrdupcProcess;
	
	
	

	/**
	 * State process operation _0000Main.
	 * 
	 * PROGRAM-ID.COCRDUPC.
	 *  DATE-WRITTEN.
	 *      April 2022.
	 *  DATE-COMPILED.
	 *      Today.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000Main(CocrdupcContext ctx, ExecutionController ctrl) {
		instanceStateMachineController.registerSignalHandler(Events.TO_ABEND_ROUTINE, ctx, "ABEND_1_VIRTUAL_SIGNAL");
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		****************************************************************
		Program:     COCRDUPC.CBL                                     *
		Layer:       Business logic                                   *
		Function:    Accept and process credit card detail request    *
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		COMMON COPYBOOKS
		Screen Titles
		Credit Card Update Screen Layout
		Current Date
		Common Messages
		Abend Variables
		Signed on user data
		Dataset layouts
		ACCOUNT RECORD LAYOUT
		COPY CVACT01Y.
		CARD RECORD LAYOUT
		CARD XREF LAYOUT
		COPY CVACT03Y.
		CUSTOMER LAYOUT */
		ctx.getSignalHandlersController().activateSignalHandler("ABEND_1_VIRTUAL_SIGNAL","!ABEND");
		HandleAbendBuilder.newInstance(ctx.getJicsEiblk(), ctx).execute().handleException();
		DataUtils.initialize(BluageUtils.unsupported());
		ctx.getWsMiscStorage().getField().initialize();
		DataUtils.initialize(ctx.getWsCommarea().getWsCommareaReference());
		
		/* 
		****************************************************************
		Store our context
		**************************************************************** */
		ctx.getWsMiscStorage().getWsTranidReference().setValue(ctx.getWsLiterals().getLitThistranidReference());
		
		/* 
		****************************************************************
		Ensure error message is cleared                               *
		**************************************************************** */
		ctx.getWsMiscStorage().setWsReturnMsgOff(true);
		
		/* 
		****************************************************************
		Store passed data if  any                *
		**************************************************************** */
		if (ctx.getDfheiblk().getEibcalen() == 0 || (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitMenupgmReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), BluageUtils.unsupported()) != 0)) {
			DataUtils.initialize(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().getField().initialize();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setCcupDetailsNotFetched(true);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			int idx = BluageUtils.unsupported().length() + 1 - 1;
			int len = ctx.getWsThisProgcommarea().getSize();
			ctx.getWsThisProgcommarea().setBytes(ctx.getDfhcommarea().getBytes(idx, len));
		}
		
		/* 
		FIXME:PERFORM YYYY-STORE-PFKEY
		THRU YYYY-STORE-PFKEY-EXIT
		****************************************************************
		Remap PFkeys as needed.
		Store the Mapped PF Key
		**************************************************************** */
		BluageUtils.unsupported();
		
		/* 
		****************************************************************
		Check the AID to see if its valid at this point               *
		F3 - Exit
		Enter show screen again
		**************************************************************** */
		ctx.getWsMiscStorage().setPfkInvalid(true);
		if (BluageUtils.unsupported() || BluageUtils.unsupported() || (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isCcupChangesOkNotConfirmed()) || (BluageUtils.unsupported() && !(ctx.getWsThisProgcommarea().isCcupDetailsNotFetched()))) {
			ctx.getWsMiscStorage().setPfkValid(true);
		} 
		if (ctx.getWsMiscStorage().isPfkInvalid()) {
			
			/* 
			FIXME: CCARD-AID-ENTER */
			BluageUtils.unsupported();
		} 
		
		/* 
		****************************************************************
		Decide what to do based on inputs received
		**************************************************************** */
		if (BluageUtils.unsupported() || (ctx.getWsThisProgcommarea().isCcupChangesOkayedAndDone() && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitCclistmapsetReference()) == 0) || (ctx.getWsThisProgcommarea().isCcupChangesFailed() && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitCclistmapsetReference()) == 0)) {
			
			/* 
			FIXME: CCARD-AID-PFK03FIXME: CDEMO-LAST-MAPSETFIXME: CDEMO-LAST-MAPSET */
			
			/* 
			FIXME: CCARD-AID-PFK03
			****************************************************************
			USER PRESSES PF03 TO EXIT
			OR   USER IS DONE WITH UPDATE
			XCTL TO CALLING PROGRAM OR MAIN MENU
			**************************************************************** */
			BluageUtils.unsupported();
			if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-TO-TRANID */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: CDEMO-TO-TRANID */
				BluageUtils.unsupported();
			}
			if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-TO-PROGRAM */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: CDEMO-TO-PROGRAM */
				BluageUtils.unsupported();
			}
			
			/* 
			FIXME: CDEMO-FROM-TRANID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			if (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitCclistmapsetReference()) == 0) {
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-CARD-NUM */
				BluageUtils.unsupported();
			} 
			
			/* 
			FIXME: CDEMO-USRTYP-USER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAP */
			BluageUtils.unsupported();
			JicsSyncpointBuilder.newInstance(ctx.getJicsEiblk(), ctx)
			.commit()
			.execute()
			.handleException();
			XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
		} else if ((BluageUtils.unsupported() && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitCclistpgmReference()) == 0) || (BluageUtils.unsupported() && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitCclistpgmReference()) == 0)) {
			
			/* 
			FIXME: CDEMO-PGM-ENTERFIXME: CDEMO-FROM-PROGRAMFIXME: CCARD-AID-PFK12FIXME: CDEMO-FROM-PROGRAM */
			
			/* 
			FIXME: CDEMO-PGM-REENTER */
			BluageUtils.unsupported();
			ctx.getWsMiscStorage().setInputOk(true);
			ctx.getWsMiscStorage().setFlgAcctfilterIsvalid(true);
			ctx.getWsMiscStorage().setFlgCardfilterIsvalid(true);
			
			/* 
			FIXME: CC-ACCT-ID-N */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CC-CARD-NUM-N */
			BluageUtils.unsupported();
			instanceCocrdupcProcess._9000ReadData(ctx, ctrl);
			ctx.getWsThisProgcommarea().setCcupShowDetails(true);
			instanceCocrdupcProcess._3000SendMap(ctx, ctrl);
			instanceCocrdupcProcess.commonReturn(ctx, ctrl);
		} else if ((ctx.getWsThisProgcommarea().isCcupDetailsNotFetched() && BluageUtils.unsupported()) || (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitMenupgmReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), BluageUtils.unsupported()) != 0)) {
			
			/* 
			FIXME: CDEMO-PGM-ENTERFIXME: CDEMO-FROM-PROGRAMFIXME: CDEMO-FROM-PROGRAMFIXME: CDEMO-PGM-REENTER */
			ctx.getWsThisProgcommarea().getField().initialize();
			instanceCocrdupcProcess._3000SendMap(ctx, ctrl);
			
			/* 
			FIXME: CDEMO-PGM-REENTER */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setCcupDetailsNotFetched(true);
			instanceCocrdupcProcess.commonReturn(ctx, ctrl);
		} else if (ctx.getWsThisProgcommarea().isCcupChangesOkayedAndDone() || ctx.getWsThisProgcommarea().isCcupChangesFailed()) {
			ctx.getWsThisProgcommarea().getField().initialize();
			ctx.getWsMiscStorage().getField().initialize();
			DataUtils.initialize(BluageUtils.unsupported());
			DataUtils.initialize(BluageUtils.unsupported());
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			instanceCocrdupcProcess._3000SendMap(ctx, ctrl);
			
			/* 
			FIXME: CDEMO-PGM-REENTER */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setCcupDetailsNotFetched(true);
			instanceCocrdupcProcess.commonReturn(ctx, ctrl);
		} else {
			instanceStateMachineController.sendEvent(Events.TO__0000_MAIN_CASEBRANCH);
			return;
		}

	}
	/**
	 * State process operation _2000DecideAction.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideAction(CocrdupcContext ctx, ExecutionController ctrl) {
		if (ctx.getWsThisProgcommarea().isCcupDetailsNotFetched() || BluageUtils.unsupported()) {
			
			/* 
			FIXME: CCARD-AID-PFK12 */
			
			/* 
			****************************************************************
			NO DETAILS SHOWN.
			SO GET THEM AND SETUP DETAIL EDIT SCREEN
			**************************************************************** */
			if (ctx.getWsMiscStorage().isFlgAcctfilterIsvalid() && ctx.getWsMiscStorage().isFlgCardfilterIsvalid()) {
				instanceCocrdupcProcess._9000ReadData(ctx, ctrl);
				if (ctx.getWsMiscStorage().isFoundCardsForAccount()) {
					ctx.getWsThisProgcommarea().setCcupShowDetails(true);
				} 
			} 
			
			/* 
			****************************************************************
			DETAILS SHOWN
			CHECK CHANGES AND ASK CONFIRMATION IF GOOD
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isCcupShowDetails()) {
			if (ctx.getWsMiscStorage().isInputError() || ctx.getWsMiscStorage().isNoChangesDetected()) {
				
				/* 
				Do nothing */
			} else {
				ctx.getWsThisProgcommarea().setCcupChangesOkNotConfirmed(true);
			}
			
			/* 
			****************************************************************
			DETAILS SHOWN
			BUT INPUT EDIT ERRORS FOUND
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isCcupChangesNotOk()) {
			
			/* 
			Do nothing
			****************************************************************
			DETAILS EDITED , FOUND OK, CONFIRM SAVE REQUESTED
			CONFIRMATION GIVEN.SO SAVE THE CHANGES
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isCcupChangesOkNotConfirmed() && BluageUtils.unsupported()) {
			
			/* 
			FIXME: CCARD-AID-PFK05 */
			instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION_CASEBRANCH);
			return;
		} else if (ctx.getWsThisProgcommarea().isCcupChangesOkNotConfirmed()) {
			
			/* 
			Do nothing
			****************************************************************
			SHOW CONFIRMATION. GO BACK TO SQUARE 1
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isCcupChangesOkayedAndDone()) {
			ctx.getWsThisProgcommarea().setCcupShowDetails(true);
			if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-CARD-NUM */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-ACCT-STATUS */
				BluageUtils.unsupported();
			} 
		} else {
			instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION_CASEBRANCH_1);
			return;
		}
		instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION_POSTIF);

	}
	/**
	 * State process operation _9200WriteProcessing.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9200WriteProcessing(CocrdupcContext ctx, ExecutionController ctrl) {
		
		/* 
		Read the Card file
		MOVE CC-ACCT-ID-N            TO WS-CARD-RID-ACCT-ID */
		ctx.getWsMiscStorage().setWsCardRidCardnum(BluageUtils.unsupported());
		JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitCardfilenameReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.setIsolationLevel(JicsIsolationLevel.UPDATE)
		.updateNoToken()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidCardnumReference())
		.keyLength(ctx.getWsMiscStorage().getWsCardRidCardnumReference().getRecord().getSize(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		
		/* 
		****************************************************************
		Could we lock the record ?
		**************************************************************** */
		if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			****************************************************************
			Did someone change the record while we were out ?
			****************************************************************
			Do nothing */
			instanceStateMachineController.addContinuationEvent(Events.TO__9200_WRITE_PROCESSING_POST__9300CHECKCHANGEINREC_THRU__9300CHECKCHANGEINRECEXIT, "END_OF__9300_CHECK_CHANGE_IN_REC_EXIT");
			instanceStateMachineController.sendEvent(Events.TO__9300_CHECK_CHANGE_IN_REC);
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setCouldNotLockForUpdate(true);
			} 
			instanceStateMachineController.sendEvent(Events.TO__9200_WRITE_PROCESSING_EXIT);
			return;
		}

	}
	/**
	 * State process operation _9200WriteProcessingExit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9200WriteProcessingExit(CocrdupcContext ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__9200_WRITE_PROCESSING_EXIT");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation _9300CheckChangeInRec.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9300CheckChangeInRec(CocrdupcContext ctx, ExecutionController ctrl) {
		InspectBuilder.newInstance(BluageUtils.unsupported(), ctx.getConfiguration())
			.convert(ctx.getWsLiterals().getLitLowerReference())
			.to(ctx.getWsLiterals().getLitUpperReference())
			.apply();
		if (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getCcupOldCvvCdReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getCcupOldCrdnameReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getCcupOldExpyearReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getCcupOldExpmonReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getCcupOldExpdayReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsThisProgcommarea().getCcupOldCrdstcdReference()) == 0) {
			
			/* 
			Do nothing */
			instanceStateMachineController.sendEvent(Events.TO__9300_CHECK_CHANGE_IN_REC_EXIT);
		} else {
			ctx.getWsMiscStorage().setDataWasChangedBeforeUpdate(true);
			ctx.getWsThisProgcommarea().setCcupOldCvvCd(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().setCcupOldCrdname(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().setCcupOldExpyear(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().setCcupOldExpmon(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().setCcupOldExpday(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().setCcupOldCrdstcd(BluageUtils.unsupported());
			instanceStateMachineController.sendEvent(Events.TO__9200_WRITE_PROCESSING_EXIT);
			return;
		}

	}
	/**
	 * State process operation _9300CheckChangeInRecExit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9300CheckChangeInRecExit(CocrdupcContext ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__9300_CHECK_CHANGE_IN_REC_EXIT");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation abendRoutine.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void abendRoutine(CocrdupcContext ctx, ExecutionController ctrl) {
				boolean res = false; 
		instanceCocrdupcProcess.abendRoutine(ctx, ctrl);
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF_ABEND_ROUTINE");
		if (res) {
			return;
		} else {
			instanceStateMachineController.sendEvent(Events.TO_FINAL);
		}

	}
	/**
	 * State process operation _0000MainCasebranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000MainCasebranch(CocrdupcContext ctx, ExecutionController ctrl) {
		instanceCocrdupcProcess._1000ProcessInputs(ctx, ctrl);
		instanceStateMachineController.addContinuationEvent(Events.TO__0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT, "END_OF__2000_DECIDE_ACTION_POSTIF");
		instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION);

	}
	/**
	 * State process operation _2000DecideActionPostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideActionPostif(CocrdupcContext ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__2000_DECIDE_ACTION_POSTIF");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation _2000DecideActionCasebranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideActionCasebranch(CocrdupcContext ctx, ExecutionController ctrl) {
		instanceStateMachineController.addContinuationEvent(Events.TO__2000_DECIDE_ACTION_POST__9200WRITEPROCESSING_THRU__9200WRITEPROCESSINGEXIT, "END_OF__9200_WRITE_PROCESSING_EXIT");
		instanceStateMachineController.sendEvent(Events.TO__9200_WRITE_PROCESSING);

	}
	/**
	 * State process operation _2000DecideActionCasebranch1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideActionCasebranch1(CocrdupcContext ctx, ExecutionController ctrl) {
		
		/* 
		FIXME: ABEND-CULPRIT */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ABEND-CODE */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ABEND-REASON */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ABEND-MSG */
		BluageUtils.unsupported();
		instanceStateMachineController.addContinuationEvent(Events.TO__2000_DECIDE_ACTION_POSTIF, "END_OF_ABEND_ROUTINE");
		instanceStateMachineController.sendEvent(Events.TO_ABEND_ROUTINE);

	}
	/**
	 * State process operation _0000MainPost2000decideactionThru2000decideactionexit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000MainPost2000decideactionThru2000decideactionexit(CocrdupcContext ctx, ExecutionController ctrl) {
		instanceCocrdupcProcess._3000SendMap(ctx, ctrl);
		instanceCocrdupcProcess.commonReturn(ctx, ctrl);

	}
	/**
	 * State process operation _2000DecideActionPost9200writeprocessingThru9200writeprocessingexit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideActionPost9200writeprocessingThru9200writeprocessingexit(CocrdupcContext ctx, ExecutionController ctrl) {
		if (ctx.getWsMiscStorage().isCouldNotLockForUpdate()) {
			ctx.getWsThisProgcommarea().setCcupChangesOkayedLockError(true);
		} else if (ctx.getWsMiscStorage().isLockedButUpdateFailed()) {
			ctx.getWsThisProgcommarea().setCcupChangesOkayedButFailed(true);
		} else if (ctx.getWsMiscStorage().isDataWasChangedBeforeUpdate()) {
			ctx.getWsThisProgcommarea().setCcupShowDetails(true);
		} else {
			ctx.getWsThisProgcommarea().setCcupChangesOkayedAndDone(true);
		}
		
		/* 
		****************************************************************
		DETAILS EDITED , FOUND OK, CONFIRM SAVE REQUESTED
		CONFIRMATION NOT GIVEN. SO SHOW DETAILS AGAIN
		**************************************************************** */
		instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION_POSTIF);

	}
	/**
	 * State process operation _9200WriteProcessingPost9300checkchangeinrecThru9300checkchangeinrecexit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9200WriteProcessingPost9300checkchangeinrecThru9300checkchangeinrecexit(CocrdupcContext ctx, ExecutionController ctrl) {
		if (ctx.getWsMiscStorage().isDataWasChangedBeforeUpdate()) {
			instanceStateMachineController.sendEvent(Events.TO__9200_WRITE_PROCESSING_EXIT);
			return;
		} else {
			
			/* 
			****************************************************************
			Prepare the update
			**************************************************************** */
			ctx.getWsThisProgcommarea().getCardUpdateRecordReference().getField().initialize();
			ctx.getWsThisProgcommarea().getCardUpdateNumReference().setValue(ctx.getWsThisProgcommarea().getCcupNewCardidReference());
			ctx.getWsThisProgcommarea().setCardUpdateAcctId(BluageUtils.unsupported());
			ctx.getWsMiscStorage().getCardCvvCdXReference().setValue(ctx.getWsThisProgcommarea().getCcupNewCvvCdReference());
			ctx.getWsThisProgcommarea().setCardUpdateCvvCd(ctx.getWsMiscStorage().getCardCvvCdN());
			ctx.getWsThisProgcommarea().getCardUpdateEmbossedNameReference().setValue(ctx.getWsThisProgcommarea().getCcupNewCrdnameReference());
			StringConcatenationBuilder.newInstance(ctx.getWsThisProgcommarea().getCardUpdateExpiraionDateReference())
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getCcupNewExpyearReference().getBytes())
				.addDelimitedBySize("-")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getCcupNewExpmonReference().getBytes())
				.addDelimitedBySize("-")
				.addDelimitedBySize(ctx.getWsThisProgcommarea().getCcupNewExpdayReference().getBytes())
				.end();
			ctx.getWsThisProgcommarea().getCardUpdateActiveStatusReference().setValue(ctx.getWsThisProgcommarea().getCcupNewCrdstcdReference());
			JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitCardfilenameReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
			.rewrite()
			.from(ctx.getWsThisProgcommarea().getCardUpdateRecordReference())
			.length(ctx.getWsThisProgcommarea().getCardUpdateRecordReference().getSize())
			.execute();
			
			/* 
			WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
			ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
			
			/* 
			WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
			ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
			
			/* 
			****************************************************************
			Did the update succeed ?  *
			**************************************************************** */
			if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
				
				/* 
				Do nothing */
			} else {
				ctx.getWsMiscStorage().setLockedButUpdateFailed(true);
			}
			instanceStateMachineController.sendEvent(Events.TO__9200_WRITE_PROCESSING_EXIT);
		}

	}
}
