// 'MAPNAME'='null'
// 'HLQ'='null'
// 'SRCCODE'='&HLQ..CARDDEMO.BMS'
// 'LOADLIB'='&HLQ..CARDDEMO.LOADLIB'
// 'CPYBKS'='&HLQ..CARDDEMO.CPY'
// 'CICSMAC'='OEM.CICSTS.V05R06M0.CICS.SDFHMAC'
// 'LISTING'='&HLQ..CARDDEMO.LST'
// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
binding.setVariable("fcmap", fcmap)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//********************************************************************
//  THIS PROC IS USED TO COMPILE BMS MAPS
//********************************************************************
// Copyright Amazon.com, Inc. or its affiliates.                   
// All Rights Reserved.                                            
//                                                                 
// Licensed under the Apache License, Version 2.0 (the "License"). 
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at                         
//                                                                 
//    http://www.apache.org/licenses/LICENSE-2.0                   
//                                                                 
// Unless required by applicable law or agreed to in writing,      
// software distributed under the License is distributed on an     
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,    
// either express or implied. See the License for the specific     
// language governing permissions and limitations under the License
//********************************************************************
//***  Sample BMS Compile PROC                                  ****** 
//***  Check with your Administrator for                        ****** 
//***  JCL suitable to your environment                         ******
//********************************************************************
//*********************************************************************
//*                             PROC                                  *
//*********************************************************************
shell.with {
	def procName = "BUILDBMS"
	mpr.setJobContext(jobContext)
	def jobName = "" + jobContext.getJobName() + "-" + procName
	displayStartProc(procName)
	mpr.withSchenv(jobContext.getSchenv())
	def lastProgramResult
	//  ---------------------------                                        
	// PROCEDURE TO COMPILE BMS MAP                                        
	//  ---------------------------                                        
	//      PRINT BMS MAP DATA                                             
	//  ---------------------------                                        
	//                                                                     
	lastProgramResult = stepPRINT(shell, params, programResults)
	//                                                                     
	//  ---------------------------                                        
	//         ASSEMBLE MAP                                                
	//  ---------------------------                                        
	//                                                                     
	lastProgramResult = stepMAP(shell, params, programResults)
	//                                                                     
	//  ---------------------------                                        
	//         LINK-EDIT STEP                                              
	//  ---------------------------                                        
	//                                                                     
	lastProgramResult = stepLKED(shell, params, programResults)
	//                                                                     
	//  ---------------------------                                        
	//        DSECT GENERATION                                             
	//  ---------------------------                                        
	//                                                                     
	lastProgramResult = stepDSECT(shell, params, programResults)
	//  *********************************                                  
	//      REPLICATE LISTING ON SYSOUT                                    
	//  *********************************                                  
	lastProgramResult = stepDISPLIST(shell, params, programResults)
	//                                                                     
	lastProgramResult = stepDELTEMP(shell, params, programResults)
	displayEndProc(procName)
	return programResults
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP PRINT - PGM - IEBGENER****************************************************
def stepPRINT(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("PRINT", "IEBGENER", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.bluesam("SYSUT2")
						.dataset("&&TEMPM")
						.normalTermination("PASS")
						.build()
						.dummy("SYSIN")
						.build()
						.getFileConfigurations(fcmap))
					.withParameters(params)
					.runProgram("IEBGENER")
				})
		}
	}
}
// STEP MAP - PGM - ASMA90********************************************************
def stepMAP(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("MAP", "ASMA90", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.concatenation("SYSLIB")
						.path("&CICSMAC")
						.disposition("SHR")
						.path("SYS1.MACLIB")
						.disposition("SHR")
						.path("CEE.SCEEMAC")
						.disposition("SHR")
						.build()
						.bluesam("SYSUT1")
						.dataset("&&SYSUT1")
						.build()
						.bluesam("SYSUT2")
						.dataset("&&SYSUT2")
						.build()
						.bluesam("SYSUT3")
						.dataset("&&SYSUT3")
						.build()
						.bluesam("SYSPUNCH")
						.dataset("&&MAP")
						.normalTermination("PASS")
						.build()
						.bluesam("SYSIN")
						.dataset("&&TEMPM")
						.disposition("OLD")
						.normalTermination("PASS")
						.build()
						.dummy("SYSLIN")
						.build()
						.getFileConfigurations(fcmap))
					.withArguments(getParm("SYSPARM(MAP),DECK,NOLOAD"))
					.withParameters(params)
					.runProgram("ASMA90")
				})
		}
	}
}
// STEP LKED - PGM - HEWL*********************************************************
def stepLKED(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("LKED", "HEWL", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.getFileConfigurations(fcmap))
					.withArguments(getParm("LIST,LET,XREF"))
					.withParameters(params)
					.runProgram("HEWL")
				})
		}
	}
}
// STEP DSECT - PGM - ASMA90******************************************************
def stepDSECT(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("DSECT", "ASMA90", programResults, {
				mpr
					.withArguments(getParm("SYSPARM(DSECT),DECK,NOLOAD"))
					.withParameters(params)
					.runProgram("ASMA90")
				})
		}
	}
}
// STEP DISPLIST - PGM - IEBGENER*************************************************
def stepDISPLIST(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("DISPLIST", "IEBGENER", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.getFileConfigurations(fcmap))
					.withParameters(params)
					.runProgram("IEBGENER")
				})
		}
	}
}
// STEP DELTEMP - PGM - IEFBR14***************************************************
def stepDELTEMP(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("DELTEMP", "IEFBR14", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.bluesam("TEMPM")
						.dataset("&&TEMPM")
						.disposition("OLD")
						.normalTermination("DELETE")
						.build()
						.getFileConfigurations(fcmap))
					.withParameters(params)
					.runProgram("IEFBR14")
				})
		}
	}
}
