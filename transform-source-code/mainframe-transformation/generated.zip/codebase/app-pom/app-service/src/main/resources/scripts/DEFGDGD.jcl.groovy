// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "DEFGDGD"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//  RESTART=STEP30                                                     
	//*****************************************************************
	// Copyright Amazon.com, Inc. or its affiliates.
	// All Rights Reserved.
	//
	// Licensed under the Apache License, Version 2.0 (the "License").
	// You may not use this file except in compliance with the License.
	// You may obtain a copy of the License at
	//
	//    http://www.apache.org/licenses/LICENSE-2.0
	//
	// Unless required by applicable law or agreed to in writing,
	// software distributed under the License is distributed on an
	// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	// either express or implied. See the License for the specific
	// language governing permissions and limitations under the License
	//*****************************************************************
	// This jcl will create GDGs and load first generation for
	// Transaction reference data
	// *******************************************************************
	//  Define GDG for Transaction Type
	// *******************************************************************
	lastProgramResult = stepSTEP10(shell, params, programResults)
	// *******************************************************************
	//  Create the first generation of GDG Transaction Type
	// *******************************************************************
	lastProgramResult = stepSTEP20(shell, params, programResults)
	// *******************************************************************
	//  Transaction Category type
	// *******************************************************************
	lastProgramResult = stepSTEP30(shell, params, programResults)
	// *******************************************************************
	//  Create the first generation of GDG Transaction Category Type
	// *******************************************************************
	lastProgramResult = stepSTEP40(shell, params, programResults)
	// *******************************************************************
	//  Disclosure Group
	// *******************************************************************
	lastProgramResult = stepSTEP50(shell, params, programResults)
	// *******************************************************************
	//  Create the first generation of GDG disclosure group
	// *******************************************************************
	lastProgramResult = stepSTEP60(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult") // End of job statement.
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult") // End of job statement.
	//
	// Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:23:04 CDT
	//
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP STEP10 - PGM - IDCAMS*****************************************************
def stepSTEP10(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP10", "IDCAMS", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSIN")
						.stream(
"""   DEFINE GENERATIONDATAGROUP -
   (NAME(AWS.M2.CARDDEMO.TRANTYPE.BKUP) -
    LIMIT(5) -
    SCRATCH -
   )""", getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IDCAMS")
				})
		}
	}
}
// STEP STEP20 - PGM - IEBGENER***************************************************
def stepSTEP20(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("STEP20", "IEBGENER", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.dummy("SYSIN")
							.build()
							.bluesam("SYSUT1")
							.dataset("AWS.M2.CARDDEMO.TRANTYPE.PS")
							.disposition("SHR")
							.build()
							.gdgSupport("SYSUT2")
							.name("AWS.M2.CARDDEMO.TRANTYPE.BKUP").ownerPath(".").relativeGeneration(1).storageProvider("filesystem").recordSize(60)
							.disposition("NEW")
							.normalTermination("CATLG")
							.build()
							.getFileConfigurations())
						.withParameters(params)
						.runProgram("IEBGENER")
					})
			}
		}
	}
}
// STEP STEP30 - PGM - IDCAMS*****************************************************
def stepSTEP30(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("STEP30", "IDCAMS", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.fileSystem("SYSIN")
							.stream(
"""   DEFINE GENERATIONDATAGROUP -
   (NAME(AWS.M2.CARDDEMO.TRANCATG.PS.BKUP) -
    LIMIT(5) -
    SCRATCH -
   )""", getEncoding())
							.build()
							.getFileConfigurations())
						.withParameters(params)
						.runProgram("IDCAMS")
					})
			}
		}
	}
}
// STEP STEP40 - PGM - IEBGENER***************************************************
def stepSTEP40(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("STEP40", "IEBGENER", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.dummy("SYSIN")
							.build()
							.bluesam("SYSUT1")
							.dataset("AWS.M2.CARDDEMO.TRANCATG.PS")
							.disposition("SHR")
							.build()
							.gdgSupport("SYSUT2")
							.name("AWS.M2.CARDDEMO.TRANCATG.PS.BKUP").ownerPath(".").relativeGeneration(1).storageProvider("filesystem").recordSize(60)
							.disposition("NEW")
							.normalTermination("CATLG")
							.build()
							.getFileConfigurations())
						.withParameters(params)
						.runProgram("IEBGENER")
					})
			}
		}
	}
}
// STEP STEP50 - PGM - IDCAMS*****************************************************
def stepSTEP50(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP50", "IDCAMS", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSIN")
						.stream(
"""   DEFINE GENERATIONDATAGROUP -
   (NAME(AWS.M2.CARDDEMO.DISCGRP.BKUP) -
    LIMIT(5) -
    SCRATCH -
   )""", getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IDCAMS")
				})
		}
	}
}
// STEP STEP60 - PGM - IEBGENER***************************************************
def stepSTEP60(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("STEP60", "IEBGENER", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.dummy("SYSIN")
							.build()
							.bluesam("SYSUT1")
							.dataset("AWS.M2.CARDDEMO.DISCGRP.PS")
							.disposition("SHR")
							.build()
							.gdgSupport("SYSUT2")
							.name("AWS.M2.CARDDEMO.DISCGRP.BKUP").ownerPath(".").relativeGeneration(1).storageProvider("filesystem").recordSize(50)
							.disposition("NEW")
							.normalTermination("CATLG")
							.build()
							.getFileConfigurations())
						.withParameters(params)
						.runProgram("IEBGENER")
					})
			}
		}
	}
}
