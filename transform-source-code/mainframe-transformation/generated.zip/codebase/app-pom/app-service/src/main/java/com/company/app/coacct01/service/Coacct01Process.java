package com.company.app.coacct01.service;

import com.company.app.coacct01.business.context.Coacct01Context;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface Coacct01Process.
 * 
 * Defines application services for Coacct01Process
 */
public interface Coacct01Process {

	/**
	 * Process operation coacct01.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void coacct01(final Coacct01Context ctx, final ExecutionController ctrl);

	/**
	 * Process operation _8000TerminationPostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8000TerminationPostif(final Coacct01Context ctx, final ExecutionController ctrl);

	/**
	 * Process operation _8000TerminationPostif1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8000TerminationPostif1(final Coacct01Context ctx, final ExecutionController ctrl);

}
