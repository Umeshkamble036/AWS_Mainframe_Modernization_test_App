
package com.company.app.cocrdlic.service.impl;

import com.company.app.cocrdlic.business.context.CocrdlicContext;
import com.company.app.cocrdlic.service.CocrdlicProcess;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.data.Record;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.NumberUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.bms.ReceiveMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendTextBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.jics.io.JicsKeyComparisonMode;
import com.netfective.bluage.gapwalk.rt.jics.io.internal.JicsFileBuilder;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.statements.InspectBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class CocrdlicProcessImpl
 * 
 * Defines application services for CocrdlicProcess
 * @see CocrdlicProcess
 */
@Service("com.company.app.cocrdlic.service.CocrdlicProcess")
@Lazy

public class CocrdlicProcessImpl implements CocrdlicProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(CocrdlicProcessImpl.class);


	/**
	 * Process operation _0000Main.
	 * 
	 * PROGRAM-ID.COCRDLIC.
	 *  DATE-WRITTEN.
	 *      April 2022.
	 *  DATE-COMPILED.
	 *      Today.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0000Main(final CocrdlicContext ctx, final ExecutionController ctrl) {
		_0000Main1(ctx, ctrl);
		
		/* 
		FIXME: CDEMO-FROM-TRANID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-FROM-PROGRAM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-LAST-MAPSET */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-LAST-MAP */
		BluageUtils.unsupported();
		ctx.getWsCommarea().setWsCommarea(BluageUtils.unsupported());
		int idx = BluageUtils.unsupported().length() + 1 - 1;
		int len = ctx.getWsThisProgcommarea().getSize();
		ctx.getWsCommarea().getWsCommareaReference().setBytes(ctx.getWsThisProgcommarea().getBytes(), idx, len);
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsConstants().getLitThistranid())
		.withCommarea(ctx.getWsCommarea().getWsCommareaReference())
		.withLength(ctx.getWsCommarea().getWsCommareaReference().getRecord().getSize())
		.execute()
		.handleException();
	}

	/**
	 * Process operation _0000Main1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0000Main1(final CocrdlicContext ctx, final ExecutionController ctrl) {
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		****************************************************************
		Program:     COCRDLIC.CBL                                     *
		Layer:       Business logic                                   *
		Function:    List Credit Cards
		a) All cards if no context passed and admin user
		b) Only the ones associated with ACCT in COMMAREA
		if user is not admin
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		COMMON COPYBOOKS
		Screen Titles
		Credit Card Search Screen Layout
		COPY COCRDSL.
		Credit Card List Screen Layout
		Current Date
		Common Messages
		Abend Variables
		COPY CSMSG02Y.
		Signed on user data
		Dataset layouts
		CARD RECORD LAYOUT */
		DataUtils.initialize(BluageUtils.unsupported());
		ctx.getWsMiscStorage().getField().initialize();
		DataUtils.initialize(ctx.getWsCommarea().getWsCommareaReference());
		
		/* 
		****************************************************************
		Store our context
		**************************************************************** */
		ctx.getWsMiscStorage().getWsTranidReference().setValue(ctx.getWsConstants().getLitThistranidReference());
		
		/* 
		****************************************************************
		Ensure error message is cleared                               *
		**************************************************************** */
		ctx.getWsMiscStorage().setWsErrorMsgOff(true);
		
		/* 
		****************************************************************
		Retrived passed data if  any. Initialize them if first run.
		**************************************************************** */
		if (ctx.getDfheiblk().getEibcalen() == 0) {
			DataUtils.initialize(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().getField().initialize();
			
			/* 
			FIXME: CDEMO-FROM-TRANID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-USRTYP-USER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAP */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAPSET */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setCaFirstPage(true);
			ctx.getWsThisProgcommarea().setCaLastPageNotShown(true);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			int idx = BluageUtils.unsupported().length() + 1 - 1;
			int len = ctx.getWsThisProgcommarea().getSize();
			ctx.getWsThisProgcommarea().setBytes(ctx.getDfhcommarea().getBytes(idx, len));
		}
		
		/* 
		****************************************************************
		If coming in from menu. Lets forget the past and start afresh *
		**************************************************************** */
		if (BluageUtils.unsupported() && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsConstants().getLitThispgmReference()) != 0) {
			ctx.getWsThisProgcommarea().getField().initialize();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAP */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setCaFirstPage(true);
			ctx.getWsThisProgcommarea().setCaLastPageNotShown(true);
		} 
		
		/* 
		FIXME:PERFORM YYYY-STORE-PFKEY
		THRU YYYY-STORE-PFKEY-EXIT
		****************************************************************
		Remap PFkeys as needed.
		Store the Mapped PF Key
		**************************************************************** */
		BluageUtils.unsupported();
		
		/* 
		****************************************************************
		If something is present in commarea
		and the from program is this program itself,
		read and edit the inputs given
		**************************************************************** */
		if (ctx.getDfheiblk().getEibcalen() > 0 && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsConstants().getLitThispgmReference()) == 0) {
			_2000ReceiveMap(ctx, ctrl);
		} 
		
		/* 
		****************************************************************
		Check the mapped key  to see if its valid at this point       *
		F3    - Exit
		Enter - List of cards for current start key
		F8    - Page down
		F7    - Page up
		**************************************************************** */
		ctx.getWsMiscStorage().setPfkInvalid(true);
		if (BluageUtils.unsupported() || BluageUtils.unsupported() || BluageUtils.unsupported() || BluageUtils.unsupported()) {
			ctx.getWsMiscStorage().setPfkValid(true);
		} 
		if (ctx.getWsMiscStorage().isPfkInvalid()) {
			
			/* 
			FIXME: CCARD-AID-ENTER */
			BluageUtils.unsupported();
		} 
		
		/* 
		****************************************************************
		If the user pressed PF3 go back to main menu
		**************************************************************** */
		if (BluageUtils.unsupported() && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsConstants().getLitThispgmReference()) == 0) {
			
			/* 
			FIXME: CDEMO-FROM-TRANID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-USRTYP-USER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAP */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-MAP */
			BluageUtils.unsupported();
			ctx.getWsMiscStorage().setWsExitMessage(true);
			
			/* 
			FIXME: CDEMO-PGM-ENTER
			CALL MENU PROGRAM */
			BluageUtils.unsupported();
			XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(ctx.getWsConstants().getLitMenupgmReference()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
		} 
		
		/* 
		FIXME: CCARD-AID-PFK08
		****************************************************************
		If the user did not press PF8, lets reset the last page flag
		**************************************************************** */
		if (BluageUtils.unsupported()) {
			
			/* 
			Do nothing */
		} else {
			ctx.getWsThisProgcommarea().setCaLastPageNotShown(true);
		}
		
		/* 
		****************************************************************
		Now we decide what to do
		**************************************************************** */
		if (ctx.getWsMiscStorage().isInputError()) {
			
			/* 
			FIXME: CCARD-ERROR-MSG
			****************************************************************
			ASK FOR CORRECTIONS TO INPUTS
			**************************************************************** */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAP */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-PROG */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-MAP */
			BluageUtils.unsupported();
			if (!(ctx.getWsMiscStorage().isFlgAcctfilterNotOk()) && !(ctx.getWsMiscStorage().isFlgCardfilterNotOk())) {
				_9000ReadForward(ctx, ctrl);
			} 
			_1000SendMap(ctx, ctrl);
			return;
		} else if ((BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isCaFirstPage()) || (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isCaFirstPage())) {
			
			/* 
			FIXME: CCARD-AID-PFK07FIXME: CCARD-AID-PFK07 */
			ctx.getWsMiscStorage().getWsCardRidCardnumReference().setValue(ctx.getWsThisProgcommarea().getWsCaFirstCardNumReference());
			
			/* 
			MOVE WS-CA-FIRST-CARD-ACCT-ID
			TO WS-CARD-RID-ACCT-ID */
			_9000ReadForward(ctx, ctrl);
			_1000SendMap(ctx, ctrl);
			return;
		} else if (BluageUtils.unsupported() || (BluageUtils.unsupported() && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsConstants().getLitThispgmReference()) != 0)) {
			
			/* 
			FIXME: CCARD-AID-PFK03FIXME: CDEMO-PGM-REENTERFIXME: CDEMO-FROM-PROGRAM */
			DataUtils.initialize(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().getField().initialize();
			
			/* 
			FIXME: CDEMO-FROM-TRANID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-USRTYP-USER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAP */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAPSET */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setCaFirstPage(true);
			ctx.getWsThisProgcommarea().setCaLastPageNotShown(true);
			ctx.getWsMiscStorage().getWsCardRidCardnumReference().setValue(ctx.getWsThisProgcommarea().getWsCaFirstCardNumReference());
			
			/* 
			MOVE WS-CA-FIRST-CARD-ACCT-ID
			TO WS-CARD-RID-ACCT-ID */
			_9000ReadForward(ctx, ctrl);
			_1000SendMap(ctx, ctrl);
			return;
		} else if (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isCaNextPageExists()) {
			
			/* 
			FIXME: CCARD-AID-PFK08 */
			ctx.getWsMiscStorage().getWsCardRidCardnumReference().setValue(ctx.getWsThisProgcommarea().getWsCaLastCardNumReference());
			
			/* 
			MOVE WS-CA-LAST-CARD-ACCT-ID
			TO WS-CARD-RID-ACCT-ID */
			ctx.getWsThisProgcommarea().setWsCaScreenNum(ctx.getWsThisProgcommarea().getWsCaScreenNum() + 1);
			_9000ReadForward(ctx, ctrl);
			_1000SendMap(ctx, ctrl);
			return;
		} else if (BluageUtils.unsupported() && !(ctx.getWsThisProgcommarea().isCaFirstPage())) {
			
			/* 
			FIXME: CCARD-AID-PFK07 */
			ctx.getWsMiscStorage().getWsCardRidCardnumReference().setValue(ctx.getWsThisProgcommarea().getWsCaFirstCardNumReference());
			
			/* 
			MOVE WS-CA-FIRST-CARD-ACCT-ID
			TO WS-CARD-RID-ACCT-ID */
			ctx.getWsThisProgcommarea().setWsCaScreenNum(ctx.getWsThisProgcommarea().getWsCaScreenNum() - 1);
			_9100ReadBackwards(ctx, ctrl);
			_1000SendMap(ctx, ctrl);
			return;
		} else if (BluageUtils.unsupported() && ctx.getWsMiscStorage().isItemFromViewRequestedOn(ctx.getWsMiscStorage().getISelected() - 1) && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsConstants().getLitThispgmReference()) == 0) {
			
			/* 
			FIXME: CCARD-AID-ENTERFIXME: CDEMO-FROM-PROGRAM */
			
			/* 
			FIXME: CDEMO-FROM-TRANID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-USRTYP-USER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAP */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-PROG */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-MAP */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-ACCT-ID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-CARD-NUM */
			BluageUtils.unsupported();
			
			/* 
			CALL CARD DETAIL PROGRAM */
			XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
		} else if (BluageUtils.unsupported() && ctx.getWsMiscStorage().isItemFromUpdateRequestedOn(ctx.getWsMiscStorage().getISelected() - 1) && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsConstants().getLitThispgmReference()) == 0) {
			
			/* 
			FIXME: CCARD-AID-ENTERFIXME: CDEMO-FROM-PROGRAM */
			
			/* 
			FIXME: CDEMO-FROM-TRANID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-USRTYP-USER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAP */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-PROG */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-MAP */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-ACCT-ID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-CARD-NUM */
			BluageUtils.unsupported();
			
			/* 
			CALL CARD UPDATE PROGRAM */
			XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
		} else {
			
			/* 
			**************************************************************** */
			ctx.getWsMiscStorage().getWsCardRidCardnumReference().setValue(ctx.getWsThisProgcommarea().getWsCaFirstCardNumReference());
			
			/* 
			MOVE WS-CA-FIRST-CARD-ACCT-ID
			TO WS-CARD-RID-ACCT-ID */
			_9000ReadForward(ctx, ctrl);
			_1000SendMap(ctx, ctrl);
			return;
		}
		
		/* 
		If we had an error setup error message to display and return */
		if (ctx.getWsMiscStorage().isInputError()) {
			
			/* 
			FIXME: CCARD-ERROR-MSG */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAP */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-PROG */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CCARD-NEXT-MAP */
			BluageUtils.unsupported();
			
			/* 
			PERFORM 1000-SEND-MAP
			THRU 1000-SEND-MAP */
			return;
		} else {
			
			/* 
			FIXME: CCARD-NEXT-PROG */
			BluageUtils.unsupported();
		}
	}

	/**
	 * Process operation _1000SendMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1000SendMap(final CocrdlicContext ctx, final ExecutionController ctrl) {
		_1100ScreenInit(ctx, ctrl);
		_1200ScreenArrayInit(ctx, ctrl);
		_1250SetupArrayAttribs(ctx, ctrl);
		_1300SetupScreenAttrs(ctx, ctrl);
		_1400SetupMessage(ctx, ctrl);
		_1500SendScreen(ctx, ctrl);
	}

	/**
	 * Process operation _1100ScreenInit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1100ScreenInit(final CocrdlicContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CCRDLIAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE01O OF CCRDLIAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE02O OF CCRDLIAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNNAMEO OF CCRDLIAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PGMNAMEO OF CCRDLIAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURDATEO OF CCRDLIAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-HH */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-SS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURTIMEO OF CCRDLIAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PAGENOO  OF CCRDLIAO
		PAGE NUMBER */
		BluageUtils.unsupported();
		ctx.getWsMiscStorage().setWsNoInfoMessage(true);
		
		/* 
		FIXME: INFOMSGO OF CCRDLIAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: INFOMSGC OF CCRDLIAO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation _1200ScreenArrayInit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1200ScreenArrayInit(final CocrdlicContext ctx, final ExecutionController ctrl) {
		/* 
		USE REDEFINES AND CLEAN UP REPETITIVE CODE !! */
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(0))) {
			
			/* 
			Do nothing */
		} else {
			
			/* 
			FIXME: CRDSEL1O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACCTNO1O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDNUM1O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDSTS1O OF CCRDLIAO */
			BluageUtils.unsupported();
		}
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(1))) {
			
			/* 
			Do nothing */
		} else {
			
			/* 
			FIXME: CRDSEL2O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACCTNO2O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDNUM2O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDSTS2O OF CCRDLIAO */
			BluageUtils.unsupported();
		}
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(2))) {
			
			/* 
			Do nothing */
		} else {
			
			/* 
			FIXME: CRDSEL3O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACCTNO3O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDNUM3O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDSTS3O OF CCRDLIAO */
			BluageUtils.unsupported();
		}
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(3))) {
			
			/* 
			Do nothing */
		} else {
			
			/* 
			FIXME: CRDSEL4O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACCTNO4O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDNUM4O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDSTS4O OF CCRDLIAO */
			BluageUtils.unsupported();
		}
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(4))) {
			
			/* 
			Do nothing */
		} else {
			
			/* 
			FIXME: CRDSEL5O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACCTNO5O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDNUM5O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDSTS5O OF CCRDLIAO */
			BluageUtils.unsupported();
		}
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(5))) {
			
			/* 
			Do nothing */
		} else {
			
			/* 
			FIXME: CRDSEL6O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACCTNO6O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDNUM6O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDSTS6O OF CCRDLIAO */
			BluageUtils.unsupported();
		}
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(6))) {
			
			/* 
			Do nothing */
		} else {
			
			/* 
			FIXME: CRDSEL7O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACCTNO7O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDNUM7O OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CRDSTS7O OF CCRDLIAO */
			BluageUtils.unsupported();
		}
	}

	/**
	 * Process operation _1250SetupArrayAttribs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1250SetupArrayAttribs(final CocrdlicContext ctx, final ExecutionController ctrl) {
		/* 
		USE REDEFINES AND CLEAN UP REPETITIVE CODE !! */
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(0)) || ctx.getWsMiscStorage().isFlgProtectSelectRowsYes()) {
			
			/* 
			FIXME: CRDSEL1A OF CCRDLIAI */
			BluageUtils.unsupported();
		} else {
			if (DataUtils.compare("1", ctx.getWsMiscStorage().getItemFromWsRowCrdselectErrorReference(0)) == 0) {
				
				/* 
				FIXME: CRDSEL1C OF CCRDLIAO */
				BluageUtils.unsupported();
				if (DataUtils.isBlank(ctx.getWsMiscStorage().getItemFromWsEditSelectReference(0)) || DataUtils.isLowValue(ctx.getWsMiscStorage().getItemFromWsEditSelectReference(0))) {
					
					/* 
					FIXME: CRDSEL1O OF CCRDLIAO */
					BluageUtils.unsupported();
				} 
			} 
			
			/* 
			FIXME: CRDSEL1A OF CCRDLIAI */
			BluageUtils.unsupported();
		}
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(1)) || ctx.getWsMiscStorage().isFlgProtectSelectRowsYes()) {
			
			/* 
			FIXME: CRDSEL2A OF CCRDLIAI */
			BluageUtils.unsupported();
		} else {
			if (DataUtils.compare("1", ctx.getWsMiscStorage().getItemFromWsRowCrdselectErrorReference(1)) == 0) {
				
				/* 
				FIXME: CRDSEL2C OF CCRDLIAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CRDSEL2L OF CCRDLIAI */
				BluageUtils.unsupported();
			} 
			
			/* 
			FIXME: CRDSEL2A OF CCRDLIAI */
			BluageUtils.unsupported();
		}
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(2)) || ctx.getWsMiscStorage().isFlgProtectSelectRowsYes()) {
			
			/* 
			FIXME: CRDSEL3A OF CCRDLIAI */
			BluageUtils.unsupported();
		} else {
			if (DataUtils.compare("1", ctx.getWsMiscStorage().getItemFromWsRowCrdselectErrorReference(2)) == 0) {
				
				/* 
				FIXME: CRDSEL3C OF CCRDLIAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CRDSEL3L OF CCRDLIAI */
				BluageUtils.unsupported();
			} 
			
			/* 
			FIXME: CRDSEL3A OF CCRDLIAI */
			BluageUtils.unsupported();
		}
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(3)) || ctx.getWsMiscStorage().isFlgProtectSelectRowsYes()) {
			
			/* 
			FIXME: CRDSEL4A OF CCRDLIAI */
			BluageUtils.unsupported();
			ctx.getWsMiscStorage().setI(NumberUtils.convert(ctx.getDfhbmsca().getDfhbmpro()).intValue());
		} else {
			if (DataUtils.compare("1", ctx.getWsMiscStorage().getItemFromWsRowCrdselectErrorReference(3)) == 0) {
				
				/* 
				FIXME: CRDSEL4C OF CCRDLIAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CRDSEL4L OF CCRDLIAI */
				BluageUtils.unsupported();
			} 
			
			/* 
			FIXME: CRDSEL4A OF CCRDLIAI */
			BluageUtils.unsupported();
		}
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(4)) || ctx.getWsMiscStorage().isFlgProtectSelectRowsYes()) {
			
			/* 
			FIXME: CRDSEL5A OF CCRDLIAI */
			BluageUtils.unsupported();
		} else {
			if (DataUtils.compare("1", ctx.getWsMiscStorage().getItemFromWsRowCrdselectErrorReference(4)) == 0) {
				
				/* 
				FIXME: CRDSEL5C OF CCRDLIAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CRDSEL5L OF CCRDLIAI */
				BluageUtils.unsupported();
			} 
			
			/* 
			FIXME: CRDSEL5A OF CCRDLIAI */
			BluageUtils.unsupported();
		}
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(5)) || ctx.getWsMiscStorage().isFlgProtectSelectRowsYes()) {
			
			/* 
			FIXME: CRDSEL6A OF CCRDLIAI */
			BluageUtils.unsupported();
		} else {
			if (DataUtils.compare("1", ctx.getWsMiscStorage().getItemFromWsRowCrdselectErrorReference(5)) == 0) {
				
				/* 
				FIXME: CRDSEL6C OF CCRDLIAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CRDSEL6L OF CCRDLIAI */
				BluageUtils.unsupported();
			} 
			
			/* 
			FIXME: CRDSEL6A OF CCRDLIAI */
			BluageUtils.unsupported();
		}
		if (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getItemFromWsEachCardReference(6)) || ctx.getWsMiscStorage().isFlgProtectSelectRowsYes()) {
			
			/* 
			FIXME: CRDSEL7A OF CCRDLIAI */
			BluageUtils.unsupported();
		} else {
			if (DataUtils.compare("1", ctx.getWsMiscStorage().getItemFromWsRowCrdselectErrorReference(6)) == 0) {
				
				/* 
				FIXME: CRDSEL7C OF CCRDLIAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CRDSEL7L OF CCRDLIAI */
				BluageUtils.unsupported();
			} 
			
			/* 
			FIXME: CRDSEL7A OF CCRDLIAI */
			BluageUtils.unsupported();
		}
	}

	/**
	 * Process operation _1300SetupScreenAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1300SetupScreenAttrs(final CocrdlicContext ctx, final ExecutionController ctrl) {
		/* 
		INITIALIZE SEARCH CRITERIA */
		if (ctx.getDfheiblk().getEibcalen() == 0 || (BluageUtils.unsupported() && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsConstants().getLitMenupgmReference()) == 0)) {
			
			/* 
			Do nothing */
		} else {
			if (ctx.getWsMiscStorage().isFlgAcctfilterIsvalid() || ctx.getWsMiscStorage().isFlgAcctfilterNotOk()) {
				
				/* 
				FIXME: ACCTSIDO OF CCRDLIAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACCTSIDA OF CCRDLIAI */
				BluageUtils.unsupported();
			} else if (DataUtils.compare("0", BluageUtils.unsupported()) == 0) {
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				
				/* 
				FIXME: ACCTSIDO OF CCRDLIAO */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: ACCTSIDO OF CCRDLIAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACCTSIDA OF CCRDLIAI */
				BluageUtils.unsupported();
			}
			if (ctx.getWsMiscStorage().isFlgCardfilterIsvalid() || ctx.getWsMiscStorage().isFlgCardfilterNotOk()) {
				
				/* 
				FIXME: CARDSIDO OF CCRDLIAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CARDSIDA OF CCRDLIAI */
				BluageUtils.unsupported();
			} else if (DataUtils.compare("0", BluageUtils.unsupported()) == 0) {
				
				/* 
				FIXME: CDEMO-CARD-NUM */
				
				/* 
				FIXME: CARDSIDO OF CCRDLIAO */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: CARDSIDO OF CCRDLIAO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CARDSIDA OF CCRDLIAI */
				BluageUtils.unsupported();
			}
		}
		
		/* 
		POSITION CURSOR */
		if (ctx.getWsMiscStorage().isFlgAcctfilterNotOk()) {
			
			/* 
			FIXME: ACCTSIDC OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACCTSIDL OF CCRDLIAI */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgCardfilterNotOk()) {
			
			/* 
			FIXME: CARDSIDC OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CARDSIDL OF CCRDLIAI */
			BluageUtils.unsupported();
		} 
		
		/* 
		IF NO ERRORS POSITION CURSOR AT ACCTID */
		if (ctx.getWsMiscStorage().isInputOk()) {
			
			/* 
			FIXME: ACCTSIDL OF CCRDLIAI */
			BluageUtils.unsupported();
		}
	}

	/**
	 * Process operation _1400SetupMessage.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1400SetupMessage(final CocrdlicContext ctx, final ExecutionController ctrl) {
		/* 
		SETUP MESSAGE */
		if (ctx.getWsMiscStorage().isFlgAcctfilterNotOk() || ctx.getWsMiscStorage().isFlgCardfilterNotOk()) {
			
			/* 
			Do nothing */
		} else if (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isCaFirstPage()) {
			
			/* 
			FIXME: CCARD-AID-PFK07 */
			ctx.getWsMiscStorage().setWsErrorMsg("NO PREVIOUS PAGES TO DISPLAY");
		} else if (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isCaNextPageNotExists() && ctx.getWsThisProgcommarea().isCaLastPageShown()) {
			
			/* 
			FIXME: CCARD-AID-PFK08 */
			ctx.getWsMiscStorage().setWsErrorMsg("NO MORE PAGES TO DISPLAY");
		} else if (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isCaNextPageNotExists()) {
			
			/* 
			FIXME: CCARD-AID-PFK08 */
			ctx.getWsMiscStorage().setWsInformRecActions(true);
			if (ctx.getWsThisProgcommarea().isCaLastPageNotShown() && ctx.getWsThisProgcommarea().isCaNextPageNotExists()) {
				ctx.getWsThisProgcommarea().setCaLastPageShown(true);
			} 
		} else if (ctx.getWsMiscStorage().isWsNoInfoMessage() || ctx.getWsThisProgcommarea().isCaNextPageExists()) {
			ctx.getWsMiscStorage().setWsInformRecActions(true);
		} else {
			ctx.getWsMiscStorage().setWsNoInfoMessage(true);
		}
		
		/* 
		FIXME: ERRMSGO OF CCRDLIAO */
		BluageUtils.unsupported();
		if (!(ctx.getWsMiscStorage().isWsNoInfoMessage()) && !(ctx.getWsMiscStorage().isWsNoRecordsFound())) {
			
			/* 
			FIXME: INFOMSGO OF CCRDLIAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: INFOMSGC OF CCRDLIAO */
			BluageUtils.unsupported();
		}
	}

	/**
	 * Process operation _1500SendScreen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1500SendScreen(final CocrdlicContext ctx, final ExecutionController ctrl) {
		SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withMap(ctx.getWsConstants().getLitThismapReference())
		.withMapset(ctx.getWsConstants().getLitThismapsetReference())
		.withData(BluageUtils.unsupported())
		.withCursor()
		.withErase()
		.withFreeKB()
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
	}

	/**
	 * Process operation _2000ReceiveMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2000ReceiveMap(final CocrdlicContext ctx, final ExecutionController ctrl) {
		_2100ReceiveScreen(ctx, ctrl);
		_2200EditInputs(ctx, ctrl);
	}

	/**
	 * Process operation _2100ReceiveScreen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2100ReceiveScreen(final CocrdlicContext ctx, final ExecutionController ctrl) {
		ReceiveMapBuilder.newInstance(ctx.getJicsEiblk(), ctrl.getExecutionContext(), ctx)
		.withMap(ctx.getWsConstants().getLitThismapReference())
		.withMapset(ctx.getWsConstants().getLitThismapsetReference())
		.into(BluageUtils.unsupported())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		FIXME: CC-ACCT-ID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CC-CARD-NUM */
		BluageUtils.unsupported();
		ctx.getWsMiscStorage().setItemFromWsEditSelect(BluageUtils.unsupported(),0);
		ctx.getWsMiscStorage().setItemFromWsEditSelect(BluageUtils.unsupported(),1);
		ctx.getWsMiscStorage().setItemFromWsEditSelect(BluageUtils.unsupported(),2);
		ctx.getWsMiscStorage().setItemFromWsEditSelect(BluageUtils.unsupported(),3);
		ctx.getWsMiscStorage().setItemFromWsEditSelect(BluageUtils.unsupported(),4);
		ctx.getWsMiscStorage().setItemFromWsEditSelect(BluageUtils.unsupported(),5);
		ctx.getWsMiscStorage().setItemFromWsEditSelect(BluageUtils.unsupported(),6);
	}

	/**
	 * Process operation _2200EditInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2200EditInputs(final CocrdlicContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setInputOk(true);
		ctx.getWsMiscStorage().setFlgProtectSelectRowsNo(true);
		_2210EditAccount(ctx, ctrl);
		_2220EditCard(ctx, ctrl);
		_2250EditArray(ctx, ctrl);
	}

	/**
	 * Process operation _2210EditAccount.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2210EditAccount(final CocrdlicContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setFlgAcctfilterBlank(true);
		
		/* 
		Not supplied */
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isZero(BluageUtils.unsupported())) {
			ctx.getWsMiscStorage().setFlgAcctfilterBlank(true);
			
			/* 
			FIXME: CDEMO-ACCT-ID */
			BluageUtils.unsupported();
			return;
		} else {
			
			/* 
			Not numeric
			Not 11 characters */
			if (!(DataUtils.isNumeric(BluageUtils.unsupported()))) {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
				ctx.getWsMiscStorage().setFlgProtectSelectRowsYes(true);
				ctx.getWsMiscStorage().setWsErrorMsg("ACCOUNT FILTER,IF SUPPLIED MUST BE A 11 DIGIT NUMBER");
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				BluageUtils.unsupported();
				return;
			} else {
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				BluageUtils.unsupported();
				ctx.getWsMiscStorage().setFlgAcctfilterIsvalid(true);
				return;
			}
		}
	}

	/**
	 * Process operation _2220EditCard.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2220EditCard(final CocrdlicContext ctx, final ExecutionController ctrl) {
		/* 
		Not numeric
		Not 16 characters */
		ctx.getWsMiscStorage().setFlgCardfilterBlank(true);
		
		/* 
		Not supplied */
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isZero(BluageUtils.unsupported())) {
			ctx.getWsMiscStorage().setFlgCardfilterBlank(true);
			
			/* 
			FIXME: CDEMO-CARD-NUM */
			BluageUtils.unsupported();
			return;
		} else {
			
			/* 
			Not numeric
			Not 16 characters */
			if (!(DataUtils.isNumeric(BluageUtils.unsupported()))) {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgCardfilterNotOk(true);
				ctx.getWsMiscStorage().setFlgProtectSelectRowsYes(true);
				if (ctx.getWsMiscStorage().isWsErrorMsgOff()) {
					ctx.getWsMiscStorage().setWsErrorMsg("CARD ID FILTER,IF SUPPLIED MUST BE A 16 DIGIT NUMBER");
				} 
				
				/* 
				FIXME: CDEMO-CARD-NUM */
				BluageUtils.unsupported();
				return;
			} else {
				
				/* 
				FIXME: CDEMO-CARD-NUM */
				BluageUtils.unsupported();
				ctx.getWsMiscStorage().setFlgCardfilterIsvalid(true);
				return;
			}
		}
	}

	/**
	 * Process operation _2250EditArray.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2250EditArray(final CocrdlicContext ctx, final ExecutionController ctrl) {
		if (ctx.getWsMiscStorage().isInputError()) {
			return;
		} else {
			InspectBuilder.newInstance(ctx.getWsMiscStorage().getWsEditSelectFlagsReference())
				.countInto(ctx.getWsMiscStorage().getIReference())
				.all("S","U")
				.apply();
			if (ctx.getWsMiscStorage().getI() > 1) {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setWsMoreThan1Action(true);
				ctx.getWsMiscStorage().getWsEditSelectErrorFlagsReference().setValue(ctx.getWsMiscStorage().getWsEditSelectFlagsReference());
				InspectBuilder.newInstance(ctx.getWsMiscStorage().getWsEditSelectErrorFlagsReference())
					.replace()
					.all("S")
					.by("1")
					.replace()
					.all("U")
					.by("1")
					.replace()
					.characters()
					.by("0")
					.apply();
			} 
			DataUtils.setToZeroes(ctx.getWsMiscStorage().getISelectedReference());
			ctx.getWsMiscStorage().setI(1);
			while (ctx.getWsMiscStorage().getI() <= 7) {
				if (ctx.getWsMiscStorage().isItemFromSelectOk(ctx.getWsMiscStorage().getI() - 1)) {
					ctx.getWsMiscStorage().getISelectedReference().setValue(ctx.getWsMiscStorage().getIReference());
					if (ctx.getWsMiscStorage().isWsMoreThan1Action()) {
						ctx.getWsMiscStorage().setItemFromWsRowCrdselectError("1",ctx.getWsMiscStorage().getI() - 1);
					} 
				} else if (ctx.getWsMiscStorage().isItemFromSelectBlank(ctx.getWsMiscStorage().getI() - 1)) {
					
					/* 
					Do nothing */
				} else {
					ctx.getWsMiscStorage().setInputError(true);
					ctx.getWsMiscStorage().setItemFromWsRowCrdselectError("1",ctx.getWsMiscStorage().getI() - 1);
					if (ctx.getWsMiscStorage().isWsErrorMsgOff()) {
						ctx.getWsMiscStorage().setWsInvalidActionCode(true);
					} 
				}
				ctx.getWsMiscStorage().setI(ctx.getWsMiscStorage().getI() + 1);
			}
		}
	}

	/**
	 * Process operation _9000ReadForward.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9000ReadForward(final CocrdlicContext ctx, final ExecutionController ctrl) {
		ctx.getWsThisProgcommarea().getWsAllRowsReference().setBytes(Record.LOW_VALUES);
		
		/* 
		****************************************************************
		Start Browse
		**************************************************************** */
		JicsFileBuilder.newInstance(ctx.getWsConstants().getLitCardFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.startBrowse()
		.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidCardnumReference())
		.keyLength(ctx.getWsMiscStorage().getWsCardRidCardnumReference().getRecord().getSize(),false)
		.keyComparisonMode(JicsKeyComparisonMode.GREATER_OR_EQUAL)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		
		/* 
		****************************************************************
		Loop through records and fetch max screen records
		**************************************************************** */
		DataUtils.setToZeroes(ctx.getWsMiscStorage().getWsScrnCounterReference());
		ctx.getWsThisProgcommarea().setCaNextPageExists(true);
		ctx.getWsMiscStorage().setMoreRecordsToRead(true);
		while (!(ctx.getWsMiscStorage().isReadLoopExit())) {
			JicsFileBuilder.newInstance(ctx.getWsConstants().getLitCardFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
			.readNext()
			.into(BluageUtils.unsupported())
			.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
			.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidCardnumReference())
			.keyLength(ctx.getWsMiscStorage().getWsCardRidCardnumReference().getRecord().getSize(),false)
			.execute();
			
			/* 
			WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
			ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
			
			/* 
			WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
			ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
			if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue() || ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.DUPREC.getIntValue()) {
				_9500FilterRecords(ctx, ctrl);
				if (ctx.getWsMiscStorage().isWsDonotExcludeThisRecord()) {
					ctx.getWsMiscStorage().setWsScrnCounter(ctx.getWsMiscStorage().getWsScrnCounter() + 1);
					ctx.getWsThisProgcommarea().setItemFromWsRowCardNum(BluageUtils.unsupported(),ctx.getWsMiscStorage().getWsScrnCounter() - 1);
					ctx.getWsThisProgcommarea().setItemFromWsRowAcctno(BluageUtils.unsupported(),ctx.getWsMiscStorage().getWsScrnCounter() - 1);
					ctx.getWsThisProgcommarea().setItemFromWsRowCardStatus(BluageUtils.unsupported(),ctx.getWsMiscStorage().getWsScrnCounter() - 1);
					if (ctx.getWsMiscStorage().getWsScrnCounter() == 1) {
						ctx.getWsThisProgcommarea().setWsCaFirstCardAcctId(BluageUtils.unsupported());
						ctx.getWsThisProgcommarea().setWsCaFirstCardNum(BluageUtils.unsupported());
						if (NumberUtils.eq(ctx.getWsThisProgcommarea().getWsCaScreenNumReference(), 0)) {
							ctx.getWsThisProgcommarea().setWsCaScreenNum(ctx.getWsThisProgcommarea().getWsCaScreenNum() + 1);
						} else {
							
							/* 
							Do nothing */
						}
					} else {
						
						/* 
						Do nothing */
					}
				} else {
					
					/* 
					Do nothing */
				}
				
				/* 
				****************************************************************
				Max Screen size
				**************************************************************** */
				if (ctx.getWsMiscStorage().getWsScrnCounter() == ctx.getWsConstants().getWsMaxScreenLines()) {
					ctx.getWsMiscStorage().setReadLoopExit(true);
					ctx.getWsThisProgcommarea().setWsCaLastCardAcctId(BluageUtils.unsupported());
					ctx.getWsThisProgcommarea().setWsCaLastCardNum(BluageUtils.unsupported());
					JicsFileBuilder.newInstance(ctx.getWsConstants().getLitCardFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
					.readNext()
					.into(BluageUtils.unsupported())
					.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
					.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidCardnumReference())
					.keyLength(ctx.getWsMiscStorage().getWsCardRidCardnumReference().getRecord().getSize(),false)
					.execute();
					
					/* 
					WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
					ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
					
					/* 
					WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
					ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
					if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue() || ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.DUPREC.getIntValue()) {
						ctx.getWsThisProgcommarea().setCaNextPageExists(true);
						ctx.getWsThisProgcommarea().setWsCaLastCardAcctId(BluageUtils.unsupported());
						ctx.getWsThisProgcommarea().setWsCaLastCardNum(BluageUtils.unsupported());
					} else if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.ENDFILE.getIntValue()) {
						ctx.getWsThisProgcommarea().setCaNextPageNotExists(true);
						if (ctx.getWsMiscStorage().isWsErrorMsgOff()) {
							ctx.getWsMiscStorage().setWsErrorMsg("NO MORE RECORDS TO SHOW");
						} 
					} else {
						
						/* 
						This is some kind of error. Change to END BR
						And exit */
						ctx.getWsMiscStorage().setReadLoopExit(true);
						ctx.getWsMiscStorage().setErrorOpname("READ");
						ctx.getWsMiscStorage().setErrorFile(ctx.getWsConstants().getLitCardFile());
						ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
						ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
						ctx.getWsMiscStorage().getWsErrorMsgReference().setBytes(ctx.getWsMiscStorage().getWsFileErrorMessageReference().getBytes());
					}
				} 
			} else if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.ENDFILE.getIntValue()) {
				ctx.getWsMiscStorage().setReadLoopExit(true);
				ctx.getWsThisProgcommarea().setCaNextPageNotExists(true);
				ctx.getWsThisProgcommarea().setWsCaLastCardAcctId(BluageUtils.unsupported());
				ctx.getWsThisProgcommarea().setWsCaLastCardNum(BluageUtils.unsupported());
				if (ctx.getWsMiscStorage().isWsErrorMsgOff()) {
					ctx.getWsMiscStorage().setWsErrorMsg("NO MORE RECORDS TO SHOW");
				} 
				if (NumberUtils.eq(ctx.getWsThisProgcommarea().getWsCaScreenNumReference(), 1) && ctx.getWsMiscStorage().getWsScrnCounter() == 0) {
					
					/* 
					MOVE 'NO RECORDS TO SHOW'  TO WS-ERROR-MSG */
					ctx.getWsMiscStorage().setWsNoRecordsFound(true);
				} 
			} else {
				
				/* 
				This is some kind of error. Change to END BR
				And exit */
				ctx.getWsMiscStorage().setReadLoopExit(true);
				ctx.getWsMiscStorage().setErrorOpname("READ");
				ctx.getWsMiscStorage().setErrorFile(ctx.getWsConstants().getLitCardFile());
				ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
				ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
				ctx.getWsMiscStorage().getWsErrorMsgReference().setBytes(ctx.getWsMiscStorage().getWsFileErrorMessageReference().getBytes());
			}
		}
		JicsFileBuilder.newInstance(ctx.getWsConstants().getLitCardFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.endBrowse()
		.execute()
		.handleException();
	}

	/**
	 * Process operation _9100ReadBackwards.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9100ReadBackwards(final CocrdlicContext ctx, final ExecutionController ctrl) {
		_9100ReadBackwards1(ctx, ctrl);
		JicsFileBuilder.newInstance(ctx.getWsConstants().getLitCardFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.endBrowse()
		.execute()
		.handleException();
	}

	/**
	 * Process operation _9100ReadBackwards1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9100ReadBackwards1(final CocrdlicContext ctx, final ExecutionController ctrl) {
		ctx.getWsThisProgcommarea().getWsAllRowsReference().setBytes(Record.LOW_VALUES);
		ctx.getWsThisProgcommarea().getWsCaLastCardkeyReference().setBytes(ctx.getWsThisProgcommarea().getWsCaFirstCardkeyReference().getBytes());
		
		/* 
		****************************************************************
		Start Browse
		**************************************************************** */
		JicsFileBuilder.newInstance(ctx.getWsConstants().getLitCardFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.startBrowse()
		.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidCardnumReference())
		.keyLength(ctx.getWsMiscStorage().getWsCardRidCardnumReference().getRecord().getSize(),false)
		.keyComparisonMode(JicsKeyComparisonMode.GREATER_OR_EQUAL)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		
		/* 
		****************************************************************
		Loop through records and fetch max screen records
		**************************************************************** */
		ctx.getWsMiscStorage().setWsScrnCounter(ctx.getWsConstants().getWsMaxScreenLines() + 1);
		ctx.getWsThisProgcommarea().setCaNextPageExists(true);
		ctx.getWsMiscStorage().setMoreRecordsToRead(true);
		
		/* 
		****************************************************************
		Now we show the records from previous set.
		**************************************************************** */
		JicsFileBuilder.newInstance(ctx.getWsConstants().getLitCardFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.readPrev()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidCardnumReference())
		.keyLength(ctx.getWsMiscStorage().getWsCardRidCardnumReference().getRecord().getSize(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue() || ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.DUPREC.getIntValue()) {
			ctx.getWsMiscStorage().setWsScrnCounter(ctx.getWsMiscStorage().getWsScrnCounter() - 1);
			while (!(ctx.getWsMiscStorage().isReadLoopExit())) {
				JicsFileBuilder.newInstance(ctx.getWsConstants().getLitCardFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
				.readPrev()
				.into(BluageUtils.unsupported())
				.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
				.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidCardnumReference())
				.keyLength(ctx.getWsMiscStorage().getWsCardRidCardnumReference().getRecord().getSize(),false)
				.execute();
				
				/* 
				WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
				ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
				
				/* 
				WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
				ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
				if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue() || ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.DUPREC.getIntValue()) {
					_9500FilterRecords(ctx, ctrl);
					if (ctx.getWsMiscStorage().isWsDonotExcludeThisRecord()) {
						ctx.getWsThisProgcommarea().setItemFromWsRowCardNum(BluageUtils.unsupported(),ctx.getWsMiscStorage().getWsScrnCounter() - 1);
						ctx.getWsThisProgcommarea().setItemFromWsRowAcctno(BluageUtils.unsupported(),ctx.getWsMiscStorage().getWsScrnCounter() - 1);
						ctx.getWsThisProgcommarea().setItemFromWsRowCardStatus(BluageUtils.unsupported(),ctx.getWsMiscStorage().getWsScrnCounter() - 1);
						ctx.getWsMiscStorage().setWsScrnCounter(ctx.getWsMiscStorage().getWsScrnCounter() - 1);
						if (ctx.getWsMiscStorage().getWsScrnCounter() == 0) {
							ctx.getWsMiscStorage().setReadLoopExit(true);
							ctx.getWsThisProgcommarea().setWsCaFirstCardAcctId(BluageUtils.unsupported());
							ctx.getWsThisProgcommarea().setWsCaFirstCardNum(BluageUtils.unsupported());
						} else {
							
							/* 
							Do nothing */
						}
					} else {
						
						/* 
						Do nothing */
					}
				} else {
					
					/* 
					This is some kind of error. Change to END BR
					And exit */
					ctx.getWsMiscStorage().setReadLoopExit(true);
					ctx.getWsMiscStorage().setErrorOpname("READ");
					ctx.getWsMiscStorage().setErrorFile(ctx.getWsConstants().getLitCardFile());
					ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
					ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
					ctx.getWsMiscStorage().getWsErrorMsgReference().setBytes(ctx.getWsMiscStorage().getWsFileErrorMessageReference().getBytes());
				}
			}
		} else {
			
			/* 
			This is some kind of error. Change to END BR
			And exit */
			ctx.getWsMiscStorage().setReadLoopExit(true);
			ctx.getWsMiscStorage().setErrorOpname("READ");
			ctx.getWsMiscStorage().setErrorFile(ctx.getWsConstants().getLitCardFile());
			ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
			ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
			ctx.getWsMiscStorage().getWsErrorMsgReference().setBytes(ctx.getWsMiscStorage().getWsFileErrorMessageReference().getBytes());
			return;
		}
	}

	/**
	 * Process operation _9500FilterRecords.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9500FilterRecords(final CocrdlicContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setWsDonotExcludeThisRecord(true);
		if (ctx.getWsMiscStorage().isFlgAcctfilterIsvalid()) {
			if (DataUtils.compare(BluageUtils.unsupported(), BluageUtils.unsupported()) == 0) {
				
				/* 
				Do nothing */
			} else {
				ctx.getWsMiscStorage().setWsExcludeThisRecord(true);
				return;
			}
		} else {
			
			/* 
			Do nothing */
		}
		if (ctx.getWsMiscStorage().isFlgCardfilterIsvalid()) {
			if (DataUtils.compare(BluageUtils.unsupported(), BluageUtils.unsupported()) == 0) {
				
				/* 
				Do nothing */
			} else {
				ctx.getWsMiscStorage().setWsExcludeThisRecord(true);
				return;
			}
		} else {
			
			/* 
			Do nothing */
		}
	}

	/**
	 * Process operation sendPlainText.
	 * 
	 * ****************************************************************
	 * Common code to store PFKey
	 * ****************************************************************
	 * ****************************************************************
	 *  Plain text exit - Dont use in production                      *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendPlainText(final CocrdlicContext ctx, final ExecutionController ctrl) {
		SendTextBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withData(ctx.getWsMiscStorage().getWsErrorMsgReference())
		.withLength(ctx.getWsMiscStorage().getWsErrorMsgReference().getRecord().getSize())
		.withErase()
		.withFreeKB()
		.execute()
		.handleException();
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.execute()
		.handleException();
	}

	/**
	 * Process operation sendLongText.
	 * 
	 * ****************************************************************
	 *  Display Long text and exit                                    *
	 *  This is primarily for debugging and should not be used in     *
	 *  regular course                                                *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendLongText(final CocrdlicContext ctx, final ExecutionController ctrl) {
		SendTextBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withData(ctx.getWsMiscStorage().getWsLongMsgReference())
		.withLength(ctx.getWsMiscStorage().getWsLongMsgReference().getRecord().getSize())
		.withErase()
		.withFreeKB()
		.execute()
		.handleException();
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.execute()
		.handleException();
		
		/* 
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:33 CDT */
		return;
	}

}
