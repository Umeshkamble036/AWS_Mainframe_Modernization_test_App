// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "CARDFILE"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//*****************************************************************
	// Copyright Amazon.com, Inc. or its affiliates.                   
	// All Rights Reserved.                                            
	//                                                                 
	// Licensed under the Apache License, Version 2.0 (the "License"). 
	// You may not use this file except in compliance with the License.
	// You may obtain a copy of the License at                         
	//                                                                 
	//    http://www.apache.org/licenses/LICENSE-2.0                   
	//                                                                 
	// Unless required by applicable law or agreed to in writing,      
	// software distributed under the License is distributed on an     
	// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,    
	// either express or implied. See the License for the specific     
	// language governing permissions and limitations under the License
	//*****************************************************************    
	//******************************************************************** 
	// Close files in CICS region                                          
	//******************************************************************** 
	lastProgramResult = stepCLCIFIL(shell, params, programResults)
	//                                                                     
	// ******************************************************************* 
	// DELETE CARD DATA VSAM FILE IF ONE ALREADY EXISTS                    
	// ******************************************************************* 
	lastProgramResult = stepSTEP05(shell, params, programResults)
	//                                                                     
	// ******************************************************************* 
	// DEFINE CARD DATA VSAM FILE                                          
	// ******************************************************************* 
	lastProgramResult = stepSTEP10(shell, params, programResults)
	// ******************************************************************* 
	// COPY DATA FROM FLAT FILE TO VSAM FILE                               
	// ******************************************************************* 
	lastProgramResult = stepSTEP15(shell, params, programResults)
	//-------------------------------------------------------------------* 
	// CREATE ALTERNATE INDEX ON ACCT ID                                   
	//-------------------------------------------------------------------* 
	lastProgramResult = stepSTEP40(shell, params, programResults)
	//-------------------------------------------------------------------* 
	// DEFINE PATH IS USED TO RELATE THE ALTERNATE INDEX TO BASE CLUSTER   
	//-------------------------------------------------------------------* 
	lastProgramResult = stepSTEP50(shell, params, programResults)
	//------------------------------------------------------------------   
	// BUILD ALTERNATE INDEX CLUSTER                                       
	//-------------------------------------------------------------------* 
	lastProgramResult = stepSTEP60(shell, params, programResults)
	//                                                                     
	//******************************************************************** 
	// Open files in CICS region                                           
	//******************************************************************** 
	lastProgramResult = stepOPCIFIL(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult") // End of job statement.
	//
	// Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:23:04 CDT
	//
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP CLCIFIL - PGM - SDSF******************************************************
def stepCLCIFIL(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("CLCIFIL", "SDSF", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("ISFOUT")
						.output("*")
						.build()
						.systemOut("CMDOUT")
						.output("*")
						.build()
						.fileSystem("ISFIN")
						.stream(
""" /F CICSAWSA,'CEMT SET FIL(CARDDAT ) CLO'                                       
 /F CICSAWSA,'CEMT SET FIL(CARDAIX ) CLO'                                       """, getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("SDSF")
				})
		}
	}
}
// STEP STEP05 - PGM - IDCAMS*****************************************************
def stepSTEP05(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP05", "IDCAMS", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSIN")
						.stream(
"""   DELETE AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS -                                  
          CLUSTER                                                               
   IF MAXCC LE 08 THEN SET MAXCC = 0                                            
   DELETE AWS.M2.CARDDEMO.CARDDATA.VSAM.AIX -                                   
          ALTERNATEINDEX                                                        
   IF MAXCC LE 08 THEN SET MAXCC = 0                                            """, getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IDCAMS")
				})
		}
	}
}
// STEP STEP10 - PGM - IDCAMS*****************************************************
def stepSTEP10(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP10", "IDCAMS", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSIN")
						.stream(
"""   DEFINE CLUSTER (NAME(AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS) -                   
          CYLINDERS(1 5) -                                                      
          VOLUMES(AWSHJ1 -                                                      
          ) -                                                                   
          KEYS(16 0) -                                                          
          RECORDSIZE(150 150) -                                                 
          SHAREOPTIONS(2 3) -                                                   
          ERASE -                                                               
          INDEXED -                                                             
          ) -                                                                   
          DATA (NAME(AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS.DATA) -                 
          ) -                                                                   
          INDEX (NAME(AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS.INDEX) -               
          )                                                                     """, getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IDCAMS")
				})
		}
	}
}
// STEP STEP15 - PGM - IDCAMS*****************************************************
def stepSTEP15(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP15", "IDCAMS", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.bluesam("CARDDATA")
						.dataset("AWS.M2.CARDDEMO.CARDDATA.PS")
						.disposition("SHR")
						.build()
						.bluesam("CARDVSAM")
						.dataset("AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS")
						.disposition("SHR")
						.build()
						.fileSystem("SYSIN")
						.stream("   REPRO INFILE(CARDDATA) OUTFILE(CARDVSAM)                                     ", getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IDCAMS")
				})
		}
	}
}
// STEP STEP40 - PGM - IDCAMS*****************************************************
def stepSTEP40(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP40", "IDCAMS", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSIN")
						.stream(
"""   DEFINE ALTERNATEINDEX (NAME(AWS.M2.CARDDEMO.CARDDATA.VSAM.AIX)-              
   RELATE(AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS)                    -              
   KEYS(11 16)                                                   -              
   NONUNIQUEKEY                                                  -              
   UPGRADE                                                       -              
   RECORDSIZE(150,150)                                           -              
   VOLUMES(AWSHJ1)                                               -              
   CYLINDERS(5,1))                                               -              
   DATA (NAME(AWS.M2.CARDDEMO.CARDDATA.VSAM.AIX.DATA))           -              
   INDEX (NAME(AWS.M2.CARDDEMO.CARDDATA.VSAM.AIX.INDEX))                        """, getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IDCAMS")
				})
		}
	}
}
// STEP STEP50 - PGM - IDCAMS*****************************************************
def stepSTEP50(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP50", "IDCAMS", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSIN")
						.stream(
"""  DEFINE PATH                                           -                       
   (NAME(AWS.M2.CARDDEMO.CARDDATA.VSAM.AIX.PATH)        -                       
    PATHENTRY(AWS.M2.CARDDEMO.CARDDATA.VSAM.AIX))                               """, getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IDCAMS")
				})
		}
	}
}
// STEP STEP60 - PGM - IDCAMS*****************************************************
def stepSTEP60(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP60", "IDCAMS", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSIN")
						.stream(
"""   BLDINDEX                                                      -              
   INDATASET(AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS)                 -              
   OUTDATASET(AWS.M2.CARDDEMO.CARDDATA.VSAM.AIX)                                """, getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IDCAMS")
				})
		}
	}
}
// STEP OPCIFIL - PGM - SDSF******************************************************
def stepOPCIFIL(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("OPCIFIL", "SDSF", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("ISFOUT")
						.output("*")
						.build()
						.systemOut("CMDOUT")
						.output("*")
						.build()
						.fileSystem("ISFIN")
						.stream(
""" /F CICSAWSA,'CEMT SET FIL(CARDDAT ) OPE'                                       
 /F CICSAWSA,'CEMT SET FIL(CARDAIX ) OPE'                                       """, getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("SDSF")
				})
		}
	}
}
