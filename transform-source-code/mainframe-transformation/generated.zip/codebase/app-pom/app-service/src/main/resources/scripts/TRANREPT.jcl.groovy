// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "TRANREPT"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//-------> TO DO ID : JOBLIB [Line : 18] *****************************************
	// ********************************************************`***********
	// Unload the processed transaction file                               
	// ******************************************************************* 
	stepSTEP05R(shell, jobName, params, programResults)
	// ******************************************************************* 
	// Filter the transactions for a the parm date and sort by card num    
	// ******************************************************************* 
	lastProgramResult = stepSTEP05R1(shell, params, programResults)
	// ******************************************************************* 
	// Produce a formatted report for processed transactions               
	// ******************************************************************* 
	lastProgramResult = stepSTEP10R(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult") // End of job statement.
	//
	// Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:23:08 CDT
	//
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP STEP05R - PROC - REPROC***************************************************
def stepSTEP05R(Object shell, String jobName, Map params, Map programResults) {
	shell.with{
		if (checkValidProgramResults(programResults)) {
			def stepName = 'STEP05R'
			execStepSimple(stepName, programResults, {
				def procName = 'REPROC'
				TreeMap mapTransfo = new TreeMap(params["MapTransfo"])
				mapTransfo['CNTLLIB'] = 'AWS.M2.CARDDEMO.CNTL'
				Map<String,FileConfiguration> fcmap = new FileConfigurationUtils()
				.withJobContext(jobContext)
				.bluesam("PRC001.FILEIN")
				.dataset("AWS.M2.CARDDEMO.TRANSACT.VSAM.KSDS")
				.disposition("SHR")
				.build()
				.gdgSupport("PRC001.FILEOUT")
				.name("AWS.M2.CARDDEMO.TRANSACT.BKUP").ownerPath(".").relativeGeneration(1).storageProvider("filesystem").recordSize(350)
				.disposition("NEW")
				.normalTermination("CATLG")
				.abnormalTermination("DELETE")
				.build()
				.getFileConfigurations();
				File procFile = ScriptRegistry.getScript(procName);
				File resolvedProcFile = buildResolvedFile(jobName,stepName,procName)
				GroovyUtils.processGroovyParams(procFile, resolvedProcFile, mapTransfo, programResults)
				return execGroovy(applicationContext, mapTransfo, resolvedProcFile, jobContext, fcmap)
			})
		}
	}
}
// STEP STEP05R1 - PGM - SORT*****************************************************
def stepSTEP05R1(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP05R1", "SORT", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.gdgSupport("SORTIN")
						.name("AWS.M2.CARDDEMO.TRANSACT.BKUP").ownerPath(".").relativeGeneration(1).storageProvider("filesystem")
						.disposition("SHR")
						.build()
						.fileSystem("SYMNAMES")
						.stream(
"""TRAN-CARD-NUM,263,16,ZD                                                         
TRAN-PROC-DT,305,10,CH                                                          
PARM-START-DATE,C'2022-01-01'                                      //Date       
PARM-END-DATE,C'2022-07-06'                                        //Date       """, getEncoding())
						.build()
						.fileSystem("SYSIN")
						.stream(
""" SORT FIELDS=(TRAN-CARD-NUM,A)                                          
 INCLUDE COND=(TRAN-PROC-DT,GE,PARM-START-DATE,AND,                     
         TRAN-PROC-DT,LE,PARM-END-DATE)                                 """, getEncoding())
						.build()
						.systemOut("SYSOUT")
						.output("*")
						.build()
						.gdgSupport("SORTOUT")
						.name("AWS.M2.CARDDEMO.TRANSACT.DALY").ownerPath(".").relativeGeneration(1).storageProvider("filesystem")
						.disposition("NEW")
						.normalTermination("CATLG")
						.abnormalTermination("DELETE")
						.dcbParameters("*.SORTIN")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("SORT")
				})
		}
	}
}
// STEP STEP10R - PGM - CBTRN03C**************************************************
def stepSTEP10R(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP10R", "CBTRN03C", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.bluesam("STEPLIB")
						.dataset("AWS.M2.CARDDEMO.LOADLIB")
						.disposition("SHR")
						.build()
						.systemOut("SYSOUT")
						.output("*")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.gdgSupport("TRANFILE")
						.name("AWS.M2.CARDDEMO.TRANSACT.DALY").ownerPath(".").relativeGeneration(1).storageProvider("filesystem")
						.disposition("SHR")
						.build()
						.bluesam("CARDXREF")
						.dataset("AWS.M2.CARDDEMO.CARDXREF.VSAM.KSDS")
						.disposition("SHR")
						.build()
						.bluesam("TRANTYPE")
						.dataset("AWS.M2.CARDDEMO.TRANTYPE.VSAM.KSDS")
						.disposition("SHR")
						.build()
						.bluesam("TRANCATG")
						.dataset("AWS.M2.CARDDEMO.TRANCATG.VSAM.KSDS")
						.disposition("SHR")
						.build()
						.bluesam("DATEPARM")
						.dataset("AWS.M2.CARDDEMO.DATEPARM")
						.disposition("SHR")
						.build()
						.gdgSupport("TRANREPT")
						.name("AWS.M2.CARDDEMO.TRANREPT").ownerPath(".").relativeGeneration(1).storageProvider("filesystem").recordSize(133)
						.disposition("NEW")
						.normalTermination("CATLG")
						.abnormalTermination("DELETE")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("CBTRN03C")
				})
		}
	}
}
