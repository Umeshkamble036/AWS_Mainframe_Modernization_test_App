package com.company.app.cocrdslc.statemachine;

import com.company.app.cocrdslc.business.context.CocrdslcContext;
import com.company.app.cocrdslc.statemachine.CocrdslcProcedureDivisionStateMachineController.Events;
import com.company.app.cocrdslc.statemachine.CocrdslcProcedureDivisionStateMachineController.States;
import com.company.app.cocrdslc.statemachine.CocrdslcProcedureDivisionStateMachineService;
import com.github.oxo42.stateless4j.StateMachineConfig;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.context.RuntimeContext;
import com.netfective.bluage.gapwalk.rt.statemachine.SimpleStateMachineController;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Controller managing the state machine "CocrdslcProcedureDivisionStateMachine" execution.
 */
@Component("com.company.app.cocrdslc.statemachine.CocrdslcProcedureDivisionStateMachineController")
@Import({
com.company.app.cocrdslc.statemachine.CocrdslcProcedureDivisionStateMachineService.class
})
@Lazy
public class CocrdslcProcedureDivisionStateMachineController extends SimpleStateMachineController<States, Events> {
	
	/**
	 * State machine states.
	 */
	public enum States {
		_0000_MAIN_1, _0000_MAIN, ABEND_ROUTINE, FINAL, LOCAL_FINAL
	}

	/**
	 * State machine events.
	 */
	public enum Events {
		TO__0000_MAIN_1, TO__0000_MAIN, TO_ABEND_ROUTINE, TO_FINAL, TO_LOCAL_FINAL
	}

	/**
	 * State machine state process service provider.
	 */
	@Autowired
	@Lazy
	private CocrdslcProcedureDivisionStateMachineService stateProcess;
	
	/**
	 * State machine controller initialization.
	 */
	@PostConstruct
	private void init(){
		initStateMachineController();
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine() throws Exception {
		throw new UnsupportedOperationException("Please use the two arguments configureStateMachine method instead: configureStateMachine(RuntimeContext ctx, ExecutionController ctrl)");
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine(RuntimeContext ctx, ExecutionController ctrl) throws Exception {
		
		StateMachineConfig<States, Events> configurer = new StateMachineConfig<>();
		configureInitialEnd(States._0000_MAIN_1,States.FINAL);
		CocrdslcContext lctx = (CocrdslcContext) ctx;

		configurer.configure(States._0000_MAIN).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._0000Main(lctx, ctrl);}))
		;	
		configurer.configure(States.ABEND_ROUTINE).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess.abendRoutine(lctx, ctrl);}))
		.permit(Events.TO_FINAL, States.FINAL)
		;	
		
		configurer.configure(States._0000_MAIN_1)
		.onEntry(()->{runSubStateMachine(Events.TO__0000_MAIN);})
		.permit(Events.TO__0000_MAIN, States._0000_MAIN)
		.permit(Events.TO_FINAL, States.FINAL)
		.permitInternal(Events.TO_ABEND_ROUTINE, buildRunAction(() -> {stateProcess.abendRoutine(lctx, ctrl);}))
		;	
		
		return configurer;
	}
	
}
