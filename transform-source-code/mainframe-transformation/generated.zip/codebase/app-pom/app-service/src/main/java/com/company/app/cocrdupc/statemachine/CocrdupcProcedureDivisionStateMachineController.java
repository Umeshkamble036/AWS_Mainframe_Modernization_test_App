package com.company.app.cocrdupc.statemachine;

import com.company.app.cocrdupc.business.context.CocrdupcContext;
import com.company.app.cocrdupc.statemachine.CocrdupcProcedureDivisionStateMachineController.Events;
import com.company.app.cocrdupc.statemachine.CocrdupcProcedureDivisionStateMachineController.States;
import com.company.app.cocrdupc.statemachine.CocrdupcProcedureDivisionStateMachineService;
import com.github.oxo42.stateless4j.StateMachineConfig;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.context.RuntimeContext;
import com.netfective.bluage.gapwalk.rt.statemachine.MultipleActiveContinuationController;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Controller managing the state machine "CocrdupcProcedureDivisionStateMachine" execution.
 */
@Component("com.company.app.cocrdupc.statemachine.CocrdupcProcedureDivisionStateMachineController")
@Import({
com.company.app.cocrdupc.statemachine.CocrdupcProcedureDivisionStateMachineService.class
})
@Lazy
public class CocrdupcProcedureDivisionStateMachineController extends MultipleActiveContinuationController<States, Events> {
	
	/**
	 * State machine states.
	 */
	public enum States {
		_0000_MAIN_1, _0000_MAIN, _2000_DECIDE_ACTION, _9200_WRITE_PROCESSING, _9200_WRITE_PROCESSING_EXIT, _9300_CHECK_CHANGE_IN_REC, _9300_CHECK_CHANGE_IN_REC_EXIT, ABEND_ROUTINE, _0000_MAIN_CASEBRANCH, _2000_DECIDE_ACTION_POSTIF, _2000_DECIDE_ACTION_CASEBRANCH, _2000_DECIDE_ACTION_CASEBRANCH_1, _0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT, _2000_DECIDE_ACTION_POST__9200WRITEPROCESSING_THRU__9200WRITEPROCESSINGEXIT, _9200_WRITE_PROCESSING_POST__9300CHECKCHANGEINREC_THRU__9300CHECKCHANGEINRECEXIT, FINAL, LOCAL_FINAL
	}

	/**
	 * State machine events.
	 */
	public enum Events {
		TO__0000_MAIN_1, TO__0000_MAIN, TO__2000_DECIDE_ACTION, TO__9200_WRITE_PROCESSING, TO__9200_WRITE_PROCESSING_EXIT, TO__9300_CHECK_CHANGE_IN_REC, TO__9300_CHECK_CHANGE_IN_REC_EXIT, TO_ABEND_ROUTINE, TO__0000_MAIN_CASEBRANCH, TO__2000_DECIDE_ACTION_POSTIF, TO__2000_DECIDE_ACTION_CASEBRANCH, TO__2000_DECIDE_ACTION_CASEBRANCH_1, TO__0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT, TO__2000_DECIDE_ACTION_POST__9200WRITEPROCESSING_THRU__9200WRITEPROCESSINGEXIT, TO__9200_WRITE_PROCESSING_POST__9300CHECKCHANGEINREC_THRU__9300CHECKCHANGEINRECEXIT, TO_FINAL, TO_LOCAL_FINAL
	}

	/**
	 * State machine state process service provider.
	 */
	@Autowired
	@Lazy
	private CocrdupcProcedureDivisionStateMachineService stateProcess;
	
	/**
	 * State machine controller initialization.
	 */
	@PostConstruct
	private void init(){
		initStateMachineController();
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine() throws Exception {
		throw new UnsupportedOperationException("Please use the two arguments configureStateMachine method instead: configureStateMachine(RuntimeContext ctx, ExecutionController ctrl)");
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine(RuntimeContext ctx, ExecutionController ctrl) throws Exception {
		
		StateMachineConfig<States, Events> configurer = new StateMachineConfig<>();
		configureInitialEnd(States._0000_MAIN_1,States.FINAL);
		CocrdupcContext lctx = (CocrdupcContext) ctx;

		configurer.configure(States._0000_MAIN).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._0000Main(lctx, ctrl);}))
		.permit(Events.TO__0000_MAIN_CASEBRANCH, States._0000_MAIN_CASEBRANCH)
		;	
		configurer.configure(States._2000_DECIDE_ACTION).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideAction(lctx, ctrl);}))
		.permit(Events.TO__2000_DECIDE_ACTION_CASEBRANCH, States._2000_DECIDE_ACTION_CASEBRANCH)
		.permit(Events.TO__2000_DECIDE_ACTION_CASEBRANCH_1, States._2000_DECIDE_ACTION_CASEBRANCH_1)
		.permit(Events.TO__2000_DECIDE_ACTION_POSTIF, States._2000_DECIDE_ACTION_POSTIF)
		;	
		configurer.configure(States._9200_WRITE_PROCESSING).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._9200WriteProcessing(lctx, ctrl);}))
		.permit(Events.TO__9200_WRITE_PROCESSING_EXIT, States._9200_WRITE_PROCESSING_EXIT)
		.permit(Events.TO__9300_CHECK_CHANGE_IN_REC, States._9300_CHECK_CHANGE_IN_REC)
		;	
		configurer.configure(States._9200_WRITE_PROCESSING_EXIT).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._9200WriteProcessingExit(lctx, ctrl);}))
		.permit(Events.TO__2000_DECIDE_ACTION_POST__9200WRITEPROCESSING_THRU__9200WRITEPROCESSINGEXIT, States._2000_DECIDE_ACTION_POST__9200WRITEPROCESSING_THRU__9200WRITEPROCESSINGEXIT)
		;	
		configurer.configure(States._9300_CHECK_CHANGE_IN_REC).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._9300CheckChangeInRec(lctx, ctrl);}))
		.permit(Events.TO__9200_WRITE_PROCESSING_EXIT, States._9200_WRITE_PROCESSING_EXIT)
		.permit(Events.TO__9300_CHECK_CHANGE_IN_REC_EXIT, States._9300_CHECK_CHANGE_IN_REC_EXIT)
		;	
		configurer.configure(States._9300_CHECK_CHANGE_IN_REC_EXIT).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._9300CheckChangeInRecExit(lctx, ctrl);}))
		.permit(Events.TO__9200_WRITE_PROCESSING_POST__9300CHECKCHANGEINREC_THRU__9300CHECKCHANGEINRECEXIT, States._9200_WRITE_PROCESSING_POST__9300CHECKCHANGEINREC_THRU__9300CHECKCHANGEINRECEXIT)
		;	
		configurer.configure(States.ABEND_ROUTINE).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess.abendRoutine(lctx, ctrl);}))
		.permit(Events.TO_FINAL, States.FINAL)
		.permit(Events.TO__2000_DECIDE_ACTION_POSTIF, States._2000_DECIDE_ACTION_POSTIF)
		;	
		configurer.configure(States._0000_MAIN_CASEBRANCH).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._0000MainCasebranch(lctx, ctrl);}))
		.permit(Events.TO__2000_DECIDE_ACTION, States._2000_DECIDE_ACTION)
		;	
		configurer.configure(States._2000_DECIDE_ACTION_POSTIF).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideActionPostif(lctx, ctrl);}))
		.permit(Events.TO__0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT, States._0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT)
		;	
		configurer.configure(States._2000_DECIDE_ACTION_CASEBRANCH).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideActionCasebranch(lctx, ctrl);}))
		.permit(Events.TO__9200_WRITE_PROCESSING, States._9200_WRITE_PROCESSING)
		;	
		configurer.configure(States._2000_DECIDE_ACTION_CASEBRANCH_1).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideActionCasebranch1(lctx, ctrl);}))
		.permit(Events.TO_ABEND_ROUTINE, States.ABEND_ROUTINE)
		;	
		configurer.configure(States._0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._0000MainPost2000decideactionThru2000decideactionexit(lctx, ctrl);}))
		;	
		configurer.configure(States._2000_DECIDE_ACTION_POST__9200WRITEPROCESSING_THRU__9200WRITEPROCESSINGEXIT).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideActionPost9200writeprocessingThru9200writeprocessingexit(lctx, ctrl);}))
		.permit(Events.TO__2000_DECIDE_ACTION_POSTIF, States._2000_DECIDE_ACTION_POSTIF)
		;	
		configurer.configure(States._9200_WRITE_PROCESSING_POST__9300CHECKCHANGEINREC_THRU__9300CHECKCHANGEINRECEXIT).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._9200WriteProcessingPost9300checkchangeinrecThru9300checkchangeinrecexit(lctx, ctrl);}))
		.permit(Events.TO__9200_WRITE_PROCESSING_EXIT, States._9200_WRITE_PROCESSING_EXIT)
		;	
		
		configurer.configure(States._0000_MAIN_1)
		.onEntry(()->{runSubStateMachine(Events.TO__0000_MAIN);})
		.permit(Events.TO__0000_MAIN, States._0000_MAIN)
		.permit(Events.TO_FINAL, States.FINAL)
		.permitInternal(Events.TO_ABEND_ROUTINE, buildRunAction(() -> {stateProcess.abendRoutine(lctx, ctrl);}))
		;	
		
		return configurer;
	}
	
}
