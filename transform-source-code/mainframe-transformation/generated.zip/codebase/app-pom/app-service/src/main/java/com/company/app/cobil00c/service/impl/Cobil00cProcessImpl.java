
package com.company.app.cobil00c.service.impl;

import com.company.app.cobil00c.business.context.Cobil00cContext;
import com.company.app.cobil00c.service.Cobil00cProcess;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.bms.ReceiveMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.jics.internal.JicsTimeBuilder;
import com.netfective.bluage.gapwalk.rt.jics.io.JicsIsolationLevel;
import com.netfective.bluage.gapwalk.rt.jics.io.internal.JicsFileBuilder;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Cobil00cProcessImpl
 * 
 * Defines application services for Cobil00cProcess
 * @see Cobil00cProcess
 */
@Service("com.company.app.cobil00c.service.Cobil00cProcess")
@Lazy

public class Cobil00cProcessImpl implements Cobil00cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Cobil00cProcessImpl.class);


	/**
	 * Process operation mainPara.
	 * 
	 * PROGRAM-ID.COBIL00C.
	 *  AUTHOR.     AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void mainPara(final Cobil00cContext ctx, final ExecutionController ctrl) {
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		*****************************************************************
		Program     : COBIL00C.CBL
		Application : CardDemo
		Type        : CICS COBOL Program
		Function    : Bill Payment - Pay account balance in full and a
		tractionsaction for the online bill payment.
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		----------------------------------------------------------------*
		WORKING STORAGE SECTION
		----------------------------------------------------------------*
		No background transparency
		----------------------------------------------------------------*
		LINKAGE SECTION
		----------------------------------------------------------------*
		----------------------------------------------------------------*
		PROCEDURE DIVISION
		----------------------------------------------------------------* */
		ctx.getWsVariables().setErrFlgOff(true);
		ctx.getWsVariables().setUsrModifiedNo(true);
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		FIXME: ERRMSGO OF COBIL0AO */
		BluageUtils.unsupported();
		if (ctx.getDfheiblk().getEibcalen() == 0) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
			returnToPrevScreen(ctx, ctrl);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			if (!(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-PGM-REENTER */
				BluageUtils.unsupported();
				
				/* 
				FIXME: COBIL0AO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACTIDINL OF COBIL0AI */
				BluageUtils.unsupported();
				if (!(DataUtils.isBlank(ctx.getWsVariables().getCdemoCb00TrnSelectedReference())) && !(DataUtils.isLowValue(ctx.getWsVariables().getCdemoCb00TrnSelectedReference()))) {
					
					/* 
					FIXME: ACTIDINI OF COBIL0AI */
					BluageUtils.unsupported();
					processEnterKey(ctx, ctrl);
				} 
				sendBillpayScreen(ctx, ctrl);
			} else {
				receiveBillpayScreen(ctx, ctrl);
				if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) == 0) {
					processEnterKey(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf3Reference()) == 0) {
					if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
						
						/* 
						FIXME: CDEMO-TO-PROGRAM */
						BluageUtils.unsupported();
					} else {
						
						/* 
						FIXME: CDEMO-TO-PROGRAM */
						BluageUtils.unsupported();
					}
					returnToPrevScreen(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf4Reference()) == 0) {
					clearCurrentScreen(ctx, ctrl);
				} else {
					ctx.getWsVariables().setWsErrFlg("Y");
					ctx.getWsVariables().setWsMessage(BluageUtils.unsupported());
					sendBillpayScreen(ctx, ctrl);
				}
			}
		}
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsVariables().getWsTranid())
		.withCommarea(BluageUtils.unsupported())
		.execute()
		.handleException();
	}

	/**
	 * Process operation processEnterKey.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-ENTER-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processEnterKey(final Cobil00cContext ctx, final ExecutionController ctrl) {
		ctx.getWsVariables().setConfPayNo(true);
		if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Acct ID can NOT be empty...");
			
			/* 
			FIXME: ACTIDINL OF COBIL0AI */
			BluageUtils.unsupported();
			sendBillpayScreen(ctx, ctrl);
		} else {
			
			/* 
			Do nothing */
		}
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			
			/* 
			FIXME: ACCT-ID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: XREF-ACCT-ID */
			BluageUtils.unsupported();
			if (DataUtils.compare("Y", BluageUtils.unsupported()) == 0 || DataUtils.compare("y", BluageUtils.unsupported()) == 0) {
				
				/* 
				FIXME: CONFIRMI OF COBIL0AIFIXME: CONFIRMI OF COBIL0AI */
				ctx.getWsVariables().setConfPayYes(true);
				readAcctdatFile(ctx, ctrl);
			} else if (DataUtils.compare("N", BluageUtils.unsupported()) == 0 || DataUtils.compare("n", BluageUtils.unsupported()) == 0) {
				
				/* 
				FIXME: CONFIRMI OF COBIL0AIFIXME: CONFIRMI OF COBIL0AI */
				clearCurrentScreen(ctx, ctrl);
				ctx.getWsVariables().setWsErrFlg("Y");
			} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
				readAcctdatFile(ctx, ctrl);
			} else {
				ctx.getWsVariables().setWsErrFlg("Y");
				ctx.getWsVariables().setWsMessage("Invalid value. Valid values are (Y/N)...");
				
				/* 
				FIXME: CONFIRML OF COBIL0AI */
				BluageUtils.unsupported();
				sendBillpayScreen(ctx, ctrl);
			}
			ctx.getWsVariables().setWsCurrBal(BluageUtils.unsupported());
			
			/* 
			FIXME: CURBALI    OF COBIL0AI */
			BluageUtils.unsupported();
		} 
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			if (BluageUtils.unsupported() && !(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
				ctx.getWsVariables().setWsErrFlg("Y");
				ctx.getWsVariables().setWsMessage("You have nothing to pay...");
				
				/* 
				FIXME: ACTIDINL OF COBIL0AI */
				BluageUtils.unsupported();
				sendBillpayScreen(ctx, ctrl);
			} 
		} 
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			if (ctx.getWsVariables().isConfPayYes()) {
				readCxacaixFile(ctx, ctrl);
				
				/* 
				FIXME: TRAN-ID */
				BluageUtils.unsupported();
				startbrTransactFile(ctx, ctrl);
				readprevTransactFile(ctx, ctrl);
				endbrTransactFile(ctx, ctrl);
				ctx.getWsVariables().setWsTranIdNum(BluageUtils.unsupported());
				ctx.getWsVariables().setWsTranIdNum(ctx.getWsVariables().getWsTranIdNum() + 1);
				DataUtils.initialize(BluageUtils.unsupported());
				
				/* 
				FIXME: TRAN-ID */
				BluageUtils.unsupported();
				
				/* 
				FIXME: TRAN-TYPE-CD */
				BluageUtils.unsupported();
				
				/* 
				FIXME: TRAN-CAT-CD */
				BluageUtils.unsupported();
				
				/* 
				FIXME: TRAN-SOURCE */
				BluageUtils.unsupported();
				
				/* 
				FIXME: TRAN-DESC */
				BluageUtils.unsupported();
				
				/* 
				FIXME: TRAN-AMT */
				BluageUtils.unsupported();
				
				/* 
				FIXME: TRAN-CARD-NUM */
				BluageUtils.unsupported();
				
				/* 
				FIXME: TRAN-MERCHANT-ID */
				BluageUtils.unsupported();
				
				/* 
				FIXME: TRAN-MERCHANT-NAME */
				BluageUtils.unsupported();
				
				/* 
				FIXME: TRAN-MERCHANT-CITY */
				BluageUtils.unsupported();
				
				/* 
				FIXME: TRAN-MERCHANT-ZIP */
				BluageUtils.unsupported();
				getCurrentTimestamp(ctx, ctrl);
				
				/* 
				FIXME: TRAN-ORIG-TS */
				BluageUtils.unsupported();
				
				/* 
				FIXME: TRAN-PROC-TS */
				BluageUtils.unsupported();
				writeTransactFile(ctx, ctrl);
				
				/* 
				FIXME: ACCT-CURR-BAL */
				BluageUtils.unsupported();
				updateAcctdatFile(ctx, ctrl);
			} else {
				ctx.getWsVariables().setWsMessage("Confirm to make a bill payment...");
				
				/* 
				FIXME: CONFIRML OF COBIL0AI */
				BluageUtils.unsupported();
			}
			sendBillpayScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation getCurrentTimestamp.
	 * 
	 * ----------------------------------------------------------------*
	 *                       GET-CURRENT-TIMESTAMP
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void getCurrentTimestamp(final Cobil00cContext ctx, final ExecutionController ctrl) {
		JicsTimeBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.askTime()
		.absoluteTime(ctx.getWsVariables().getWsAbsTimeReference())
		.execute()
		.handleException();
		JicsTimeBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.formatTime()
		.time(ctx.getWsVariables().getWsCurTimeX08Reference())
		.absoluteTime(ctx.getWsVariables().getWsAbsTimeReference())
		.formattedDate(ctx.getWsVariables().getWsCurDateX10Reference(),"YYYYMMDD")
		.datesep("-")
		.timesep(":")
		.execute()
		.handleException();
		DataUtils.initialize(BluageUtils.unsupported());
		
		/* 
		FIXME: WS-TIMESTAMP(01:10) */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-TIMESTAMP(12:08) */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-TIMESTAMP-TM-MS6 */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation returnToPrevScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RETURN-TO-PREV-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void returnToPrevScreen(final Cobil00cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
		} 
		
		/* 
		FIXME: CDEMO-FROM-TRANID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-FROM-PROGRAM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-PGM-CONTEXT */
		BluageUtils.unsupported();
		XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
	}

	/**
	 * Process operation sendBillpayScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       SEND-BILLPAY-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendBillpayScreen(final Cobil00cContext ctx, final ExecutionController ctrl) {
		populateHeaderInfo(ctx, ctrl);
		
		/* 
		FIXME: ERRMSGO OF COBIL0AO */
		BluageUtils.unsupported();
		SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withMap("COBIL0A")
		.withMapset("COBIL00")
		.withData(BluageUtils.unsupported())
		.withErase()
		.withCursor()
		.execute()
		.handleException();
	}

	/**
	 * Process operation receiveBillpayScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RECEIVE-BILLPAY-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void receiveBillpayScreen(final Cobil00cContext ctx, final ExecutionController ctrl) {
		ReceiveMapBuilder.newInstance(ctx.getJicsEiblk(), ctrl.getExecutionContext(), ctx)
		.withMap("COBIL0A")
		.withMapset("COBIL00")
		.into(BluageUtils.unsupported())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
	}

	/**
	 * Process operation populateHeaderInfo.
	 * 
	 * ----------------------------------------------------------------*
	 *                       POPULATE-HEADER-INFO
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void populateHeaderInfo(final Cobil00cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE01O OF COBIL0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE02O OF COBIL0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNNAMEO OF COBIL0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PGMNAMEO OF COBIL0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURDATEO OF COBIL0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-HH */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-SS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURTIMEO OF COBIL0AO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation readAcctdatFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       READ-ACCTDAT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readAcctdatFile(final Cobil00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsAcctdatFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.setIsolationLevel(JicsIsolationLevel.UPDATE)
		.updateNoToken()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Account ID NOT found...");
			
			/* 
			FIXME: ACTIDINL OF COBIL0AI */
			BluageUtils.unsupported();
			sendBillpayScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup Account...");
			
			/* 
			FIXME: ACTIDINL OF COBIL0AI */
			BluageUtils.unsupported();
			sendBillpayScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation updateAcctdatFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       UPDATE-ACCTDAT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void updateAcctdatFile(final Cobil00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsAcctdatFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.rewrite()
		.from(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Account ID NOT found...");
			
			/* 
			FIXME: ACTIDINL OF COBIL0AI */
			BluageUtils.unsupported();
			sendBillpayScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to Update Account...");
			
			/* 
			FIXME: ACTIDINL OF COBIL0AI */
			BluageUtils.unsupported();
			sendBillpayScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation readCxacaixFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       READ-CXACAIX-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readCxacaixFile(final Cobil00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsCxacaixFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Account ID NOT found...");
			
			/* 
			FIXME: ACTIDINL OF COBIL0AI */
			BluageUtils.unsupported();
			sendBillpayScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup XREF AIX file...");
			
			/* 
			FIXME: ACTIDINL OF COBIL0AI */
			BluageUtils.unsupported();
			sendBillpayScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation startbrTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       STARTBR-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void startbrTransactFile(final Cobil00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.startBrowse()
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Transaction ID NOT found...");
			
			/* 
			FIXME: ACTIDINL OF COBIL0AI */
			BluageUtils.unsupported();
			sendBillpayScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup Transaction...");
			
			/* 
			FIXME: ACTIDINL OF COBIL0AI */
			BluageUtils.unsupported();
			sendBillpayScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation readprevTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       READPREV-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readprevTransactFile(final Cobil00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.readPrev()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.ENDFILE.getIntValue()) {
			
			/* 
			FIXME: TRAN-ID */
			BluageUtils.unsupported();
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup Transaction...");
			
			/* 
			FIXME: ACTIDINL OF COBIL0AI */
			BluageUtils.unsupported();
			sendBillpayScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation endbrTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       ENDBR-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void endbrTransactFile(final Cobil00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.endBrowse()
		.execute()
		.handleException();
	}

	/**
	 * Process operation writeTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       WRITE-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void writeTransactFile(final Cobil00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.write(false)
		.from(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			initializeAllFields(ctx, ctrl);
			DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
			
			/* 
			FIXME: ERRMSGC  OF COBIL0AO */
			BluageUtils.unsupported();
			StringConcatenationBuilder.newInstance(ctx.getWsVariables().getWsMessageReference())
				.addDelimitedBySize("Payment successful. ")
				.addDelimitedBySize(" Your Transaction ID is ")
				.addDelimitedByLiteral(BluageUtils.unsupported()," ")
				.addDelimitedBySize(".")
				.end();
			sendBillpayScreen(ctx, ctrl);
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.DUPKEY.getIntValue() || ctx.getWsVariables().getWsRespCd() == ResponseCode.DUPREC.getIntValue()) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Tran ID already exist...");
			
			/* 
			FIXME: ACTIDINL OF COBIL0AI */
			BluageUtils.unsupported();
			sendBillpayScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to Add Bill pay Transaction...");
			
			/* 
			FIXME: ACTIDINL OF COBIL0AI */
			BluageUtils.unsupported();
			sendBillpayScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation clearCurrentScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       CLEAR-CURRENT-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void clearCurrentScreen(final Cobil00cContext ctx, final ExecutionController ctrl) {
		initializeAllFields(ctx, ctrl);
		sendBillpayScreen(ctx, ctrl);
	}

	/**
	 * Process operation initializeAllFields.
	 * 
	 * ----------------------------------------------------------------*
	 *                       INITIALIZE-ALL-FIELDS
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void initializeAllFields(final Cobil00cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: ACTIDINL OF COBIL0AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTIDINI OF COBIL0AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURBALI  OF COBIL0AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CONFIRMI OF COBIL0AI */
		BluageUtils.unsupported();
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:32 CDT */
		return;
	}

}
