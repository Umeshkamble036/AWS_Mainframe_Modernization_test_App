package com.company.app.cbstm03a.statemachine;

import com.company.app.cbstm03a.business.context.Cbstm03aContext;
import com.company.app.cbstm03a.statemachine.Cbstm03aProceduredivisionStateMachineController.Events;
import com.company.app.cbstm03a.statemachine.Cbstm03aProceduredivisionStateMachineController.States;
import com.company.app.cbstm03a.statemachine.Cbstm03aProceduredivisionStateMachineService;
import com.github.oxo42.stateless4j.StateMachineConfig;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.context.RuntimeContext;
import com.netfective.bluage.gapwalk.rt.statemachine.SimpleStateMachineController;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Controller managing the state machine "Cbstm03aProceduredivisionStateMachine" execution.
 */
@Component("com.company.app.cbstm03a.statemachine.Cbstm03aProceduredivisionStateMachineController")
@Import({
com.company.app.cbstm03a.statemachine.Cbstm03aProceduredivisionStateMachineService.class
})
@Lazy
public class Cbstm03aProceduredivisionStateMachineController extends SimpleStateMachineController<States, Events> {
	
	/**
	 * State machine states.
	 */
	public enum States {
		PROCEDUREDIVISION, _0000_START, _8100_FILE_OPEN, FINAL
	}

	/**
	 * State machine events.
	 */
	public enum Events {
		TO_PROCEDUREDIVISION, TO__0000_START, TO__8100_FILE_OPEN, TO_FINAL
	}

	/**
	 * State machine state process service provider.
	 */
	@Autowired
	@Lazy
	private Cbstm03aProceduredivisionStateMachineService stateProcess;
	
	/**
	 * State machine controller initialization.
	 */
	@PostConstruct
	private void init(){
		initStateMachineController();
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine() throws Exception {
		throw new UnsupportedOperationException("Please use the two arguments configureStateMachine method instead: configureStateMachine(RuntimeContext ctx, ExecutionController ctrl)");
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine(RuntimeContext ctx, ExecutionController ctrl) throws Exception {
		
		StateMachineConfig<States, Events> configurer = new StateMachineConfig<>();
		configureInitialEnd(States.PROCEDUREDIVISION,States.FINAL);
		Cbstm03aContext lctx = (Cbstm03aContext) ctx;
		configurer.configure(States.PROCEDUREDIVISION).onEntry(buildRunAction(() -> {stateProcess.proceduredivision(lctx, ctrl);}))
		.permit(Events.TO__0000_START, States._0000_START)
		;	
		configurer.configure(States._0000_START).onEntry(buildRunAction(() -> {stateProcess._0000Start(lctx, ctrl);}))
		.permit(Events.TO__8100_FILE_OPEN, States._8100_FILE_OPEN)
		.permit(Events.TO_FINAL, States.FINAL)
		;	
		configurer.configure(States._8100_FILE_OPEN).onEntry(buildRunAction(() -> {stateProcess._8100FileOpen(lctx, ctrl);}))
		.permit(Events.TO__0000_START, States._0000_START)
		.permit(Events.TO_FINAL, States.FINAL)
		;	
		return configurer;
	}
	
}
