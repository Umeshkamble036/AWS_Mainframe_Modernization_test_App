
package com.company.app.cotrn02c.service.impl;

import com.company.app.core.helper.BluageUtils;
import com.company.app.cotrn02c.business.context.Cotrn02cContext;
import com.company.app.cotrn02c.service.Cotrn02cProcess;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.NumberUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.bms.ReceiveMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.jics.io.internal.JicsFileBuilder;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.statements.CallBuilder;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Cotrn02cProcessImpl
 * 
 * Defines application services for Cotrn02cProcess
 * @see Cotrn02cProcess
 */
@Service("com.company.app.cotrn02c.service.Cotrn02cProcess")
@Lazy

public class Cotrn02cProcessImpl implements Cotrn02cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Cotrn02cProcessImpl.class);


	/**
	 * Process operation mainPara.
	 * 
	 * PROGRAM-ID.COTRN02C.
	 *  AUTHOR.     AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void mainPara(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		*****************************************************************
		Program     : COTRN02C.CBL
		Application : CardDemo
		Type        : CICS COBOL Program
		Function    : Add a new Transaction to TRANSACT file
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		----------------------------------------------------------------*
		WORKING STORAGE SECTION
		----------------------------------------------------------------*
		No background transparency
		----------------------------------------------------------------*
		LINKAGE SECTION
		----------------------------------------------------------------*
		----------------------------------------------------------------*
		PROCEDURE DIVISION
		----------------------------------------------------------------* */
		ctx.getWsVariables().setErrFlgOff(true);
		ctx.getWsVariables().setUsrModifiedNo(true);
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		FIXME: ERRMSGO OF COTRN2AO */
		BluageUtils.unsupported();
		if (ctx.getDfheiblk().getEibcalen() == 0) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
			returnToPrevScreen(ctx, ctrl);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			if (!(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-PGM-REENTER */
				BluageUtils.unsupported();
				
				/* 
				FIXME: COTRN2AO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: ACTIDINL OF COTRN2AI */
				BluageUtils.unsupported();
				if (!(DataUtils.isBlank(ctx.getCsutldtcParm().getCdemoCt02TrnSelectedReference())) && !(DataUtils.isLowValue(ctx.getCsutldtcParm().getCdemoCt02TrnSelectedReference()))) {
					
					/* 
					FIXME: CARDNINI OF COTRN2AI */
					BluageUtils.unsupported();
					processEnterKey(ctx, ctrl);
				} 
				sendTrnaddScreen(ctx, ctrl);
			} else {
				receiveTrnaddScreen(ctx, ctrl);
				if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) == 0) {
					processEnterKey(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf3Reference()) == 0) {
					if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
						
						/* 
						FIXME: CDEMO-TO-PROGRAM */
						BluageUtils.unsupported();
					} else {
						
						/* 
						FIXME: CDEMO-TO-PROGRAM */
						BluageUtils.unsupported();
					}
					returnToPrevScreen(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf4Reference()) == 0) {
					clearCurrentScreen(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf5Reference()) == 0) {
					copyLastTranData(ctx, ctrl);
				} else {
					ctx.getWsVariables().setWsErrFlg("Y");
					ctx.getWsVariables().setWsMessage(BluageUtils.unsupported());
					sendTrnaddScreen(ctx, ctrl);
				}
			}
		}
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsVariables().getWsTranid())
		.withCommarea(BluageUtils.unsupported())
		.execute()
		.handleException();
	}

	/**
	 * Process operation processEnterKey.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-ENTER-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processEnterKey(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		validateInputKeyFields(ctx, ctrl);
		validateInputDataFields(ctx, ctrl);
		if (DataUtils.compare("Y", BluageUtils.unsupported()) == 0 || DataUtils.compare("y", BluageUtils.unsupported()) == 0) {
			
			/* 
			FIXME: CONFIRMI OF COTRN2AIFIXME: CONFIRMI OF COTRN2AI */
			addTransaction(ctx, ctrl);
		} else if (DataUtils.compare("N", BluageUtils.unsupported()) == 0 || DataUtils.compare("n", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CONFIRMI OF COTRN2AIFIXME: CONFIRMI OF COTRN2AI */
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Confirm to add this transaction...");
			
			/* 
			FIXME: CONFIRML OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Invalid value. Valid values are (Y/N)...");
			
			/* 
			FIXME: CONFIRML OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation validateInputKeyFields.
	 * 
	 * ----------------------------------------------------------------*
	 *                       VALIDATE-INPUT-KEY-FIELDS
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void validateInputKeyFields(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			if (!(DataUtils.isNumeric(BluageUtils.unsupported()))) {
				ctx.getWsVariables().setWsErrFlg("Y");
				ctx.getWsVariables().setWsMessage("Account ID must be Numeric...");
				
				/* 
				FIXME: ACTIDINL OF COTRN2AI */
				BluageUtils.unsupported();
				sendTrnaddScreen(ctx, ctrl);
			} 
			ctx.getWsVariables().setWsAcctIdN(NumberUtils.convert(BluageUtils.unsupported()).longValue());
			
			/* 
			FIXME: XREF-ACCT-ID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACTIDINI OF COTRN2AI */
			BluageUtils.unsupported();
			readCxacaixFile(ctx, ctrl);
			
			/* 
			FIXME: CARDNINI OF COTRN2AI */
			BluageUtils.unsupported();
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			if (!(DataUtils.isNumeric(BluageUtils.unsupported()))) {
				ctx.getWsVariables().setWsErrFlg("Y");
				ctx.getWsVariables().setWsMessage("Card Number must be Numeric...");
				
				/* 
				FIXME: CARDNINL OF COTRN2AI */
				BluageUtils.unsupported();
				sendTrnaddScreen(ctx, ctrl);
			} 
			ctx.getWsVariables().setWsCardNumN(NumberUtils.convert(BluageUtils.unsupported()).longValue());
			
			/* 
			FIXME: XREF-CARD-NUM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CARDNINI OF COTRN2AI */
			BluageUtils.unsupported();
			readCcxrefFile(ctx, ctrl);
			
			/* 
			FIXME: ACTIDINI OF COTRN2AI */
			BluageUtils.unsupported();
		} else {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Account or Card Number must be entered...");
			
			/* 
			FIXME: ACTIDINL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation validateInputDataFields.
	 * 
	 * ----------------------------------------------------------------*
	 *                  VALIDATE-INPUT-DATA-FIELDS
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void validateInputDataFields(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		if (ctx.getWsVariables().isErrFlgOn()) {
			
			/* 
			FIXME: TTYPCDI  OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TCATCDI  OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TRNSRCI  OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TRNAMTI  OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESCI   OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TORIGDTI OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TPROCDTI OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MIDI     OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MNAMEI   OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MCITYI   OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MZIPI    OF COTRN2AI */
			BluageUtils.unsupported();
		} 
		if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Type CD can NOT be empty...");
			
			/* 
			FIXME: TTYPCDL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Category CD can NOT be empty...");
			
			/* 
			FIXME: TCATCDL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Source can NOT be empty...");
			
			/* 
			FIXME: TRNSRCL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Description can NOT be empty...");
			
			/* 
			FIXME: TDESCL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Amount can NOT be empty...");
			
			/* 
			FIXME: TRNAMTL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Orig Date can NOT be empty...");
			
			/* 
			FIXME: TORIGDTL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Proc Date can NOT be empty...");
			
			/* 
			FIXME: TPROCDTL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Merchant ID can NOT be empty...");
			
			/* 
			FIXME: MIDL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Merchant Name can NOT be empty...");
			
			/* 
			FIXME: MNAMEL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Merchant City can NOT be empty...");
			
			/* 
			FIXME: MCITYL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Merchant Zip can NOT be empty...");
			
			/* 
			FIXME: MZIPL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else {
			
			/* 
			Do nothing */
		}
		if (!(DataUtils.isNumeric(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Type CD must be Numeric...");
			
			/* 
			FIXME: TTYPCDL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else if (!(DataUtils.isNumeric(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Category CD must be Numeric...");
			
			/* 
			FIXME: TCATCDL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else {
			
			/* 
			Do nothing */
		}
		if ((DataUtils.compare("-", BluageUtils.unsupported()) != 0 && DataUtils.compare("+", BluageUtils.unsupported()) != 0) || !(DataUtils.isNumeric(BluageUtils.unsupported())) || DataUtils.compare(".", BluageUtils.unsupported()) != 0 || !(DataUtils.isNumeric(BluageUtils.unsupported()))) {
			
			/* 
			FIXME: TRNAMTI OF COTRN2AI(1:1)FIXME: TRNAMTI OF COTRN2AI(1:1)FIXME: TRNAMTI OF COTRN2AI(10:1) */
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Amount should be in format -99999999.99");
			
			/* 
			FIXME: TRNAMTL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else {
			
			/* 
			Do nothing */
		}
		if (!(DataUtils.isNumeric(BluageUtils.unsupported())) || DataUtils.compare("-", BluageUtils.unsupported()) != 0 || !(DataUtils.isNumeric(BluageUtils.unsupported())) || DataUtils.compare("-", BluageUtils.unsupported()) != 0 || !(DataUtils.isNumeric(BluageUtils.unsupported()))) {
			
			/* 
			FIXME: TORIGDTI OF COTRN2AI(5:1)FIXME: TORIGDTI OF COTRN2AI(8:1) */
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Orig Date should be in format YYYY-MM-DD");
			
			/* 
			FIXME: TORIGDTL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else {
			
			/* 
			Do nothing */
		}
		if (!(DataUtils.isNumeric(BluageUtils.unsupported())) || DataUtils.compare("-", BluageUtils.unsupported()) != 0 || !(DataUtils.isNumeric(BluageUtils.unsupported())) || DataUtils.compare("-", BluageUtils.unsupported()) != 0 || !(DataUtils.isNumeric(BluageUtils.unsupported()))) {
			
			/* 
			FIXME: TPROCDTI OF COTRN2AI(5:1)FIXME: TPROCDTI OF COTRN2AI(8:1) */
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Proc Date should be in format YYYY-MM-DD");
			
			/* 
			FIXME: TPROCDTL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else {
			
			/* 
			Do nothing */
		}
		ctx.getWsVariables().setWsTranAmtN(NumberUtils.convert(BluageUtils.unsupported()));
		ctx.getWsVariables().getWsTranAmtEReference().setValue(ctx.getWsVariables().getWsTranAmtN());
		
		/* 
		FIXME: TRNAMTI OF COTRN2AI */
		BluageUtils.unsupported();
		ctx.getCsutldtcParm().setCsutldtcDate(BluageUtils.unsupported());
		ctx.getCsutldtcParm().getCsutldtcDateFormatReference().setValue(ctx.getWsVariables().getWsDateFormatReference());
		DataUtils.setToBlank(ctx.getCsutldtcParm().getCsutldtcResultReference());
		ctrl.callSubProgram("CSUTLDTC", CallBuilder.newInstance()
			.byReference(ctx.getCsutldtcParm().getCsutldtcDateReference())
			.byReference(ctx.getCsutldtcParm().getCsutldtcDateFormatReference())
			.byReference(ctx.getCsutldtcParm().getCsutldtcResultReference())
			.getArguments(), ctx);
		if (DataUtils.compare(ctx.getCsutldtcParm().getCsutldtcResultSevCdReference(), "0000") == 0) {
			
			/* 
			Do nothing */
		} else {
			if (DataUtils.compare(ctx.getCsutldtcParm().getCsutldtcResultMsgNumReference(), "2513") != 0) {
				ctx.getWsVariables().setWsMessage("Orig Date - Not a valid date...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: TORIGDTL OF COTRN2AI */
				BluageUtils.unsupported();
				sendTrnaddScreen(ctx, ctrl);
			} 
		}
		ctx.getCsutldtcParm().setCsutldtcDate(BluageUtils.unsupported());
		ctx.getCsutldtcParm().getCsutldtcDateFormatReference().setValue(ctx.getWsVariables().getWsDateFormatReference());
		DataUtils.setToBlank(ctx.getCsutldtcParm().getCsutldtcResultReference());
		ctrl.callSubProgram("CSUTLDTC", CallBuilder.newInstance()
			.byReference(ctx.getCsutldtcParm().getCsutldtcDateReference())
			.byReference(ctx.getCsutldtcParm().getCsutldtcDateFormatReference())
			.byReference(ctx.getCsutldtcParm().getCsutldtcResultReference())
			.getArguments(), ctx);
		if (DataUtils.compare(ctx.getCsutldtcParm().getCsutldtcResultSevCdReference(), "0000") == 0) {
			
			/* 
			Do nothing */
		} else {
			if (DataUtils.compare(ctx.getCsutldtcParm().getCsutldtcResultMsgNumReference(), "2513") != 0) {
				ctx.getWsVariables().setWsMessage("Proc Date - Not a valid date...");
				ctx.getWsVariables().setWsErrFlg("Y");
				
				/* 
				FIXME: TPROCDTL OF COTRN2AI */
				BluageUtils.unsupported();
				sendTrnaddScreen(ctx, ctrl);
			} 
		}
		if (!(DataUtils.isNumeric(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Merchant ID must be Numeric...");
			
			/* 
			FIXME: MIDL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation addTransaction.
	 * 
	 * ----------------------------------------------------------------*
	 *                         ADD-TRANSACTION
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void addTransaction(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: TRAN-ID */
		BluageUtils.unsupported();
		startbrTransactFile(ctx, ctrl);
		readprevTransactFile(ctx, ctrl);
		endbrTransactFile(ctx, ctrl);
		ctx.getWsVariables().setWsTranIdN(BluageUtils.unsupported());
		ctx.getWsVariables().setWsTranIdN(ctx.getWsVariables().getWsTranIdN() + 1);
		DataUtils.initialize(BluageUtils.unsupported());
		
		/* 
		FIXME: TRAN-ID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-TYPE-CD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-CAT-CD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-SOURCE */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-DESC */
		BluageUtils.unsupported();
		ctx.getWsVariables().setWsTranAmtN(NumberUtils.convert(BluageUtils.unsupported()));
		
		/* 
		FIXME: TRAN-AMT */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-CARD-NUM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-MERCHANT-ID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-MERCHANT-NAME */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-MERCHANT-CITY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-MERCHANT-ZIP */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-ORIG-TS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-PROC-TS */
		BluageUtils.unsupported();
		writeTransactFile(ctx, ctrl);
	}

	/**
	 * Process operation copyLastTranData.
	 * 
	 * ----------------------------------------------------------------*
	 *                       COPY-LAST-TRAN-DATA
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void copyLastTranData(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		validateInputKeyFields(ctx, ctrl);
		
		/* 
		FIXME: TRAN-ID */
		BluageUtils.unsupported();
		startbrTransactFile(ctx, ctrl);
		readprevTransactFile(ctx, ctrl);
		endbrTransactFile(ctx, ctrl);
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			ctx.getWsVariables().setWsTranAmtE(BluageUtils.unsupported());
			
			/* 
			FIXME: TTYPCDI  OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TCATCDI  OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TRNSRCI  OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TRNAMTI  OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESCI   OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TORIGDTI OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TPROCDTI OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MIDI     OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MNAMEI   OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MCITYI   OF COTRN2AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: MZIPI    OF COTRN2AI */
			BluageUtils.unsupported();
		} 
		processEnterKey(ctx, ctrl);
	}

	/**
	 * Process operation returnToPrevScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RETURN-TO-PREV-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void returnToPrevScreen(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
		} 
		
		/* 
		FIXME: CDEMO-FROM-TRANID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-FROM-PROGRAM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-PGM-CONTEXT */
		BluageUtils.unsupported();
		XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
	}

	/**
	 * Process operation sendTrnaddScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       SEND-TRNADD-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendTrnaddScreen(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		populateHeaderInfo(ctx, ctrl);
		
		/* 
		FIXME: ERRMSGO OF COTRN2AO */
		BluageUtils.unsupported();
		SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withMap("COTRN2A")
		.withMapset("COTRN02")
		.withData(BluageUtils.unsupported())
		.withErase()
		.withCursor()
		.execute()
		.handleException();
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsVariables().getWsTranid())
		.withCommarea(BluageUtils.unsupported())
		.execute()
		.handleException();
	}

	/**
	 * Process operation receiveTrnaddScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RECEIVE-TRNADD-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void receiveTrnaddScreen(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		ReceiveMapBuilder.newInstance(ctx.getJicsEiblk(), ctrl.getExecutionContext(), ctx)
		.withMap("COTRN2A")
		.withMapset("COTRN02")
		.into(BluageUtils.unsupported())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
	}

	/**
	 * Process operation populateHeaderInfo.
	 * 
	 * ----------------------------------------------------------------*
	 *                       POPULATE-HEADER-INFO
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void populateHeaderInfo(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE01O OF COTRN2AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE02O OF COTRN2AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNNAMEO OF COTRN2AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PGMNAMEO OF COTRN2AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURDATEO OF COTRN2AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-HH */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-SS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURTIMEO OF COTRN2AO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation readCxacaixFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       READ-CXACAIX-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readCxacaixFile(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsCxacaixFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Account ID NOT found...");
			
			/* 
			FIXME: ACTIDINL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup Acct in XREF AIX file...");
			
			/* 
			FIXME: ACTIDINL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation readCcxrefFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       READ-CCXREF-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readCcxrefFile(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsCcxrefFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Card Number NOT found...");
			
			/* 
			FIXME: CARDNINL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup Card # in XREF file...");
			
			/* 
			FIXME: CARDNINL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation startbrTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                     STARTBR-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void startbrTransactFile(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.startBrowse()
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Transaction ID NOT found...");
			
			/* 
			FIXME: ACTIDINL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup Transaction...");
			
			/* 
			FIXME: ACTIDINL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation readprevTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                     READPREV-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readprevTransactFile(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.readPrev()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.ENDFILE.getIntValue()) {
			
			/* 
			FIXME: TRAN-ID */
			BluageUtils.unsupported();
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup Transaction...");
			
			/* 
			FIXME: ACTIDINL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation endbrTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                     ENDBR-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void endbrTransactFile(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.endBrowse()
		.execute()
		.handleException();
	}

	/**
	 * Process operation writeTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                     WRITE-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void writeTransactFile(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.write(false)
		.from(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			initializeAllFields(ctx, ctrl);
			DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
			
			/* 
			FIXME: ERRMSGC  OF COTRN2AO */
			BluageUtils.unsupported();
			StringConcatenationBuilder.newInstance(ctx.getWsVariables().getWsMessageReference())
				.addDelimitedBySize("Transaction added successfully. ")
				.addDelimitedBySize(" Your Tran ID is ")
				.addDelimitedByLiteral(BluageUtils.unsupported()," ")
				.addDelimitedBySize(".")
				.end();
			sendTrnaddScreen(ctx, ctrl);
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.DUPKEY.getIntValue() || ctx.getWsVariables().getWsRespCd() == ResponseCode.DUPREC.getIntValue()) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Tran ID already exist...");
			
			/* 
			FIXME: ACTIDINL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to Add Transaction...");
			
			/* 
			FIXME: ACTIDINL OF COTRN2AI */
			BluageUtils.unsupported();
			sendTrnaddScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation clearCurrentScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                     CLEAR-CURRENT-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void clearCurrentScreen(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		initializeAllFields(ctx, ctrl);
		sendTrnaddScreen(ctx, ctrl);
	}

	/**
	 * Process operation initializeAllFields.
	 * 
	 * ----------------------------------------------------------------*
	 *                     INITIALIZE-ALL-FIELDS
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void initializeAllFields(final Cotrn02cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: ACTIDINL OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTIDINI OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CARDNINI OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TTYPCDI  OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TCATCDI  OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNSRCI  OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNAMTI  OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TDESCI   OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TORIGDTI OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TPROCDTI OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: MIDI     OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: MNAMEI   OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: MCITYI   OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: MZIPI    OF COTRN2AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CONFIRMI OF COTRN2AI */
		BluageUtils.unsupported();
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:34 CDT */
		return;
	}

}
