package com.company.app.cbexport.service;

import com.company.app.cbexport.business.context.CbexportContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface CbexportProcess.
 * 
 * Defines application services for CbexportProcess
 */
public interface CbexportProcess {

	/**
	 * Process operation _0000MainProcessing.
	 * 
	 * PROGRAM-ID.CBEXPORT.
	 *  AUTHOR.        CARDDEMO TEAM.
	 * *****************************************************************
	 *  Program     : CBEXPORT.CBL
	 *  Application : CardDemo
	 *  Type        : BATCH COBOL Program
	 *  Function    : Export Customer Data for Branch Migration
	 *                Reads normalized CardDemo files and creates
	 *                multi-record export file for data migration
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 *  Business Use Case: Branch Migration Export
	 *  - Read complete customer profiles from CardDemo files
	 *  - Create multi-record export file with different record types
	 *  - Generate export statistics and processing reports
	 * *****************************************************************
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000MainProcessing(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000Initialize.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000Initialize(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1050GenerateTimestamp.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1050GenerateTimestamp(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1100OpenFiles.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1100OpenFiles(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2000ExportCustomers.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000ExportCustomers(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2100ReadCustomerRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2100ReadCustomerRecord(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2200CreateCustomerExpRec.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2200CreateCustomerExpRec(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3000ExportAccounts.
	 * 
	 * ************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000ExportAccounts(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3100ReadAccountRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3100ReadAccountRecord(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3200CreateAccountExpRec.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3200CreateAccountExpRec(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _4000ExportXrefs.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4000ExportXrefs(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _4100ReadXrefRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4100ReadXrefRecord(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _4200CreateXrefExportRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4200CreateXrefExportRecord(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _5000ExportTransactions.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5000ExportTransactions(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _5100ReadTransactionRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5100ReadTransactionRecord(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _5200CreateTranExpRec.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5200CreateTranExpRec(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _5500ExportCards.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5500ExportCards(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _5600ReadCardRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5600ReadCardRecord(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _5700CreateCardExportRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5700CreateCardExportRecord(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _6000Finalize.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _6000Finalize(final CbexportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9999AbendProgram.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9999AbendProgram(final CbexportContext ctx, final ExecutionController ctrl);

}
