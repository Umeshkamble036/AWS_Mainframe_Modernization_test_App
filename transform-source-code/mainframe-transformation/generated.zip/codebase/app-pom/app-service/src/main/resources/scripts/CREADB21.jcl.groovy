// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "CREADB2"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//-------> TO DO ID : null [Line : 31] *******************************************
	mapTransfo['CODER'] = 'AWS' 
	mapTransfo['LBNM'] = '&CODER..M2.CARDDEMO' 
	mapTransfo['DB2S'] = 'DAZ1' 
	//******************************************************************** 
	//***  STEP 00 : Free existing plans and packages               ****** 
	//***          : It ends with RC 8 if not existing.             ****** 
	//***          : So dont run it if creating new database        ****** 
	//******************************************************************** 
	lastProgramResult = stepFREEPLN(shell, params, programResults)
	//******************************************************************** 
	//***  STEP 10 : Use Utility DSNTIAD to create the database     ****** 
	//***            This uses an existing STOGROUP AWST1STG        ****** 
	//***            You would have to create it if not available   ****** 
	//******************************************************************** 
	lastProgramResult = stepCRCRDDB(shell, params, programResults)
	//******************************************************************** 
	//***  STEP 20 : Load the transaction Type table                ****** 
	//***            using DSNTEP4 utility                          ****** 
	//******************************************************************** 
	lastProgramResult = stepLDTTYPE(shell, params, programResults)
	lastProgramResult = stepRUNTEP2(shell, params, programResults)
	//******************************************************************** 
	//***  STEP 30 : Load Transaction Type Category table           ****** 
	//***            using DSNTEP4 utility                          ****** 
	//******************************************************************** 
	lastProgramResult = stepLDTCCAT(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP FREEPLN - PGM - IKJEFT01**************************************************
def stepFREEPLN(Object shell, Map params, Map programResults){
	mapTransfo['CODER'] = 'AWS' 
	mapTransfo['LBNM'] = '&CODER..M2.CARDDEMO' 
	mapTransfo['DB2S'] = 'DAZ1' 
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("FREEPLN", "IKJEFT01", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.concatenation("STEPLIB")
						.path("OEM.DB2.DAZ1.SDSNEXIT")
						.disposition("SHR")
						.path("OEMA.DB2.VERSIONA.SDSNLOAD")
						.disposition("SHR")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.systemOut("SYSTSPRT")
						.output("*")
						.build()
						.systemOut("SYSUDUMP")
						.output("*")
						.build()
						.fileSystem("SYSTSIN")
						.path("&LBNM..CNTL(DB2FREE)")
						.disposition("SHR")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IKJEFT01")
				})
		}
	}
}
// STEP CRCRDDB - PGM - IKJEFT01**************************************************
def stepCRCRDDB(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("CRCRDDB", "IKJEFT01", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.concatenation("STEPLIB")
						.path("OEM.DB2.&DB2S..RUNLIB.LOAD")
						.disposition("SHR")
						.path("OEMA.DB2.VERSIONA.SDSNLOAD")
						.disposition("SHR")
						.build()
						.systemOut("SYSTSPRT")
						.output("*")
						.build()
						.systemOut("SYSUDUMP")
						.output("*")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSTSIN")
						.path("&LBNM..CNTL(DB2TIAD1)")
						.disposition("SHR")
						.build()
						.fileSystem("SYSIN")
						.path("&LBNM..CNTL(DB2CREAT)")
						.disposition("SHR")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IKJEFT01")
				})
		}
	}
}
// STEP LDTTYPE - PGM - IEFBR14***************************************************
def stepLDTTYPE(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("LDTTYPE", "IEFBR14", programResults, {
					mpr
						.withParameters(params)
						.runProgram("IEFBR14")
					})
			}
		}
	}
}
// STEP RUNTEP2 - PGM - IKJEFT01**************************************************
def stepRUNTEP2(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("RUNTEP2", "IKJEFT01", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.concatenation("STEPLIB")
						.path("OEM.DB2.&DB2S..RUNLIB.LOAD")
						.disposition("SHR")
						.path("OEMA.DB2.VERSIONA.SDSNLOAD")
						.disposition("SHR")
						.build()
						.systemOut("SYSTSPRT")
						.output("*")
						.build()
						.systemOut("SYSUDUMP")
						.output("*")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSTSIN")
						.path("&LBNM..CNTL(DB2TEP41)")
						.disposition("SHR")
						.build()
						.fileSystem("SYSIN")
						.path("&LBNM..CNTL(DB2LTTYP)")
						.disposition("SHR")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IKJEFT01")
				})
		}
	}
}
// STEP LDTCCAT - PGM - IKJEFT01**************************************************
def stepLDTCCAT(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("LDTCCAT", "IKJEFT01", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.concatenation("STEPLIB")
							.path("OEM.DB2.&DB2S..RUNLIB.LOAD")
							.disposition("SHR")
							.path("OEMA.DB2.VERSIONA.SDSNLOAD")
							.disposition("SHR")
							.build()
							.systemOut("SYSTSPRT")
							.output("*")
							.build()
							.systemOut("SYSUDUMP")
							.output("*")
							.build()
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.fileSystem("SYSTSIN")
							.path("&LBNM..CNTL(DB2TEP41)")
							.disposition("SHR")
							.build()
							.fileSystem("SYSIN")
							.path("&LBNM..CNTL(DB2LTCAT)")
							.disposition("SHR")
							.build()
							.getFileConfigurations())
						.withParameters(params)
						.runProgram("IKJEFT01")
					})
			}
		}
	}
}
