
package com.company.app.cotrtupc.statemachine;

import com.company.app.core.helper.BluageUtils;
import com.company.app.cotrtupc.business.context.CotrtupcContext;
import com.company.app.cotrtupc.service.CotrtupcProcess;
import com.company.app.cotrtupc.statemachine.CotrtupcProcedureDivisionStateMachineController.Events;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.control.HandleAbendBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.jics.internal.JicsSyncpointBuilder;
import com.netfective.bluage.gapwalk.rt.statemachine.StateMachineControllerWithContinuation;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Service class containing states process used to drive state machine "CotrtupcProcedureDivisionStateMachine".
 */
@Service("com.company.app.cotrtupc.statemachine.CotrtupcProcedureDivisionStateMachineService")
@Lazy
public class CotrtupcProcedureDivisionStateMachineService {
	
	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(CotrtupcProcedureDivisionStateMachineService.class);

	/**
	 * The associated state machine controller.
	 */
	@Autowired
	@Qualifier("com.company.app.cotrtupc.statemachine.CotrtupcProcedureDivisionStateMachineController")	
	private StateMachineControllerWithContinuation<Events> instanceStateMachineController;
	
	
	/**
	 * Service used by the state machine.
	 */
	@Autowired
	@Qualifier("com.company.app.cotrtupc.service.CotrtupcProcess")
	private CotrtupcProcess instanceCotrtupcProcess;
	
	
	

	/**
	 * State process operation _0000Main.
	 * 
	 * PROGRAM-ID.COTRTUPC.
	 *  DATE-WRITTEN.
	 *      Dec 2022.
	 *  DATE-COMPILED.
	 *      Today.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000Main(CotrtupcContext ctx, ExecutionController ctrl) {
		instanceStateMachineController.registerSignalHandler(Events.TO_ABEND_ROUTINE, ctx, "ABEND_1_VIRTUAL_SIGNAL");
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		*************************************** *************************
		Program:     COTRTUPC.CBL                                      *
		Layer:       Business logic                                    *
		Function:    Accept and process TRANSACTION TYPE UPDATE        *
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		***************************************************************** */
		ctx.getSignalHandlersController().activateSignalHandler("ABEND_1_VIRTUAL_SIGNAL","!ABEND");
		HandleAbendBuilder.newInstance(ctx.getJicsEiblk(), ctx).execute().handleException();
		DataUtils.initialize(BluageUtils.unsupported());
		ctx.getWsMiscStorage().getField().initialize();
		DataUtils.initialize(ctx.getWsCommarea().getWsCommareaReference());
		
		/* 
		****************************************************************
		Store our context
		**************************************************************** */
		ctx.getWsMiscStorage().getWsTranidReference().setValue(ctx.getWsLiterals().getLitThistranidReference());
		
		/* 
		****************************************************************
		Ensure error message is cleared                               *
		**************************************************************** */
		ctx.getWsMiscStorage().setWsReturnMsgOff(true);
		
		/* 
		****************************************************************
		Store passed data if  any                *
		**************************************************************** */
		if (ctx.getDfheiblk().getEibcalen() == 0 || (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitAdminpgmReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), BluageUtils.unsupported()) != 0) || (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitListtpgmReference()) == 0 && DataUtils.compare(BluageUtils.unsupported(), BluageUtils.unsupported()) != 0)) {
			DataUtils.initialize(BluageUtils.unsupported());
			ctx.getWsThisProgcommarea().getField().initialize();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setTtupDetailsNotFetched(true);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			int idx = BluageUtils.unsupported().length() + 1 - 1;
			int len = ctx.getWsThisProgcommarea().getSize();
			ctx.getWsThisProgcommarea().setBytes(ctx.getDfhcommarea().getBytes(idx, len));
		}
		
		/* 
		FIXME:PERFORM YYYY-STORE-PFKEY
		THRU YYYY-STORE-PFKEY-EXIT
		****************************************************************
		Store the Mapped PF Key
		Remap PFkeys as needed.
		**************************************************************** */
		BluageUtils.unsupported();
		
		/* 
		****************************************************************
		Check the AID to see if its valid at this point               *
		Change the key to some valid value if possible
		F3 - Exit
		Enter show screen again
		F4 - Delete
		F5 - Save
		F12 - Cancel
		**************************************************************** */
		ctx.getWsMiscStorage().setPfkInvalid(true);
		instanceCotrtupcProcess._0001CheckPfkeys(ctx, ctrl);
		
		/* 
		****************************************************************
		Simulate initial entry if the following flags are set
		**************************************************************** */
		if ((BluageUtils.unsupported() && (ctx.getWsThisProgcommarea().isTtupShowDetails() || ctx.getWsThisProgcommarea().isTtupCreateNewRecord() || ctx.getWsThisProgcommarea().isTtupDetailsNotFound())) || ctx.getWsThisProgcommarea().isTtupChangesOkayedAndDone() || ctx.getWsThisProgcommarea().isTtupChangesFailed() || (ctx.getWsThisProgcommarea().isTtupChangesBackedOut() && (DataUtils.isLowValue(ctx.getWsThisProgcommarea().getTtupOldDetailsReference()) || DataUtils.isBlank(ctx.getWsThisProgcommarea().getTtupOldDetailsReference()))) || ctx.getWsThisProgcommarea().isTtupDeleteDone() || ctx.getWsThisProgcommarea().isTtupDeleteFailed()) {
			
			/* 
			FIXME: CCARD-AID-PFK12 */
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setTtupDetailsNotFetched(true);
		} 
		
		/* 
		****************************************************************
		Decide what to do based on PF KEY PRESSED AND CONTEXT
		**************************************************************** */
		if (BluageUtils.unsupported()) {
			
			/* 
			FIXME: CCARD-AID-PFK03 */
			
			/* 
			****************************************************************
			USER PRESSES PF03 TO EXIT
			OR   USER IS DONE WITH UPDATE
			XCTL TO CALLING PROGRAM OR MAIN MENU
			**************************************************************** */
			if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-TO-TRANID */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: CDEMO-TO-TRANID */
				BluageUtils.unsupported();
			}
			if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-TO-PROGRAM */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: CDEMO-TO-PROGRAM */
				BluageUtils.unsupported();
			}
			
			/* 
			FIXME: CDEMO-FROM-TRANID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-FROM-PROGRAM */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-USRTYP-ADMIN */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAPSET */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-LAST-MAP */
			BluageUtils.unsupported();
			JicsSyncpointBuilder.newInstance(ctx.getJicsEiblk(), ctx)
			.commit()
			.execute()
			.handleException();
			XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
		} else if ((!(BluageUtils.unsupported()) && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitAdminpgmReference()) == 0) || (!(BluageUtils.unsupported()) && DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitListtpgmReference()) == 0) || (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isTtupDetailsNotFetched())) {
			
			/* 
			FIXME: CDEMO-PGM-REENTERFIXME: CDEMO-FROM-PROGRAMFIXME: CDEMO-PGM-REENTERFIXME: CDEMO-FROM-PROGRAMFIXME: CDEMO-PGM-ENTER */
			ctx.getWsThisProgcommarea().getField().initialize();
			ctx.getWsMiscStorage().getField().initialize();
			DataUtils.initialize(BluageUtils.unsupported());
			instanceCotrtupcProcess._3000SendMap(ctx, ctrl);
			
			/* 
			FIXME: CDEMO-PGM-REENTER */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setTtupDetailsNotFetched(true);
			instanceCotrtupcProcess.commonReturn(ctx, ctrl);
		} else if (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isTtupConfirmDelete()) {
			
			/* 
			FIXME: CCARD-AID-PFK04 */
			ctx.getWsThisProgcommarea().setTtupStartDelete(true);
			instanceCotrtupcProcess._9800DeleteProcessing(ctx, ctrl);
			instanceCotrtupcProcess._3000SendMap(ctx, ctrl);
			instanceCotrtupcProcess.commonReturn(ctx, ctrl);
		} else if (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isTtupShowDetails()) {
			
			/* 
			FIXME: CCARD-AID-PFK04 */
			ctx.getWsThisProgcommarea().setTtupConfirmDelete(true);
			instanceCotrtupcProcess._3000SendMap(ctx, ctrl);
			instanceCotrtupcProcess.commonReturn(ctx, ctrl);
		} else if (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isTtupDetailsNotFound()) {
			
			/* 
			FIXME: CCARD-AID-PFK05 */
			ctx.getWsThisProgcommarea().setTtupCreateNewRecord(true);
			instanceCotrtupcProcess._3000SendMap(ctx, ctrl);
			instanceCotrtupcProcess.commonReturn(ctx, ctrl);
		} else if (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isTtupChangesOkNotConfirmed()) {
			
			/* 
			FIXME: CCARD-AID-PFK05 */
			instanceCotrtupcProcess._9600WriteProcessing(ctx, ctrl);
			instanceCotrtupcProcess._3000SendMap(ctx, ctrl);
			instanceCotrtupcProcess.commonReturn(ctx, ctrl);
		} else if (BluageUtils.unsupported() && (ctx.getWsThisProgcommarea().isTtupChangesOkNotConfirmed() || ctx.getWsThisProgcommarea().isTtupConfirmDelete() || ctx.getWsThisProgcommarea().isTtupShowDetails())) {
			
			/* 
			FIXME: CCARD-AID-PFK12 */
			instanceStateMachineController.sendEvent(Events.TO__0000_MAIN_CASEBRANCH);
			return;
		} else if (ctx.getWsMiscStorage().isWsInvalidKeyPressed()) {
			instanceCotrtupcProcess._3000SendMap(ctx, ctrl);
			instanceCotrtupcProcess.commonReturn(ctx, ctrl);
		} else {
			instanceStateMachineController.sendEvent(Events.TO__0000_MAIN_CASEBRANCH_1);
			return;
		}

	}
	/**
	 * State process operation _2000DecideAction.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideAction(CotrtupcContext ctx, ExecutionController ctrl) {
		if (ctx.getWsThisProgcommarea().isTtupDetailsNotFetched() || BluageUtils.unsupported()) {
			
			/* 
			FIXME: CCARD-AID-PFK12 */
			
			/* 
			****************************************************************
			NO DETAILS SHOWN.
			SO GET THEM AND SETUP DETAIL EDIT SCREEN
			**************************************************************** */
			if (ctx.getWsMiscStorage().isFlgTranfilterIsvalid()) {
				ctx.getWsMiscStorage().setWsReturnMsgOff(true);
				instanceCotrtupcProcess._9000ReadTrantype(ctx, ctrl);
				if (ctx.getWsMiscStorage().isFoundTrantypeInTable()) {
					ctx.getWsThisProgcommarea().setTtupShowDetails(true);
				} else {
					ctx.getWsThisProgcommarea().setTtupDetailsNotFound(true);
				}
			} else {
				if (ctx.getWsThisProgcommarea().isTtupConfirmDelete()) {
					ctx.getWsMiscStorage().setWsDeleteWasCancelled(true);
					ctx.getWsThisProgcommarea().setTtupDetailsNotFetched(true);
				} else if (ctx.getWsThisProgcommarea().isTtupChangesOkNotConfirmed()) {
					ctx.getWsMiscStorage().setWsUpdateWasCancelled(true);
					ctx.getWsThisProgcommarea().setTtupChangesBackedOut(true);
				} else {
					ctx.getWsThisProgcommarea().setTtupDetailsNotFetched(true);
				}
			}
			
			/* 
			****************************************************************
			DETAILS SHOWN
			BUT USER PRESSES F4 FOR DELETE
			ASK THE USER TO CONFIRM THE DELETE
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isTtupConfirmDelete() && BluageUtils.unsupported()) {
			
			/* 
			FIXME: CCARD-AID-PFK12 */
			ctx.getWsThisProgcommarea().setTtupConfirmDelete(true);
			
			/* 
			****************************************************************
			DETAILS SHOWN
			CHECK CHANGES AND ASK CONFIRMATION IF GOOD
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isTtupShowDetails()) {
			if (ctx.getWsMiscStorage().isInputError() || ctx.getWsMiscStorage().isNoChangesDetected() || ctx.getWsMiscStorage().isWsInvalidKey()) {
				
				/* 
				Do nothing */
			} else {
				ctx.getWsThisProgcommarea().setTtupChangesOkNotConfirmed(true);
			}
			
			/* 
			****************************************************************
			DETAILS SHOWN
			BUT INPUT EDIT ERRORS FOUND
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isTtupChangesNotOk()) {
			
			/* 
			Do nothing
			****************************************************************
			CHANGES BACKED OUT
			GO BACK TO CHANGES NOT OK STATE
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isTtupChangesBackedOut()) {
			ctx.getWsThisProgcommarea().setTtupChangesNotOk(true);
			
			/* 
			****************************************************************
			PROBLEMS FOUND IN SEARCH KEYS
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isTtupInvalidSearchKeys()) {
			
			/* 
			Do nothing
			****************************************************************
			SEARCH KEY WAS VALID.
			BUT DATA WAS NOT FOUND IN TABLE
			CUSTOMER DECIDES TO CONTINUE AND ADD RECORD
			**************************************************************** */
		} else if (BluageUtils.unsupported() && ctx.getWsThisProgcommarea().isTtupDetailsNotFound()) {
			
			/* 
			FIXME: CCARD-AID-PFK05 */
			ctx.getWsThisProgcommarea().setTtupCreateNewRecord(true);
			
			/* 
			****************************************************************
			DETAILS EDITED , FOUND OK, CONFIRM SAVE REQUESTED
			CONFIRMATION NOT GIVEN. SO SHOW DETAILS AGAIN
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isTtupChangesOkNotConfirmed()) {
			
			/* 
			Do nothing
			****************************************************************
			SHOW CONFIRMATION. GO BACK TO SQUARE 1
			**************************************************************** */
		} else if (ctx.getWsThisProgcommarea().isTtupChangesOkayedAndDone()) {
			ctx.getWsThisProgcommarea().setTtupShowDetails(true);
			if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-CARD-NUM */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-ACCT-STATUS */
				BluageUtils.unsupported();
			} 
		} else {
			instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION_CASEBRANCH);
			return;
		}
		instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION_POSTIF);

	}
	/**
	 * State process operation abendRoutine.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void abendRoutine(CotrtupcContext ctx, ExecutionController ctrl) {
				boolean res = false; 
		instanceCotrtupcProcess.abendRoutine(ctx, ctrl);
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF_ABEND_ROUTINE");
		if (res) {
			return;
		} else {
			instanceStateMachineController.sendEvent(Events.TO_FINAL);
		}

	}
	/**
	 * State process operation _0000MainCasebranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000MainCasebranch(CotrtupcContext ctx, ExecutionController ctrl) {
		ctx.getWsMiscStorage().setFoundTrantypeInTable(true);
		instanceStateMachineController.addContinuationEvent(Events.TO__0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT, "END_OF__2000_DECIDE_ACTION_POSTIF");
		instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION);

	}
	/**
	 * State process operation _0000MainCasebranch1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000MainCasebranch1(CotrtupcContext ctx, ExecutionController ctrl) {
		instanceCotrtupcProcess._1000ProcessInputs(ctx, ctrl);
		instanceStateMachineController.addContinuationEvent(Events.TO__0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT_1, "END_OF__2000_DECIDE_ACTION_POSTIF");
		instanceStateMachineController.sendEvent(Events.TO__2000_DECIDE_ACTION);

	}
	/**
	 * State process operation _2000DecideActionPostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideActionPostif(CotrtupcContext ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__2000_DECIDE_ACTION_POSTIF");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation _2000DecideActionCasebranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000DecideActionCasebranch(CotrtupcContext ctx, ExecutionController ctrl) {
		
		/* 
		FIXME: ABEND-CULPRIT */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ABEND-CODE */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ABEND-REASON */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ABEND-MSG */
		BluageUtils.unsupported();
		instanceStateMachineController.addContinuationEvent(Events.TO__2000_DECIDE_ACTION_POSTIF, "END_OF_ABEND_ROUTINE");
		instanceStateMachineController.sendEvent(Events.TO_ABEND_ROUTINE);

	}
	/**
	 * State process operation _0000MainPost2000decideactionThru2000decideactionexit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000MainPost2000decideactionThru2000decideactionexit(CotrtupcContext ctx, ExecutionController ctrl) {
		instanceCotrtupcProcess._3000SendMap(ctx, ctrl);
		instanceCotrtupcProcess.commonReturn(ctx, ctrl);

	}
	/**
	 * State process operation _0000MainPost2000decideactionThru2000decideactionexit1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000MainPost2000decideactionThru2000decideactionexit1(CotrtupcContext ctx, ExecutionController ctrl) {
		instanceCotrtupcProcess._3000SendMap(ctx, ctrl);
		instanceCotrtupcProcess.commonReturn(ctx, ctrl);

	}
}
