// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "CBEXPORT"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//*****************************************************************
	// Copyright Amazon.com, Inc. or its affiliates.                   
	// All Rights Reserved.                                            
	//                                                                 
	// Licensed under the Apache License, Version 2.0 (the "License"). 
	// You may not use this file except in compliance with the License.
	// You may obtain a copy of the License at                         
	//                                                                 
	//    http://www.apache.org/licenses/LICENSE-2.0                   
	//                                                                 
	// Unless required by applicable law or agreed to in writing,      
	// software distributed under the License is distributed on an     
	// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,    
	// either express or implied. See the License for the specific     
	// language governing permissions and limitations under the License
	// *******************************************************************
	// EXPORT CUSTOMER DATA FROM VSAM FILES TO MULTI-RECORD EXPORT FILE
	// FOR BRANCH MIGRATION OR DATA TRANSFER PURPOSES
	// *******************************************************************
	// STEP 1: DEFINE VSAM CLUSTER FOR EXPORT FILE
	// *******************************************************************
	lastProgramResult = stepSTEP01(shell, params, programResults)
	// *******************************************************************
	// STEP 2: RUN EXPORT PROGRAM
	// *******************************************************************
	lastProgramResult = stepSTEP02(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP STEP01 - PGM - IDCAMS*****************************************************
def stepSTEP01(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP01", "IDCAMS", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.fileSystem("SYSIN")
						.stream(
"""  DELETE AWS.M2.CARDDEMO.EXPORT.DATA CLUSTER PURGE
  SET MAXCC = 0
  
  DEFINE CLUSTER (NAME(AWS.M2.CARDDEMO.EXPORT.DATA) -
                  INDEXED -
                  KEYS(4 28) -
                  RECORDSIZE(500 500) -
                  CYLINDERS(10 5) -
                  FREESPACE(10 10) -
                  SHAREOPTIONS(2 3)) -
         DATA (NAME(AWS.M2.CARDDEMO.EXPORT.DATA.DATA)) -
         INDEX (NAME(AWS.M2.CARDDEMO.EXPORT.DATA.INDEX))""", getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IDCAMS")
				})
		}
	}
}
// STEP STEP02 - PGM - CBEXPORT***************************************************
def stepSTEP02(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP02", "CBEXPORT", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.bluesam("STEPLIB")
						.dataset("AWS.M2.CARDDEMO.LOADLIB")
						.disposition("SHR")
						.build()
						.bluesam("CUSTFILE")
						.dataset("AWS.M2.CARDDEMO.CUSTDATA.VSAM.KSDS")
						.disposition("SHR")
						.build()
						.bluesam("ACCTFILE")
						.dataset("AWS.M2.CARDDEMO.ACCTDATA.VSAM.KSDS")
						.disposition("SHR")
						.build()
						.bluesam("XREFFILE")
						.dataset("AWS.M2.CARDDEMO.CARDXREF.VSAM.KSDS")
						.disposition("SHR")
						.build()
						.bluesam("TRANSACT")
						.dataset("AWS.M2.CARDDEMO.TRANSACT.VSAM.KSDS")
						.disposition("SHR")
						.build()
						.bluesam("CARDFILE")
						.dataset("AWS.M2.CARDDEMO.CARDDATA.VSAM.KSDS")
						.disposition("SHR")
						.build()
						.bluesam("EXPFILE")
						.dataset("AWS.M2.CARDDEMO.EXPORT.DATA")
						.disposition("SHR")
						.build()
						.systemOut("SYSOUT")
						.output("*")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("CBEXPORT")
				})
		}
	}
}
