// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "TXT2PDF1"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//
	//*****************************************************************
	// Copyright Amazon.com, Inc. or its affiliates.
	// All Rights Reserved.
	//
	// Licensed under the Apache License, Version 2.0 (the "License").
	// You may not use this file except in compliance with the License.
	// You may obtain a copy of the License at
	//
	//    http://www.apache.org/licenses/LICENSE-2.0
	//
	// Unless required by applicable law or agreed to in writing,
	// software distributed under the License is distributed on an
	// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	// either express or implied. See the License for the specific
	// language governing permissions and limitations under the License
	// *******************************************************************
	//
	// ********************************************************`***********
	// CONVERT TEXT FILE TO A PDF FILE
	// *******************************************************************
	//
	lastProgramResult = stepTXT2PDF(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP TXT2PDF - PGM - IKJEFT1B**************************************************
def stepTXT2PDF(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'NE', 0)) {
				return execStep("TXT2PDF", "IKJEFT1B", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.bluesam("STEPLIB")
							.dataset("AWS.M2.LBD.TXT2PDF.LOAD")
							.disposition("SHR")
							.build()
							.bluesam("SYSEXEC")
							.dataset("AWS.M2.LBD.TXT2PDF.EXEC")
							.disposition("SHR")
							.build()
							.bluesam("INDD")
							.dataset("AWS.M2.CARDDEMO.STATEMNT.PS")
							.disposition("SHR")
							.build()
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.systemOut("SYSTSPRT")
							.output("*")
							.build()
							.fileSystem("SYSTSIN")
							.stream(
""" %TXT2PDF BROWSE Y IN DD:INDD +
 OUT 'AWS.M2.CARDDEMO.STATEMNT.PS.PDF'""", getEncoding())
							.build()
							.getFileConfigurations())
						.withArguments(getParm(""))
						.withParameters(params)
						.runProgram("IKJEFT1B")
					})
			}
		}
	}
}
