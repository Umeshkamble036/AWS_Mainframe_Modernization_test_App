
package com.company.app.cousr03c.service.impl;

import com.company.app.core.helper.BluageUtils;
import com.company.app.cousr03c.business.context.Cousr03cContext;
import com.company.app.cousr03c.service.Cousr03cProcess;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.bms.ReceiveMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.jics.io.JicsIsolationLevel;
import com.netfective.bluage.gapwalk.rt.jics.io.internal.JicsFileBuilder;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Cousr03cProcessImpl
 * 
 * Defines application services for Cousr03cProcess
 * @see Cousr03cProcess
 */
@Service("com.company.app.cousr03c.service.Cousr03cProcess")
@Lazy

public class Cousr03cProcessImpl implements Cousr03cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Cousr03cProcessImpl.class);


	/**
	 * Process operation mainPara.
	 * 
	 * PROGRAM-ID.COUSR03C.
	 *  AUTHOR.     AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void mainPara(final Cousr03cContext ctx, final ExecutionController ctrl) {
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		*****************************************************************
		Program     : COUSR03C.CBL
		Application : CardDemo
		Type        : CICS COBOL Program
		Function    : Delete a user from USRSEC file
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		----------------------------------------------------------------*
		WORKING STORAGE SECTION
		----------------------------------------------------------------*
		No background transparency
		----------------------------------------------------------------*
		LINKAGE SECTION
		----------------------------------------------------------------*
		----------------------------------------------------------------*
		PROCEDURE DIVISION
		----------------------------------------------------------------* */
		ctx.getWsVariables().setErrFlgOff(true);
		ctx.getWsVariables().setUsrModifiedNo(true);
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		FIXME: ERRMSGO OF COUSR3AO */
		BluageUtils.unsupported();
		if (ctx.getDfheiblk().getEibcalen() == 0) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
			returnToPrevScreen(ctx, ctrl);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			if (!(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-PGM-REENTER */
				BluageUtils.unsupported();
				
				/* 
				FIXME: COUSR3AO */
				BluageUtils.unsupported();
				
				/* 
				FIXME: USRIDINL OF COUSR3AI */
				BluageUtils.unsupported();
				if (!(DataUtils.isBlank(ctx.getWsVariables().getCdemoCu03UsrSelectedReference())) && !(DataUtils.isLowValue(ctx.getWsVariables().getCdemoCu03UsrSelectedReference()))) {
					
					/* 
					FIXME: USRIDINI OF COUSR3AI */
					BluageUtils.unsupported();
					processEnterKey(ctx, ctrl);
				} 
				sendUsrdelScreen(ctx, ctrl);
			} else {
				receiveUsrdelScreen(ctx, ctrl);
				if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) == 0) {
					processEnterKey(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf3Reference()) == 0) {
					if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
						
						/* 
						FIXME: CDEMO-TO-PROGRAM */
						BluageUtils.unsupported();
					} else {
						
						/* 
						FIXME: CDEMO-TO-PROGRAM */
						BluageUtils.unsupported();
					}
					returnToPrevScreen(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf4Reference()) == 0) {
					clearCurrentScreen(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf5Reference()) == 0) {
					deleteUserInfo(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf12Reference()) == 0) {
					
					/* 
					FIXME: CDEMO-TO-PROGRAM */
					BluageUtils.unsupported();
					returnToPrevScreen(ctx, ctrl);
				} else {
					ctx.getWsVariables().setWsErrFlg("Y");
					ctx.getWsVariables().setWsMessage(BluageUtils.unsupported());
					sendUsrdelScreen(ctx, ctrl);
				}
			}
		}
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsVariables().getWsTranid())
		.withCommarea(BluageUtils.unsupported())
		.execute()
		.handleException();
	}

	/**
	 * Process operation processEnterKey.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-ENTER-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processEnterKey(final Cousr03cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("User ID can NOT be empty...");
			
			/* 
			FIXME: USRIDINL OF COUSR3AI */
			BluageUtils.unsupported();
			sendUsrdelScreen(ctx, ctrl);
		} else {
			
			/* 
			FIXME: USRIDINL OF COUSR3AI */
			BluageUtils.unsupported();
			
			/* 
			Do nothing */
		}
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			
			/* 
			FIXME: FNAMEI   OF COUSR3AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAMEI   OF COUSR3AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: USRTYPEI OF COUSR3AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: SEC-USR-ID */
			BluageUtils.unsupported();
			readUserSecFile(ctx, ctrl);
		} 
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			
			/* 
			FIXME: FNAMEI    OF COUSR3AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: LNAMEI    OF COUSR3AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: USRTYPEI  OF COUSR3AI */
			BluageUtils.unsupported();
			sendUsrdelScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation deleteUserInfo.
	 * 
	 * ----------------------------------------------------------------*
	 *                       DELETE-USER-INFO
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void deleteUserInfo(final Cousr03cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("User ID can NOT be empty...");
			
			/* 
			FIXME: USRIDINL OF COUSR3AI */
			BluageUtils.unsupported();
			sendUsrdelScreen(ctx, ctrl);
		} else {
			
			/* 
			FIXME: USRIDINL OF COUSR3AI */
			BluageUtils.unsupported();
			
			/* 
			Do nothing */
		}
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			
			/* 
			FIXME: SEC-USR-ID */
			BluageUtils.unsupported();
			readUserSecFile(ctx, ctrl);
			deleteUserSecFile(ctx, ctrl);
		}
	}

	/**
	 * Process operation returnToPrevScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RETURN-TO-PREV-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void returnToPrevScreen(final Cousr03cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
		} 
		
		/* 
		FIXME: CDEMO-FROM-TRANID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-FROM-PROGRAM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-PGM-CONTEXT */
		BluageUtils.unsupported();
		XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
	}

	/**
	 * Process operation sendUsrdelScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       SEND-USRDEL-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendUsrdelScreen(final Cousr03cContext ctx, final ExecutionController ctrl) {
		populateHeaderInfo(ctx, ctrl);
		
		/* 
		FIXME: ERRMSGO OF COUSR3AO */
		BluageUtils.unsupported();
		SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withMap("COUSR3A")
		.withMapset("COUSR03")
		.withData(BluageUtils.unsupported())
		.withErase()
		.withCursor()
		.execute()
		.handleException();
	}

	/**
	 * Process operation receiveUsrdelScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RECEIVE-USRDEL-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void receiveUsrdelScreen(final Cousr03cContext ctx, final ExecutionController ctrl) {
		ReceiveMapBuilder.newInstance(ctx.getJicsEiblk(), ctrl.getExecutionContext(), ctx)
		.withMap("COUSR3A")
		.withMapset("COUSR03")
		.into(BluageUtils.unsupported())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
	}

	/**
	 * Process operation populateHeaderInfo.
	 * 
	 * ----------------------------------------------------------------*
	 *                       POPULATE-HEADER-INFO
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void populateHeaderInfo(final Cousr03cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE01O OF COUSR3AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE02O OF COUSR3AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNNAMEO OF COUSR3AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PGMNAMEO OF COUSR3AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURDATEO OF COUSR3AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-HH */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-SS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURTIMEO OF COUSR3AO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation readUserSecFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       READ-USER-SEC-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readUserSecFile(final Cousr03cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsUsrsecFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.setIsolationLevel(JicsIsolationLevel.UPDATE)
		.updateNoToken()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
			ctx.getWsVariables().setWsMessage("Press PF5 key to delete this user ...");
			
			/* 
			FIXME: ERRMSGC  OF COUSR3AO */
			BluageUtils.unsupported();
			sendUsrdelScreen(ctx, ctrl);
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("User ID NOT found...");
			
			/* 
			FIXME: USRIDINL OF COUSR3AI */
			BluageUtils.unsupported();
			sendUsrdelScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup User...");
			
			/* 
			FIXME: FNAMEL OF COUSR3AI */
			BluageUtils.unsupported();
			sendUsrdelScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation deleteUserSecFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       DELETE-USER-SEC-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void deleteUserSecFile(final Cousr03cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsUsrsecFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.delete()
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			initializeAllFields(ctx, ctrl);
			DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
			
			/* 
			FIXME: ERRMSGC  OF COUSR3AO */
			BluageUtils.unsupported();
			StringConcatenationBuilder.newInstance(ctx.getWsVariables().getWsMessageReference())
				.addDelimitedBySize("User ")
				.addDelimitedByLiteral(BluageUtils.unsupported()," ")
				.addDelimitedBySize(" has been deleted ...")
				.end();
			sendUsrdelScreen(ctx, ctrl);
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("User ID NOT found...");
			
			/* 
			FIXME: USRIDINL OF COUSR3AI */
			BluageUtils.unsupported();
			sendUsrdelScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to Update User...");
			
			/* 
			FIXME: FNAMEL OF COUSR3AI */
			BluageUtils.unsupported();
			sendUsrdelScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation clearCurrentScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       CLEAR-CURRENT-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void clearCurrentScreen(final Cousr03cContext ctx, final ExecutionController ctrl) {
		initializeAllFields(ctx, ctrl);
		sendUsrdelScreen(ctx, ctrl);
	}

	/**
	 * Process operation initializeAllFields.
	 * 
	 * ----------------------------------------------------------------*
	 *                       INITIALIZE-ALL-FIELDS
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void initializeAllFields(final Cousr03cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: USRIDINL OF COUSR3AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: USRIDINI OF COUSR3AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: FNAMEI   OF COUSR3AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: LNAMEI   OF COUSR3AI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: USRTYPEI OF COUSR3AI */
		BluageUtils.unsupported();
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:35 CDT */
		return;
	}

}
