
package com.company.app.cobtupdt.service.impl;

import com.company.app.cobtupdt.business.context.CobtupdtContext;
import com.company.app.cobtupdt.service.CobtupdtProcess;
import com.netfective.bluage.gapwalk.database.support.central.SQLExecutorBuilder;
import com.netfective.bluage.gapwalk.database.support.central.SQLParameterBuilder;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.io.OpenMode;
import com.netfective.bluage.gapwalk.rt.io.SequentialFile;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import java.sql.JDBCType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class CobtupdtProcessImpl
 * 
 * Defines application services for CobtupdtProcess
 * @see CobtupdtProcess
 */
@Service("com.company.app.cobtupdt.service.CobtupdtProcess")
@Lazy

public class CobtupdtProcessImpl implements CobtupdtProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(CobtupdtProcessImpl.class);


	/**
	 * Process operation _0001OpenFiles.
	 * 
	 * PROGRAM-ID.COBTUPDT.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0001OpenFiles(final CobtupdtContext ctx, final ExecutionController ctrl) {
		_0001OpenFiles1(ctx, ctrl);
		_1002ReadRecords(ctx, ctrl);
		while (DataUtils.compare(ctx.getFlags().getLastrecReference(), "Y") != 0) {
			_1003TreatRecord(ctx, ctrl);
			_1002ReadRecords(ctx, ctrl);
		}
		_2001CloseStop(ctx, ctrl);
		ctrl.stopRunUnit();
	}

	/**
	 * Process operation _0001OpenFiles1.
	 * 
	 * *************************************** *************************
	 *  Program:     COBTUPDT.CBL                                      *
	 *  Layer:       Business logic                                    *
	 *  Function:    Update Transaction type based on user input       *
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0001OpenFiles1(final CobtupdtContext ctx, final ExecutionController ctrl) {
		SequentialFile trRecord = ctx.getTrRecordHandler(ctrl.getExecutionContext()); 
		trRecord.open(OpenMode.INPUT);
		if (DataUtils.compare("00", ctx.getWsInfStatus()) == 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "OPEN FILE OK");
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "OPEN FILE NOT OK");
		}
	}

	/**
	 * Process operation _1002ReadRecords.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1002ReadRecords(final CobtupdtContext ctx, final ExecutionController ctrl) {
		boolean eof = false; 
		boolean result = false; 
		SequentialFile trRecord = ctx.getTrRecordHandler(ctrl.getExecutionContext()); 
		result = trRecord.readNext();
		if (result) {
			ctx.getWsInputRec().setBytes(ctx.getTrRecord().getWsInputVarsReference().getBytes());
		} 
		eof = trRecord.isAtEnd();
		if (eof) {
			ctx.getFlags().setLastrec("Y");
		} 
		if (DataUtils.compare(ctx.getFlags().getLastrecReference(), "Y") != 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "PROCESSING   " , DataUtils.toString(ctx.getWsInputRec().getBytes()));
		}
	}

	/**
	 * Process operation _1003TreatRecord.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1003TreatRecord(final CobtupdtContext ctx, final ExecutionController ctrl) {
		if (DataUtils.compare(ctx.getWsInputRec().getInputRecTypeReference(), "A") == 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ADDING RECORD");
			_10031InsertDb(ctx, ctrl);
		} else if (DataUtils.compare(ctx.getWsInputRec().getInputRecTypeReference(), "U") == 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "UPDATING RECORD");
			_10032UpdateDb(ctx, ctrl);
		} else if (DataUtils.compare(ctx.getWsInputRec().getInputRecTypeReference(), "D") == 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "DELETING RECORD");
			_10033DeleteDb(ctx, ctrl);
		} else if (DataUtils.compare(ctx.getWsInputRec().getInputRecTypeReference(), "*") == 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "IGNORING COMMENTED LINE");
		} else {
			StringConcatenationBuilder.newInstance(ctx.getWorkingVariables().getWsReturnMsgReference())
				.addDelimitedBySize("ERROR: TYPE NOT VALID")
				.end();
			_9999Abend(ctx, ctrl);
		}
	}

	/**
	 * Process operation _10031InsertDb.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _10031InsertDb(final CobtupdtContext ctx, final ExecutionController ctrl) {
		/* 
		****************************************************************
		SQL TO INSERT THE RECORD
		**************************************************************** */
		SQLExecutorBuilder.newInstance(ctrl, ctx, ctx.getSqlca())
			.mapInParameter(SQLParameterBuilder.newInstance(ctx.getWsInputRec().getInputRecNumber()))
			.mapInParameter(SQLParameterBuilder.newInstance(ctx.getWsInputRec().getInputRecDesc()).type(JDBCType.VARCHAR))
			.execute("COBTUPDT_1");
		ctx.getWsMiscVars().getWsVarSqlcodeReference().setValue(ctx.getSqlca().getSqlcode());
		if (ctx.getSqlca().getSqlcode() == 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "RECORD INSERTED SUCCESSFULLY");
		} else if (ctx.getSqlca().getSqlcode() < 0) {
			StringConcatenationBuilder.newInstance(ctx.getWorkingVariables().getWsReturnMsgReference())
				.addDelimitedBySize("Error accessing:")
				.addDelimitedBySize(" TRANSACTION_TYPE table. SQLCODE:")
				.addDelimitedBySize(ctx.getWsMiscVars().getWsVarSqlcodeReference().getBytes())
				.end();
			_9999Abend(ctx, ctrl);
		}
	}

	/**
	 * Process operation _10032UpdateDb.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _10032UpdateDb(final CobtupdtContext ctx, final ExecutionController ctrl) {
		/* 
		****************************************************************
		SQL TO UPDATE THE RECORD
		**************************************************************** */
		SQLExecutorBuilder.newInstance(ctrl, ctx, ctx.getSqlca())
			.mapInParameter(SQLParameterBuilder.newInstance(ctx.getWsInputRec().getInputRecDesc()).type(JDBCType.VARCHAR))
			.mapInParameter(SQLParameterBuilder.newInstance(ctx.getWsInputRec().getInputRecNumber()).type(JDBCType.CHAR))
			.execute("COBTUPDT_2");
		ctx.getWsMiscVars().getWsVarSqlcodeReference().setValue(ctx.getSqlca().getSqlcode());
		if (ctx.getSqlca().getSqlcode() == 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "RECORD UPDATED SUCCESSFULLY");
		} else if (ctx.getSqlca().getSqlcode() == 100) {
			StringConcatenationBuilder.newInstance(ctx.getWorkingVariables().getWsReturnMsgReference())
				.addDelimitedBySize("No records found.")
				.end();
			_9999Abend(ctx, ctrl);
		} else if (ctx.getSqlca().getSqlcode() < 0) {
			StringConcatenationBuilder.newInstance(ctx.getWorkingVariables().getWsReturnMsgReference())
				.addDelimitedBySize("Error accessing:")
				.addDelimitedBySize(" TRANSACTION_TYPE table. SQLCODE:")
				.addDelimitedBySize(ctx.getWsMiscVars().getWsVarSqlcodeReference().getBytes())
				.end();
			_9999Abend(ctx, ctrl);
		}
	}

	/**
	 * Process operation _10033DeleteDb.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _10033DeleteDb(final CobtupdtContext ctx, final ExecutionController ctrl) {
		/* 
		****************************************************************
		SQL TO DELETE THE RECORD
		**************************************************************** */
		SQLExecutorBuilder.newInstance(ctrl, ctx, ctx.getSqlca())
			.mapInParameter(SQLParameterBuilder.newInstance(ctx.getWsInputRec().getInputRecNumber()).type(JDBCType.CHAR))
			.execute("COBTUPDT_3");
		ctx.getWsMiscVars().getWsVarSqlcodeReference().setValue(ctx.getSqlca().getSqlcode());
		if (ctx.getSqlca().getSqlcode() == 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "RECORD DELETED SUCCESSFULLY");
		} else if (ctx.getSqlca().getSqlcode() == 100) {
			StringConcatenationBuilder.newInstance(ctx.getWorkingVariables().getWsReturnMsgReference())
				.addDelimitedBySize("No records found.")
				.end();
			_9999Abend(ctx, ctrl);
		} else if (ctx.getSqlca().getSqlcode() < 0) {
			StringConcatenationBuilder.newInstance(ctx.getWorkingVariables().getWsReturnMsgReference())
				.addDelimitedBySize("Error accessing:")
				.addDelimitedBySize(" TRANSACTION_TYPE table. SQLCODE:")
				.addDelimitedBySize(ctx.getWsMiscVars().getWsVarSqlcodeReference().getBytes())
				.end();
			_9999Abend(ctx, ctrl);
		}
	}

	/**
	 * Process operation _9999Abend.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9999Abend(final CobtupdtContext ctx, final ExecutionController ctrl) {
		DisplayUtils.display(ctx, ctrl, LOGGER, ctx.getWorkingVariables().getWsReturnMsg());
		ctx.setReturnCode(4);
	}

	/**
	 * Process operation _2001CloseStop.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2001CloseStop(final CobtupdtContext ctx, final ExecutionController ctrl) {
		SequentialFile trRecord = ctx.getTrRecordHandler(ctrl.getExecutionContext()); 
		trRecord.close();
	}

}
