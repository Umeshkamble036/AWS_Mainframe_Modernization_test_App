package com.company.app.cbact03c.service;

import com.company.app.cbact03c.business.context.Cbact03cContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface Cbact03cProcess.
 * 
 * Defines application services for Cbact03cProcess
 */
public interface Cbact03cProcess {

	/**
	 * Process operation procedureDivision.
	 * 
	 * PROGRAM-ID.CBACT03C.
	 *  AUTHOR.        AWS.
	 * *****************************************************************
	 *  Program     : CBACT03C.CBL
	 *  Application : CardDemo
	 *  Type        : BATCH COBOL Program
	 *  Function    : Read and print account cross reference data file.
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void procedureDivision(final Cbact03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000XreffileGetNext.
	 * 
	 * ****************************************************************
	 *  I/O ROUTINES TO ACCESS A KSDS, VSAM DATA SET...               *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000XreffileGetNext(final Cbact03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0000XreffileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000XreffileOpen(final Cbact03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9000XreffileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9000XreffileClose(final Cbact03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9999AbendProgram.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9999AbendProgram(final Cbact03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9910DisplayIoStatus.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9910DisplayIoStatus(final Cbact03cContext ctx, final ExecutionController ctrl);

}
