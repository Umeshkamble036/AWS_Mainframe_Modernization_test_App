package com.company.app.cobtupdt.service;

import com.company.app.cobtupdt.business.context.CobtupdtContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface CobtupdtProcess.
 * 
 * Defines application services for CobtupdtProcess
 */
public interface CobtupdtProcess {

	/**
	 * Process operation _0001OpenFiles.
	 * 
	 * PROGRAM-ID.COBTUPDT.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0001OpenFiles(final CobtupdtContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0001OpenFiles1.
	 * 
	 * *************************************** *************************
	 *  Program:     COBTUPDT.CBL                                      *
	 *  Layer:       Business logic                                    *
	 *  Function:    Update Transaction type based on user input       *
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0001OpenFiles1(final CobtupdtContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1002ReadRecords.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1002ReadRecords(final CobtupdtContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1003TreatRecord.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1003TreatRecord(final CobtupdtContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _10031InsertDb.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _10031InsertDb(final CobtupdtContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _10032UpdateDb.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _10032UpdateDb(final CobtupdtContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _10033DeleteDb.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _10033DeleteDb(final CobtupdtContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9999Abend.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9999Abend(final CobtupdtContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2001CloseStop.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2001CloseStop(final CobtupdtContext ctx, final ExecutionController ctrl);

}
