// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "IMSMQCMP"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	mapTransfo['HLQ'] = 'AWS.M2' 
	mapTransfo['CICSHLQ'] = 'CICSTS' 
	mapTransfo['IMSHLQ'] = 'IMS' 
	mapTransfo['MQHLQ'] = 'MQ' 
	//
	lastProgramResult = stepTRN(shell, params, programResults)
	//
	lastProgramResult = stepCOBOL(shell, params, programResults)
	//
	//  *********************************
	//        COPY LINK STEP
	//  *********************************
	lastProgramResult = stepCOPYIMS(shell, params, programResults)
	//
	lastProgramResult = stepCOPYLINK(shell, params, programResults)
	//
	lastProgramResult = stepCOPYMQ(shell, params, programResults)
	//
	lastProgramResult = stepLKED(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP TRN - PGM - DFHECP1$******************************************************
def stepTRN(Object shell, Map params, Map programResults){
	mapTransfo['HLQ'] = 'AWS.M2' 
	mapTransfo['CICSHLQ'] = 'CICSTS' 
	mapTransfo['IMSHLQ'] = 'IMS' 
	mapTransfo['MQHLQ'] = 'MQ' 
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("TRN", "DFHECP1$", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.bluesam("STEPLIB")
						.dataset("&CICSHLQ..CICS.SDFHLOAD")
						.disposition("SHR")
						.build()
						.fileSystem("SYSIN")
						.path("&HLQ..COBOL.SRC(IMSMQPGM)")
						.disposition("SHR")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.bluesam("SYSPUNCH")
						.dataset("&&SYSCIN")
						.normalTermination("PASS")
						.build()
						.getFileConfigurations())
					.withArguments(getParm("CICS,DLI,COBOL3"))
					.withParameters(params)
					.runProgram("DFHECP1$")
				})
		}
	}
}
// STEP COBOL - PGM - IGYCRCTL****************************************************
def stepCOBOL(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'LT', 4)) {
				return execStep("COBOL", "IGYCRCTL", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.concatenation("STEPLIB")
							.path("IGY.SIGYCOMP.V63")
							.disposition("SHR")
							.path("CEE.SCEERUN")
							.disposition("SHR")
							.path("CEE.SCEERUN2")
							.disposition("SHR")
							.build()
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.bluesam("SYSLIN")
							.dataset("&&LOADSET")
							.disposition("MOD")
							.normalTermination("PASS")
							.build()
							.bluesam("SYSUT1")
							.dataset("&&SYSUT1")
							.build()
							.bluesam("SYSUT2")
							.dataset("&&SYSUT2")
							.build()
							.bluesam("SYSUT3")
							.dataset("&&SYSUT3")
							.build()
							.bluesam("SYSUT4")
							.dataset("&&SYSUT4")
							.build()
							.bluesam("SYSUT5")
							.dataset("&&SYSUT5")
							.build()
							.bluesam("SYSUT6")
							.dataset("&&SYSUT6")
							.build()
							.bluesam("SYSUT7")
							.dataset("&&SYSUT7")
							.build()
							.bluesam("SYSUT8")
							.dataset("&&SYSUT8")
							.build()
							.bluesam("SYSUT9")
							.dataset("&&SYSUT9")
							.build()
							.bluesam("SYSUT10")
							.dataset("&&SYSUT10")
							.build()
							.bluesam("SYSUT11")
							.dataset("&&SYSUT11")
							.build()
							.bluesam("SYSUT12")
							.dataset("&&SYSUT12")
							.build()
							.bluesam("SYSUT13")
							.dataset("&&SYSUT13")
							.build()
							.bluesam("SYSUT14")
							.dataset("&&SYSUT14")
							.build()
							.bluesam("SYSUT15")
							.dataset("&&SYSUT15")
							.build()
							.bluesam("SYSMDECK")
							.dataset("&&SYSMDECK")
							.build()
							.concatenation("SYSLIB")
							.path("CEE.SCEESAMP")
							.disposition("SHR")
							.path("&CICSHLQ..CICS.SDFHCOB")
							.disposition("SHR")
							.path("&MQHLQ..SCSQCOBC")
							.disposition("SHR")
							.path("&HLQ..COBCOPY")
							.disposition("SHR")
							.build()
							.bluesam("SYSIN")
							.dataset("&&SYSCIN")
							.disposition("OLD")
							.normalTermination("DELETE")
							.build()
							.getFileConfigurations())
						.withArguments(getParm("NODYNAM,OBJECT,RENT,APOST,MAP,XREF"))
						.withParameters(params)
						.runProgram("IGYCRCTL")
					})
			}
		}
	}
}
// STEP COPYIMS - PGM - IEBGENER**************************************************
def stepCOPYIMS(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'LT', 4)) {
				return execStep("COPYIMS", "IEBGENER", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.fileSystem("SYSUT1")
							.stream(
"""   ENTRY IMSMQPGM
   NAME IMSMQPGM(R)""", getEncoding())
							.build()
							.bluesam("SYSUT2")
							.dataset("&&COPYIMS")
							.disposition("NEW")
							.normalTermination("PASS")
							.build()
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.dummy("SYSIN")
							.build()
							.getFileConfigurations())
						.withParameters(params)
						.runProgram("IEBGENER")
					})
			}
		}
	}
}
// STEP COPYLINK - PGM - IEBGENER*************************************************
def stepCOPYLINK(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'LT', 4)) {
				return execStep("COPYLINK", "IEBGENER", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.fileSystem("SYSUT1")
							.stream("  INCLUDE SYSLIB(DFHELII)", getEncoding())
							.build()
							.bluesam("SYSUT2")
							.dataset("&&COPYLINK")
							.disposition("NEW")
							.normalTermination("PASS")
							.build()
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.dummy("SYSIN")
							.build()
							.getFileConfigurations())
						.withParameters(params)
						.runProgram("IEBGENER")
					})
			}
		}
	}
}
// STEP COPYMQ - PGM - IEBGENER***************************************************
def stepCOPYMQ(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'LT', 4)) {
				return execStep("COPYMQ", "IEBGENER", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.fileSystem("SYSUT1")
							.stream(" INCLUDE CSQSTUB(CSQCSTUB)", getEncoding())
							.build()
							.bluesam("SYSUT2")
							.dataset("&&COPYMQ")
							.disposition("NEW")
							.normalTermination("PASS")
							.build()
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.dummy("SYSIN")
							.build()
							.getFileConfigurations())
						.withParameters(params)
						.runProgram("IEBGENER")
					})
			}
		}
	}
}
// STEP LKED - PGM - IEWL*********************************************************
def stepLKED(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			if (checkAllPreviousProgramResults(programResults, 'LT', 4)) {
				return execStep("LKED", "IEWL", programResults, {
					mpr
						.withFileConfigurations(new FileConfigurationUtils()
							.withJobContext(jobContext)
							.concatenation("SYSLIB")
							.path("&MQHLQ..SCSQLOAD")
							.disposition("SHR")
							.path("SYS1.LINKLIB")
							.disposition("SHR")
							.path("CEE.SCEELKED")
							.disposition("SHR")
							.path("&CICSHLQ..CICS.SDFHLOAD")
							.disposition("SHR")
							.path("&IMSHLQ..SDFSRESL")
							.disposition("SHR")
							.build()
							.bluesam("CSQSTUB")
							.dataset("&MQHLQ..SCSQLOAD")
							.disposition("SHR")
							.build()
							.concatenation("SYSLIN")
							.path("&&COPYLINK").temporary()
							.disposition("OLD")
							.normalTermination("DELETE")
							.path("&&COPYMQ").temporary()
							.disposition("OLD")
							.normalTermination("DELETE")
							.path("&&LOADSET").temporary()
							.disposition("OLD")
							.normalTermination("DELETE")
							.path("&&COPYIMS").temporary()
							.disposition("OLD")
							.normalTermination("DELETE")
							.build()
							.systemOut("SYSPRINT")
							.output("*")
							.build()
							.fileSystem("SYSLMOD")
							.path("&HLQ..CICSLOAD(IMSMQPGM)")
							.disposition("SHR")
							.build()
							.bluesam("SYSUT1")
							.dataset("&&SYSUT1")
							.build()
							.getFileConfigurations())
						.withArguments(getParm("LIST,XREF"))
						.withParameters(params)
						.runProgram("IEWL")
					})
			}
		}
	}
}
