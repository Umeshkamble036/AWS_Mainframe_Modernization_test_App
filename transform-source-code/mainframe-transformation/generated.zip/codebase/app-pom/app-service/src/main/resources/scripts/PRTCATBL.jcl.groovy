// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "PRTCATBL"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//-------> TO DO ID : JOBLIB [Line : 18] *****************************************
	//
	lastProgramResult = stepDELDEF(shell, params, programResults)
	// ********************************************************`***********
	// Unload the processed transaction category balance file              
	// ******************************************************************* 
	stepSTEP05R(shell, jobName, params, programResults)
	// ******************************************************************* 
	// Filter the TCATBALFions for a the parm date and sort by card num    
	// ******************************************************************* 
	lastProgramResult = stepSTEP10R(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP DELDEF - PGM - IEFBR14****************************************************
def stepDELDEF(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("DELDEF", "IEFBR14", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.bluesam("THEFILE")
						.dataset("AWS.M2.CARDDEMO.TCATBALF.REPT")
						.disposition("MOD")
						.normalTermination("DELETE")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IEFBR14")
				})
		}
	}
}
// STEP STEP05R - PROC - REPROC***************************************************
def stepSTEP05R(Object shell, String jobName, Map params, Map programResults) {
	shell.with{
		if (checkValidProgramResults(programResults)) {
			def stepName = 'STEP05R'
			execStepSimple(stepName, programResults, {
				def procName = 'REPROC'
				TreeMap mapTransfo = new TreeMap(params["MapTransfo"])
				mapTransfo['CNTLLIB'] = 'AWS.M2.CARDDEMO.CNTL'
				Map<String,FileConfiguration> fcmap = new FileConfigurationUtils()
				.withJobContext(jobContext)
				.bluesam("PRC001.FILEIN")
				.dataset("AWS.M2.CARDDEMO.TCATBALF.VSAM.KSDS")
				.disposition("SHR")
				.build()
				.gdgSupport("PRC001.FILEOUT")
				.name("AWS.M2.CARDDEMO.TCATBALF.BKUP").ownerPath(".").relativeGeneration(1).storageProvider("filesystem").recordSize(50)
				.disposition("NEW")
				.normalTermination("CATLG")
				.abnormalTermination("DELETE")
				.build()
				.getFileConfigurations();
				File procFile = ScriptRegistry.getScript(procName);
				File resolvedProcFile = buildResolvedFile(jobName,stepName,procName)
				GroovyUtils.processGroovyParams(procFile, resolvedProcFile, mapTransfo, programResults)
				return execGroovy(applicationContext, mapTransfo, resolvedProcFile, jobContext, fcmap)
			})
		}
	}
}
// STEP STEP10R - PGM - SORT******************************************************
def stepSTEP10R(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP10R", "SORT", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.gdgSupport("SORTIN")
						.name("AWS.M2.CARDDEMO.TCATBALF.BKUP").ownerPath(".").relativeGeneration(1).storageProvider("filesystem")
						.disposition("SHR")
						.build()
						.fileSystem("SYMNAMES")
						.stream(
"""TRANCAT-ACCT-ID,1,11,ZD                                                         
TRANCAT-TYPE-CD,12,2,CH                                                         
TRANCAT-CD,14,4,ZD
TRAN-CAT-BAL,18,11,ZD""", getEncoding())
						.build()
						.fileSystem("SYSIN")
						.stream(
""" SORT FIELDS=(TRANCAT-ACCT-ID,A,TRANCAT-TYPE-CD,A,TRANCAT-CD,A)         
 OUTREC FIELDS=(TRANCAT-ACCT-ID,X,
     TRANCAT-TYPE-CD,X,
     TRANCAT-CD,X,
     TRAN-CAT-BAL,EDIT=(TTTTTTTTT.TT),9X)""", getEncoding())
						.build()
						.systemOut("SYSOUT")
						.output("*")
						.build()
						.bluesam("SORTOUT")
						.dataset("AWS.M2.CARDDEMO.TCATBALF.REPT")
						.disposition("NEW")
						.normalTermination("CATLG")
						.abnormalTermination("DELETE")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("SORT")
				})
		}
	}
}
