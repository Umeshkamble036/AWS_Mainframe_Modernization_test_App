// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "CBIMPORT"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//*****************************************************************
	// Copyright Amazon.com, Inc. or its affiliates.                   
	// All Rights Reserved.                                            
	//                                                                 
	// Licensed under the Apache License, Version 2.0 (the "License"). 
	// You may not use this file except in compliance with the License.
	// You may obtain a copy of the License at                         
	//                                                                 
	//    http://www.apache.org/licenses/LICENSE-2.0                   
	//                                                                 
	// Unless required by applicable law or agreed to in writing,      
	// software distributed under the License is distributed on an     
	// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,    
	// either express or implied. See the License for the specific     
	// language governing permissions and limitations under the License
	// *******************************************************************
	// IMPORT CUSTOMER DATA FROM MULTI-RECORD EXPORT FILE AND SPLIT
	// INTO SEPARATE NORMALIZED FILES FOR TARGET SYSTEM
	// *******************************************************************
	lastProgramResult = stepSTEP01(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP STEP01 - PGM - CBIMPORT***************************************************
def stepSTEP01(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP01", "CBIMPORT", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.bluesam("STEPLIB")
						.dataset("AWS.M2.CARDDEMO.LOADLIB")
						.disposition("SHR")
						.build()
						.bluesam("EXPFILE")
						.dataset("AWS.M2.CARDDEMO.EXPORT.DATA")
						.disposition("SHR")
						.build()
						.bluesam("CUSTOUT")
						.dataset("AWS.M2.CARDDEMO.CUSTDATA.IMPORT")
						.disposition("NEW")
						.normalTermination("CATLG")
						.abnormalTermination("DELETE")
						.build()
						.bluesam("ACCTOUT")
						.dataset("AWS.M2.CARDDEMO.ACCTDATA.IMPORT")
						.disposition("NEW")
						.normalTermination("CATLG")
						.abnormalTermination("DELETE")
						.build()
						.bluesam("XREFOUT")
						.dataset("AWS.M2.CARDDEMO.CARDXREF.IMPORT")
						.disposition("NEW")
						.normalTermination("CATLG")
						.abnormalTermination("DELETE")
						.build()
						.bluesam("TRNXOUT")
						.dataset("AWS.M2.CARDDEMO.TRANSACT.IMPORT")
						.disposition("NEW")
						.normalTermination("CATLG")
						.abnormalTermination("DELETE")
						.build()
						.bluesam("ERROUT")
						.dataset("AWS.M2.CARDDEMO.IMPORT.ERRORS")
						.disposition("NEW")
						.normalTermination("CATLG")
						.abnormalTermination("DELETE")
						.build()
						.systemOut("SYSOUT")
						.output("*")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("CBIMPORT")
				})
		}
	}
}
