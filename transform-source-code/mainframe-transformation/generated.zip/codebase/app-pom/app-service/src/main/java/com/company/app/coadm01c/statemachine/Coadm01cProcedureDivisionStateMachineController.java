package com.company.app.coadm01c.statemachine;

import com.company.app.coadm01c.business.context.Coadm01cContext;
import com.company.app.coadm01c.statemachine.Coadm01cProcedureDivisionStateMachineController.Events;
import com.company.app.coadm01c.statemachine.Coadm01cProcedureDivisionStateMachineController.States;
import com.company.app.coadm01c.statemachine.Coadm01cProcedureDivisionStateMachineService;
import com.github.oxo42.stateless4j.StateMachineConfig;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.context.RuntimeContext;
import com.netfective.bluage.gapwalk.rt.statemachine.SimpleStateMachineController;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Controller managing the state machine "Coadm01cProcedureDivisionStateMachine" execution.
 */
@Component("com.company.app.coadm01c.statemachine.Coadm01cProcedureDivisionStateMachineController")
@Import({
com.company.app.coadm01c.statemachine.Coadm01cProcedureDivisionStateMachineService.class
})
@Lazy
public class Coadm01cProcedureDivisionStateMachineController extends SimpleStateMachineController<States, Events> {
	
	/**
	 * State machine states.
	 */
	public enum States {
		MAIN_PARA_1, MAIN_PARA, PGMIDERR_ERR_PARA, FINAL, LOCAL_FINAL
	}

	/**
	 * State machine events.
	 */
	public enum Events {
		TO_MAIN_PARA_1, TO_MAIN_PARA, TO_PGMIDERR_ERR_PARA, TO_FINAL, TO_LOCAL_FINAL
	}

	/**
	 * State machine state process service provider.
	 */
	@Autowired
	@Lazy
	private Coadm01cProcedureDivisionStateMachineService stateProcess;
	
	/**
	 * State machine controller initialization.
	 */
	@PostConstruct
	private void init(){
		initStateMachineController();
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine() throws Exception {
		throw new UnsupportedOperationException("Please use the two arguments configureStateMachine method instead: configureStateMachine(RuntimeContext ctx, ExecutionController ctrl)");
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine(RuntimeContext ctx, ExecutionController ctrl) throws Exception {
		
		StateMachineConfig<States, Events> configurer = new StateMachineConfig<>();
		configureInitialEnd(States.MAIN_PARA_1,States.FINAL);
		Coadm01cContext lctx = (Coadm01cContext) ctx;

		configurer.configure(States.MAIN_PARA).substateOf(States.MAIN_PARA_1).onEntry(buildRunAction(() -> {stateProcess.mainPara(lctx, ctrl);}))
		;	
		configurer.configure(States.PGMIDERR_ERR_PARA).substateOf(States.MAIN_PARA_1).onEntry(buildRunAction(() -> {stateProcess.pgmiderrErrPara(lctx, ctrl);}))
		;	
		
		configurer.configure(States.MAIN_PARA_1)
		.onEntry(()->{runSubStateMachine(Events.TO_MAIN_PARA);})
		.permit(Events.TO_MAIN_PARA, States.MAIN_PARA)
		.permit(Events.TO_FINAL, States.FINAL)
		.permitInternal(Events.TO_PGMIDERR_ERR_PARA, buildRunAction(() -> {stateProcess.pgmiderrErrPara(lctx, ctrl);}))
		.permit(Events.TO_LOCAL_FINAL, States.LOCAL_FINAL)
		;	
		
		return configurer;
	}
	
}
