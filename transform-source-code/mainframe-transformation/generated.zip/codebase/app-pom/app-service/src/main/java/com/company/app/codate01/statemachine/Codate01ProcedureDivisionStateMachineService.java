
package com.company.app.codate01.statemachine;

import com.company.app.codate01.business.context.Codate01Context;
import com.company.app.codate01.service.Codate01Process;
import com.company.app.codate01.statemachine.Codate01ProcedureDivisionStateMachineController.Events;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.control.RetrieveBuilder;
import com.netfective.bluage.gapwalk.rt.jics.internal.JicsSyncpointBuilder;
import com.netfective.bluage.gapwalk.rt.jics.internal.JicsTimeBuilder;
import com.netfective.bluage.gapwalk.rt.statemachine.StateMachineControllerWithContinuation;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.statements.MessageQueueBuilder;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Service class containing states process used to drive state machine "Codate01ProcedureDivisionStateMachine".
 */
@Service("com.company.app.codate01.statemachine.Codate01ProcedureDivisionStateMachineService")
@Lazy
public class Codate01ProcedureDivisionStateMachineService {
	
	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Codate01ProcedureDivisionStateMachineService.class);

	/**
	 * The associated state machine controller.
	 */
	@Autowired
	@Qualifier("com.company.app.codate01.statemachine.Codate01ProcedureDivisionStateMachineController")	
	private StateMachineControllerWithContinuation<Events> instanceStateMachineController;
	
	
	/**
	 * Service used by the state machine.
	 */
	@Autowired
	@Qualifier("com.company.app.codate01.service.Codate01Process")
	private Codate01Process instanceCodate01Process;
	
	
	

	/**
	 * State process operation _1000Control.
	 * 
	 * PROGRAM-ID.CODATE01ISINITIAL.
	 *  AUTHOR.               AWS.
	 *  DATE-WRITTEN.         03/21.
	 *  DATE-COMPILED.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000Control(Codate01Context ctx, ExecutionController ctrl) {
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		DataUtils.setToBlank(ctx.getQueueInfo().getInputQueueNameReference());
		DataUtils.setToBlank(ctx.getQueueInfo().getQmgrNameReference());
		DataUtils.setToBlank(ctx.getQueueMessage().getQueueMessageReference());
		ctx.getMqErrDisplay().getField().initialize();
		instanceStateMachineController.addContinuationEvent(Events.TO__1000_CONTROL_POST__2100OPENERRORQUEUE, "END_OF__2100_OPEN_ERROR_QUEUE");
		instanceStateMachineController.sendEvent(Events.TO__2100_OPEN_ERROR_QUEUE);

	}
	/**
	 * State process operation _2300OpenInputQueue.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2300OpenInputQueue(Codate01Context ctx, ExecutionController ctrl) {
		
		/* 
		OPEN-INPUT WILL OPEN A QUEUE FOR GET PROCESSING */
		DataUtils.setToBlank(ctx.getMqObjectDescriptor().getMqodObjectqmgrnameReference());
		ctx.getMqObjectDescriptor().getMqodObjectnameReference().setValue(ctx.getQueueInfo().getInputQueueNameReference());
		ctx.getMqOptions().setMqOptions(ctx.getCmqvMqoo().getMqooInputShared() + ctx.getCmqvMqoo().getMqooSaveAllContext() + ctx.getCmqvMqoo().getMqooFailIfQuiescing());
		MessageQueueBuilder.newInstance(ctx)
		.command("OPEN")
		.hConn(ctx.getQmgrHandleConn().getQmgrHandleConnReference())
		.objDesc(ctx.getMqObjectDescriptor())
		.options(ctx.getMqOptions().getMqOptionsReference())
		.hObj(ctx.getMqHobj().getMqHobjReference())
		.compCode(ctx.getMqConditionCode().getMqConditionCodeReference())
		.reason(ctx.getMqReasonCode().getMqReasonCodeReference())
		.execute();
		if (ctx.getMqConditionCode().getMqConditionCode() == ctx.getCmqvMqhc().getMqccOk()) {
			ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
			ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
			ctx.getInputQueueHandle().getInputQueueHandleReference().setValue(ctx.getMqHobj().getMqHobjReference());
			ctx.getWsReplyQueueSts().setReplyQueueOpen(true);
			instanceStateMachineController.sendEvent(Events.TO__2300_OPEN_INPUT_QUEUE_POSTIF);
		} else {
			instanceStateMachineController.sendEvent(Events.TO__2300_OPEN_INPUT_QUEUE_CASEBRANCH);
			return;
		}

	}
	/**
	 * State process operation _2400OpenOutputQueue.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2400OpenOutputQueue(Codate01Context ctx, ExecutionController ctrl) {
		
		/* 
		OPEN-OUTPUT WILL OPEN A QUEUE FOR PUT PROCESSING */
		DataUtils.setToBlank(ctx.getMqObjectDescriptor().getMqodObjectqmgrnameReference());
		ctx.getMqObjectDescriptor().getMqodObjectnameReference().setValue(ctx.getQueueInfo().getReplyQueueNameReference());
		ctx.getMqOptions().setMqOptions(ctx.getCmqvMqoo().getMqooOutput() + ctx.getCmqvMqoo().getMqooPassAllContext() + ctx.getCmqvMqoo().getMqooFailIfQuiescing());
		MessageQueueBuilder.newInstance(ctx)
		.command("OPEN")
		.hConn(ctx.getQmgrHandleConn().getQmgrHandleConnReference())
		.objDesc(ctx.getMqObjectDescriptor())
		.options(ctx.getMqOptions().getMqOptionsReference())
		.hObj(ctx.getMqHobj().getMqHobjReference())
		.compCode(ctx.getMqConditionCode().getMqConditionCodeReference())
		.reason(ctx.getMqReasonCode().getMqReasonCodeReference())
		.execute();
		if (ctx.getMqConditionCode().getMqConditionCode() == ctx.getCmqvMqhc().getMqccOk()) {
			ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
			ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
			ctx.getOutputQueueHandle().getOutputQueueHandleReference().setValue(ctx.getMqHobj().getMqHobjReference());
			ctx.getWsRespQueueSts().setRespQueueOpen(true);
			instanceStateMachineController.sendEvent(Events.TO__2400_OPEN_OUTPUT_QUEUE_POSTIF);
		} else {
			instanceStateMachineController.sendEvent(Events.TO__2400_OPEN_OUTPUT_QUEUE_CASEBRANCH);
			return;
		}

	}
	/**
	 * State process operation _2100OpenErrorQueue.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2100OpenErrorQueue(Codate01Context ctx, ExecutionController ctrl) {
				boolean res = false; 
		
		/* 
		OPEN-OUTPUT WILL OPEN A QUEUE FOR PUT PROCESSING */
		ctx.getQueueInfo().setErrorQueueName("CARD.DEMO.ERROR");
		DataUtils.setToBlank(ctx.getMqObjectDescriptor().getMqodObjectqmgrnameReference());
		ctx.getMqObjectDescriptor().getMqodObjectnameReference().setValue(ctx.getQueueInfo().getErrorQueueNameReference());
		ctx.getMqOptions().setMqOptions(ctx.getCmqvMqoo().getMqooOutput() + ctx.getCmqvMqoo().getMqooPassAllContext() + ctx.getCmqvMqoo().getMqooFailIfQuiescing());
		MessageQueueBuilder.newInstance(ctx)
		.command("OPEN")
		.hConn(ctx.getQmgrHandleConn().getQmgrHandleConnReference())
		.objDesc(ctx.getMqObjectDescriptor())
		.options(ctx.getMqOptions().getMqOptionsReference())
		.hObj(ctx.getMqHobj().getMqHobjReference())
		.compCode(ctx.getMqConditionCode().getMqConditionCodeReference())
		.reason(ctx.getMqReasonCode().getMqReasonCodeReference())
		.execute();
		if (ctx.getMqConditionCode().getMqConditionCode() == ctx.getCmqvMqhc().getMqccOk()) {
			ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
			ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
			ctx.getErrorQueueHandle().getErrorQueueHandleReference().setValue(ctx.getMqHobj().getMqHobjReference());
			ctx.getWsErrQueueSts().setErrQueueOpen(true);
			res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__2100_OPEN_ERROR_QUEUE");
			if (res) {
				return;
			} 
		} else {
			ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
			ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
			ctx.getMqErrDisplay().getMqApplQueueNameReference().setValue(ctx.getQueueInfo().getErrorQueueNameReference());
			ctx.getMqErrDisplay().setMqApplReturnMessage("ERR MQOPEN ERR");
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}" , DataUtils.toString(ctx.getMqErrDisplay().getBytes()));
			instanceStateMachineController.sendEvent(Events.TO__8000_TERMINATION);
			return;
		}

	}
	/**
	 * State process operation _4000MainProcess.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4000MainProcess(Codate01Context ctx, ExecutionController ctrl) {
		JicsSyncpointBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.commit()
		.execute()
		.handleException();
		instanceStateMachineController.addContinuationEvent(Events.TO__4000_MAIN_PROCESS_POST__3000GETREQUEST, "END_OF__3000_GET_REQUEST_POSTIF");
		instanceStateMachineController.sendEvent(Events.TO__3000_GET_REQUEST);

	}
	/**
	 * State process operation _3000GetRequest.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000GetRequest(Codate01Context ctx, ExecutionController ctrl) {
		
		/* 
		GET WILL GET A MESSAGE FROM THE QUEUE
		** ADDED 5000 MS (5 SECS) AS THE WAIT INTERVAL FOR GET */
		ctx.getMqGetMessageOptions().setMqgmoWaitinterval(5000);
		DataUtils.setToBlank(ctx.getMqCorrelid().getMqCorrelidReference());
		DataUtils.setToBlank(ctx.getMqMsgId().getMqMsgIdReference());
		ctx.getMqQueue().getMqQueueReference().setValue(ctx.getQueueInfo().getInputQueueNameReference());
		ctx.getMqHobj().getMqHobjReference().setValue(ctx.getInputQueueHandle().getInputQueueHandleReference());
		ctx.getMqBufferLength().setMqBufferLength(1000);
		ctx.getMqMessageDescriptor().getMqmdMsgidReference().setValue(ctx.getCmqvMqmd().getMqmiNoneReference());
		ctx.getMqMessageDescriptor().getMqmdCorrelidReference().setValue(ctx.getCmqvMqmd().getMqciNoneReference());
		DataUtils.initializer(ctx.getRequestMsgCopy())
		.replacingNumeric(0)
		.initialize();
		ctx.getMqGetMessageOptions().setMqgmoOptions(ctx.getCmqvMqgmo().getMqgmoSyncpoint() + ctx.getCmqvMqgmo().getMqgmoFailIfQuiescing() + ctx.getCmqvMqgmo().getMqgmoConvert() + ctx.getCmqvMqgmo().getMqgmoWait());
		MessageQueueBuilder.newInstance(ctx)
		.command("GET")
		.hConn(ctx.getMqHconn().getMqHconnReference())
		.hObj(ctx.getMqHobj().getMqHobjReference())
		.msgDesc(ctx.getMqMessageDescriptor())
		.getMsgOpts(ctx.getMqGetMessageOptions())
		.bufferLength(ctx.getMqBufferLength().getMqBufferLength())
		.buffer(ctx.getMqBuffer().getMqBufferReference())
		.dataLength(ctx.getMqDataLength().getMqDataLengthReference())
		.compCode(ctx.getMqConditionCode().getMqConditionCodeReference())
		.reason(ctx.getMqReasonCode().getMqReasonCodeReference())
		.execute();
		if (ctx.getMqConditionCode().getMqConditionCode() == ctx.getCmqvMqhc().getMqccOk()) {
			instanceStateMachineController.sendEvent(Events.TO__3000_GET_REQUEST_THENBRANCH);
			return;
		} else {
			instanceStateMachineController.sendEvent(Events.TO__3000_GET_REQUEST_ELSEBRANCH);
			return;
		}

	}
	/**
	 * State process operation _4000ProcessRequestReply.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4000ProcessRequestReply(Codate01Context ctx, ExecutionController ctrl) {
		DataUtils.setToBlank(ctx.getReplyMessage().getReplyMessageReference());
		DataUtils.initializer(ctx.getWsDateTime())
		.replacingNumeric(0)
		.initialize();
		JicsTimeBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.askTime()
		.absoluteTime(ctx.getWsDateTime().getWsAbsTimeReference())
		.execute()
		.handleException();
		JicsTimeBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.formatTime()
		.time(ctx.getWsDateTime().getWsTimeReference())
		.absoluteTime(ctx.getWsDateTime().getWsAbsTimeReference())
		.formattedDate(ctx.getWsDateTime().getWsMmddyyyyReference(),"MMDDYYYY")
		.datesep("-")
		.timesep()
		.execute()
		.handleException();
		StringConcatenationBuilder.newInstance(ctx.getReplyMessage().getReplyMessageReference())
			.addDelimitedBySize("SYSTEM DATE : ")
			.addDelimitedBySize(ctx.getWsDateTime().getWsMmddyyyyReference().getBytes())
			.addDelimitedBySize("SYSTEM TIME : ")
			.addDelimitedBySize(ctx.getWsDateTime().getWsTimeReference().getBytes())
			.end();
		instanceStateMachineController.addContinuationEvent(Events.TO__4000_PROCESS_REQUEST_REPLY_POST__4100PUTREPLY, "END_OF__4100_PUT_REPLY_POSTIF");
		instanceStateMachineController.sendEvent(Events.TO__4100_PUT_REPLY);

	}
	/**
	 * State process operation _4100PutReply.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4100PutReply(Codate01Context ctx, ExecutionController ctrl) {
		
		/* 
		PUT WILL PUT A MESSAGE ON THE QUEUE AND CONVERT IT TO A STRING */
		ctx.getMqBuffer().getMqBufferReference().setValue(ctx.getReplyMessage().getReplyMessageReference());
		ctx.getMqBufferLength().setMqBufferLength(1000);
		ctx.getMqMessageDescriptor().getMqmdMsgidReference().setValue(ctx.getSaveMsgid().getSaveMsgidReference());
		ctx.getMqMessageDescriptor().getMqmdCorrelidReference().setValue(ctx.getSaveCorelid().getSaveCorelidReference());
		ctx.getMqMessageDescriptor().getMqmdFormatReference().setValue(ctx.getCmqvMqmd().getMqfmtStringReference());
		ctx.getMqMessageDescriptor().getMqmdCodedcharsetidReference().setValue(ctx.getCmqvMqmd().getMqccsiQMgrReference());
		ctx.getMqPutMessageOptions().setMqpmoOptions(ctx.getCmqvMqpmo().getMqpmoSyncpoint() + ctx.getCmqvMqpmo().getMqpmoDefaultContext() + ctx.getCmqvMqpmo().getMqpmoFailIfQuiescing());
		MessageQueueBuilder.newInstance(ctx)
		.command("PUT")
		.hConn(ctx.getMqHconn().getMqHconnReference())
		.hObj(ctx.getOutputQueueHandle().getOutputQueueHandleReference())
		.msgDesc(ctx.getMqMessageDescriptor())
		.putMsgOpts(ctx.getMqPutMessageOptions())
		.bufferLength(ctx.getMqBufferLength().getMqBufferLength())
		.buffer(ctx.getMqBuffer().getMqBufferReference())
		.compCode(ctx.getMqConditionCode().getMqConditionCodeReference())
		.reason(ctx.getMqReasonCode().getMqReasonCodeReference())
		.execute();
		if (ctx.getMqConditionCode().getMqConditionCode() == ctx.getCmqvMqhc().getMqccOk()) {
			ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
			ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
			instanceStateMachineController.sendEvent(Events.TO__4100_PUT_REPLY_POSTIF);
		} else {
			instanceStateMachineController.sendEvent(Events.TO__4100_PUT_REPLY_CASEBRANCH);
			return;
		}

	}
	/**
	 * State process operation _9000Error.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9000Error(Codate01Context ctx, ExecutionController ctrl) {
				boolean res = false; 
		
		/* 
		PUT WILL PUT A MESSAGE ON THE QUEUE AND CONVERT IT TO A STRING */
		ctx.getErrorMessage().getErrorMessageReference().setBytes(ctx.getMqErrDisplay().getBytes());
		ctx.getMqBuffer().getMqBufferReference().setValue(ctx.getErrorMessage().getErrorMessageReference());
		ctx.getMqBufferLength().setMqBufferLength(1000);
		ctx.getMqMessageDescriptor().getMqmdFormatReference().setValue(ctx.getCmqvMqmd().getMqfmtStringReference());
		ctx.getMqMessageDescriptor().getMqmdCodedcharsetidReference().setValue(ctx.getCmqvMqmd().getMqccsiQMgrReference());
		ctx.getMqPutMessageOptions().setMqpmoOptions(ctx.getCmqvMqpmo().getMqpmoSyncpoint() + ctx.getCmqvMqpmo().getMqpmoDefaultContext() + ctx.getCmqvMqpmo().getMqpmoFailIfQuiescing());
		MessageQueueBuilder.newInstance(ctx)
		.command("PUT")
		.hConn(ctx.getMqHconn().getMqHconnReference())
		.hObj(ctx.getErrorQueueHandle().getErrorQueueHandleReference())
		.msgDesc(ctx.getMqMessageDescriptor())
		.putMsgOpts(ctx.getMqPutMessageOptions())
		.bufferLength(ctx.getMqBufferLength().getMqBufferLength())
		.buffer(ctx.getMqBuffer().getMqBufferReference())
		.compCode(ctx.getMqConditionCode().getMqConditionCodeReference())
		.reason(ctx.getMqReasonCode().getMqReasonCodeReference())
		.execute();
		if (ctx.getMqConditionCode().getMqConditionCode() == ctx.getCmqvMqhc().getMqccOk()) {
			ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
			ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
			res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__9000_ERROR");
			if (res) {
				return;
			} 
		} else {
			ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
			ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
			ctx.getMqErrDisplay().getMqApplQueueNameReference().setValue(ctx.getQueueInfo().getErrorQueueNameReference());
			ctx.getMqErrDisplay().setMqApplReturnMessage("MQPUT ERR");
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}" , DataUtils.toString(ctx.getMqErrDisplay().getBytes()));
			instanceStateMachineController.sendEvent(Events.TO__8000_TERMINATION);
			return;
		}

	}
	/**
	 * State process operation _8000Termination.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8000Termination(Codate01Context ctx, ExecutionController ctrl) {
		if (ctx.getWsReplyQueueSts().isReplyQueueOpen()) {
			instanceStateMachineController.sendEvent(Events.TO__8000_TERMINATION_THENBRANCH);
			return;
		} else {
			instanceStateMachineController.sendEvent(Events.TO__8000_TERMINATION_POSTIF);
		}

	}
	/**
	 * State process operation _5000CloseInputQueue.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5000CloseInputQueue(Codate01Context ctx, ExecutionController ctrl) {
				boolean res = false; 
		ctx.getMqQueue().getMqQueueReference().setValue(ctx.getQueueInfo().getInputQueueNameReference());
		ctx.getMqHobj().getMqHobjReference().setValue(ctx.getInputQueueHandle().getInputQueueHandleReference());
		ctx.getMqOptions().getMqOptionsReference().setValue(ctx.getCmqvMqho().getMqcoNoneReference());
		MessageQueueBuilder.newInstance(ctx)
		.command("CLOSE")
		.hConn(ctx.getMqHconn().getMqHconnReference())
		.hObj(ctx.getMqHobj().getMqHobjReference())
		.options(ctx.getMqOptions().getMqOptionsReference())
		.compCode(ctx.getMqConditionCode().getMqConditionCodeReference())
		.reason(ctx.getMqReasonCode().getMqReasonCodeReference())
		.execute();
		if (ctx.getMqConditionCode().getMqConditionCode() == ctx.getCmqvMqhc().getMqccOk()) {
			ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
			ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
			res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__5000_CLOSE_INPUT_QUEUE");
			if (res) {
				return;
			} 
		} else {
			ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
			ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
			ctx.getMqErrDisplay().getMqApplQueueNameReference().setValue(ctx.getQueueInfo().getInputQueueNameReference());
			ctx.getMqErrDisplay().setMqApplReturnMessage("MQCLOSE ERR");
			instanceStateMachineController.sendEvent(Events.TO__8000_TERMINATION);
			return;
		}

	}
	/**
	 * State process operation _5100CloseOutputQueue.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5100CloseOutputQueue(Codate01Context ctx, ExecutionController ctrl) {
				boolean res = false; 
		ctx.getMqQueue().getMqQueueReference().setValue(ctx.getQueueInfo().getReplyQueueNameReference());
		ctx.getMqHobj().getMqHobjReference().setValue(ctx.getOutputQueueHandle().getOutputQueueHandleReference());
		ctx.getMqOptions().getMqOptionsReference().setValue(ctx.getCmqvMqho().getMqcoNoneReference());
		MessageQueueBuilder.newInstance(ctx)
		.command("CLOSE")
		.hConn(ctx.getMqHconn().getMqHconnReference())
		.hObj(ctx.getMqHobj().getMqHobjReference())
		.options(ctx.getMqOptions().getMqOptionsReference())
		.compCode(ctx.getMqConditionCode().getMqConditionCodeReference())
		.reason(ctx.getMqReasonCode().getMqReasonCodeReference())
		.execute();
		if (ctx.getMqConditionCode().getMqConditionCode() == ctx.getCmqvMqhc().getMqccOk()) {
			ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
			ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
			res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__5100_CLOSE_OUTPUT_QUEUE");
			if (res) {
				return;
			} 
		} else {
			ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
			ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
			ctx.getMqErrDisplay().getMqApplQueueNameReference().setValue(ctx.getQueueInfo().getInputQueueNameReference());
			ctx.getMqErrDisplay().setMqApplReturnMessage("MQCLOSE ERR");
			instanceStateMachineController.sendEvent(Events.TO__8000_TERMINATION);
			return;
		}

	}
	/**
	 * State process operation _5200CloseErrorQueue.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5200CloseErrorQueue(Codate01Context ctx, ExecutionController ctrl) {
		ctx.getMqQueue().getMqQueueReference().setValue(ctx.getQueueInfo().getErrorQueueNameReference());
		ctx.getMqHobj().getMqHobjReference().setValue(ctx.getErrorQueueHandle().getErrorQueueHandleReference());
		ctx.getMqOptions().getMqOptionsReference().setValue(ctx.getCmqvMqho().getMqcoNoneReference());
		MessageQueueBuilder.newInstance(ctx)
		.command("CLOSE")
		.hConn(ctx.getMqHconn().getMqHconnReference())
		.hObj(ctx.getMqHobj().getMqHobjReference())
		.options(ctx.getMqOptions().getMqOptionsReference())
		.compCode(ctx.getMqConditionCode().getMqConditionCodeReference())
		.reason(ctx.getMqReasonCode().getMqReasonCodeReference())
		.execute();
		if (ctx.getMqConditionCode().getMqConditionCode() == ctx.getCmqvMqhc().getMqccOk()) {
			ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
			ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
			instanceStateMachineController.sendEvent(Events.TO__5200_CLOSE_ERROR_QUEUE_POSTIF);
		} else {
			instanceStateMachineController.sendEvent(Events.TO__5200_CLOSE_ERROR_QUEUE_CASEBRANCH);
			return;
		}

	}
	/**
	 * State process operation _1000ControlPostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000ControlPostif(Codate01Context ctx, ExecutionController ctrl) {
		instanceStateMachineController.addContinuationEvent(Events.TO__1000_CONTROL_POST__2300OPENINPUTQUEUE, "END_OF__2300_OPEN_INPUT_QUEUE_POSTIF");
		instanceStateMachineController.sendEvent(Events.TO__2300_OPEN_INPUT_QUEUE);

	}
	/**
	 * State process operation _1000ControlElsebranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000ControlElsebranch(Codate01Context ctx, ExecutionController ctrl) {
		ctx.getMqErrDisplay().setMqErrorPara("CICS RETRIEVE");
		ctx.getWsCicsRespCds().setWsCicsResp1CdD(ctx.getWsCicsRespCds().getWsCicsResp1Cd());
		ctx.getWsCicsRespCds().getWsCicsResp2CdReference().setValue(ctx.getWsCicsRespCds().getWsCicsResp2CdReference());
		StringConcatenationBuilder.newInstance(ctx.getMqErrDisplay().getMqApplReturnMessageReference())
			.addDelimitedBySize("RESP: ")
			.addDelimitedBySize(ctx.getWsCicsRespCds().getWsCicsResp1CdDReference().getValue(String.class))
			.addDelimitedBySize(ctx.getWsCicsRespCds().getWsCicsResp2CdDReference().getValue(String.class))
			.addDelimitedBySize("END")
			.end();
		instanceStateMachineController.addContinuationEvent(Events.TO__8000_TERMINATION, "END_OF__9000_ERROR");
		instanceStateMachineController.sendEvent(Events.TO__9000_ERROR);

	}
	/**
	 * State process operation _1000ControlLoop.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000ControlLoop(Codate01Context ctx, ExecutionController ctrl) {
		if (ctx.getWsMqMsgFlag().isNoMoreMsgs()) {
			instanceStateMachineController.sendEvent(Events.TO__8000_TERMINATION);
			return;
		} else {
			instanceStateMachineController.addContinuationEvent(Events.TO__1000_CONTROL_LOOP, "END_OF__4000_MAIN_PROCESS_POST__3000GETREQUEST");
			instanceStateMachineController.sendEvent(Events.TO__4000_MAIN_PROCESS);
		}

	}
	/**
	 * State process operation _2300OpenInputQueuePostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2300OpenInputQueuePostif(Codate01Context ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__2300_OPEN_INPUT_QUEUE_POSTIF");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation _2300OpenInputQueueCasebranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2300OpenInputQueueCasebranch(Codate01Context ctx, ExecutionController ctrl) {
		ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
		ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
		ctx.getMqErrDisplay().getMqApplQueueNameReference().setValue(ctx.getQueueInfo().getInputQueueNameReference());
		ctx.getMqErrDisplay().setMqApplReturnMessage("INP MQOPEN ERR");
		instanceStateMachineController.addContinuationEvent(Events.TO__8000_TERMINATION, "END_OF__9000_ERROR");
		instanceStateMachineController.sendEvent(Events.TO__9000_ERROR);

	}
	/**
	 * State process operation _2400OpenOutputQueuePostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2400OpenOutputQueuePostif(Codate01Context ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__2400_OPEN_OUTPUT_QUEUE_POSTIF");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation _2400OpenOutputQueueCasebranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2400OpenOutputQueueCasebranch(Codate01Context ctx, ExecutionController ctrl) {
		ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
		ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
		ctx.getMqErrDisplay().getMqApplQueueNameReference().setValue(ctx.getQueueInfo().getReplyQueueNameReference());
		ctx.getMqErrDisplay().setMqApplReturnMessage("OUT MQOPEN ERR");
		instanceStateMachineController.addContinuationEvent(Events.TO__8000_TERMINATION, "END_OF__9000_ERROR");
		instanceStateMachineController.sendEvent(Events.TO__9000_ERROR);

	}
	/**
	 * State process operation _3000GetRequestPostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000GetRequestPostif(Codate01Context ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__3000_GET_REQUEST_POSTIF");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation _3000GetRequestThenbranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000GetRequestThenbranch(Codate01Context ctx, ExecutionController ctrl) {
		ctx.getMqMsgId().getMqMsgIdReference().setValue(ctx.getMqMessageDescriptor().getMqmdMsgidReference());
		ctx.getMqCorrelid().getMqCorrelidReference().setValue(ctx.getMqMessageDescriptor().getMqmdCorrelidReference());
		ctx.getMqQueueReply().getMqQueueReplyReference().setValue(ctx.getMqMessageDescriptor().getMqmdReplytoqReference());
		ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
		ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
		ctx.getRequestMessage().getRequestMessageReference().setValue(ctx.getMqBuffer().getMqBufferReference());
		ctx.getSaveCorelid().getSaveCorelidReference().setValue(ctx.getMqCorrelid().getMqCorrelidReference());
		ctx.getSaveReply2q().getSaveReply2qReference().setValue(ctx.getMqQueueReply().getMqQueueReplyReference());
		ctx.getSaveMsgid().getSaveMsgidReference().setValue(ctx.getMqMsgId().getMqMsgIdReference());
		ctx.getRequestMsgCopy().setBytes(ctx.getRequestMessage().getRequestMessageReference().getBytes());
		instanceStateMachineController.addContinuationEvent(Events.TO__3000_GET_REQUEST_POST__4000PROCESSREQUESTREPLY, "END_OF__4000_PROCESS_REQUEST_REPLY_POST__4100PUTREPLY");
		instanceStateMachineController.sendEvent(Events.TO__4000_PROCESS_REQUEST_REPLY);

	}
	/**
	 * State process operation _3000GetRequestElsebranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000GetRequestElsebranch(Codate01Context ctx, ExecutionController ctrl) {
		if (ctx.getMqReasonCode().getMqReasonCode() == ctx.getCmqvMqhc().getMqrcNoMsgAvailable()) {
			ctx.getWsMqMsgFlag().setNoMoreMsgs(true);
			instanceStateMachineController.sendEvent(Events.TO__3000_GET_REQUEST_POSTIF);
		} else {
			instanceStateMachineController.sendEvent(Events.TO__3000_GET_REQUEST_ELSEBRANCH_1);
			return;
		}

	}
	/**
	 * State process operation _3000GetRequestElsebranch1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000GetRequestElsebranch1(Codate01Context ctx, ExecutionController ctrl) {
		ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
		ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
		ctx.getMqErrDisplay().getMqApplQueueNameReference().setValue(ctx.getQueueInfo().getInputQueueNameReference());
		ctx.getMqErrDisplay().setMqApplReturnMessage("INP MQGET ERR:");
		instanceStateMachineController.addContinuationEvent(Events.TO__8000_TERMINATION, "END_OF__9000_ERROR");
		instanceStateMachineController.sendEvent(Events.TO__9000_ERROR);

	}
	/**
	 * State process operation _4100PutReplyPostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4100PutReplyPostif(Codate01Context ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__4100_PUT_REPLY_POSTIF");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation _4100PutReplyCasebranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4100PutReplyCasebranch(Codate01Context ctx, ExecutionController ctrl) {
		ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
		ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
		ctx.getMqErrDisplay().getMqApplQueueNameReference().setValue(ctx.getQueueInfo().getReplyQueueNameReference());
		ctx.getMqErrDisplay().setMqApplReturnMessage("MQPUT ERR");
		instanceStateMachineController.addContinuationEvent(Events.TO__8000_TERMINATION, "END_OF__9000_ERROR");
		instanceStateMachineController.sendEvent(Events.TO__9000_ERROR);

	}
	/**
	 * State process operation _8000TerminationPostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8000TerminationPostif(Codate01Context ctx, ExecutionController ctrl) {
		if (ctx.getWsRespQueueSts().isRespQueueOpen()) {
			instanceStateMachineController.sendEvent(Events.TO__8000_TERMINATION_THENBRANCH_1);
			return;
		} else {
			instanceStateMachineController.sendEvent(Events.TO__8000_TERMINATION_POSTIF_1);
		}

	}
	/**
	 * State process operation _8000TerminationThenbranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8000TerminationThenbranch(Codate01Context ctx, ExecutionController ctrl) {
		instanceStateMachineController.addContinuationEvent(Events.TO__8000_TERMINATION_POSTIF, "END_OF__5000_CLOSE_INPUT_QUEUE");
		instanceStateMachineController.sendEvent(Events.TO__5000_CLOSE_INPUT_QUEUE);

	}
	/**
	 * State process operation _8000TerminationPostif1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8000TerminationPostif1(Codate01Context ctx, ExecutionController ctrl) {
		instanceCodate01Process._8000TerminationPostif(ctx, ctrl);
		instanceStateMachineController.addContinuationEvent(Events.TO__8000_TERMINATION_POST__5200CLOSEERRORQUEUE, "END_OF__5200_CLOSE_ERROR_QUEUE_POSTIF");
		instanceStateMachineController.sendEvent(Events.TO__5200_CLOSE_ERROR_QUEUE);

	}
	/**
	 * State process operation _8000TerminationThenbranch1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8000TerminationThenbranch1(Codate01Context ctx, ExecutionController ctrl) {
		instanceStateMachineController.addContinuationEvent(Events.TO__8000_TERMINATION_POSTIF_1, "END_OF__5100_CLOSE_OUTPUT_QUEUE");
		instanceStateMachineController.sendEvent(Events.TO__5100_CLOSE_OUTPUT_QUEUE);

	}
	/**
	 * State process operation _5200CloseErrorQueuePostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5200CloseErrorQueuePostif(Codate01Context ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__5200_CLOSE_ERROR_QUEUE_POSTIF");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation _5200CloseErrorQueueCasebranch.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _5200CloseErrorQueueCasebranch(Codate01Context ctx, ExecutionController ctrl) {
		ctx.getMqErrDisplay().setMqApplConditionCode(ctx.getMqConditionCode().getMqConditionCode());
		ctx.getMqErrDisplay().setMqApplReasonCode(ctx.getMqReasonCode().getMqReasonCode());
		ctx.getMqErrDisplay().getMqApplQueueNameReference().setValue(ctx.getQueueInfo().getErrorQueueNameReference());
		ctx.getMqErrDisplay().setMqApplReturnMessage("MQCLOSE ERR");
		instanceStateMachineController.addContinuationEvent(Events.TO__8000_TERMINATION, "END_OF__9000_ERROR");
		instanceStateMachineController.sendEvent(Events.TO__9000_ERROR);

	}
	/**
	 * State process operation _1000ControlPost2100openerrorqueue.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000ControlPost2100openerrorqueue(Codate01Context ctx, ExecutionController ctrl) {
		
		/* 
		****************************************************************
		GET THE QUEUE NAME WHICH STARTED THE TRANSACTION               *
		**************************************************************** */
		RetrieveBuilder.newInstance(ctx.getJicsEiblk().getRecord(), ctrl.getExecutionContext(), ctx)
		.into(ctx.getMqGetQueueMessage().getMqtmReference())
		.execute();
		ctx.getWsCicsRespCds().getWsCicsResp1CdReference().setValue(ctx.getDfheiblk().getEibrespReference());
		ctx.getWsCicsRespCds().getWsCicsResp2CdReference().setValue(ctx.getDfheiblk().getEibresp2Reference());
		if (ctx.getWsCicsRespCds().getWsCicsResp1Cd() == ResponseCode.NORMAL.getIntValue()) {
			ctx.getQueueInfo().getInputQueueNameReference().setValue(ctx.getMqGetQueueMessage().getMqtmQnameReference());
			ctx.getQueueInfo().setReplyQueueName("CARD.DEMO.REPLY.DATE");
			instanceStateMachineController.sendEvent(Events.TO__1000_CONTROL_POSTIF);
		} else {
			instanceStateMachineController.sendEvent(Events.TO__1000_CONTROL_ELSEBRANCH);
			return;
		}

	}
	/**
	 * State process operation _1000ControlPost2300openinputqueue.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000ControlPost2300openinputqueue(Codate01Context ctx, ExecutionController ctrl) {
		instanceStateMachineController.addContinuationEvent(Events.TO__1000_CONTROL_POST__2400OPENOUTPUTQUEUE, "END_OF__2400_OPEN_OUTPUT_QUEUE_POSTIF");
		instanceStateMachineController.sendEvent(Events.TO__2400_OPEN_OUTPUT_QUEUE);

	}
	/**
	 * State process operation _1000ControlPost2400openoutputqueue.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000ControlPost2400openoutputqueue(Codate01Context ctx, ExecutionController ctrl) {
		instanceStateMachineController.addContinuationEvent(Events.TO__1000_CONTROL_LOOP, "END_OF__3000_GET_REQUEST_POSTIF");
		instanceStateMachineController.sendEvent(Events.TO__3000_GET_REQUEST);

	}
	/**
	 * State process operation _4000MainProcessPost3000getrequest.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4000MainProcessPost3000getrequest(Codate01Context ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__4000_MAIN_PROCESS_POST__3000GETREQUEST");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation _3000GetRequestPost4000processrequestreply.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000GetRequestPost4000processrequestreply(Codate01Context ctx, ExecutionController ctrl) {
		ctx.getMqMsgCount().setMqMsgCount(ctx.getMqMsgCount().getMqMsgCount() + 1);
		instanceStateMachineController.sendEvent(Events.TO__3000_GET_REQUEST_POSTIF);

	}
	/**
	 * State process operation _4000ProcessRequestReplyPost4100putreply.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4000ProcessRequestReplyPost4100putreply(Codate01Context ctx, ExecutionController ctrl) {
				boolean res = false; 
		res = instanceStateMachineController.sendContinuationEventIfActive("END_OF__4000_PROCESS_REQUEST_REPLY_POST__4100PUTREPLY");
		if (res) {
			return;
		} 

	}
	/**
	 * State process operation _8000TerminationPost5200closeerrorqueue.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8000TerminationPost5200closeerrorqueue(Codate01Context ctx, ExecutionController ctrl) {
		instanceCodate01Process._8000TerminationPostif1(ctx, ctrl);

	}
}
