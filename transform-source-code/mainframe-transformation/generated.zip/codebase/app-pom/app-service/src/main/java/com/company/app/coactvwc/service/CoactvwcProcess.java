package com.company.app.coactvwc.service;

import com.company.app.coactvwc.business.context.CoactvwcContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface CoactvwcProcess.
 * 
 * Defines application services for CoactvwcProcess
 */
public interface CoactvwcProcess {

	/**
	 * Process operation coactvwc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void coactvwc(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation commonReturn.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void commonReturn(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000SendMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000SendMap(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1100ScreenInit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1100ScreenInit(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1200SetupScreenVars.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1200SetupScreenVars(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1300SetupScreenAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1300SetupScreenAttrs(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1400SendScreen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1400SendScreen(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2000ProcessInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000ProcessInputs(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2100ReceiveMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2100ReceiveMap(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2200EditMapInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2200EditMapInputs(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2210EditAccount.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2210EditAccount(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9000ReadAcct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9000ReadAcct(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9200GetcardxrefByacct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9200GetcardxrefByacct(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9300GetacctdataByacct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9300GetacctdataByacct(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9400GetcustdataBycust.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9400GetcustdataBycust(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation sendPlainText.
	 * 
	 * ****************************************************************
	 *  Plain text exit - Dont use in production                      *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void sendPlainText(final CoactvwcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation sendLongText.
	 * 
	 * ****************************************************************
	 *  Display Long text and exit                                    *
	 *  This is primarily for debugging and should not be used in     *
	 *  regular course                                                *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void sendLongText(final CoactvwcContext ctx, final ExecutionController ctrl);

}
