package com.company.app.cotrtupc.service;

import com.company.app.cotrtupc.business.context.CotrtupcContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface CotrtupcProcess.
 * 
 * Defines application services for CotrtupcProcess
 */
public interface CotrtupcProcess {

	/**
	 * Process operation cotrtupc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void cotrtupc(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation commonReturn.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void commonReturn(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0001CheckPfkeys.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0001CheckPfkeys(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000ProcessInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000ProcessInputs(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1100ReceiveMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1100ReceiveMap(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1150StoreMapInNew.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1150StoreMapInNew(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1200EditMapInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1200EditMapInputs(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1205CompareOldNew.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1205CompareOldNew(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1210EditTrantype.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1210EditTrantype(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1230EditAlphanumReqd.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1230EditAlphanumReqd(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1245EditNumReqd.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1245EditNumReqd(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3000SendMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000SendMap(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3100ScreenInit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3100ScreenInit(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3200SetupScreenVars.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3200SetupScreenVars(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3201ShowInitialValues.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3201ShowInitialValues(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3202ShowOriginalValues.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3202ShowOriginalValues(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3203ShowUpdatedValues.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3203ShowUpdatedValues(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3250SetupInfomsg.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3250SetupInfomsg(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3300SetupScreenAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3300SetupScreenAttrs(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3310ProtectAllAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3310ProtectAllAttrs(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3320UnprotectFewAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3320UnprotectFewAttrs(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3390SetupInfomsgAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3390SetupInfomsgAttrs(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3391SetupPfkeyAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3391SetupPfkeyAttrs(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3400SendScreen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3400SendScreen(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9000ReadTrantype.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9000ReadTrantype(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9100GetTransactionType.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9100GetTransactionType(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9500StoreFetchedData.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9500StoreFetchedData(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9600WriteProcessing.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9600WriteProcessing(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9700InsertRecord.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9700InsertRecord(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9800DeleteProcessing.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9800DeleteProcessing(final CotrtupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation abendRoutine.
	 * 
	 * ****************************************************************
	 * Common code to store PFKey
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void abendRoutine(final CotrtupcContext ctx, final ExecutionController ctrl);

}
