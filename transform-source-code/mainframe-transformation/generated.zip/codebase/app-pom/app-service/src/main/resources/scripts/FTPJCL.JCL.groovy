// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "FTPJCLS"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//
	//
	//*****************************************************************
	// Copyright Amazon.com, Inc. or its affiliates.
	// All Rights Reserved.
	//
	// Licensed under the Apache License, Version 2.0 (the "License").
	// You may not use this file except in compliance with the License.
	// You may obtain a copy of the License at
	//
	//    http://www.apache.org/licenses/LICENSE-2.0
	//
	// Unless required by applicable law or agreed to in writing,
	// software distributed under the License is distributed on an
	// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	// either express or implied. See the License for the specific
	// language governing permissions and limitations under the License
	//*****************************************************************
	//********************************************************************
	// FTP JOB TO RECEIVE A FILE
	// MY.FTP.SERVER.COM IS THE FTP SERVER NAME(SUBJECT TO CHANGE FOR SITE)
	// USER ID - EITHER SCHEDULER ID OR TSO USER ID
	// PASSWORD OF THE USER
	// FOLDER TO FTP THE MAINFRAME FILE
	// PUT COMMAND FOR SENDING MAINFRAME FILE TO TXT
	// CHANGE THE PUT COMMAND TO GET TO RECEIVE FILE INTO MAINFRAME
	//********************************************************************
	lastProgramResult = stepSTEP1(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP STEP1 - PGM - FTP*********************************************************
def stepSTEP1(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP1", "FTP", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.fileSystem("SYSIN")
						.stream(
""" 172.31.21.124
 carddemousr
 ftpdemo1
 ASCII
 pwd
 dir
 cd /ftpfolder
 PUT 'AWS.M2.CARDEMO.FTP.TEST' welcome.txt
 QUIT""", getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("FTP")
				})
		}
	}
}
