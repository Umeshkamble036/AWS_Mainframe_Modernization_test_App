
package com.company.app.cotrn00c.service.impl;

import com.company.app.core.helper.BluageUtils;
import com.company.app.cotrn00c.business.context.Cotrn00cContext;
import com.company.app.cotrn00c.service.Cotrn00cProcess;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.NumberUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.bms.ReceiveMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.XCTLBuilder;
import com.netfective.bluage.gapwalk.rt.jics.io.internal.JicsFileBuilder;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Cotrn00cProcessImpl
 * 
 * Defines application services for Cotrn00cProcess
 * @see Cotrn00cProcess
 */
@Service("com.company.app.cotrn00c.service.Cotrn00cProcess")
@Lazy

public class Cotrn00cProcessImpl implements Cotrn00cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Cotrn00cProcessImpl.class);


	/**
	 * Process operation mainPara.
	 * 
	 * PROGRAM-ID.COTRN00C.
	 *  AUTHOR.     AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void mainPara(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		ctx.getDfheiblk().bind(ArgUtils.get(ctx, 0));
		ctx.getDfhcommarea().bind(ArgUtils.get(ctx, 1));
		
		/* 
		*****************************************************************
		Program     : COTRN00C.CBL
		Application : CardDemo
		Type        : CICS COBOL Program
		Function    : List Transactions from TRANSACT file
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		----------------------------------------------------------------*
		WORKING STORAGE SECTION
		----------------------------------------------------------------*
		No background transparency
		----------------------------------------------------------------*
		LINKAGE SECTION
		----------------------------------------------------------------*
		----------------------------------------------------------------*
		PROCEDURE DIVISION
		----------------------------------------------------------------* */
		ctx.getWsVariables().setErrFlgOff(true);
		ctx.getWsVariables().setTransactNotEof(true);
		ctx.getWsVariables().setNextPageNo(true);
		ctx.getWsVariables().setSendEraseYes(true);
		DataUtils.setToBlank(ctx.getWsVariables().getWsMessageReference());
		
		/* 
		FIXME: ERRMSGO OF COTRN0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNIDINL OF COTRN0AI */
		BluageUtils.unsupported();
		if (ctx.getDfheiblk().getEibcalen() == 0) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
			returnToPrevScreen(ctx, ctrl);
		} else {
			
			/* 
			FIXME: CARDDEMO-COMMAREA */
			BluageUtils.unsupported();
			if (!(BluageUtils.unsupported())) {
				
				/* 
				FIXME: CDEMO-PGM-REENTER */
				BluageUtils.unsupported();
				
				/* 
				FIXME: COTRN0AO */
				BluageUtils.unsupported();
				processEnterKey(ctx, ctrl);
				sendTrnlstScreen(ctx, ctrl);
			} else {
				receiveTrnlstScreen(ctx, ctrl);
				if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) == 0) {
					processEnterKey(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf3Reference()) == 0) {
					
					/* 
					FIXME: CDEMO-TO-PROGRAM */
					BluageUtils.unsupported();
					returnToPrevScreen(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf7Reference()) == 0) {
					processPf7Key(ctx, ctrl);
				} else if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf8Reference()) == 0) {
					processPf8Key(ctx, ctrl);
				} else {
					ctx.getWsVariables().setWsErrFlg("Y");
					
					/* 
					FIXME: TRNIDINL OF COTRN0AI */
					BluageUtils.unsupported();
					ctx.getWsVariables().setWsMessage(BluageUtils.unsupported());
					sendTrnlstScreen(ctx, ctrl);
				}
			}
		}
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsVariables().getWsTranid())
		.withCommarea(BluageUtils.unsupported())
		.execute()
		.handleException();
	}

	/**
	 * Process operation processEnterKey.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-ENTER-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processEnterKey(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setCdemoCt00TrnSelFlg(BluageUtils.unsupported());
			ctx.getWsVariables().setCdemoCt00TrnSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setCdemoCt00TrnSelFlg(BluageUtils.unsupported());
			ctx.getWsVariables().setCdemoCt00TrnSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setCdemoCt00TrnSelFlg(BluageUtils.unsupported());
			ctx.getWsVariables().setCdemoCt00TrnSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setCdemoCt00TrnSelFlg(BluageUtils.unsupported());
			ctx.getWsVariables().setCdemoCt00TrnSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setCdemoCt00TrnSelFlg(BluageUtils.unsupported());
			ctx.getWsVariables().setCdemoCt00TrnSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setCdemoCt00TrnSelFlg(BluageUtils.unsupported());
			ctx.getWsVariables().setCdemoCt00TrnSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setCdemoCt00TrnSelFlg(BluageUtils.unsupported());
			ctx.getWsVariables().setCdemoCt00TrnSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setCdemoCt00TrnSelFlg(BluageUtils.unsupported());
			ctx.getWsVariables().setCdemoCt00TrnSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setCdemoCt00TrnSelFlg(BluageUtils.unsupported());
			ctx.getWsVariables().setCdemoCt00TrnSelected(BluageUtils.unsupported());
		} else if (!(DataUtils.isBlank(BluageUtils.unsupported())) && !(DataUtils.isLowValue(BluageUtils.unsupported()))) {
			ctx.getWsVariables().setCdemoCt00TrnSelFlg(BluageUtils.unsupported());
			ctx.getWsVariables().setCdemoCt00TrnSelected(BluageUtils.unsupported());
		} else {
			DataUtils.setToBlank(ctx.getWsVariables().getCdemoCt00TrnSelFlgReference());
			DataUtils.setToBlank(ctx.getWsVariables().getCdemoCt00TrnSelectedReference());
		}
		if (!(DataUtils.isBlank(ctx.getWsVariables().getCdemoCt00TrnSelFlgReference())) && !(DataUtils.isLowValue(ctx.getWsVariables().getCdemoCt00TrnSelFlgReference())) && !(DataUtils.isBlank(ctx.getWsVariables().getCdemoCt00TrnSelectedReference())) && !(DataUtils.isLowValue(ctx.getWsVariables().getCdemoCt00TrnSelectedReference()))) {
			if (DataUtils.compare(ctx.getWsVariables().getCdemoCt00TrnSelFlgReference(), "S") == 0 || DataUtils.compare(ctx.getWsVariables().getCdemoCt00TrnSelFlgReference(), "s") == 0) {
				
				/* 
				FIXME: CDEMO-TO-PROGRAM */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-FROM-TRANID */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-FROM-PROGRAM */
				BluageUtils.unsupported();
				
				/* 
				FIXME: CDEMO-PGM-CONTEXT */
				BluageUtils.unsupported();
				XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
			} else {
				
				/* 
				SET TRANSACT-EOF TO TRUE */
				ctx.getWsVariables().setWsMessage("Invalid selection. Valid value is S");
				
				/* 
				FIXME: TRNIDINL OF COTRN0AI */
				BluageUtils.unsupported();
				
				/* 
				PERFORM SEND-TRNLST-SCREEN */
			}
		} 
		if (DataUtils.isBlank(BluageUtils.unsupported()) || DataUtils.isLowValue(BluageUtils.unsupported())) {
			
			/* 
			FIXME: TRAN-ID */
			BluageUtils.unsupported();
		} else {
			if (DataUtils.isNumeric(BluageUtils.unsupported())) {
				
				/* 
				FIXME: TRAN-ID */
				BluageUtils.unsupported();
			} else {
				ctx.getWsVariables().setWsErrFlg("Y");
				ctx.getWsVariables().setWsMessage("Tran ID must be Numeric ...");
				
				/* 
				FIXME: TRNIDINL OF COTRN0AI */
				BluageUtils.unsupported();
				sendTrnlstScreen(ctx, ctrl);
			}
		}
		
		/* 
		FIXME: TRNIDINL OF COTRN0AI */
		BluageUtils.unsupported();
		ctx.getWsVariables().setCdemoCt00PageNum(0);
		processPageForward(ctx, ctrl);
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			
			/* 
			FIXME: TRNIDINO  OF COTRN0AO */
			BluageUtils.unsupported();
		}
	}

	/**
	 * Process operation processPf7Key.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-PF7-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processPf7Key(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isBlank(ctx.getWsVariables().getCdemoCt00TrnidFirstReference()) || DataUtils.isLowValue(ctx.getWsVariables().getCdemoCt00TrnidFirstReference())) {
			
			/* 
			FIXME: TRAN-ID */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: TRAN-ID */
			BluageUtils.unsupported();
		}
		ctx.getWsVariables().setNextPageYes(true);
		
		/* 
		FIXME: TRNIDINL OF COTRN0AI */
		BluageUtils.unsupported();
		if (NumberUtils.gt(ctx.getWsVariables().getCdemoCt00PageNumReference(), 1)) {
			processPageBackward(ctx, ctrl);
		} else {
			ctx.getWsVariables().setWsMessage("You are already at the top of the page...");
			ctx.getWsVariables().setSendEraseNo(true);
			sendTrnlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation processPf8Key.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-PF8-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processPf8Key(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isBlank(ctx.getWsVariables().getCdemoCt00TrnidLastReference()) || DataUtils.isLowValue(ctx.getWsVariables().getCdemoCt00TrnidLastReference())) {
			
			/* 
			FIXME: TRAN-ID */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: TRAN-ID */
			BluageUtils.unsupported();
		}
		
		/* 
		FIXME: TRNIDINL OF COTRN0AI */
		BluageUtils.unsupported();
		if (ctx.getWsVariables().isNextPageYes()) {
			processPageForward(ctx, ctrl);
		} else {
			ctx.getWsVariables().setWsMessage("You are already at the bottom of the page...");
			ctx.getWsVariables().setSendEraseNo(true);
			sendTrnlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation processPageForward.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-PAGE-FORWARD
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processPageForward(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		startbrTransactFile(ctx, ctrl);
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) != 0 && DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf7Reference()) != 0 && DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf3Reference()) != 0) {
				readnextTransactFile(ctx, ctrl);
			} 
			if (ctx.getWsVariables().isTransactNotEof() && ctx.getWsVariables().isErrFlgOff()) {
				ctx.getWsVariables().setWsIdx(1);
				while (ctx.getWsVariables().getWsIdx() <= 10) {
					initializeTranData(ctx, ctrl);
					ctx.getWsVariables().setWsIdx(ctx.getWsVariables().getWsIdx() + 1);
				}
			} 
			ctx.getWsVariables().setWsIdx(1);
			while (!(ctx.getWsVariables().getWsIdx() >= 11 || ctx.getWsVariables().isTransactEof() || ctx.getWsVariables().isErrFlgOn())) {
				readnextTransactFile(ctx, ctrl);
				if (ctx.getWsVariables().isTransactNotEof() && ctx.getWsVariables().isErrFlgOff()) {
					populateTranData(ctx, ctrl);
					ctx.getWsVariables().setWsIdx(ctx.getWsVariables().getWsIdx() + 1);
				} 
			}
			if (ctx.getWsVariables().isTransactNotEof() && ctx.getWsVariables().isErrFlgOff()) {
				ctx.getWsVariables().setCdemoCt00PageNum(ctx.getWsVariables().getCdemoCt00PageNum() + 1);
				readnextTransactFile(ctx, ctrl);
				if (ctx.getWsVariables().isTransactNotEof() && ctx.getWsVariables().isErrFlgOff()) {
					ctx.getWsVariables().setNextPageYes(true);
				} else {
					ctx.getWsVariables().setNextPageNo(true);
				}
			} else {
				ctx.getWsVariables().setNextPageNo(true);
				if (ctx.getWsVariables().getWsIdx() > 1) {
					ctx.getWsVariables().setCdemoCt00PageNum(ctx.getWsVariables().getCdemoCt00PageNum() + 1);
				} 
			}
			endbrTransactFile(ctx, ctrl);
			
			/* 
			FIXME: PAGENUMI  OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TRNIDINO  OF COTRN0AO */
			BluageUtils.unsupported();
			sendTrnlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation processPageBackward.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-PAGE-BACKWARD
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processPageBackward(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		startbrTransactFile(ctx, ctrl);
		if (!(ctx.getWsVariables().isErrFlgOn())) {
			if (DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhenterReference()) != 0 && DataUtils.compare(ctx.getDfheiblk().getEibaidReference(), ctx.getDfhaid().getDfhpf8Reference()) != 0) {
				readprevTransactFile(ctx, ctrl);
			} 
			if (ctx.getWsVariables().isTransactNotEof() && ctx.getWsVariables().isErrFlgOff()) {
				ctx.getWsVariables().setWsIdx(1);
				while (ctx.getWsVariables().getWsIdx() <= 10) {
					initializeTranData(ctx, ctrl);
					ctx.getWsVariables().setWsIdx(ctx.getWsVariables().getWsIdx() + 1);
				}
			} 
			ctx.getWsVariables().setWsIdx(10);
			while (!(ctx.getWsVariables().getWsIdx() <= 0 || ctx.getWsVariables().isTransactEof() || ctx.getWsVariables().isErrFlgOn())) {
				readprevTransactFile(ctx, ctrl);
				if (ctx.getWsVariables().isTransactNotEof() && ctx.getWsVariables().isErrFlgOff()) {
					populateTranData(ctx, ctrl);
					ctx.getWsVariables().setWsIdx(ctx.getWsVariables().getWsIdx() - 1);
				} 
			}
			if (ctx.getWsVariables().isTransactNotEof() && ctx.getWsVariables().isErrFlgOff()) {
				readprevTransactFile(ctx, ctrl);
				if (ctx.getWsVariables().isNextPageYes()) {
					if (ctx.getWsVariables().isTransactNotEof() && ctx.getWsVariables().isErrFlgOff() && NumberUtils.gt(ctx.getWsVariables().getCdemoCt00PageNumReference(), 1)) {
						ctx.getWsVariables().setCdemoCt00PageNum(ctx.getWsVariables().getCdemoCt00PageNum() - 1);
					} else {
						ctx.getWsVariables().setCdemoCt00PageNum(1);
					}
				} 
			} 
			endbrTransactFile(ctx, ctrl);
			
			/* 
			FIXME: PAGENUMI  OF COTRN0AI */
			BluageUtils.unsupported();
			sendTrnlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation populateTranData.
	 * 
	 * ----------------------------------------------------------------*
	 *                       POPULATE-TRAN-DATA
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void populateTranData(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		ctx.getWsVariables().setWsTranAmt(BluageUtils.unsupported());
		
		/* 
		FIXME: WS-TIMESTAMP */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		ctx.getWsVariables().setWsTranDate(BluageUtils.unsupported());
		if (ctx.getWsVariables().getWsIdx() == 1) {
			
			/* 
			FIXME: TRNID01I OF COTRN0AI */
			BluageUtils.unsupported();
			ctx.getWsVariables().setCdemoCt00TrnidFirst(BluageUtils.unsupported());
			
			/* 
			FIXME: TDATE01I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC01I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT001I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 2) {
			
			/* 
			FIXME: TRNID02I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE02I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC02I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT002I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 3) {
			
			/* 
			FIXME: TRNID03I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE03I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC03I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT003I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 4) {
			
			/* 
			FIXME: TRNID04I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE04I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC04I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT004I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 5) {
			
			/* 
			FIXME: TRNID05I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE05I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC05I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT005I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 6) {
			
			/* 
			FIXME: TRNID06I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE06I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC06I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT006I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 7) {
			
			/* 
			FIXME: TRNID07I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE07I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC07I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT007I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 8) {
			
			/* 
			FIXME: TRNID08I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE08I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC08I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT008I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 9) {
			
			/* 
			FIXME: TRNID09I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE09I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC09I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT009I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 10) {
			
			/* 
			FIXME: TRNID10I OF COTRN0AI */
			BluageUtils.unsupported();
			ctx.getWsVariables().setCdemoCt00TrnidLast(BluageUtils.unsupported());
			
			/* 
			FIXME: TDATE10I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC10I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT010I OF COTRN0AI */
			BluageUtils.unsupported();
		} else {
			
			/* 
			Do nothing */
		}
	}

	/**
	 * Process operation initializeTranData.
	 * 
	 * ----------------------------------------------------------------*
	 *                       INITIALIZE-TRAN-DATA
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void initializeTranData(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		if (ctx.getWsVariables().getWsIdx() == 1) {
			
			/* 
			FIXME: TRNID01I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE01I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC01I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT001I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 2) {
			
			/* 
			FIXME: TRNID02I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE02I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC02I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT002I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 3) {
			
			/* 
			FIXME: TRNID03I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE03I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC03I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT003I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 4) {
			
			/* 
			FIXME: TRNID04I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE04I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC04I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT004I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 5) {
			
			/* 
			FIXME: TRNID05I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE05I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC05I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT005I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 6) {
			
			/* 
			FIXME: TRNID06I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE06I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC06I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT006I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 7) {
			
			/* 
			FIXME: TRNID07I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE07I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC07I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT007I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 8) {
			
			/* 
			FIXME: TRNID08I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE08I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC08I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT008I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 9) {
			
			/* 
			FIXME: TRNID09I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE09I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC09I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT009I OF COTRN0AI */
			BluageUtils.unsupported();
		} else if (ctx.getWsVariables().getWsIdx() == 10) {
			
			/* 
			FIXME: TRNID10I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDATE10I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TDESC10I OF COTRN0AI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: TAMT010I OF COTRN0AI */
			BluageUtils.unsupported();
		} else {
			
			/* 
			Do nothing */
		}
	}

	/**
	 * Process operation returnToPrevScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RETURN-TO-PREV-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void returnToPrevScreen(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CDEMO-TO-PROGRAM */
			BluageUtils.unsupported();
		} 
		
		/* 
		FIXME: CDEMO-FROM-TRANID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-FROM-PROGRAM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-PGM-CONTEXT */
		BluageUtils.unsupported();
		XCTLBuilder.newInstance(ctx.getJicsEiblk(), ctx).withProgram(BluageUtils.unsupported()).withNonParentCommarea(BluageUtils.unsupported()).execute().handleException();
	}

	/**
	 * Process operation sendTrnlstScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       SEND-TRNLST-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendTrnlstScreen(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		populateHeaderInfo(ctx, ctrl);
		
		/* 
		FIXME: ERRMSGO OF COTRN0AO */
		BluageUtils.unsupported();
		if (ctx.getWsVariables().isSendEraseYes()) {
			SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
			.withMap("COTRN0A")
			.withMapset("COTRN00")
			.withData(BluageUtils.unsupported())
			.withErase()
			.withCursor()
			.execute()
			.handleException();
		} else {
			SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
			.withMap("COTRN0A")
			.withMapset("COTRN00")
			.withData(BluageUtils.unsupported())
			.withCursor()
			.execute()
			.handleException();
		}
	}

	/**
	 * Process operation receiveTrnlstScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       RECEIVE-TRNLST-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void receiveTrnlstScreen(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		ReceiveMapBuilder.newInstance(ctx.getJicsEiblk(), ctrl.getExecutionContext(), ctx)
		.withMap("COTRN0A")
		.withMapset("COTRN00")
		.into(BluageUtils.unsupported())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
	}

	/**
	 * Process operation populateHeaderInfo.
	 * 
	 * ----------------------------------------------------------------*
	 *                       POPULATE-HEADER-INFO
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void populateHeaderInfo(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE01O OF COTRN0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE02O OF COTRN0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNNAMEO OF COTRN0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PGMNAMEO OF COTRN0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURDATEO OF COTRN0AO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-HH */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-SS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURTIMEO OF COTRN0AO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation startbrTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       STARTBR-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void startbrTransactFile(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.startBrowse()
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			
			/* 
			Do nothing */
			ctx.getWsVariables().setTransactEof(true);
			ctx.getWsVariables().setWsMessage("You are at the top of the page...");
			
			/* 
			FIXME: TRNIDINL OF COTRN0AI */
			BluageUtils.unsupported();
			sendTrnlstScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup transaction...");
			
			/* 
			FIXME: TRNIDINL OF COTRN0AI */
			BluageUtils.unsupported();
			sendTrnlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation readnextTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       READNEXT-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readnextTransactFile(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.readNext()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.ENDFILE.getIntValue()) {
			
			/* 
			Do nothing */
			ctx.getWsVariables().setTransactEof(true);
			ctx.getWsVariables().setWsMessage("You have reached the bottom of the page...");
			
			/* 
			FIXME: TRNIDINL OF COTRN0AI */
			BluageUtils.unsupported();
			sendTrnlstScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup transaction...");
			
			/* 
			FIXME: TRNIDINL OF COTRN0AI */
			BluageUtils.unsupported();
			sendTrnlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation readprevTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       READPREV-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readprevTransactFile(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.readPrev()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(BluageUtils.unsupported())
		.keyLength(BluageUtils.unsupported().length(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsVariables().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsVariables().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			Do nothing */
		} else if (ctx.getWsVariables().getWsRespCd() == ResponseCode.ENDFILE.getIntValue()) {
			
			/* 
			Do nothing */
			ctx.getWsVariables().setTransactEof(true);
			ctx.getWsVariables().setWsMessage("You have reached the top of the page...");
			
			/* 
			FIXME: TRNIDINL OF COTRN0AI */
			BluageUtils.unsupported();
			sendTrnlstScreen(ctx, ctrl);
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}{}{}" , "RESP:" , ctx.getWsVariables().getWsRespCdReference().getDisplayValue(String.class) , "REAS:" , ctx.getWsVariables().getWsReasCdReference().getDisplayValue(String.class));
			ctx.getWsVariables().setWsErrFlg("Y");
			ctx.getWsVariables().setWsMessage("Unable to lookup transaction...");
			
			/* 
			FIXME: TRNIDINL OF COTRN0AI */
			BluageUtils.unsupported();
			sendTrnlstScreen(ctx, ctrl);
		}
	}

	/**
	 * Process operation endbrTransactFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       ENDBR-TRANSACT-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void endbrTransactFile(final Cotrn00cContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsVariables().getWsTransactFileReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.endBrowse()
		.execute()
		.handleException();
		
		/* 
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:34 CDT */
		return;
	}

}
