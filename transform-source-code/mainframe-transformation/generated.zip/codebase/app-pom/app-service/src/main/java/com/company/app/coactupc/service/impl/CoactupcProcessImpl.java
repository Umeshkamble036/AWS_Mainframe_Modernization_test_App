
package com.company.app.coactupc.service.impl;

import com.company.app.coactupc.business.context.CoactupcContext;
import com.company.app.coactupc.service.CoactupcProcess;
import com.company.app.coactupc.statemachine.CoactupcProcedureDivisionStateMachineController;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.data.Record;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.NumberUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.StringUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.jics.ResponseCode;
import com.netfective.bluage.gapwalk.rt.jics.bms.ReceiveMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.bms.SendMapBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.AbendBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.HandleAbendBuilder;
import com.netfective.bluage.gapwalk.rt.jics.control.ReturnBuilder;
import com.netfective.bluage.gapwalk.rt.jics.io.internal.JicsFileBuilder;
import com.netfective.bluage.gapwalk.runtime.statements.InspectBuilder;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class CoactupcProcessImpl
 * 
 * Defines application services for CoactupcProcess
 * @see CoactupcProcess
 */
@Service("com.company.app.coactupc.service.CoactupcProcess")
@Import({
com.company.app.coactupc.statemachine.CoactupcProcedureDivisionStateMachineController.class 
}) 	
@Lazy

public class CoactupcProcessImpl implements CoactupcProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(CoactupcProcessImpl.class);

	@Autowired
	private CoactupcProcedureDivisionStateMachineController coactupcProcedureDivisionStateMachineRunner;


	/**
	 * Process operation coactupc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void coactupc(final CoactupcContext ctx, final ExecutionController ctrl) {
		coactupcProcedureDivisionStateMachineRunner.run(ctx,ctrl);
	}

	/**
	 * Process operation commonReturn.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void commonReturn(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CCARD-ERROR-MSG */
		BluageUtils.unsupported();
		ctx.getWsCommarea().setWsCommarea(BluageUtils.unsupported());
		int idx = BluageUtils.unsupported().length() + 1 - 1;
		int len = ctx.getWsThisProgcommarea().getSize();
		ctx.getWsCommarea().getWsCommareaReference().setBytes(ctx.getWsThisProgcommarea().getBytes(), idx, len);
		ReturnBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withTransID(ctx.getWsLiterals().getLitThistranid())
		.withCommarea(ctx.getWsCommarea().getWsCommareaReference())
		.withLength(ctx.getWsCommarea().getWsCommareaReference().getRecord().getSize())
		.execute()
		.handleException();
	}

	/**
	 * Process operation _1000ProcessInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1000ProcessInputs(final CoactupcContext ctx, final ExecutionController ctrl) {
		_1100ReceiveMap(ctx, ctrl);
		_1200EditMapInputs(ctx, ctrl);
		
		/* 
		FIXME: CCARD-ERROR-MSG */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CCARD-NEXT-PROG */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CCARD-NEXT-MAPSET */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CCARD-NEXT-MAP */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation _1100ReceiveMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1100ReceiveMap(final CoactupcContext ctx, final ExecutionController ctrl) {
		ReceiveMapBuilder.newInstance(ctx.getJicsEiblk(), ctrl.getExecutionContext(), ctx)
		.withMap(ctx.getWsLiterals().getLitThismapReference())
		.withMapset(ctx.getWsLiterals().getLitThismapsetReference())
		.into(BluageUtils.unsupported())
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		ctx.getWsThisProgcommarea().getAcupNewDetailsReference().getField().initialize();
		
		/* 
		****************************************************************
		Account Master data
		**************************************************************** */
		if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
			
			/* 
			FIXME: CC-ACCT-ID */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().getAcupNewAcctIdXReference().setBytes(Record.LOW_VALUES);
		} else {
			
			/* 
			FIXME: CC-ACCT-ID */
			BluageUtils.unsupported();
			ctx.getWsThisProgcommarea().setAcupNewAcctIdX(BluageUtils.unsupported());
		}
		if (ctx.getWsThisProgcommarea().isAcupDetailsNotFetched()) {
			return;
		} else {
			
			/* 
			Active Status */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewActiveStatusReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewActiveStatus(BluageUtils.unsupported());
			}
			
			/* 
			Credit Limit */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsMiscStorage().getAcupNewCreditLimitXReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsMiscStorage().setAcupNewCreditLimitX(BluageUtils.unsupported());
				if (DataUtils.compare(NumberUtils.testNumvalC(ctx.getWsMiscStorage().getAcupNewCreditLimitX()), 0) == 0) {
					ctx.getWsThisProgcommarea().setAcupNewCreditLimitN(NumberUtils.convert(BluageUtils.unsupported()));
				} else {
					
					/* 
					Do nothing */
				}
			}
			
			/* 
			Cash Limit */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsMiscStorage().getAcupNewCashCreditLimitXReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsMiscStorage().setAcupNewCashCreditLimitX(BluageUtils.unsupported());
				if (DataUtils.compare(NumberUtils.testNumvalC(ctx.getWsMiscStorage().getAcupNewCashCreditLimitX()), 0) == 0) {
					ctx.getWsThisProgcommarea().setAcupNewCashCreditLimitN(NumberUtils.convert(BluageUtils.unsupported()));
				} else {
					
					/* 
					Do nothing */
				}
			}
			
			/* 
			Current Balance */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsMiscStorage().getAcupNewCurrBalXReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsMiscStorage().setAcupNewCurrBalX(BluageUtils.unsupported());
				if (DataUtils.compare(NumberUtils.testNumvalC(ctx.getWsMiscStorage().getAcupNewCurrBalX()), 0) == 0) {
					ctx.getWsThisProgcommarea().setAcupNewCurrBalN(NumberUtils.convert(ctx.getWsMiscStorage().getAcupNewCurrBalX()));
				} else {
					
					/* 
					Do nothing */
				}
			}
			
			/* 
			Current Cycle Credit */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsMiscStorage().getAcupNewCurrCycCreditXReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsMiscStorage().setAcupNewCurrCycCreditX(BluageUtils.unsupported());
				if (DataUtils.compare(NumberUtils.testNumvalC(ctx.getWsMiscStorage().getAcupNewCurrCycCreditX()), 0) == 0) {
					ctx.getWsThisProgcommarea().setAcupNewCurrCycCreditN(NumberUtils.convert(BluageUtils.unsupported()));
				} else {
					
					/* 
					Do nothing */
				}
			}
			
			/* 
			Current Cycle Debit */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsMiscStorage().getAcupNewCurrCycDebitXReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsMiscStorage().setAcupNewCurrCycDebitX(BluageUtils.unsupported());
				if (DataUtils.compare(NumberUtils.testNumvalC(ctx.getWsMiscStorage().getAcupNewCurrCycDebitX()), 0) == 0) {
					ctx.getWsThisProgcommarea().setAcupNewCurrCycDebitN(NumberUtils.convert(BluageUtils.unsupported()));
				} else {
					
					/* 
					Do nothing */
				}
			}
			
			/* 
			Open date */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewOpenYearReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewOpenYear(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewOpenMonReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewOpenMon(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewOpenDayReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewOpenDay(BluageUtils.unsupported());
			}
			
			/* 
			Expiry date */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewExpYearReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewExpYear(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewExpMonReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewExpMon(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewExpDayReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewExpDay(BluageUtils.unsupported());
			}
			
			/* 
			Reissue date */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewReissueYearReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewReissueYear(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewReissueMonReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewReissueMon(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewReissueDayReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewReissueDay(BluageUtils.unsupported());
			}
			
			/* 
			Account Group */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewGroupIdReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewGroupId(BluageUtils.unsupported());
			}
			
			/* 
			****************************************************************
			Customer Master data
			****************************************************************
			Customer Id (actually not editable) */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustIdXReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustIdX(BluageUtils.unsupported());
			}
			
			/* 
			Social Security Number */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustSsn1Reference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustSsn1(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustSsn2Reference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustSsn2(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustSsn3Reference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustSsn3(BluageUtils.unsupported());
			}
			
			/* 
			Date of birth */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustDobYearReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustDobYear(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustDobMonReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustDobMon(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustDobDayReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustDobDay(BluageUtils.unsupported());
			}
			
			/* 
			FICO */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustFicoScoreXReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustFicoScoreX(BluageUtils.unsupported());
			}
			
			/* 
			First Name */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustFirstNameReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustFirstName(BluageUtils.unsupported());
			}
			
			/* 
			Middle Name */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustMiddleNameReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustMiddleName(BluageUtils.unsupported());
			}
			
			/* 
			Last Name */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustLastNameReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustLastName(BluageUtils.unsupported());
			}
			
			/* 
			Address */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustAddrLine1Reference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustAddrLine1(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustAddrLine2Reference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustAddrLine2(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustAddrLine3Reference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustAddrLine3(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustAddrStateCdReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustAddrStateCd(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustAddrCountryCdReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustAddrCountryCd(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustAddrZipReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustAddrZip(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum1aReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustPhoneNum1a(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum1bReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustPhoneNum1b(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum1cReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustPhoneNum1c(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum2aReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustPhoneNum2a(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum2bReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustPhoneNum2b(BluageUtils.unsupported());
			}
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum2cReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustPhoneNum2c(BluageUtils.unsupported());
			}
			
			/* 
			Government Id */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustGovtIssuedIdReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustGovtIssuedId(BluageUtils.unsupported());
			}
			
			/* 
			EFT Code */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustEftAccountIdReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustEftAccountId(BluageUtils.unsupported());
			}
			
			/* 
			Primary Holder Indicator */
			if (DataUtils.compare("*", BluageUtils.unsupported()) == 0 || DataUtils.isBlank(BluageUtils.unsupported())) {
				ctx.getWsThisProgcommarea().getAcupNewCustPriHolderIndReference().setBytes(Record.LOW_VALUES);
			} else {
				ctx.getWsThisProgcommarea().setAcupNewCustPriHolderInd(BluageUtils.unsupported());
			}
		}
	}

	/**
	 * Process operation _1200EditMapInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1200EditMapInputs(final CoactupcContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setInputOk(true);
		if (ctx.getWsThisProgcommarea().isAcupDetailsNotFetched()) {
			
			/* 
			VALIDATE THE SEARCH KEYS */
			_1210EditAccount(ctx, ctrl);
			ctx.getWsThisProgcommarea().getAcupOldAcctDataReference().setBytes(Record.LOW_VALUES);
			
			/* 
			IF THE SEARCH CONDITIONS HAVE PROBLEMS FLAG THEM */
			if (ctx.getWsMiscStorage().isFlgAcctfilterBlank()) {
				ctx.getWsMiscStorage().setNoSearchCriteriaReceived(true);
			} 
			
			/* 
			AT THIS STAGE. NO DETAILS FETCHED. NOTHING MORE TO EDIT. */
			return;
		} else {
			
			/* 
			SEARCH KEYS ALREADY VALIDATED AND DATA FETCHED
			Do nothing */
			ctx.getWsMiscStorage().setFoundAccountData(true);
			ctx.getWsMiscStorage().setFoundAcctInMaster(true);
			ctx.getWsMiscStorage().setFlgAcctfilterIsvalid(true);
			ctx.getWsMiscStorage().setFoundCustInMaster(true);
			ctx.getWsMiscStorage().setFlgCustfilterIsvalid(true);
			_1205CompareOldNew(ctx, ctrl);
			if (ctx.getWsMiscStorage().isNoChangesFound() || ctx.getWsThisProgcommarea().isAcupChangesOkNotConfirmed() || ctx.getWsThisProgcommarea().isAcupChangesOkayedAndDone()) {
				ctx.getWsMiscStorage().getWsNonKeyFlagsReference().setBytes(Record.LOW_VALUES);
				return;
			} else {
				ctx.getWsThisProgcommarea().setAcupChangesNotOk(true);
				ctx.getWsMiscStorage().setWsEditVariableName("Account Status");
				ctx.getWsMiscStorage().getWsEditYesNoReference().setValue(ctx.getWsThisProgcommarea().getAcupNewActiveStatusReference());
				_1220EditYesno(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditAcctStatusReference().setValue(ctx.getWsMiscStorage().getWsEditYesNoReference());
				ctx.getWsMiscStorage().setWsEditVariableName("Open Date");
				
				/* 
				FIXME: WS-EDIT-DATE-CCYYMMDD */
				BluageUtils.unsupported();
				
				/* 
				FIXME:PERFORM EDIT-DATE-CCYYMMDD
				THRU EDIT-DATE-CCYYMMDD-EXIT */
				BluageUtils.unsupported();
				ctx.getWsMiscStorage().getWsEditOpenDateFlgsReference().setBytes(BluageUtils.unsupported());
				ctx.getWsMiscStorage().setWsEditVariableName("Credit Limit");
				ctx.getWsMiscStorage().getWsEditSignedNumber9v2XReference().setValue(ctx.getWsMiscStorage().getAcupNewCreditLimitXReference());
				_1250EditSigned9v2(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditCreditLimitReference().setValue(ctx.getWsMiscStorage().getWsFlgSignedNumberEditReference());
				ctx.getWsMiscStorage().setWsEditVariableName("Expiry Date");
				
				/* 
				FIXME: WS-EDIT-DATE-CCYYMMDD */
				BluageUtils.unsupported();
				
				/* 
				FIXME:PERFORM EDIT-DATE-CCYYMMDD
				THRU EDIT-DATE-CCYYMMDD-EXIT */
				BluageUtils.unsupported();
				ctx.getWsMiscStorage().getWsExpiryDateFlgsReference().setBytes(BluageUtils.unsupported());
				ctx.getWsMiscStorage().setWsEditVariableName("Cash Credit Limit");
				ctx.getWsMiscStorage().getWsEditSignedNumber9v2XReference().setValue(ctx.getWsMiscStorage().getAcupNewCashCreditLimitXReference());
				_1250EditSigned9v2(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditCashCreditLimitReference().setValue(ctx.getWsMiscStorage().getWsFlgSignedNumberEditReference());
				ctx.getWsMiscStorage().setWsEditVariableName("Reissue Date");
				
				/* 
				FIXME: WS-EDIT-DATE-CCYYMMDD */
				BluageUtils.unsupported();
				
				/* 
				FIXME:PERFORM EDIT-DATE-CCYYMMDD
				THRU EDIT-DATE-CCYYMMDD-EXIT */
				BluageUtils.unsupported();
				ctx.getWsMiscStorage().getWsEditReissueDateFlgsReference().setBytes(BluageUtils.unsupported());
				ctx.getWsMiscStorage().setWsEditVariableName("Current Balance");
				ctx.getWsMiscStorage().getWsEditSignedNumber9v2XReference().setValue(ctx.getWsMiscStorage().getAcupNewCurrBalXReference());
				_1250EditSigned9v2(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditCurrBalReference().setValue(ctx.getWsMiscStorage().getWsFlgSignedNumberEditReference());
				ctx.getWsMiscStorage().setWsEditVariableName("Current Cycle Credit Limit");
				ctx.getWsMiscStorage().getWsEditSignedNumber9v2XReference().setValue(ctx.getWsMiscStorage().getAcupNewCurrCycCreditXReference());
				_1250EditSigned9v2(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditCurrCycCreditReference().setValue(ctx.getWsMiscStorage().getWsFlgSignedNumberEditReference());
				ctx.getWsMiscStorage().setWsEditVariableName("Current Cycle Debit Limit");
				ctx.getWsMiscStorage().getWsEditSignedNumber9v2XReference().setValue(ctx.getWsMiscStorage().getAcupNewCurrCycDebitXReference());
				_1250EditSigned9v2(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditCurrCycDebitReference().setValue(ctx.getWsMiscStorage().getWsFlgSignedNumberEditReference());
				ctx.getWsMiscStorage().setWsEditVariableName("SSN");
				_1265EditUsSsn(ctx, ctrl);
				ctx.getWsMiscStorage().setWsEditVariableName("Date of Birth");
				
				/* 
				FIXME: WS-EDIT-DATE-CCYYMMDD */
				BluageUtils.unsupported();
				
				/* 
				FIXME:PERFORM EDIT-DATE-CCYYMMDD
				THRU EDIT-DATE-CCYYMMDD-EXIT */
				BluageUtils.unsupported();
				ctx.getWsMiscStorage().getWsEditDtOfBirthFlgsReference().setBytes(BluageUtils.unsupported());
				if (ctx.getWsMiscStorage().isWsEditDtOfBirthIsvalid()) {
					
					/* 
					FIXME:PERFORM  EDIT-DATE-OF-BIRTH
					THRU  EDIT-DATE-OF-BIRTH-EXIT */
					BluageUtils.unsupported();
					ctx.getWsMiscStorage().getWsEditDtOfBirthFlgsReference().setBytes(BluageUtils.unsupported());
				} 
				ctx.getWsMiscStorage().setWsEditVariableName("FICO Score");
				ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustFicoScoreX());
				ctx.getWsMiscStorage().setWsEditAlphanumLength(3);
				_1245EditNumReqd(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditFicoScoreFlgsReference().setValue(ctx.getWsMiscStorage().getWsEditAlphanumOnlyFlagsReference());
				if (ctx.getWsMiscStorage().isFlgFicoScoreIsvalid()) {
					_1275EditFicoScore(ctx, ctrl);
				} 
				
				/* 
				****************************************************************
				Edit names
				**************************************************************** */
				ctx.getWsMiscStorage().setWsEditVariableName("First Name");
				ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustFirstName());
				ctx.getWsMiscStorage().setWsEditAlphanumLength(25);
				_1225EditAlphaReqd(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditFirstNameFlgsReference().setValue(ctx.getWsMiscStorage().getWsEditAlphaOnlyFlagsReference());
				ctx.getWsMiscStorage().setWsEditVariableName("Middle Name");
				ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustMiddleName());
				ctx.getWsMiscStorage().setWsEditAlphanumLength(25);
				_1235EditAlphaOpt(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditMiddleNameFlgsReference().setValue(ctx.getWsMiscStorage().getWsEditAlphaOnlyFlagsReference());
				ctx.getWsMiscStorage().setWsEditVariableName("Last Name");
				ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustLastName());
				ctx.getWsMiscStorage().setWsEditAlphanumLength(25);
				_1225EditAlphaReqd(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditLastNameFlgsReference().setValue(ctx.getWsMiscStorage().getWsEditAlphaOnlyFlagsReference());
				ctx.getWsMiscStorage().setWsEditVariableName("Address Line 1");
				ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustAddrLine1());
				ctx.getWsMiscStorage().setWsEditAlphanumLength(50);
				_1215EditMandatory(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditAddressLine1FlgsReference().setValue(ctx.getWsMiscStorage().getWsEditMandatoryFlagsReference());
				ctx.getWsMiscStorage().setWsEditVariableName("State");
				ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustAddrStateCd());
				ctx.getWsMiscStorage().setWsEditAlphanumLength(2);
				_1225EditAlphaReqd(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditStateFlgsReference().setValue(ctx.getWsMiscStorage().getWsEditAlphaOnlyFlagsReference());
				if (ctx.getWsMiscStorage().isFlgAlphaIsvalid()) {
					_1270EditUsStateCd(ctx, ctrl);
				} 
				ctx.getWsMiscStorage().setWsEditVariableName("Zip");
				ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustAddrZip());
				ctx.getWsMiscStorage().setWsEditAlphanumLength(5);
				_1245EditNumReqd(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditZipcodeFlgsReference().setValue(ctx.getWsMiscStorage().getWsEditAlphanumOnlyFlagsReference());
				
				/* 
				Address Line 2 is optional
				MOVE 'Address Line 2'         TO WS-EDIT-VARIABLE-NAME */
				ctx.getWsMiscStorage().setWsEditVariableName("City");
				ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustAddrLine3());
				ctx.getWsMiscStorage().setWsEditAlphanumLength(50);
				_1225EditAlphaReqd(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditCityFlgsReference().setValue(ctx.getWsMiscStorage().getWsEditAlphaOnlyFlagsReference());
				ctx.getWsMiscStorage().setWsEditVariableName("Country");
				ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustAddrCountryCd());
				ctx.getWsMiscStorage().setWsEditAlphanumLength(3);
				_1225EditAlphaReqd(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditCountryFlgsReference().setValue(ctx.getWsMiscStorage().getWsEditAlphaOnlyFlagsReference());
				ctx.getWsMiscStorage().setWsEditVariableName("Phone Number 1");
				ctx.getWsMiscStorage().getWsEditUsPhoneNumReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum1Reference());
				_1260EditUsPhoneNum(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditPhoneNum1FlgsReference().setBytes(ctx.getWsMiscStorage().getWsEditUsPhoneNumFlgsReference().getBytes());
				ctx.getWsMiscStorage().setWsEditVariableName("Phone Number 2");
				ctx.getWsMiscStorage().getWsEditUsPhoneNumReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum2Reference());
				_1260EditUsPhoneNum(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditPhoneNum2FlgsReference().setBytes(ctx.getWsMiscStorage().getWsEditUsPhoneNumFlgsReference().getBytes());
				ctx.getWsMiscStorage().setWsEditVariableName("EFT Account Id");
				ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustEftAccountId());
				ctx.getWsMiscStorage().setWsEditAlphanumLength(10);
				_1245EditNumReqd(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEftAccountIdFlgsReference().setValue(ctx.getWsMiscStorage().getWsEditAlphanumOnlyFlagsReference());
				ctx.getWsMiscStorage().setWsEditVariableName("Primary Card Holder");
				ctx.getWsMiscStorage().getWsEditYesNoReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustPriHolderIndReference());
				_1220EditYesno(ctx, ctrl);
				ctx.getWsMiscStorage().getWsEditPriCardholderReference().setValue(ctx.getWsMiscStorage().getWsEditYesNoReference());
				
				/* 
				Cross field edits begin here */
				if (ctx.getWsMiscStorage().isFlgStateIsvalid() && ctx.getWsMiscStorage().isFlgZipcodeIsvalid()) {
					_1280EditUsStateZipCd(ctx, ctrl);
				} 
				if (ctx.getWsMiscStorage().isInputError()) {
					
					/* 
					Do nothing */
				} else {
					ctx.getWsThisProgcommarea().setAcupChangesOkNotConfirmed(true);
				}
			}
		}
	}

	/**
	 * Process operation _1205CompareOldNew.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1205CompareOldNew(final CoactupcContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setNoChangesFound(true);
		if (DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewAcctIdXReference(), ctx.getWsThisProgcommarea().getAcupOldAcctIdXReference()) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewActiveStatus()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldActiveStatus())) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCurrBalReference(), ctx.getWsThisProgcommarea().getAcupOldCurrBalReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCreditLimitReference(), ctx.getWsThisProgcommarea().getAcupOldCreditLimitReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCashCreditLimitReference(), ctx.getWsThisProgcommarea().getAcupOldCashCreditLimitReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewOpenDateReference(), ctx.getWsThisProgcommarea().getAcupOldOpenDateReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewExpiraionDateReference(), ctx.getWsThisProgcommarea().getAcupOldExpiraionDateReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewReissueDateReference(), ctx.getWsThisProgcommarea().getAcupOldReissueDateReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCurrCycCreditReference(), ctx.getWsThisProgcommarea().getAcupOldCurrCycCreditReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCurrCycDebitReference(), ctx.getWsThisProgcommarea().getAcupOldCurrCycDebitReference()) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewGroupId().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldGroupId().trim())) == 0) {
			
			/* 
			Do nothing */
			if (DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewCustIdX().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustIdX().trim())) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewCustFirstName().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustFirstName().trim())) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewCustMiddleName().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustMiddleName().trim())) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewCustLastName().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustLastName().trim())) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewCustAddrLine1().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustAddrLine1().trim())) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewCustAddrLine2().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustAddrLine2().trim())) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewCustAddrLine3().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustAddrLine3().trim())) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewCustAddrStateCd().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustAddrStateCd().trim())) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewCustAddrCountryCd().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustAddrCountryCd().trim())) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewCustAddrZip().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustAddrZip().trim())) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum1aReference(), ctx.getWsThisProgcommarea().getAcupOldCustPhoneNum1aReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum1bReference(), ctx.getWsThisProgcommarea().getAcupOldCustPhoneNum1bReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum1cReference(), ctx.getWsThisProgcommarea().getAcupOldCustPhoneNum1cReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum2aReference(), ctx.getWsThisProgcommarea().getAcupOldCustPhoneNum2aReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum2bReference(), ctx.getWsThisProgcommarea().getAcupOldCustPhoneNum2bReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCustPhoneNum2cReference(), ctx.getWsThisProgcommarea().getAcupOldCustPhoneNum2cReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCustSsnXReference(), ctx.getWsThisProgcommarea().getAcupOldCustSsnXReference()) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewCustGovtIssuedId().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustGovtIssuedId().trim())) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCustDobYyyyMmDdReference(), ctx.getWsThisProgcommarea().getAcupOldCustDobYyyyMmDdReference()) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCustEftAccountIdReference(), ctx.getWsThisProgcommarea().getAcupOldCustEftAccountIdReference()) == 0 && DataUtils.compare(StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupNewCustPriHolderInd().trim()), StringUtils.upperCase(ctx.getWsThisProgcommarea().getAcupOldCustPriHolderInd().trim())) == 0 && DataUtils.compare(ctx.getWsThisProgcommarea().getAcupNewCustFicoScoreXReference(), ctx.getWsThisProgcommarea().getAcupOldCustFicoScoreXReference()) == 0) {
				ctx.getWsMiscStorage().setNoChangesDetected(true);
				return;
			} else {
				ctx.getWsMiscStorage().setChangeHasOccurred(true);
				return;
			}
		} else {
			ctx.getWsMiscStorage().setChangeHasOccurred(true);
			return;
		}
	}

	/**
	 * Process operation _1210EditAccount.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1210EditAccount(final CoactupcContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
		
		/* 
		Not supplied */
		if (DataUtils.isLowValue(BluageUtils.unsupported()) || DataUtils.isBlank(BluageUtils.unsupported())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAcctfilterBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setWsPromptForAcct(true);
			} 
			
			/* 
			FIXME: CDEMO-ACCT-ID */
			BluageUtils.unsupported();
			DataUtils.setToZeroes(ctx.getWsThisProgcommarea().getAcupNewAcctIdReference());
			return;
		} else {
			
			/* 
			Not numeric
			Not 11 characters */
			ctx.getWsThisProgcommarea().setAcupNewAcctId(BluageUtils.unsupported());
			if (!(DataUtils.isNumeric(BluageUtils.unsupported())) || DataUtils.isZero(BluageUtils.unsupported())) {
				ctx.getWsMiscStorage().setInputError(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
						.addDelimitedBySize("Account Number if supplied must be a 11 digit")
						.addDelimitedBySize(" Non-Zero Number")
						.end();
				} 
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				BluageUtils.unsupported();
				return;
			} else {
				
				/* 
				FIXME: CDEMO-ACCT-ID */
				BluageUtils.unsupported();
				ctx.getWsMiscStorage().setFlgAcctfilterIsvalid(true);
				return;
			}
		}
	}

	/**
	 * Process operation _1215EditMandatory.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1215EditMandatory(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		Initialize */
		ctx.getWsMiscStorage().setFlgMandatoryNotOk(true);
		
		/* 
		Not supplied */
		int len = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		int len1 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		int len2 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		if (DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len)) || DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len1)) || DataUtils.toString(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len2)).trim().length() == 0) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgMandatoryBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(" must be supplied.")
					.end();
			} 
			return;
		} else {
			ctx.getWsMiscStorage().setFlgMandatoryIsvalid(true);
		}
	}

	/**
	 * Process operation _1220EditYesno.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1220EditYesno(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		Must be Y or N
		SET FLG-YES-NO-NOT-OK         TO TRUE
		Not supplied */
		if (DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditYesNoReference()) || DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditYesNoReference()) || DataUtils.isZero(ctx.getWsMiscStorage().getWsEditYesNoReference())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgYesNoBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(" must be supplied.")
					.end();
			} 
			return;
		} else {
			if (ctx.getWsMiscStorage().isFlgYesNoIsvalid()) {
				
				/* 
				Do nothing */
				return;
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgYesNoNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
						.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
						.addDelimitedBySize(" must be Y or N.")
						.end();
				} 
				return;
			}
		}
	}

	/**
	 * Process operation _1225EditAlphaReqd.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1225EditAlphaReqd(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		Initialize */
		ctx.getWsMiscStorage().setFlgAlphaNotOk(true);
		
		/* 
		Not supplied */
		int len = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		int len1 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		int len2 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		if (DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len)) || DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len1)) || DataUtils.toString(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len2)).trim().length() == 0) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAlphaBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(" must be supplied.")
					.end();
			} 
			return;
		} else {
			
			/* 
			Only Alphabets and space allowed */
			ctx.getLitAllAlphaFrom().getLitAllAlphaFromReference().setBytes(ctx.getWsLiterals().getLitAllAlphaFromXReference().getBytes());
			InspectBuilder.newInstance(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference(), 0, ctx.getWsMiscStorage().getWsEditAlphanumLength())
				.convert(ctx.getLitAllAlphaFrom().getLitAllAlphaFromReference())
				.to(ctx.getLitAlphaSpacesTo().getLitAlphaSpacesToReference())
				.apply();
			int len3 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
			if (DataUtils.toString(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len3)).trim().length() == 0) {
				
				/* 
				Do nothing */
				ctx.getWsMiscStorage().setFlgAlphaIsvalid(true);
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgAlphaNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
						.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
						.addDelimitedBySize(" can have alphabets only.")
						.end();
				} 
				return;
			}
		}
	}

	/**
	 * Process operation _1230EditAlphanumReqd.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1230EditAlphanumReqd(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		Initialize */
		ctx.getWsMiscStorage().setFlgAlphnanumNotOk(true);
		
		/* 
		Not supplied */
		int len = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		int len1 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		int len2 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		if (DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len)) || DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len1)) || DataUtils.toString(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len2)).trim().length() == 0) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAlphnanumBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(" must be supplied.")
					.end();
			} 
			
			/* 
			GotoStatement to _1230EditAlphanumReqdExit */
		} 
		
		/* 
		Only Alphabets,numbers and space allowed */
		ctx.getLitAllAlphanumFrom().getLitAllAlphanumFromReference().setBytes(ctx.getWsLiterals().getLitAllAlphanumFromXReference().getBytes());
		InspectBuilder.newInstance(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference(), 0, ctx.getWsMiscStorage().getWsEditAlphanumLength())
			.convert(ctx.getLitAllAlphanumFrom().getLitAllAlphanumFromReference())
			.to(ctx.getLitAlphanumSpacesTo().getLitAlphanumSpacesToReference())
			.apply();
		int len3 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		if (DataUtils.toString(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len3)).trim().length() == 0) {
			
			/* 
			Do nothing */
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAlphnanumNotOk(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(" can have numbers or alphabets only.")
					.end();
			} 
			
			/* 
			GotoStatement to _1230EditAlphanumReqdExit */
		}
		ctx.getWsMiscStorage().setFlgAlphnanumIsvalid(true);
	}

	/**
	 * Process operation _1235EditAlphaOpt.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1235EditAlphaOpt(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		Initialize */
		ctx.getWsMiscStorage().setFlgAlphaNotOk(true);
		
		/* 
		Not supplied */
		int len = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		int len1 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		int len2 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		if (DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len)) || DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len1)) || DataUtils.toString(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len2)).trim().length() == 0) {
			ctx.getWsMiscStorage().setFlgAlphaIsvalid(true);
			return;
		} else {
			
			/* 
			Only Alphabets and space allowed
			Do nothing */
			ctx.getLitAllAlphaFrom().getLitAllAlphaFromReference().setBytes(ctx.getWsLiterals().getLitAllAlphaFromXReference().getBytes());
			InspectBuilder.newInstance(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference(), 0, ctx.getWsMiscStorage().getWsEditAlphanumLength())
				.convert(ctx.getLitAllAlphaFrom().getLitAllAlphaFromReference())
				.to(ctx.getLitAlphaSpacesTo().getLitAlphaSpacesToReference())
				.apply();
			int len3 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
			if (DataUtils.toString(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len3)).trim().length() == 0) {
				
				/* 
				Do nothing */
				ctx.getWsMiscStorage().setFlgAlphaIsvalid(true);
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgAlphaNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
						.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
						.addDelimitedBySize(" can have alphabets only.")
						.end();
				} 
				return;
			}
		}
	}

	/**
	 * Process operation _1240EditAlphanumOpt.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1240EditAlphanumOpt(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		Initialize */
		ctx.getWsMiscStorage().setFlgAlphnanumNotOk(true);
		
		/* 
		Not supplied, but ok as optional */
		int len = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		int len1 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		int len2 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		if (DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len)) || DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len1)) || DataUtils.toString(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len2)).trim().length() == 0) {
			ctx.getWsMiscStorage().setFlgAlphnanumIsvalid(true);
			
			/* 
			GotoStatement to _1240EditAlphanumOptExit */
		} else {
			
			/* 
			Do nothing */
		}
		
		/* 
		Only Alphabets and space allowed */
		ctx.getLitAllAlphanumFrom().getLitAllAlphanumFromReference().setBytes(ctx.getWsLiterals().getLitAllAlphanumFromXReference().getBytes());
		InspectBuilder.newInstance(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference(), 0, ctx.getWsMiscStorage().getWsEditAlphanumLength())
			.convert(ctx.getLitAllAlphanumFrom().getLitAllAlphanumFromReference())
			.to(ctx.getLitAlphanumSpacesTo().getLitAlphanumSpacesToReference())
			.apply();
		int len3 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		if (DataUtils.toString(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len3)).trim().length() == 0) {
			
			/* 
			Do nothing */
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAlphnanumNotOk(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(" can have numbers or alphabets only.")
					.end();
			} 
			
			/* 
			GotoStatement to _1240EditAlphanumOptExit */
		}
		ctx.getWsMiscStorage().setFlgAlphnanumIsvalid(true);
	}

	/**
	 * Process operation _1245EditNumReqd.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1245EditNumReqd(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		Initialize */
		ctx.getWsMiscStorage().setFlgAlphnanumNotOk(true);
		
		/* 
		Not supplied */
		int len = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		int len1 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		int len2 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
		if (DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len)) || DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len1)) || DataUtils.toString(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len2)).trim().length() == 0) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAlphnanumBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(" must be supplied.")
					.end();
			} 
			return;
		} else {
			
			/* 
			Only all numeric allowed */
			int len3 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
			if (DataUtils.isNumeric(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len3))) {
				
				/* 
				Must not be zero
				Do nothing */
				int len4 = ctx.getWsMiscStorage().getWsEditAlphanumLength();
				if (NumberUtils.compare(NumberUtils.convert(ctx.getWsMiscStorage().getWsEditAlphanumOnlyReference().getBytes(0, len4)), 0) == 0) {
					ctx.getWsMiscStorage().setInputError(true);
					ctx.getWsMiscStorage().setFlgAlphnanumNotOk(true);
					if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
						StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
							.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
							.addDelimitedBySize(" must not be zero.")
							.end();
					} 
					return;
				} else {
					
					/* 
					Do nothing */
					ctx.getWsMiscStorage().setFlgAlphnanumIsvalid(true);
				}
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgAlphnanumNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
						.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
						.addDelimitedBySize(" must be all numeric.")
						.end();
				} 
				return;
			}
		}
	}

	/**
	 * Process operation _1250EditSigned9v2.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1250EditSigned9v2(final CoactupcContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().setFlgSignedNumberNotOk(true);
		
		/* 
		Not supplied */
		if (DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditSignedNumber9v2XReference()) || DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditSignedNumber9v2XReference())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgSignedNumberBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(" must be supplied.")
					.end();
			} 
			return;
		} else {
			
			/* 
			Do nothing */
			if (DataUtils.compare(NumberUtils.testNumvalC(ctx.getWsMiscStorage().getWsEditSignedNumber9v2X()), 0) == 0) {
				
				/* 
				If we got here all edits were cleared
				Do nothing */
				ctx.getWsMiscStorage().setFlgSignedNumberIsvalid(true);
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgSignedNumberNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
						.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
						.addDelimitedBySize(" is not valid")
						.end();
				} 
				return;
			}
		}
	}

	/**
	 * Process operation _1260EditUsPhoneNum.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1260EditUsPhoneNum(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		The database stores date in X(15) format (999)999-9999
		1234567890123
		So we take the X(15) input into WS-EDIT-US-PHONE-NUM
		and edit it */
		ctx.getWsMiscStorage().setWsEditUsPhoneIsInvalid(true);
		
		/* 
		Not mandatory to enter a phone number */
		if ((DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditUsPhoneNumaReference()) || DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditUsPhoneNumaReference())) && (DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditUsPhoneNumbReference()) || DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditUsPhoneNumbReference())) && (DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditUsPhoneNumaReference()) || DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditUsPhoneNumcReference()))) {
			ctx.getWsMiscStorage().setWsEditUsPhoneIsValid(true);
			return;
		} else {
			
			/* 
			Do nothing */
			editAreaCode(ctx, ctrl);
		}
	}

	/**
	 * Process operation editAreaCode.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void editAreaCode(final CoactupcContext ctx, final ExecutionController ctrl) {
		editAreaCode1(ctx, ctrl);
		if (DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditUsPhoneNumcReference()) || DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditUsPhoneNumcReference())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgEditUsPhonecBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(": Line number code must be supplied.")
					.end();
			} 
			return;
		} else {
			
			/* 
			Do nothing */
			if (DataUtils.isNumeric(ctx.getWsMiscStorage().getWsEditUsPhoneNumcReference())) {
				
				/* 
				Do nothing */
				if (NumberUtils.eq(ctx.getWsMiscStorage().getWsEditUsPhoneNumcNReference(), 0)) {
					ctx.getWsMiscStorage().setInputError(true);
					ctx.getWsMiscStorage().setFlgEditUsPhonecNotOk(true);
					if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
						StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
							.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
							.addDelimitedBySize(": Line number code cannot be zero")
							.end();
					} 
					return;
				} else {
					
					/* 
					Do nothing */
					ctx.getWsMiscStorage().setFlgEditUsPhonecIsvalid(true);
				}
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgEditUsPhonecNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
						.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
						.addDelimitedBySize(": Line number code must be A 4 digit number.")
						.end();
				} 
				return;
			}
		}
	}

	/**
	 * Process operation editAreaCode1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void editAreaCode1(final CoactupcContext ctx, final ExecutionController ctrl) {
		editAreaCode2(ctx, ctrl);
		if (DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditUsPhoneNumbReference()) || DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditUsPhoneNumbReference())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgEditUsPhonebBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(": Prefix code must be supplied.")
					.end();
			} 
			return;
		} else {
			
			/* 
			Do nothing */
			if (DataUtils.isNumeric(ctx.getWsMiscStorage().getWsEditUsPhoneNumbReference())) {
				
				/* 
				Do nothing */
				if (NumberUtils.eq(ctx.getWsMiscStorage().getWsEditUsPhoneNumbNReference(), 0)) {
					ctx.getWsMiscStorage().setInputError(true);
					ctx.getWsMiscStorage().setFlgEditUsPhonebNotOk(true);
					if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
						StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
							.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
							.addDelimitedBySize(": Prefix code cannot be zero")
							.end();
					} 
					return;
				} else {
					
					/* 
					Do nothing */
					ctx.getWsMiscStorage().setFlgEditUsPhonebIsvalid(true);
				}
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgEditUsPhonebNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
						.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
						.addDelimitedBySize(": Prefix code must be A 3 digit number.")
						.end();
				} 
				return;
			}
		}
	}

	/**
	 * Process operation editAreaCode2.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void editAreaCode2(final CoactupcContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isBlank(ctx.getWsMiscStorage().getWsEditUsPhoneNumaReference()) || DataUtils.isLowValue(ctx.getWsMiscStorage().getWsEditUsPhoneNumaReference())) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgEditUsPhoneaBlank(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(": Area code must be supplied.")
					.end();
			} 
			return;
		} else {
			
			/* 
			Do nothing */
			if (DataUtils.isNumeric(ctx.getWsMiscStorage().getWsEditUsPhoneNumaReference())) {
				
				/* 
				Do nothing */
				if (NumberUtils.eq(ctx.getWsMiscStorage().getWsEditUsPhoneNumaNReference(), 0)) {
					ctx.getWsMiscStorage().setInputError(true);
					ctx.getWsMiscStorage().setFlgEditUsPhoneaNotOk(true);
					if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
						StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
							.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
							.addDelimitedBySize(": Area code cannot be zero")
							.end();
					} 
					return;
				} else {
					
					/* 
					FIXME: WS-US-PHONE-AREA-CODE-TO-EDIT
					Do nothing */
					BluageUtils.unsupported();
					
					/* 
					FIXME: VALID-GENERAL-PURP-CODE */
					if (BluageUtils.unsupported()) {
						
						/* 
						Do nothing */
						ctx.getWsMiscStorage().setFlgEditUsPhoneaIsvalid(true);
					} else {
						ctx.getWsMiscStorage().setInputError(true);
						ctx.getWsMiscStorage().setFlgEditUsPhoneaNotOk(true);
						if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
							StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
								.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
								.addDelimitedBySize(": Not valid North America general purpose area code")
								.end();
						} 
						return;
					}
				}
			} else {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgEditUsPhoneaNotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
						.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
						.addDelimitedBySize(": Area code must be A 3 digit number.")
						.end();
				} 
				return;
			}
		}
	}

	/**
	 * Process operation _1265EditUsSsn.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1265EditUsSsn(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		Format xxx-xx-xxxx
		Part1 :should have 3 digits
		Part2 :should have 2 digits and it should be from 01 to 99
		Part3 should have 4 digits from 0001 to 9999.
		****************************************************************
		Edit SSN Part 1
		**************************************************************** */
		ctx.getWsMiscStorage().setWsEditVariableName("SSN: First 3 chars");
		ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustSsn1());
		ctx.getWsMiscStorage().setWsEditAlphanumLength(3);
		_1245EditNumReqd(ctx, ctrl);
		ctx.getWsMiscStorage().getWsEditUsSsnPart1FlgsReference().setValue(ctx.getWsMiscStorage().getWsEditAlphanumOnlyFlagsReference());
		
		/* 
		Part1 :should not be 000, 666, or between 900 and 999 */
		if (ctx.getWsMiscStorage().isFlgEditUsSsnPart1Isvalid()) {
			ctx.getWsMiscStorage().getWsEditUsSsnPart1Reference().setValue(ctx.getWsThisProgcommarea().getAcupNewCustSsn1Reference());
			if (ctx.getWsMiscStorage().isInvalidSsnPart1()) {
				ctx.getWsMiscStorage().setInputError(true);
				ctx.getWsMiscStorage().setFlgEditUsSsnPart1NotOk(true);
				if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
					StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
						.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
						.addDelimitedBySize(": should not be 000, 666, or between 900 and 999")
						.end();
				} else {
					
					/* 
					Do nothing */
				}
			} 
			
			/* 
			****************************************************************
			Edit SSN Part 2
			**************************************************************** */
			ctx.getWsMiscStorage().setWsEditVariableName("SSN 4th & 5th chars");
			ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustSsn2());
			ctx.getWsMiscStorage().setWsEditAlphanumLength(2);
			_1245EditNumReqd(ctx, ctrl);
			ctx.getWsMiscStorage().getWsEditUsSsnPart2FlgsReference().setValue(ctx.getWsMiscStorage().getWsEditAlphanumOnlyFlagsReference());
			
			/* 
			****************************************************************
			Edit SSN Part 3
			**************************************************************** */
			ctx.getWsMiscStorage().setWsEditVariableName("SSN Last 4 chars");
			ctx.getWsMiscStorage().setWsEditAlphanumOnly(ctx.getWsThisProgcommarea().getAcupNewCustSsn3());
			ctx.getWsMiscStorage().setWsEditAlphanumLength(4);
			_1245EditNumReqd(ctx, ctrl);
			ctx.getWsMiscStorage().getWsEditUsSsnPart3FlgsReference().setValue(ctx.getWsMiscStorage().getWsEditAlphanumOnlyFlagsReference());
		}
	}

	/**
	 * Process operation _1270EditUsStateCd.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1270EditUsStateCd(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: US-STATE-CODE-TO-EDIT */
		BluageUtils.unsupported();
		
		/* 
		FIXME: VALID-US-STATE-CODE */
		if (BluageUtils.unsupported()) {
			
			/* 
			Do nothing */
			return;
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgStateNotOk(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(": is not a valid state code")
					.end();
			} 
			return;
		}
	}

	/**
	 * Process operation _1275EditFicoScore.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1275EditFicoScore(final CoactupcContext ctx, final ExecutionController ctrl) {
		if (ctx.getWsThisProgcommarea().isFicoRangeIsValid()) {
			
			/* 
			Do nothing */
			return;
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgFicoScoreNotOk(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsEditVariableName().trim())
					.addDelimitedBySize(": should be between 300 and 850")
					.end();
			} 
			return;
		}
	}

	/**
	 * Process operation _1280EditUsStateZipCd.
	 * 
	 * A crude zip code edit based on data from USPS web site
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1280EditUsStateZipCd(final CoactupcContext ctx, final ExecutionController ctrl) {
		StringConcatenationBuilder.newInstance(BluageUtils.unsupported())
			.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewCustAddrStateCdReference().getBytes())
			.addDelimitedBySize(ctx.getWsThisProgcommarea().getAcupNewCustAddrZipReference().getBytes(0, 2))
			.end();
		
		/* 
		FIXME: VALID-US-STATE-ZIP-CD2-COMBO */
		if (BluageUtils.unsupported()) {
			
			/* 
			Do nothing */
			return;
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgStateNotOk(true);
			ctx.getWsMiscStorage().setFlgZipcodeNotOk(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize("Invalid zip code for state")
					.end();
			} 
			return;
		}
	}

	/**
	 * Process operation _3000SendMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3000SendMap(final CoactupcContext ctx, final ExecutionController ctrl) {
		_3100ScreenInit(ctx, ctrl);
		_3200SetupScreenVars(ctx, ctrl);
		_3250SetupInfomsg(ctx, ctrl);
		_3300SetupScreenAttrs(ctx, ctrl);
		_3390SetupInfomsgAttrs(ctx, ctrl);
		_3400SendScreen(ctx, ctrl);
	}

	/**
	 * Process operation _3100ScreenInit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3100ScreenInit(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE01O OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TITLE02O OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRNNAMEO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: PGMNAMEO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DATA */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-DD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURDATE-YY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURDATEO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-HH */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-MM */
		BluageUtils.unsupported();
		
		/* 
		FIXME: WS-CURTIME-SS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CURTIMEO OF CACTUPAO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation _3200SetupScreenVars.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3200SetupScreenVars(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CDEMO-PGM-ENTER
		INITIALIZE SEARCH CRITERIA */
		if (BluageUtils.unsupported()) {
			
			/* 
			Do nothing */
		} else {
			if (DataUtils.compare("0", BluageUtils.unsupported()) == 0 && ctx.getWsMiscStorage().isFlgAcctfilterIsvalid()) {
				
				/* 
				FIXME: ACCTSIDO OF CACTUPAO */
				BluageUtils.unsupported();
			} else {
				
				/* 
				FIXME: ACCTSIDO OF CACTUPAO */
				BluageUtils.unsupported();
			}
			if (ctx.getWsThisProgcommarea().isAcupDetailsNotFetched() || DataUtils.compare("0", BluageUtils.unsupported()) == 0) {
				
				/* 
				FIXME: CC-ACCT-ID-N */
				_3201ShowInitialValues(ctx, ctrl);
			} else if (ctx.getWsThisProgcommarea().isAcupShowDetails()) {
				_3202ShowOriginalValues(ctx, ctrl);
			} else if (ctx.getWsThisProgcommarea().isAcupChangesMade()) {
				_3203ShowUpdatedValues(ctx, ctrl);
			} else {
				_3202ShowOriginalValues(ctx, ctrl);
			}
		}
	}

	/**
	 * Process operation _3201ShowInitialValues.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3201ShowInitialValues(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: ACSTTUSO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACRDLIMO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACURBALO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSHLIMO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACRCYCRO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACRCYDBO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: OPNYEARO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: OPNMONO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: OPNDAYO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: EXPYEARO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: EXPMONO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: EXPDAYO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: RISYEARO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: RISMONO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: RISDAYO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: AADDGRPO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSTNUMO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTSSN1O OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTSSN2O OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTSSN3O OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSTFCOO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: DOBYEARO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: DOBMONO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: DOBDAYO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSFNAMO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSMNAMO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSLNAMO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSADL1O OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSADL2O OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSCITYO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSSTTEO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSZIPCO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSCTRYO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH1AO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH1BO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH1CO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH2AO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH2BO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH2CO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSGOVTO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSEFTCO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPFLGO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		Account Limits
		Account Dates
		Customer data
		Customer address and contact info
		Customer other good stuff */
		return;
	}

	/**
	 * Process operation _3202ShowOriginalValues.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3202ShowOriginalValues(final CoactupcContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscStorage().getWsNonKeyFlagsReference().setBytes(Record.LOW_VALUES);
		ctx.getWsMiscStorage().setPromptForChanges(true);
		if (ctx.getWsMiscStorage().isFoundAcctInMaster() || ctx.getWsMiscStorage().isFoundCustInMaster()) {
			
			/* 
			FIXME: ACSTTUSO OF CACTUPAO */
			BluageUtils.unsupported();
			ctx.getWsMiscStorage().getWsEditCurrency92FReference().setValue(ctx.getWsThisProgcommarea().getAcupOldCurrBalN());
			
			/* 
			FIXME: ACURBALO OF CACTUPAO */
			BluageUtils.unsupported();
			ctx.getWsMiscStorage().getWsEditCurrency92FReference().setValue(ctx.getWsThisProgcommarea().getAcupOldCreditLimitN());
			
			/* 
			FIXME: ACRDLIMO OF CACTUPAO */
			BluageUtils.unsupported();
			ctx.getWsMiscStorage().getWsEditCurrency92FReference().setValue(ctx.getWsThisProgcommarea().getAcupOldCashCreditLimitN());
			
			/* 
			FIXME: ACSHLIMO OF CACTUPAO */
			BluageUtils.unsupported();
			ctx.getWsMiscStorage().getWsEditCurrency92FReference().setValue(ctx.getWsThisProgcommarea().getAcupOldCurrCycCreditN());
			
			/* 
			FIXME: ACRCYCRO OF CACTUPAO */
			BluageUtils.unsupported();
			ctx.getWsMiscStorage().getWsEditCurrency92FReference().setValue(ctx.getWsThisProgcommarea().getAcupOldCurrCycDebitN());
			
			/* 
			FIXME: ACRCYDBO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: OPNYEARO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: OPNMONO  OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: OPNDAYO  OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPYEARO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPMONO  OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: EXPDAYO  OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: RISYEARO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: RISMONO  OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: RISDAYO  OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: AADDGRPO OF CACTUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFoundCustInMaster()) {
			
			/* 
			FIXME: ACSTNUMO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACTSSN1O OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACTSSN2O OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACTSSN3O OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSTFCOO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: DOBYEARO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: DOBMONO  OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: DOBDAYO  OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSFNAMO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSMNAMO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSLNAMO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSADL1O OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSADL2O OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSCITYO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSSTTEO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSZIPCO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSCTRYO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSPH1AO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSPH1BO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSPH1CO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSPH2AO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSPH2BO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSPH2CO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSGOVTO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSEFTCO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACSPFLGO OF CACTUPAO */
			BluageUtils.unsupported();
		}
	}

	/**
	 * Process operation _3203ShowUpdatedValues.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3203ShowUpdatedValues(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: ACSTTUSO OF CACTUPAO */
		BluageUtils.unsupported();
		if (ctx.getWsMiscStorage().isFlgCredLimitIsvalid()) {
			ctx.getWsMiscStorage().getWsEditCurrency92FReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCreditLimitN());
			
			/* 
			FIXME: ACRDLIMO OF CACTUPAO */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: ACRDLIMO OF CACTUPAO */
			BluageUtils.unsupported();
		}
		if (ctx.getWsMiscStorage().isFlgCashCreditLimitIsvalid()) {
			ctx.getWsMiscStorage().getWsEditCurrency92FReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCashCreditLimitN());
			
			/* 
			FIXME: ACSHLIMO OF CACTUPAO */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: ACSHLIMO OF CACTUPAO */
			BluageUtils.unsupported();
		}
		if (ctx.getWsMiscStorage().isFlgCurrBalIsvalid()) {
			ctx.getWsMiscStorage().getWsEditCurrency92FReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCurrBalN());
			
			/* 
			FIXME: ACURBALO OF CACTUPAO */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: ACURBALO OF CACTUPAO */
			BluageUtils.unsupported();
		}
		if (ctx.getWsMiscStorage().isFlgCurrCycCreditIsvalid()) {
			ctx.getWsMiscStorage().getWsEditCurrency92FReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCurrCycCreditN());
			
			/* 
			FIXME: ACRCYCRO OF CACTUPAO */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: ACRCYCRO OF CACTUPAO */
			BluageUtils.unsupported();
		}
		if (ctx.getWsMiscStorage().isFlgCurrCycDebitIsvalid()) {
			ctx.getWsMiscStorage().getWsEditCurrency92FReference().setValue(ctx.getWsThisProgcommarea().getAcupNewCurrCycDebitN());
			
			/* 
			FIXME: ACRCYDBO OF CACTUPAO */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: ACRCYDBO OF CACTUPAO */
			BluageUtils.unsupported();
		}
		
		/* 
		FIXME: OPNYEARO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: OPNMONO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: OPNDAYO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: EXPYEARO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: EXPMONO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: EXPDAYO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: RISYEARO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: RISMONO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: RISDAYO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: AADDGRPO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSTNUMO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTSSN1O OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTSSN2O OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTSSN3O OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSTFCOO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: DOBYEARO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: DOBMONO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: DOBDAYO  OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSFNAMO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSMNAMO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSLNAMO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSADL1O OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSADL2O OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSCITYO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSSTTEO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSZIPCO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSCTRYO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH1AO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH1BO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH1CO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH2AO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH2BO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH2CO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSGOVTO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSEFTCO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPFLGO OF CACTUPAO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation _3250SetupInfomsg.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3250SetupInfomsg(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		SETUP INFORMATION MESSAGE */
		if (BluageUtils.unsupported()) {
			
			/* 
			FIXME: CDEMO-PGM-ENTER */
			ctx.getWsMiscStorage().setPromptForSearchKeys(true);
		} else if (ctx.getWsThisProgcommarea().isAcupDetailsNotFetched()) {
			ctx.getWsMiscStorage().setPromptForSearchKeys(true);
		} else if (ctx.getWsThisProgcommarea().isAcupShowDetails()) {
			ctx.getWsMiscStorage().setPromptForChanges(true);
		} else if (ctx.getWsThisProgcommarea().isAcupChangesNotOk()) {
			ctx.getWsMiscStorage().setPromptForChanges(true);
		} else if (ctx.getWsThisProgcommarea().isAcupChangesOkNotConfirmed()) {
			ctx.getWsMiscStorage().setPromptForConfirmation(true);
		} else if (ctx.getWsThisProgcommarea().isAcupChangesOkayedAndDone()) {
			ctx.getWsMiscStorage().setConfirmUpdateSuccess(true);
		} else if (ctx.getWsThisProgcommarea().isAcupChangesOkayedLockError()) {
			ctx.getWsMiscStorage().setInformFailure(true);
		} else if (ctx.getWsThisProgcommarea().isAcupChangesOkayedButFailed()) {
			ctx.getWsMiscStorage().setInformFailure(true);
		} else if (ctx.getWsMiscStorage().isWsNoInfoMessage()) {
			ctx.getWsMiscStorage().setPromptForSearchKeys(true);
		} 
		
		/* 
		FIXME: INFOMSGO OF CACTUPAO */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ERRMSGO OF CACTUPAO */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation _3300SetupScreenAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3300SetupScreenAttrs(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		PROTECT ALL FIELDS */
		_3310ProtectAllAttrs(ctx, ctrl);
		
		/* 
		UNPROTECT BASED ON CONTEXT */
		if (ctx.getWsThisProgcommarea().isAcupDetailsNotFetched()) {
			
			/* 
			FIXME: ACCTSIDA OF CACTUPAI
			Make Account Id editable */
			BluageUtils.unsupported();
		} else if (ctx.getWsThisProgcommarea().isAcupShowDetails() || ctx.getWsThisProgcommarea().isAcupChangesNotOk()) {
			_3320UnprotectFewAttrs(ctx, ctrl);
		} else if (ctx.getWsThisProgcommarea().isAcupChangesOkNotConfirmed() || ctx.getWsThisProgcommarea().isAcupChangesOkayedAndDone()) {
			
			/* 
			Do nothing */
		} else {
			
			/* 
			FIXME: ACCTSIDA OF CACTUPAI */
			BluageUtils.unsupported();
		}
		
		/* 
		POSITION CURSOR - ORDER BASED ON SCREEN LOCATION */
		if (ctx.getWsMiscStorage().isFoundAccountData() || ctx.getWsMiscStorage().isNoChangesDetected()) {
			
			/* 
			FIXME: ACSTTUSL OF CACTUPAI */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().isFlgAcctfilterNotOk() || ctx.getWsMiscStorage().isFlgAcctfilterBlank()) {
			
			/* 
			FIXME: ACCTSIDL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Account Status */
		} else if (ctx.getWsMiscStorage().isFlgAcctStatusNotOk() || ctx.getWsMiscStorage().isFlgAcctStatusBlank()) {
			
			/* 
			FIXME: ACSTTUSL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Open Year */
		} else if (ctx.getWsMiscStorage().isFlgOpenYearNotOk() || ctx.getWsMiscStorage().isFlgOpenYearBlank()) {
			
			/* 
			FIXME: OPNYEARL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Open Month */
		} else if (ctx.getWsMiscStorage().isFlgOpenMonthNotOk() || ctx.getWsMiscStorage().isFlgOpenMonthBlank()) {
			
			/* 
			FIXME: OPNMONL  OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Open Day */
		} else if (ctx.getWsMiscStorage().isFlgOpenDayNotOk() || ctx.getWsMiscStorage().isFlgOpenDayBlank()) {
			
			/* 
			FIXME: OPNDAYL  OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Credit Limit */
		} else if (ctx.getWsMiscStorage().isFlgCredLimitNotOk() || ctx.getWsMiscStorage().isFlgCredLimitBlank()) {
			
			/* 
			FIXME: ACRDLIML OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Expiry Year */
		} else if (ctx.getWsMiscStorage().isFlgExpiryYearNotOk() || ctx.getWsMiscStorage().isFlgExpiryYearBlank()) {
			
			/* 
			FIXME: EXPYEARL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Expiry Month */
		} else if (ctx.getWsMiscStorage().isFlgExpiryMonthNotOk() || ctx.getWsMiscStorage().isFlgExpiryMonthBlank()) {
			
			/* 
			FIXME: EXPMONL  OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Expiry Day */
		} else if (ctx.getWsMiscStorage().isFlgExpiryDayNotOk() || ctx.getWsMiscStorage().isFlgExpiryDayBlank()) {
			
			/* 
			FIXME: EXPDAYL  OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Cash credit limit */
		} else if (ctx.getWsMiscStorage().isFlgCashCreditLimitNotOk() || ctx.getWsMiscStorage().isFlgCashCreditLimitBlank()) {
			
			/* 
			FIXME: ACSHLIML OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Reissue Year */
		} else if (ctx.getWsMiscStorage().isFlgReissueYearNotOk() || ctx.getWsMiscStorage().isFlgReissueYearBlank()) {
			
			/* 
			FIXME: RISYEARL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Expiry Month */
		} else if (ctx.getWsMiscStorage().isFlgReissueMonthNotOk() || ctx.getWsMiscStorage().isFlgReissueMonthBlank()) {
			
			/* 
			FIXME: RISMONL  OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Expiry Day */
		} else if (ctx.getWsMiscStorage().isFlgReissueDayNotOk() || ctx.getWsMiscStorage().isFlgReissueDayBlank()) {
			
			/* 
			FIXME: RISDAYL  OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Current Balance */
		} else if (ctx.getWsMiscStorage().isFlgCurrBalNotOk() || ctx.getWsMiscStorage().isFlgCurrBalBlank()) {
			
			/* 
			FIXME: ACURBALL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Current Cycle Credit */
		} else if (ctx.getWsMiscStorage().isFlgCurrCycCreditNotOk() || ctx.getWsMiscStorage().isFlgCurrCycCreditBlank()) {
			
			/* 
			FIXME: ACRCYCRL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Current Cycle Debit */
		} else if (ctx.getWsMiscStorage().isFlgCurrCycDebitNotOk() || ctx.getWsMiscStorage().isFlgCurrCycDebitBlank()) {
			
			/* 
			FIXME: ACRCYDBL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			SSN Part 1 */
		} else if (ctx.getWsMiscStorage().isFlgEditUsSsnPart1NotOk() || ctx.getWsMiscStorage().isFlgEditUsSsnPart1Blank()) {
			
			/* 
			FIXME: ACTSSN1L OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			SSN Part 2 */
		} else if (ctx.getWsMiscStorage().isFlgEditUsSsnPart2NotOk() || ctx.getWsMiscStorage().isFlgEditUsSsnPart2Blank()) {
			
			/* 
			FIXME: ACTSSN2L  OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			SSN Part 3 */
		} else if (ctx.getWsMiscStorage().isFlgEditUsSsnPart3NotOk() || ctx.getWsMiscStorage().isFlgEditUsSsnPart3Blank()) {
			
			/* 
			FIXME: ACTSSN3L  OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Date of Birth Year */
		} else if (ctx.getWsMiscStorage().isFlgDtOfBirthYearNotOk() || ctx.getWsMiscStorage().isFlgDtOfBirthYearBlank()) {
			
			/* 
			FIXME: DOBYEARL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Date of Birth Month */
		} else if (ctx.getWsMiscStorage().isFlgDtOfBirthMonthNotOk() || ctx.getWsMiscStorage().isFlgDtOfBirthMonthBlank()) {
			
			/* 
			FIXME: DOBMONL  OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Date of Birth Day */
		} else if (ctx.getWsMiscStorage().isFlgDtOfBirthDayNotOk() || ctx.getWsMiscStorage().isFlgDtOfBirthDayBlank()) {
			
			/* 
			FIXME: DOBDAYL  OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			FICO Score */
		} else if (ctx.getWsMiscStorage().isFlgFicoScoreNotOk() || ctx.getWsMiscStorage().isFlgFicoScoreBlank()) {
			
			/* 
			FIXME: ACSTFCOL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			First Name */
		} else if (ctx.getWsMiscStorage().isFlgFirstNameNotOk() || ctx.getWsMiscStorage().isFlgFirstNameBlank()) {
			
			/* 
			FIXME: ACSFNAML OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Middle Name */
		} else if (ctx.getWsMiscStorage().isFlgMiddleNameNotOk()) {
			
			/* 
			FIXME: ACSMNAML OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Last Name */
		} else if (ctx.getWsMiscStorage().isFlgLastNameNotOk() || ctx.getWsMiscStorage().isFlgLastNameBlank()) {
			
			/* 
			FIXME: ACSLNAML OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Address Line 1 */
		} else if (ctx.getWsMiscStorage().isFlgAddressLine1NotOk() || ctx.getWsMiscStorage().isFlgAddressLine1Blank()) {
			
			/* 
			FIXME: ACSADL1L OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			State (appears next to Line 2 on screen before city) */
		} else if (ctx.getWsMiscStorage().isFlgStateNotOk() || ctx.getWsMiscStorage().isFlgStateBlank()) {
			
			/* 
			FIXME: ACSSTTEL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Address Line 2 has no edits
			Zip code */
		} else if (ctx.getWsMiscStorage().isFlgZipcodeNotOk() || ctx.getWsMiscStorage().isFlgZipcodeBlank()) {
			
			/* 
			FIXME: ACSZIPCL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Address Line 3 (City) */
		} else if (ctx.getWsMiscStorage().isFlgCityNotOk() || ctx.getWsMiscStorage().isFlgCityBlank()) {
			
			/* 
			FIXME: ACSCITYL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Country edits. */
		} else if (ctx.getWsMiscStorage().isFlgCountryNotOk() || ctx.getWsMiscStorage().isFlgCountryBlank()) {
			
			/* 
			FIXME: ACSCTRYL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Phone 1 */
		} else if (ctx.getWsMiscStorage().isFlgPhoneNum1aNotOk() || ctx.getWsMiscStorage().isFlgPhoneNum1aBlank()) {
			
			/* 
			FIXME: ACSPH1AL OF CACTUPAI */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().isFlgPhoneNum1bNotOk() || ctx.getWsMiscStorage().isFlgPhoneNum1bBlank()) {
			
			/* 
			FIXME: ACSPH1BL OF CACTUPAI */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().isFlgPhoneNum1cNotOk() || ctx.getWsMiscStorage().isFlgPhoneNum1cBlank()) {
			
			/* 
			FIXME: ACSPH1CL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Phone 2 */
		} else if (ctx.getWsMiscStorage().isFlgPhoneNum2aNotOk() || ctx.getWsMiscStorage().isFlgPhoneNum2aBlank()) {
			
			/* 
			FIXME: ACSPH2AL OF CACTUPAI */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().isFlgPhoneNum2bNotOk() || ctx.getWsMiscStorage().isFlgPhoneNum2bBlank()) {
			
			/* 
			FIXME: ACSPH2BL OF CACTUPAI */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().isFlgPhoneNum2cNotOk() || ctx.getWsMiscStorage().isFlgPhoneNum2cBlank()) {
			
			/* 
			FIXME: ACSPH2CL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			EFT Account Id */
		} else if (ctx.getWsMiscStorage().isFlgEftAccountIdNotOk() || ctx.getWsMiscStorage().isFlgEftAccountIdBlank()) {
			
			/* 
			FIXME: ACSEFTCL OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			Primary Card Holder */
		} else if (ctx.getWsMiscStorage().isFlgPriCardholderNotOk() || ctx.getWsMiscStorage().isFlgPriCardholderBlank()) {
			
			/* 
			FIXME: ACSPFLGL OF CACTUPAI */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: ACCTSIDL OF CACTUPAI */
			BluageUtils.unsupported();
		}
		
		/* 
		SETUP COLOR */
		if (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsLiterals().getLitCclistmapsetReference()) == 0) {
			
			/* 
			FIXME: ACCTSIDC OF CACTUPAO */
			BluageUtils.unsupported();
		} 
		
		/* 
		Account Filter */
		if (ctx.getWsMiscStorage().isFlgAcctfilterNotOk()) {
			
			/* 
			FIXME: ACCTSIDC OF CACTUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isFlgAcctfilterBlank() && BluageUtils.unsupported()) {
			
			/* 
			FIXME: ACCTSIDO OF CACTUPAO */
			BluageUtils.unsupported();
			
			/* 
			FIXME: ACCTSIDC OF CACTUPAO */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsThisProgcommarea().isAcupDetailsNotFetched() || ctx.getWsMiscStorage().isFlgAcctfilterBlank() || ctx.getWsMiscStorage().isFlgAcctfilterNotOk()) {
			return;
		} else {
			
			/* 
			****************************************************************
			Using Copy replacing to set attribs for remaining vars
			Write specific code only if rules differ
			****************************************************************
			IF (FLG-ACCT-STATUS-NOT-OK
			OR  FLG-ACCT-STATUS-BLANK)
			AND CDEMO-PGM-REENTER
			MOVE DFHRED             TO ACSTTUSC OF CACTUPAO
			IF  FLG-ACCT-STATUS-BLANK
			MOVE '*'            TO ACSTTUSO OF CACTUPAO
			END-IF
			END-IF
			Account Status
			Open Year
			Open Month
			Open Day
			Credit Limit
			Expiry Year
			Expiry Month
			Expiry Day
			Cash Credit Limit
			Reissue Year
			Reissue Month
			Reissue Day
			Current Balance
			Current Cycle Credit
			Current Cycle Debit
			SSN Part 1
			SSN Part 2
			SSN Part 3
			Date of Birth Year
			Date of Birth Month
			Date of Birth Day
			FICO Score
			First Name
			Middle Name (no edits coded)
			Last Name
			Address Line 1
			State
			Address Line 2 (NO EDITS CODED AS YET)
			State
			City
			Country
			Phone 1 Area Code
			Phone 1 Prefix
			Phone 1 Line number
			Phone 2 Area Code
			Phone 2 Prefix
			Phone 2 Line number
			EFT Account Id
			Primary Card Holder
			Do nothing */
			return;
		}
	}

	/**
	 * Process operation _3310ProtectAllAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3310ProtectAllAttrs(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: ACCTSIDA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSTTUSA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACRDLIMA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSHLIMA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACURBALA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACRCYCRA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACRCYDBA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: OPNYEARA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: OPNMONA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: OPNDAYA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: EXPYEARA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: EXPMONA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: EXPDAYA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: RISYEARA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: RISMONA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: RISDAYA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: AADDGRPA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSTNUMA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTSSN1A OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTSSN2A OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTSSN3A OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSTFCOA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: DOBYEARA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: DOBMONA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: DOBDAYA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSFNAMA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSMNAMA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSLNAMA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSADL1A OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSADL2A OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSCITYA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSSTTEA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSZIPCA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSCTRYA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH1AA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH1BA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH1CA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH2AA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH2BA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH2CA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSGOVTA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSEFTCA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPFLGA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: INFOMSGA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		Account Limits
		Account dates
		Customer data
		Date of Birth
		Address */
		return;
	}

	/**
	 * Process operation _3320UnprotectFewAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3320UnprotectFewAttrs(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: ACSTTUSA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACRDLIMA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSHLIMA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACURBALA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACRCYCRA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACRCYDBA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: OPNYEARA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: OPNMONA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: OPNDAYA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: EXPYEARA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: EXPMONA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: EXPDAYA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: RISYEARA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: RISMONA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: RISDAYA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: DOBYEARA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: DOBMONA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: DOBDAYA  OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: AADDGRPA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSTNUMA OF CACTUPAI
		Account Limits
		Account dates
		Open Date
		Expiry date
		Reissue date
		Date of Birth
		Customer data */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTSSN1A OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTSSN2A OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACTSSN3A OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSTFCOA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSFNAMA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSMNAMA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSLNAMA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSADL1A OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSADL2A OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSCITYA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSSTTEA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSZIPCA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSCTRYA OF CACTUPAI
		Address
		Since most of the edits are USA specific protected country */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH1AA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH1BA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH1CA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH2AA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH2BA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPH2CA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSGOVTA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSEFTCA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACSPFLGA OF CACTUPAI */
		BluageUtils.unsupported();
		
		/* 
		FIXME: INFOMSGA OF CACTUPAI */
		BluageUtils.unsupported();
	}

	/**
	 * Process operation _3390SetupInfomsgAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3390SetupInfomsgAttrs(final CoactupcContext ctx, final ExecutionController ctrl) {
		if (ctx.getWsMiscStorage().isWsNoInfoMessage()) {
			
			/* 
			FIXME: INFOMSGA OF CACTUPAI */
			BluageUtils.unsupported();
		} else {
			
			/* 
			FIXME: INFOMSGA OF CACTUPAI */
			BluageUtils.unsupported();
		}
		if (ctx.getWsThisProgcommarea().isAcupChangesMade() && !(ctx.getWsThisProgcommarea().isAcupChangesOkayedAndDone())) {
			
			/* 
			FIXME: FKEY12A  OF CACTUPAI */
			BluageUtils.unsupported();
		} 
		if (ctx.getWsMiscStorage().isPromptForConfirmation()) {
			
			/* 
			FIXME: FKEY05A  OF CACTUPAI */
			BluageUtils.unsupported();
			
			/* 
			FIXME: FKEY12A  OF CACTUPAI */
			BluageUtils.unsupported();
		}
	}

	/**
	 * Process operation _3400SendScreen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3400SendScreen(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CCARD-NEXT-MAPSET */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CCARD-NEXT-MAP */
		BluageUtils.unsupported();
		SendMapBuilder.newInstance(ctx.getJicsEiblk(), ctx)
		.withMap(BluageUtils.unsupported())
		.withMapset(BluageUtils.unsupported())
		.withData(BluageUtils.unsupported())
		.withCursor()
		.withErase()
		.withFreeKB()
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
	}

	/**
	 * Process operation _9000ReadAcct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9000ReadAcct(final CoactupcContext ctx, final ExecutionController ctrl) {
		ctx.getWsThisProgcommarea().getAcupOldDetailsReference().getField().initialize();
		ctx.getWsMiscStorage().setWsNoInfoMessage(true);
		ctx.getWsThisProgcommarea().setAcupOldAcctId(BluageUtils.unsupported());
		ctx.getWsMiscStorage().setWsCardRidAcctId(BluageUtils.unsupported());
		_9200GetcardxrefByacct(ctx, ctrl);
		if (ctx.getWsMiscStorage().isFlgAcctfilterNotOk()) {
			return;
		} else {
			_9300GetacctdataByacct(ctx, ctrl);
			if (ctx.getWsMiscStorage().isDidNotFindAcctInAcctdat()) {
				return;
			} else {
				ctx.getWsMiscStorage().setWsCardRidCustId(BluageUtils.unsupported());
				_9400GetcustdataBycust(ctx, ctrl);
				if (ctx.getWsMiscStorage().isDidNotFindCustInCustdat()) {
					return;
				} else {
					_9500StoreFetchedData(ctx, ctrl);
				}
			}
		}
	}

	/**
	 * Process operation _9200GetcardxrefByacct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9200GetcardxrefByacct(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		Read the Card file. Access via alternate index ACCTID */
		JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitCardxrefnameAcctPathReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference())
		.keyLength(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference().getRecord().getSize(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			
			/* 
			FIXME: CDEMO-CUST-ID */
			BluageUtils.unsupported();
			
			/* 
			FIXME: CDEMO-CARD-NUM */
			BluageUtils.unsupported();
		} else if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
				ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize("Account:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference().getBytes())
					.addDelimitedBySize(" not found in")
					.addDelimitedBySize(" Cross ref file.  Resp:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getErrorRespReference().getBytes())
					.addDelimitedBySize(" Reas:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getErrorResp2Reference().getBytes())
					.end();
			} 
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
			ctx.getWsMiscStorage().setErrorOpname("READ");
			ctx.getWsMiscStorage().setErrorFile(ctx.getWsLiterals().getLitCardxrefnameAcctPath());
			ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
			ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
			ctx.getWsMiscStorage().getWsReturnMsgReference().setBytes(ctx.getWsMiscStorage().getWsFileErrorMessageReference().getBytes());
			
			/* 
			WS-LONG-MSG
			PERFORM SEND-LONG-TEXT */
		}
	}

	/**
	 * Process operation _9300GetacctdataByacct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9300GetacctdataByacct(final CoactupcContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitAcctfilenameReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference())
		.keyLength(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference().getRecord().getSize(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			ctx.getWsMiscStorage().setFoundAcctInMaster(true);
		} else if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
			
			/* 
			SET DID-NOT-FIND-ACCT-IN-ACCTDAT TO TRUE */
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
				ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize("Account:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsCardRidAcctIdXReference().getBytes())
					.addDelimitedBySize(" not found in")
					.addDelimitedBySize(" Acct Master file.Resp:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getErrorRespReference().getBytes())
					.addDelimitedBySize(" Reas:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getErrorResp2Reference().getBytes())
					.end();
			} 
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgAcctfilterNotOk(true);
			ctx.getWsMiscStorage().setErrorOpname("READ");
			ctx.getWsMiscStorage().setErrorFile(ctx.getWsLiterals().getLitAcctfilename());
			ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
			ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
			ctx.getWsMiscStorage().getWsReturnMsgReference().setBytes(ctx.getWsMiscStorage().getWsFileErrorMessageReference().getBytes());
			
			/* 
			WS-LONG-MSG
			PERFORM SEND-LONG-TEXT */
		}
	}

	/**
	 * Process operation _9400GetcustdataBycust.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9400GetcustdataBycust(final CoactupcContext ctx, final ExecutionController ctrl) {
		JicsFileBuilder.newInstance(ctx.getWsLiterals().getLitCustfilenameReference(), ctx.getJicsEiblk(), ctx, ctrl.getExecutionContext())
		.read()
		.into(BluageUtils.unsupported())
		.length(DataUtils.getBytes(BluageUtils.unsupported().length()))
		.recordIndentificationField(ctx.getWsMiscStorage().getWsCardRidCustIdXReference())
		.keyLength(ctx.getWsMiscStorage().getWsCardRidCustIdXReference().getRecord().getSize(),false)
		.execute();
		
		/* 
		WARNING: assignment between EIBRESP [binary(8, 0)] and WS-RESP-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsRespCd(ctx.getDfheiblk().getEibresp());
		
		/* 
		WARNING: assignment between EIBRESP2 [binary(8, 0)] and WS-REAS-CD [binary(9, 0)] */
		ctx.getWsMiscStorage().setWsReasCd(ctx.getDfheiblk().getEibresp2());
		if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NORMAL.getIntValue()) {
			ctx.getWsMiscStorage().setFoundCustInMaster(true);
		} else if (ctx.getWsMiscStorage().getWsRespCd() == ResponseCode.NOTFND.getIntValue()) {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgCustfilterNotOk(true);
			
			/* 
			SET DID-NOT-FIND-CUST-IN-CUSTDAT TO TRUE */
			ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
			ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
			if (ctx.getWsMiscStorage().isWsReturnMsgOff()) {
				StringConcatenationBuilder.newInstance(ctx.getWsMiscStorage().getWsReturnMsgReference())
					.addDelimitedBySize("CustId:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getWsCardRidCustIdXReference().getBytes())
					.addDelimitedBySize(" not found")
					.addDelimitedBySize(" in customer master.Resp: ")
					.addDelimitedBySize(ctx.getWsMiscStorage().getErrorRespReference().getBytes())
					.addDelimitedBySize(" REAS:")
					.addDelimitedBySize(ctx.getWsMiscStorage().getErrorResp2Reference().getBytes())
					.end();
			} 
		} else {
			ctx.getWsMiscStorage().setInputError(true);
			ctx.getWsMiscStorage().setFlgCustfilterNotOk(true);
			ctx.getWsMiscStorage().setErrorOpname("READ");
			ctx.getWsMiscStorage().setErrorFile(ctx.getWsLiterals().getLitCustfilename());
			ctx.getWsMiscStorage().setErrorResp(ctx.getWsMiscStorage().getWsRespCdReference().getValue(String.class));
			ctx.getWsMiscStorage().setErrorResp2(ctx.getWsMiscStorage().getWsReasCdReference().getValue(String.class));
			ctx.getWsMiscStorage().getWsReturnMsgReference().setBytes(ctx.getWsMiscStorage().getWsFileErrorMessageReference().getBytes());
			
			/* 
			WS-LONG-MSG
			PERFORM SEND-LONG-TEXT */
		}
	}

	/**
	 * Process operation _9500StoreFetchedData.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9500StoreFetchedData(final CoactupcContext ctx, final ExecutionController ctrl) {
		/* 
		FIXME: CDEMO-ACCT-ID
		Store Context in Commarea */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-CUST-ID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-CUST-FNAME */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-CUST-MNAME */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-CUST-LNAME */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-ACCT-STATUS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CDEMO-CARD-NUM */
		BluageUtils.unsupported();
		ctx.getWsThisProgcommarea().getAcupOldDetailsReference().getField().initialize();
		
		/* 
		****************************************************************
		Account Master data
		**************************************************************** */
		ctx.getWsThisProgcommarea().setAcupOldAcctId(BluageUtils.unsupported());
		
		/* 
		Active Status */
		ctx.getWsThisProgcommarea().setAcupOldActiveStatus(BluageUtils.unsupported());
		
		/* 
		Current Balance */
		ctx.getWsThisProgcommarea().setAcupOldCurrBalN(BluageUtils.unsupported());
		
		/* 
		Credit Limit */
		ctx.getWsThisProgcommarea().setAcupOldCreditLimitN(BluageUtils.unsupported());
		
		/* 
		Cash Limit */
		ctx.getWsThisProgcommarea().setAcupOldCashCreditLimitN(BluageUtils.unsupported());
		
		/* 
		Current Cycle Credit */
		ctx.getWsThisProgcommarea().setAcupOldCurrCycCreditN(BluageUtils.unsupported());
		
		/* 
		Current Cycle Debit */
		ctx.getWsThisProgcommarea().setAcupOldCurrCycDebitN(BluageUtils.unsupported());
		
		/* 
		Open date
		MOVE ACCT-OPEN-DATE           TO ACUP-OLD-OPEN-DATE */
		ctx.getWsThisProgcommarea().setAcupOldOpenYear(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldOpenMon(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldOpenDay(BluageUtils.unsupported());
		
		/* 
		Expiry date
		MOVE ACCT-EXPIRAION-DATE      TO ACUP-OLD-EXPIRAION-DATE */
		ctx.getWsThisProgcommarea().setAcupOldExpYear(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldExpMon(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldExpDay(BluageUtils.unsupported());
		
		/* 
		Reissue date
		MOVE ACCT-REISSUE-DATE        TO ACUP-OLD-REISSUE-DATE */
		ctx.getWsThisProgcommarea().setAcupOldReissueYear(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldReissueMon(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldReissueDay(BluageUtils.unsupported());
		
		/* 
		Account Group */
		ctx.getWsThisProgcommarea().setAcupOldGroupId(BluageUtils.unsupported());
		
		/* 
		****************************************************************
		Customer Master data
		****************************************************************
		Customer Id (actually not editable) */
		ctx.getWsThisProgcommarea().setAcupOldCustId(BluageUtils.unsupported());
		
		/* 
		Social Security Number */
		ctx.getWsThisProgcommarea().setAcupOldCustSsn(BluageUtils.unsupported());
		
		/* 
		Date of birth
		MOVE CUST-DOB-YYYY-MM-DD      TO ACUP-OLD-CUST-DOB-YYYY-MM-DD */
		ctx.getWsThisProgcommarea().setAcupOldCustDobYear(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldCustDobMon(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldCustDobDay(BluageUtils.unsupported());
		
		/* 
		FICO */
		ctx.getWsThisProgcommarea().setAcupOldCustFicoScore(BluageUtils.unsupported());
		
		/* 
		First Name */
		ctx.getWsThisProgcommarea().setAcupOldCustFirstName(BluageUtils.unsupported());
		
		/* 
		Middle Name */
		ctx.getWsThisProgcommarea().setAcupOldCustMiddleName(BluageUtils.unsupported());
		
		/* 
		Last Name */
		ctx.getWsThisProgcommarea().setAcupOldCustLastName(BluageUtils.unsupported());
		
		/* 
		Address */
		ctx.getWsThisProgcommarea().setAcupOldCustAddrLine1(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldCustAddrLine2(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldCustAddrLine3(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldCustAddrStateCd(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldCustAddrCountryCd(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldCustAddrZip(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldCustPhoneNum1(BluageUtils.unsupported());
		ctx.getWsThisProgcommarea().setAcupOldCustPhoneNum2(BluageUtils.unsupported());
		
		/* 
		Government Id */
		ctx.getWsThisProgcommarea().setAcupOldCustGovtIssuedId(BluageUtils.unsupported());
		
		/* 
		EFT Code */
		ctx.getWsThisProgcommarea().setAcupOldCustEftAccountId(BluageUtils.unsupported());
		
		/* 
		Primary Holder Indicator */
		ctx.getWsThisProgcommarea().setAcupOldCustPriHolderInd(BluageUtils.unsupported());
	}

	/**
	 * Process operation abendRoutine.
	 * 
	 * ****************************************************************
	 * Common code to store PFKey
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void abendRoutine(final CoactupcContext ctx, final ExecutionController ctrl) {
		if (DataUtils.isLowValue(BluageUtils.unsupported())) {
			
			/* 
			FIXME: ABEND-MSG */
			BluageUtils.unsupported();
		} 
		
		/* 
		FIXME: ABEND-CULPRIT */
		BluageUtils.unsupported();
		
		/* 
		Ignored CICS Command SEND */
		HandleAbendBuilder.newInstance(ctx.getJicsEiblk(), ctx).cancel().execute().handleException();
		AbendBuilder.newInstance(ctx.getJicsEiblk(), ctx).withAbendCode("9999").execute().handleException();
		
		/* 
		****************************************************************
		Common Date Routines
		****************************************************************
		Ver: CardDemo_v1.0-15-g27d6c6f-68 Date: 2022-07-19 23:12:32 CDT */
		return;
	}

}
