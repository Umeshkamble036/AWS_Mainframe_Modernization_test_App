// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "MNTTRDB2"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//******************************************************************//
	//                                                                 *//
	// USE THIS JOB TO MAINTAIN DB2 TRANSACTION TABLE, INSERTING,      *//
	// UPDATING OR REMOVING RECORDS IN BATCH.                          *//
	//                                                                 *//
	// INPFILE - THE INPUT FILE TO USE FOR UPDATES. THE ALLOWED VALUES *//
	//           ARE:                                                  *//
	//                                                                 *//
	// COLUMN 1     - A - ADD                                          *//
	//                D - DELETE                                       *//
	//                U - UPDATE                                       *//
	//                * - COMMENT                                      *//
	//                                                                 *//
	// COLUMNS 2-3  - TRANSACTION TYPE. NUMERIC VALUE                  *//
	//                                                                 *//
	// COLUMNS 4-53 - TRANSACTION DESCRIPTION                          *//
	//                                                                 *//
	//******************************************************************//
	lastProgramResult = stepSTEP1(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP STEP1 - PGM - IKJEFT01****************************************************
def stepSTEP1(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP1", "IKJEFT01", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.concatenation("STEPLIB")
						.path("OEM.DB2.DAZ1.SDSNEXIT")
						.disposition("SHR")
						.path("OEMA.DB2.VERSIONA.SDSNLOAD")
						.disposition("SHR")
						.path("AWS.M2.CARDDEMO.LOADLIB")
						.disposition("SHR")
						.build()
						.bluesam("DBRMLIB")
						.dataset("AWS.M2.CARDDEMO.DBRMLIB")
						.disposition("SHR")
						.build()
						.systemOut("SYSTSPRT")
						.output("*")
						.build()
						.bluesam("INPFILE")
						.dataset("INPFILE")
						.disposition("SHR")
						.build()
						.fileSystem("SYSTSIN")
						.stream(
"""     DSN SYSTEM(DAZ1)
          RUN PROGRAM(COBTUPDT) PLAN(CARDDEMO)""", getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IKJEFT01")
				})
		}
	}
}
