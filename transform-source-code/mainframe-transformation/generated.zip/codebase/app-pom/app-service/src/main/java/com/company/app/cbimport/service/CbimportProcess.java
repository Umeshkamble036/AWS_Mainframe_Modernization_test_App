package com.company.app.cbimport.service;

import com.company.app.cbimport.business.context.CbimportContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface CbimportProcess.
 * 
 * Defines application services for CbimportProcess
 */
public interface CbimportProcess {

	/**
	 * Process operation _0000MainProcessing.
	 * 
	 * PROGRAM-ID.CBIMPORT.
	 *  AUTHOR.        CARDDEMO TEAM.
	 * *****************************************************************
	 *  Program     : CBIMPORT.CBL
	 *  Application : CardDemo
	 *  Type        : BATCH COBOL Program
	 *  Function    : Import Customer Data from Branch Migration Export
	 *                Reads multi-record export file and splits it into
	 *                separate normalized target files (CUSTOMER, ACCOUN
	 *                CARD-XREF, TRANSACTION) with validation
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 *  Business Use Case: Branch Migration Import
	 *  - Import complete customer profiles from export file
	 *  - Split multi-record layout into normalized target files
	 *  - Validate data integrity using checksums
	 *  - Generate import statistics and error reports
	 * *****************************************************************
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000MainProcessing(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000Initialize.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000Initialize(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1100OpenFiles.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1100OpenFiles(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2000ProcessExportFile.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000ProcessExportFile(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2100ReadExportRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2100ReadExportRecord(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2200ProcessRecordByType.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2200ProcessRecordByType(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2300ProcessCustomerRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2300ProcessCustomerRecord(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2400ProcessAccountRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2400ProcessAccountRecord(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2500ProcessXrefRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2500ProcessXrefRecord(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2600ProcessTranRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2600ProcessTranRecord(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2650ProcessCardRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2650ProcessCardRecord(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2700ProcessUnknownRecord.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2700ProcessUnknownRecord(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2750WriteError.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2750WriteError(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3000ValidateImport.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000ValidateImport(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _4000Finalize.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _4000Finalize(final CbimportContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9999AbendProgram.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9999AbendProgram(final CbimportContext ctx, final ExecutionController ctrl);

}
