package com.company.app.cbtrn03c.service;

import com.company.app.cbtrn03c.business.context.Cbtrn03cContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface Cbtrn03cProcess.
 * 
 * Defines application services for Cbtrn03cProcess
 */
public interface Cbtrn03cProcess {

	/**
	 * Process operation procedureDivision.
	 * 
	 * PROGRAM-ID.CBTRN03C.
	 *  AUTHOR.        AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void procedureDivision(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation procedureDivision1.
	 * 
	 * *****************************************************************
	 *  Program     : CBTRN03C.CBL
	 *  Application : CardDemo
	 *  Type        : BATCH COBOL Program
	 *  Function    : Print the transaction detail report.
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void procedureDivision1(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0550DateparmRead.
	 * 
	 *  Read the date parameter file.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0550DateparmRead(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000TranfileGetNext.
	 * 
	 * ****************************************************************
	 *  I/O ROUTINES TO ACCESS A KSDS, VSAM DATA SET...               *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000TranfileGetNext(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1100WriteTransactionReport.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1100WriteTransactionReport(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1110WritePageTotals.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1110WritePageTotals(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1120WriteAccountTotals.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1120WriteAccountTotals(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1110WriteGrandTotals.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1110WriteGrandTotals(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1120WriteHeaders.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1120WriteHeaders(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1111WriteReportRec.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1111WriteReportRec(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1120WriteDetail.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1120WriteDetail(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0000TranfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0000TranfileOpen(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0100ReptfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0100ReptfileOpen(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0200CardxrefOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0200CardxrefOpen(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0300TrantypeOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0300TrantypeOpen(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0400TrancatgOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0400TrancatgOpen(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _0500DateparmOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _0500DateparmOpen(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1500ALookupXref.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1500ALookupXref(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1500BLookupTrantype.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1500BLookupTrantype(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1500CLookupTrancatg.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1500CLookupTrancatg(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9000TranfileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9000TranfileClose(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9100ReptfileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9100ReptfileClose(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9200CardxrefClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9200CardxrefClose(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9300TrantypeClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9300TrantypeClose(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9400TrancatgClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9400TrancatgClose(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9500DateparmClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9500DateparmClose(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9999AbendProgram.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9999AbendProgram(final Cbtrn03cContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9910DisplayIoStatus.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9910DisplayIoStatus(final Cbtrn03cContext ctx, final ExecutionController ctrl);

}
