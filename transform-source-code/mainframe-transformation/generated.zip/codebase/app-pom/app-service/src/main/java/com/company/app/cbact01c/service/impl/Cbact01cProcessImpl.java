
package com.company.app.cbact01c.service.impl;

import com.company.app.cbact01c.business.context.Cbact01cContext;
import com.company.app.cbact01c.service.Cbact01cProcess;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.io.IndexedFile;
import com.netfective.bluage.gapwalk.rt.io.OpenMode;
import com.netfective.bluage.gapwalk.rt.io.SequentialFile;
import com.netfective.bluage.gapwalk.runtime.statements.CallBuilder;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import java.math.BigDecimal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Cbact01cProcessImpl
 * 
 * Defines application services for Cbact01cProcess
 * @see Cbact01cProcess
 */
@Service("com.company.app.cbact01c.service.Cbact01cProcess")
@Lazy

public class Cbact01cProcessImpl implements Cbact01cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Cbact01cProcessImpl.class);


	/**
	 * Process operation procedureDivision.
	 * 
	 * PROGRAM-ID.CBACT01C.
	 *  AUTHOR.        AWS.
	 * *****************************************************************
	 *  PROGRAM     : CBACT01C.CBL
	 *  Application : CardDemo
	 *  Type        : BATCH COBOL Program
	 *  FUNCTION    : READ THE ACCOUNT FILE AND WRITE INTO FILES.
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void procedureDivision(final Cbact01cContext ctx, final ExecutionController ctrl) {
		/* 
		**************************************************************** */
		DisplayUtils.display(ctx, ctrl, LOGGER, "START OF EXECUTION OF PROGRAM CBACT01C");
		_0000AcctfileOpen(ctx, ctrl);
		_2000OutfileOpen(ctx, ctrl);
		_3000ArrfileOpen(ctx, ctrl);
		_4000VbrfileOpen(ctx, ctrl);
		while (DataUtils.compare(ctx.getEndOfFile().getEndOfFileReference(), "Y") != 0) {
			if (DataUtils.compare(ctx.getEndOfFile().getEndOfFileReference(), "N") == 0) {
				_1000AcctfileGetNext(ctx, ctrl);
				if (DataUtils.compare(ctx.getEndOfFile().getEndOfFileReference(), "N") == 0) {
					// FIXME An error occured while generating Java from BAGS (@LoggerUtils.info(@BluageUtils.unsupported("ACCOUNT-RECORD")))
					BluageUtils.unsupported();
				} 
			} 
		}
		_9000AcctfileClose(ctx, ctrl);
		DisplayUtils.display(ctx, ctrl, LOGGER, "END OF EXECUTION OF PROGRAM CBACT01C");
		if (ctx.isMainProgram()) {
			ctrl.stopRunUnit();
		}
	}

	/**
	 * Process operation _1000AcctfileGetNext.
	 * 
	 * ****************************************************************
	 *  I/O ROUTINES TO ACCESS A KSDS, VSAM DATA SET...               *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1000AcctfileGetNext(final Cbact01cContext ctx, final ExecutionController ctrl) {
		IndexedFile acctfileFile = ctx.getAcctfileFileHandler(ctrl.getExecutionContext()); 
		boolean result = false; 
		result = acctfileFile.read();
		if (result) {
			
			/* 
			FIXME: ACCOUNT-RECORD */
			BluageUtils.unsupported();
		} 
		if (DataUtils.compare("00", ctx.getAcctfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
			ctx.getArryFile().getArrArrayRecReference().getField().initialize();
			_1100DisplayAcctRecord(ctx, ctrl);
			_1300PopulAcctRecord(ctx, ctrl);
			_1350WriteAcctRecord(ctx, ctrl);
			_1400PopulArrayRecord(ctx, ctrl);
			_1450WriteArryRecord(ctx, ctrl);
			ctx.getVbrcRec1().getField().initialize();
			_1500PopulVbrcRecord(ctx, ctrl);
			_1550WriteVb1Record(ctx, ctrl);
			_1575WriteVb2Record(ctx, ctrl);
		} else {
			if (DataUtils.compare("10", ctx.getAcctfileStatus()) == 0) {
				ctx.getApplResult().setApplResult(16);
			} else {
				ctx.getApplResult().setApplResult(12);
			}
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			if (ctx.getApplResult().isApplEof()) {
				ctx.getEndOfFile().setEndOfFile("Y");
			} else {
				DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR READING ACCOUNT FILE");
				ctx.getIoStatus().setBytes(ctx.getAcctfileStatus().getBytes());
				_9910DisplayIoStatus(ctx, ctrl);
				_9999AbendProgram(ctx, ctrl);
			}
		}
	}

	/**
	 * Process operation _1100DisplayAcctRecord.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1100DisplayAcctRecord(final Cbact01cContext ctx, final ExecutionController ctrl) {
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCT-ID                 :" , BluageUtils.unsupported());
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCT-ACTIVE-STATUS      :" , BluageUtils.unsupported());
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCT-CURR-BAL           :" , BluageUtils.unsupported());
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCT-CREDIT-LIMIT       :" , BluageUtils.unsupported());
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCT-CASH-CREDIT-LIMIT  :" , BluageUtils.unsupported());
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCT-OPEN-DATE          :" , BluageUtils.unsupported());
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCT-EXPIRAION-DATE     :" , BluageUtils.unsupported());
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCT-REISSUE-DATE       :" , BluageUtils.unsupported());
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCT-CURR-CYC-CREDIT    :" , BluageUtils.unsupported());
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCT-CURR-CYC-DEBIT     :" , BluageUtils.unsupported());
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCT-GROUP-ID           :" , BluageUtils.unsupported());
		DisplayUtils.display(ctx, ctrl, LOGGER, "-------------------------------------------------");
	}

	/**
	 * Process operation _1300PopulAcctRecord.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1300PopulAcctRecord(final Cbact01cContext ctx, final ExecutionController ctrl) {
		ctx.getOutFile().setOutAcctId(BluageUtils.unsupported());
		ctx.getOutFile().setOutAcctActiveStatus(BluageUtils.unsupported());
		ctx.getOutFile().setOutAcctCurrBal(BluageUtils.unsupported());
		ctx.getOutFile().setOutAcctCreditLimit(BluageUtils.unsupported());
		ctx.getOutFile().setOutAcctCashCreditLimit(BluageUtils.unsupported());
		ctx.getOutFile().setOutAcctOpenDate(BluageUtils.unsupported());
		ctx.getOutFile().setOutAcctExpiraionDate(BluageUtils.unsupported());
		
		/* 
		FIXME: CODATECN-INP-DATE */
		BluageUtils.unsupported();
		ctx.getGroup2().setWsReissueDate(BluageUtils.unsupported());
		
		/* 
		FIXME: CODATECN-TYPE */
		BluageUtils.unsupported();
		
		/* 
		FIXME: CODATECN-OUTTYPE */
		BluageUtils.unsupported();
		
		/* 
		---------------------------------------------------------------*
		CALL ASSEMBLER PROGRAM FOR DATE FORMATTING                     *
		---------------------------------------------------------------* */
		ctrl.callSubProgram("COBDATFT", CallBuilder.newInstance()
			.byReference(BluageUtils.unsupported())
			.getArguments(), ctx);
		ctx.getOutFile().setOutAcctReissueDate(BluageUtils.unsupported());
		ctx.getOutFile().setOutAcctCurrCycCredit(BluageUtils.unsupported());
		if (DataUtils.isZero(BluageUtils.unsupported())) {
			ctx.getOutFile().setOutAcctCurrCycDebit(BigDecimal.valueOf(2525.00));
		} 
		ctx.getOutFile().setOutAcctGroupId(BluageUtils.unsupported());
	}

	/**
	 * Process operation _1350WriteAcctRecord.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1350WriteAcctRecord(final Cbact01cContext ctx, final ExecutionController ctrl) {
		SequentialFile outFile = ctx.getOutFileHandler(ctrl.getExecutionContext()); 
		outFile.write(ctx.getOutFile().getOutAcctRecReference());
		if (DataUtils.compare("00", ctx.getOutfileStatus()) != 0 && DataUtils.compare("10", ctx.getOutfileStatus()) != 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCOUNT FILE WRITE STATUS IS:" , DataUtils.toString(ctx.getOutfileStatus().getBytes()));
			ctx.getIoStatus().setBytes(ctx.getOutfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _1400PopulArrayRecord.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1400PopulArrayRecord(final Cbact01cContext ctx, final ExecutionController ctrl) {
		ctx.getArryFile().setArrAcctId(BluageUtils.unsupported());
		ctx.getArryFile().setItemFromArrAcctCurrBal(BluageUtils.unsupported(),0);
		ctx.getArryFile().setItemFromArrAcctCurrCycDebit(BigDecimal.valueOf(1005.00),0);
		ctx.getArryFile().setItemFromArrAcctCurrBal(BluageUtils.unsupported(),1);
		ctx.getArryFile().setItemFromArrAcctCurrCycDebit(BigDecimal.valueOf(1525.00),1);
		ctx.getArryFile().setItemFromArrAcctCurrBal(BigDecimal.valueOf(-1025.00),2);
		ctx.getArryFile().setItemFromArrAcctCurrCycDebit(BigDecimal.valueOf(-2500.00),2);
	}

	/**
	 * Process operation _1450WriteArryRecord.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1450WriteArryRecord(final Cbact01cContext ctx, final ExecutionController ctrl) {
		SequentialFile arryFile = ctx.getArryFileHandler(ctrl.getExecutionContext()); 
		arryFile.write(ctx.getArryFile().getArrArrayRecReference());
		if (DataUtils.compare("00", ctx.getArryfileStatus()) != 0 && DataUtils.compare("10", ctx.getArryfileStatus()) != 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCOUNT FILE WRITE STATUS IS:" , DataUtils.toString(ctx.getArryfileStatus().getBytes()));
			ctx.getIoStatus().setBytes(ctx.getArryfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _1500PopulVbrcRecord.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1500PopulVbrcRecord(final Cbact01cContext ctx, final ExecutionController ctrl) {
		ctx.getVbrcRec1().setVb1AcctId(BluageUtils.unsupported());
		ctx.getVbrcRec2().setVb2AcctId(BluageUtils.unsupported());
		ctx.getVbrcRec1().setVb1AcctActiveStatus(BluageUtils.unsupported());
		ctx.getVbrcRec2().setVb2AcctCurrBal(BluageUtils.unsupported());
		ctx.getVbrcRec2().setVb2AcctCreditLimit(BluageUtils.unsupported());
		ctx.getVbrcRec2().getVb2AcctReissueYyyyReference().setValue(ctx.getGroup2().getWsAcctReissueYyyyReference());
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "VBRC-REC1:" , DataUtils.toString(ctx.getVbrcRec1().getBytes()));
		DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "VBRC-REC2:" , DataUtils.toString(ctx.getVbrcRec2().getBytes()));
	}

	/**
	 * Process operation _1550WriteVb1Record.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1550WriteVb1Record(final Cbact01cContext ctx, final ExecutionController ctrl) {
		SequentialFile vbrcFile = ctx.getVbrcFileHandler(ctrl.getExecutionContext()); 
		ctx.getWsRecdLen().setWsRecdLen(12);
		int len = ctx.getWsRecdLen().getWsRecdLen();
		ctx.getVbrcFile().getVbrRecReference().setBytes(ctx.getVbrcRec1().getBytes(), 0, len);
		vbrcFile.write(ctx.getVbrcFile().getVbrRecReference());
		if (DataUtils.compare("00", ctx.getVbrcfileStatus()) != 0 && DataUtils.compare("10", ctx.getVbrcfileStatus()) != 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCOUNT FILE WRITE STATUS IS:" , DataUtils.toString(ctx.getVbrcfileStatus().getBytes()));
			ctx.getIoStatus().setBytes(ctx.getVbrcfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _1575WriteVb2Record.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1575WriteVb2Record(final Cbact01cContext ctx, final ExecutionController ctrl) {
		SequentialFile vbrcFile = ctx.getVbrcFileHandler(ctrl.getExecutionContext()); 
		ctx.getWsRecdLen().setWsRecdLen(39);
		int len = ctx.getWsRecdLen().getWsRecdLen();
		ctx.getVbrcFile().getVbrRecReference().setBytes(ctx.getVbrcRec2().getBytes(), 0, len);
		vbrcFile.write(ctx.getVbrcFile().getVbrRecReference());
		if (DataUtils.compare("00", ctx.getVbrcfileStatus()) != 0 && DataUtils.compare("10", ctx.getVbrcfileStatus()) != 0) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCOUNT FILE WRITE STATUS IS:" , DataUtils.toString(ctx.getVbrcfileStatus().getBytes()));
			ctx.getIoStatus().setBytes(ctx.getVbrcfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _0000AcctfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0000AcctfileOpen(final Cbact01cContext ctx, final ExecutionController ctrl) {
		IndexedFile acctfileFile = ctx.getAcctfileFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		acctfileFile.open(OpenMode.INPUT);
		if (DataUtils.compare("00", ctx.getAcctfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR OPENING ACCTFILE");
			ctx.getIoStatus().setBytes(ctx.getAcctfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _2000OutfileOpen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2000OutfileOpen(final Cbact01cContext ctx, final ExecutionController ctrl) {
		SequentialFile outFile = ctx.getOutFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		outFile.open(OpenMode.OUTPUT);
		if (DataUtils.compare("00", ctx.getOutfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ERROR OPENING OUTFILE" , DataUtils.toString(ctx.getOutfileStatus().getBytes()));
			ctx.getIoStatus().setBytes(ctx.getOutfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _3000ArrfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3000ArrfileOpen(final Cbact01cContext ctx, final ExecutionController ctrl) {
		SequentialFile arryFile = ctx.getArryFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		arryFile.open(OpenMode.OUTPUT);
		if (DataUtils.compare("00", ctx.getArryfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ERROR OPENING ARRAYFILE" , DataUtils.toString(ctx.getArryfileStatus().getBytes()));
			ctx.getIoStatus().setBytes(ctx.getArryfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _4000VbrfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _4000VbrfileOpen(final Cbact01cContext ctx, final ExecutionController ctrl) {
		SequentialFile vbrcFile = ctx.getVbrcFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		vbrcFile.open(OpenMode.OUTPUT);
		if (DataUtils.compare("00", ctx.getVbrcfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ERROR OPENING VBRC FILE" , DataUtils.toString(ctx.getVbrcfileStatus().getBytes()));
			ctx.getIoStatus().setBytes(ctx.getVbrcfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _9000AcctfileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9000AcctfileClose(final Cbact01cContext ctx, final ExecutionController ctrl) {
		IndexedFile acctfileFile = ctx.getAcctfileFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		acctfileFile.close();
		if (DataUtils.compare("00", ctx.getAcctfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(ctx.getApplResult().getApplResult() - ctx.getApplResult().getApplResult());
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR CLOSING ACCOUNT FILE");
			ctx.getIoStatus().setBytes(ctx.getAcctfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _9999AbendProgram.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9999AbendProgram(final Cbact01cContext ctx, final ExecutionController ctrl) {
		DisplayUtils.display(ctx, ctrl, LOGGER, "ABENDING PROGRAM");
		ctx.getTiming().setTiming(0);
		ctx.getAbcode().setAbcode(999);
		ctrl.callSubProgram("CEE3ABD", CallBuilder.newInstance()
			.byReference(ctx.getAbcode().getAbcodeReference())
			.byReference(ctx.getTiming().getTimingReference())
			.getArguments(), ctx);
	}

	/**
	 * Process operation _9910DisplayIoStatus.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9910DisplayIoStatus(final Cbact01cContext ctx, final ExecutionController ctrl) {
		if (!(DataUtils.isNumeric(ctx.getIoStatus())) || DataUtils.compare(ctx.getIoStatus().getIoStat1Reference(), "9") == 0) {
			ctx.getIoStatus04().setBytes(ctx.getIoStatus().getIoStat1Reference().getBytes(), 0, 1);
			ctx.getGroup1().setTwoBytesBinary(0);
			ctx.getGroup1().getTwoBytesRightReference().setValue(ctx.getIoStatus().getIoStat2Reference());
			ctx.getIoStatus04().setIoStatus0403(ctx.getGroup1().getTwoBytesBinary());
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "FILE STATUS IS: NNNN" , DataUtils.toString(ctx.getIoStatus04().getBytes()));
		} else {
			ctx.getIoStatus04().setBytes(DataUtils.getBytes("0000"));
			ctx.getIoStatus04().setBytes(ctx.getIoStatus().getBytes(), 2, 2);
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "FILE STATUS IS: NNNN" , DataUtils.toString(ctx.getIoStatus04().getBytes()));
		}
		
		/* 
		Ver: CardDemo_v2.0-25-gdb72e6b-235 Date: 2025-04-29 11:01:27 CDT */
		return;
	}

}
