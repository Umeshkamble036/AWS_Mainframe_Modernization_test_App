// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "UNLDPADB"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//*****************************************************************
	// Copyright Amazon.com, Inc. or its affiliates.
	// All Rights Reserved.
	//
	// Licensed under the Apache License, Version 2.0 (the "License").
	// You may not use this file except in compliance with the License.
	// You may obtain a copy of the License at
	//
	//    http://www.apache.org/licenses/LICENSE-2.0
	//
	// Unless required by applicable law or agreed to in writing,
	// software distributed under the License is distributed on an
	// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	// either express or implied. See the License for the specific
	// language governing permissions and limitations under the License
	//*****************************************************************
	//
	//
	//
	//*********************************************************************
	//  EXECUTE IMS PROGRAM
	//*********************************************************************
	lastProgramResult = stepSTEP0(shell, params, programResults)
	//
	lastProgramResult = stepSTEP01(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP STEP0 - PGM - IEFBR14*****************************************************
def stepSTEP0(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP0", "IEFBR14", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.systemOut("SYSOUT")
						.output("*")
						.build()
						.systemOut("SYSDUMP")
						.output("*")
						.build()
						.bluesam("DD1")
						.dataset("AWS.M2.CARDDEMO.PAUTDB.ROOT.FILEO")
						.disposition("OLD")
						.normalTermination("DELETE")
						.abnormalTermination("DELETE")
						.build()
						.bluesam("DD2")
						.dataset("AWS.M2.CARDDEMO.PAUTDB.CHILD.FILEO")
						.disposition("OLD")
						.normalTermination("DELETE")
						.abnormalTermination("DELETE")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IEFBR14")
				})
		}
	}
}
// STEP STEP01 - PGM - DFSRRC00***************************************************
def stepSTEP01(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP01", "DFSRRC00", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.concatenation("STEPLIB")
						.path("OEMA.IMS.IMSP.SDFSRESL")
						.disposition("SHR")
						.path("OEMA.IMS.IMSP.SDFSRESL.V151")
						.disposition("SHR")
						.path("AWS.M2.CARDDEMO.LOADLIB")
						.disposition("SHR")
						.build()
						.bluesam("DFSRESLB")
						.dataset("OEMA.IMS.IMSP.SDFSRESL")
						.disposition("SHR")
						.build()
						.concatenation("IMS")
						.path("OEM.IMS.IMSP.PSBLIB")
						.disposition("SHR")
						.path("OEM.IMS.IMSP.DBDLIB")
						.disposition("SHR")
						.build()
						.bluesam("OUTFIL1")
						.dataset("AWS.M2.CARDDEMO.PAUTDB.ROOT.FILEO")
						.disposition("NEW")
						.normalTermination("CATLG")
						.abnormalTermination("DELETE")
						.build()
						.bluesam("OUTFIL2")
						.dataset("AWS.M2.CARDDEMO.PAUTDB.CHILD.FILEO")
						.disposition("NEW")
						.normalTermination("CATLG")
						.abnormalTermination("DELETE")
						.build()
						.bluesam("DDPAUTP0")
						.dataset("OEM.IMS.IMSP.PAUTHDB")
						.disposition("SHR")
						.build()
						.bluesam("DDPAUTX0")
						.dataset("OEM.IMS.IMSP.PAUTHDBX")
						.disposition("SHR")
						.build()
						.fileSystem("DFSVSAMP")
						.path("OEMPP.IMS.V15R01MB.PROCLIB(DFSVSMDB)")
						.disposition("SHR")
						.build()
						.dummy("IMSLOGR")
						.build()
						.dummy("IEFRDER")
						.build()
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.systemOut("SYSUDUMP")
						.output("*")
						.build()
						.systemOut("IMSERR")
						.output("*")
						.build()
						.getFileConfigurations())
					.withArguments(getParm("DLI,PAUDBUNL,PAUTBUNL,,,,,,,,,,,N"))
					.withParameters(params)
					.runProgram("DFSRRC00")
				})
		}
	}
}
