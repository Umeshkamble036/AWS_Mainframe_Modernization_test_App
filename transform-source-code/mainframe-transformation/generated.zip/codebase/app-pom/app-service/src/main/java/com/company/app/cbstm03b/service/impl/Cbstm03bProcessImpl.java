
package com.company.app.cbstm03b.service.impl;

import com.company.app.cbstm03b.business.context.Cbstm03bContext;
import com.company.app.cbstm03b.service.Cbstm03bProcess;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.NumberUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.io.IndexedFile;
import com.netfective.bluage.gapwalk.rt.io.OpenMode;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Cbstm03bProcessImpl
 * 
 * Defines application services for Cbstm03bProcess
 * @see Cbstm03bProcess
 */
@Service("com.company.app.cbstm03b.service.Cbstm03bProcess")
@Lazy

public class Cbstm03bProcessImpl implements Cbstm03bProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Cbstm03bProcessImpl.class);


	/**
	 * Process operation _0000Start.
	 * 
	 * PROGRAM-ID.CBSTM03B.
	 *  AUTHOR.        AWS.
	 * *****************************************************************
	 *  Program     : CBSTM03B.CBL
	 *  Application : CardDemo
	 *  Type        : BATCH COBOL Subroutine
	 *  Function    : Does file processing related to Transact Report
	 * *****************************************************************
	 *  Copyright Amazon.com, Inc. or its affiliates.
	 *  All Rights Reserved.
	 *  Licensed under the Apache License, Version 2.0 (the \"License\").
	 *  You may not use this file except in compliance with the License.
	 *  You may obtain a copy of the License at
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *  Unless required by applicable law or agreed to in writing,
	 *  software distributed under the License is distributed on an
	 *  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
	 *  either express or implied. See the License for the specific
	 *  language governing permissions and limitations under the License
	 * *****************************************************************
	 *  This program is to called by the statement create program
	 *  It does file handling
	 * *****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0000Start(final Cbstm03bContext ctx, final ExecutionController ctrl) {
		_0000Start1(ctx, ctrl);
		if (ctx.isMainProgram()) {
			ctrl.stopRunUnit();
		}
	}

	/**
	 * Process operation _0000Start1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0000Start1(final Cbstm03bContext ctx, final ExecutionController ctrl) {
		ctx.getLkM03bArea().bind(ArgUtils.get(ctx, 0));
		if (DataUtils.compare(ctx.getLkM03bArea().getLkM03bDdReference(), "TRNXFILE") == 0) {
			_1000TrnxfileProc(ctx, ctrl);
		} else if (DataUtils.compare(ctx.getLkM03bArea().getLkM03bDdReference(), "XREFFILE") == 0) {
			_2000XreffileProc(ctx, ctrl);
		} else if (DataUtils.compare(ctx.getLkM03bArea().getLkM03bDdReference(), "CUSTFILE") == 0) {
			_3000CustfileProc(ctx, ctrl);
		} else if (DataUtils.compare(ctx.getLkM03bArea().getLkM03bDdReference(), "ACCTFILE") == 0) {
			_4000AcctfileProc(ctx, ctrl);
		} else {
			return;
		}
	}

	/**
	 * Process operation _1000TrnxfileProc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1000TrnxfileProc(final Cbstm03bContext ctx, final ExecutionController ctrl) {
		_1000TrnxfileProc1(ctx, ctrl);
		ctx.getLkM03bArea().getLkM03bRcReference().setBytes(ctx.getTrnxfileStatus().getBytes());
	}

	/**
	 * Process operation _1000TrnxfileProc1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1000TrnxfileProc1(final Cbstm03bContext ctx, final ExecutionController ctrl) {
		boolean result = false; 
		IndexedFile trnxFile = ctx.getTrnxFileHandler(ctrl.getExecutionContext()); 
		if (ctx.getLkM03bArea().isM03bOpen()) {
			trnxFile.open(OpenMode.INPUT);
			return;
		} else {
			if (ctx.getLkM03bArea().isM03bRead()) {
				result = trnxFile.read();
				if (result) {
					ctx.getLkM03bArea().getLkM03bFldtReference().setBytes(ctx.getTrnxFile().getFdTrnxfileRecReference().getBytes());
				} 
				return;
			} else {
				if (ctx.getLkM03bArea().isM03bClose()) {
					trnxFile.close();
					return;
				} else {
					return;
				}
			}
		}
	}

	/**
	 * Process operation _2000XreffileProc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2000XreffileProc(final Cbstm03bContext ctx, final ExecutionController ctrl) {
		_2000XreffileProc1(ctx, ctrl);
		ctx.getLkM03bArea().getLkM03bRcReference().setBytes(ctx.getXreffileStatus().getBytes());
	}

	/**
	 * Process operation _2000XreffileProc1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _2000XreffileProc1(final Cbstm03bContext ctx, final ExecutionController ctrl) {
		boolean result = false; 
		IndexedFile xrefFile = ctx.getXrefFileHandler(ctrl.getExecutionContext()); 
		if (ctx.getLkM03bArea().isM03bOpen()) {
			xrefFile.open(OpenMode.INPUT);
			return;
		} else {
			if (ctx.getLkM03bArea().isM03bRead()) {
				result = xrefFile.read();
				if (result) {
					ctx.getLkM03bArea().getLkM03bFldtReference().setBytes(ctx.getXrefFile().getFdXreffileRecReference().getBytes());
				} 
				return;
			} else {
				if (ctx.getLkM03bArea().isM03bClose()) {
					xrefFile.close();
					return;
				} else {
					return;
				}
			}
		}
	}

	/**
	 * Process operation _3000CustfileProc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3000CustfileProc(final Cbstm03bContext ctx, final ExecutionController ctrl) {
		_3000CustfileProc1(ctx, ctrl);
		ctx.getLkM03bArea().getLkM03bRcReference().setBytes(ctx.getCustfileStatus().getBytes());
	}

	/**
	 * Process operation _3000CustfileProc1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _3000CustfileProc1(final Cbstm03bContext ctx, final ExecutionController ctrl) {
		IndexedFile custFile = ctx.getCustFileHandler(ctrl.getExecutionContext()); 
		boolean result = false; 
		if (ctx.getLkM03bArea().isM03bOpen()) {
			custFile.open(OpenMode.INPUT);
			return;
		} else {
			if (ctx.getLkM03bArea().isM03bReadK()) {
				int len = ctx.getLkM03bArea().getLkM03bKeyLn();
				ctx.getCustFile().getFdCustIdReference().setBytes(ctx.getLkM03bArea().getLkM03bKeyReference().getBytes(0, len));
				result = custFile.read();
				if (result) {
					ctx.getLkM03bArea().getLkM03bFldtReference().setBytes(ctx.getCustFile().getFdCustfileRecReference().getBytes());
				} 
				return;
			} else {
				if (ctx.getLkM03bArea().isM03bClose()) {
					custFile.close();
					return;
				} else {
					return;
				}
			}
		}
	}

	/**
	 * Process operation _4000AcctfileProc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _4000AcctfileProc(final Cbstm03bContext ctx, final ExecutionController ctrl) {
		_4000AcctfileProc1(ctx, ctrl);
		ctx.getLkM03bArea().getLkM03bRcReference().setBytes(ctx.getAcctfileStatus().getBytes());
	}

	/**
	 * Process operation _4000AcctfileProc1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _4000AcctfileProc1(final Cbstm03bContext ctx, final ExecutionController ctrl) {
		IndexedFile acctFile = ctx.getAcctFileHandler(ctrl.getExecutionContext()); 
		boolean result = false; 
		if (ctx.getLkM03bArea().isM03bOpen()) {
			acctFile.open(OpenMode.INPUT);
			return;
		} else {
			if (ctx.getLkM03bArea().isM03bReadK()) {
				int len = ctx.getLkM03bArea().getLkM03bKeyLn();
				ctx.getAcctFile().setFdAcctId(NumberUtils.convert(ctx.getLkM03bArea().getLkM03bKeyReference().getBytes(0, len)).longValue());
				result = acctFile.read();
				if (result) {
					ctx.getLkM03bArea().getLkM03bFldtReference().setBytes(ctx.getAcctFile().getFdAcctfileRecReference().getBytes());
				} 
				return;
			} else {
				if (ctx.getLkM03bArea().isM03bClose()) {
					acctFile.close();
					return;
				} else {
					return;
				}
			}
		}
	}

}
