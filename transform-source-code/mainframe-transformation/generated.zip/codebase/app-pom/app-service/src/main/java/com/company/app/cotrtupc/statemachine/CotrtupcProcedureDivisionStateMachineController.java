package com.company.app.cotrtupc.statemachine;

import com.company.app.cotrtupc.business.context.CotrtupcContext;
import com.company.app.cotrtupc.statemachine.CotrtupcProcedureDivisionStateMachineController.Events;
import com.company.app.cotrtupc.statemachine.CotrtupcProcedureDivisionStateMachineController.States;
import com.company.app.cotrtupc.statemachine.CotrtupcProcedureDivisionStateMachineService;
import com.github.oxo42.stateless4j.StateMachineConfig;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.context.RuntimeContext;
import com.netfective.bluage.gapwalk.rt.statemachine.MultipleActiveContinuationController;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Controller managing the state machine "CotrtupcProcedureDivisionStateMachine" execution.
 */
@Component("com.company.app.cotrtupc.statemachine.CotrtupcProcedureDivisionStateMachineController")
@Import({
com.company.app.cotrtupc.statemachine.CotrtupcProcedureDivisionStateMachineService.class
})
@Lazy
public class CotrtupcProcedureDivisionStateMachineController extends MultipleActiveContinuationController<States, Events> {
	
	/**
	 * State machine states.
	 */
	public enum States {
		_0000_MAIN_1, _0000_MAIN, _2000_DECIDE_ACTION, ABEND_ROUTINE, _0000_MAIN_CASEBRANCH, _0000_MAIN_CASEBRANCH_1, _2000_DECIDE_ACTION_POSTIF, _2000_DECIDE_ACTION_CASEBRANCH, _0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT, _0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT_1, FINAL, LOCAL_FINAL
	}

	/**
	 * State machine events.
	 */
	public enum Events {
		TO__0000_MAIN_1, TO__0000_MAIN, TO__2000_DECIDE_ACTION, TO_ABEND_ROUTINE, TO__0000_MAIN_CASEBRANCH, TO__0000_MAIN_CASEBRANCH_1, TO__2000_DECIDE_ACTION_POSTIF, TO__2000_DECIDE_ACTION_CASEBRANCH, TO__0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT, TO__0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT_1, TO_FINAL, TO_LOCAL_FINAL
	}

	/**
	 * State machine state process service provider.
	 */
	@Autowired
	@Lazy
	private CotrtupcProcedureDivisionStateMachineService stateProcess;
	
	/**
	 * State machine controller initialization.
	 */
	@PostConstruct
	private void init(){
		initStateMachineController();
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine() throws Exception {
		throw new UnsupportedOperationException("Please use the two arguments configureStateMachine method instead: configureStateMachine(RuntimeContext ctx, ExecutionController ctrl)");
	}
	
	@Override
	protected StateMachineConfig<States, Events> configureStateMachine(RuntimeContext ctx, ExecutionController ctrl) throws Exception {
		
		StateMachineConfig<States, Events> configurer = new StateMachineConfig<>();
		configureInitialEnd(States._0000_MAIN_1,States.FINAL);
		CotrtupcContext lctx = (CotrtupcContext) ctx;

		configurer.configure(States._0000_MAIN).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._0000Main(lctx, ctrl);}))
		.permit(Events.TO__0000_MAIN_CASEBRANCH, States._0000_MAIN_CASEBRANCH)
		.permit(Events.TO__0000_MAIN_CASEBRANCH_1, States._0000_MAIN_CASEBRANCH_1)
		;	
		configurer.configure(States._2000_DECIDE_ACTION).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideAction(lctx, ctrl);}))
		.permit(Events.TO__2000_DECIDE_ACTION_CASEBRANCH, States._2000_DECIDE_ACTION_CASEBRANCH)
		.permit(Events.TO__2000_DECIDE_ACTION_POSTIF, States._2000_DECIDE_ACTION_POSTIF)
		;	
		configurer.configure(States.ABEND_ROUTINE).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess.abendRoutine(lctx, ctrl);}))
		.permit(Events.TO_FINAL, States.FINAL)
		.permit(Events.TO__2000_DECIDE_ACTION_POSTIF, States._2000_DECIDE_ACTION_POSTIF)
		;	
		configurer.configure(States._0000_MAIN_CASEBRANCH).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._0000MainCasebranch(lctx, ctrl);}))
		.permit(Events.TO__2000_DECIDE_ACTION, States._2000_DECIDE_ACTION)
		;	
		configurer.configure(States._0000_MAIN_CASEBRANCH_1).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._0000MainCasebranch1(lctx, ctrl);}))
		.permit(Events.TO__2000_DECIDE_ACTION, States._2000_DECIDE_ACTION)
		;	
		configurer.configure(States._2000_DECIDE_ACTION_POSTIF).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideActionPostif(lctx, ctrl);}))
		.permit(Events.TO__0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT, States._0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT)
		.permit(Events.TO__0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT_1, States._0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT_1)
		;	
		configurer.configure(States._2000_DECIDE_ACTION_CASEBRANCH).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._2000DecideActionCasebranch(lctx, ctrl);}))
		.permit(Events.TO_ABEND_ROUTINE, States.ABEND_ROUTINE)
		;	
		configurer.configure(States._0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._0000MainPost2000decideactionThru2000decideactionexit(lctx, ctrl);}))
		;	
		configurer.configure(States._0000_MAIN_POST__2000DECIDEACTION_THRU__2000DECIDEACTIONEXIT_1).substateOf(States._0000_MAIN_1).onEntry(buildRunAction(() -> {stateProcess._0000MainPost2000decideactionThru2000decideactionexit1(lctx, ctrl);}))
		;	
		
		configurer.configure(States._0000_MAIN_1)
		.onEntry(()->{runSubStateMachine(Events.TO__0000_MAIN);})
		.permit(Events.TO__0000_MAIN, States._0000_MAIN)
		.permit(Events.TO_FINAL, States.FINAL)
		.permitInternal(Events.TO_ABEND_ROUTINE, buildRunAction(() -> {stateProcess.abendRoutine(lctx, ctrl);}))
		;	
		
		return configurer;
	}
	
}
