package com.company.app.cocrdslc.service;

import com.company.app.cocrdslc.business.context.CocrdslcContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface CocrdslcProcess.
 * 
 * Defines application services for CocrdslcProcess
 */
public interface CocrdslcProcess {

	/**
	 * Process operation cocrdslc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void cocrdslc(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation commonReturn.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void commonReturn(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000SendMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000SendMap(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1100ScreenInit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1100ScreenInit(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1200SetupScreenVars.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1200SetupScreenVars(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1300SetupScreenAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1300SetupScreenAttrs(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1400SendScreen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1400SendScreen(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2000ProcessInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2000ProcessInputs(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2100ReceiveMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2100ReceiveMap(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2200EditMapInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2200EditMapInputs(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2210EditAccount.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2210EditAccount(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _2220EditCard.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _2220EditCard(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9100GetcardByacctcard.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9100GetcardByacctcard(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9150GetcardByacct.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9150GetcardByacct(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation sendLongText.
	 * 
	 * ****************************************************************
	 *  Display Long text and exit                                    *
	 *  This is primarily for debugging and should not be used in     *
	 *  regular course                                                *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void sendLongText(final CocrdslcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation sendPlainText.
	 * 
	 * ****************************************************************
	 *  Plain text exit - Dont use in production                      *
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void sendPlainText(final CocrdslcContext ctx, final ExecutionController ctrl);

}
