package com.company.app.cocrdupc.service;

import com.company.app.cocrdupc.business.context.CocrdupcContext;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface CocrdupcProcess.
 * 
 * Defines application services for CocrdupcProcess
 */
public interface CocrdupcProcess {

	/**
	 * Process operation cocrdupc.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void cocrdupc(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation commonReturn.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void commonReturn(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1000ProcessInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1000ProcessInputs(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1100ReceiveMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1100ReceiveMap(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1200EditMapInputs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1200EditMapInputs(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1210EditAccount.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1210EditAccount(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1220EditCard.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1220EditCard(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1230EditName.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1230EditName(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1240EditCardstatus.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1240EditCardstatus(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1250EditExpiryMon.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1250EditExpiryMon(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _1260EditExpiryYear.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _1260EditExpiryYear(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3000SendMap.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3000SendMap(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3100ScreenInit.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3100ScreenInit(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3200SetupScreenVars.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3200SetupScreenVars(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3250SetupInfomsg.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3250SetupInfomsg(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3300SetupScreenAttrs.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3300SetupScreenAttrs(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _3400SendScreen.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _3400SendScreen(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9000ReadData.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9000ReadData(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation _9100GetcardByacctcard.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _9100GetcardByacctcard(final CocrdupcContext ctx, final ExecutionController ctrl);

	/**
	 * Process operation abendRoutine.
	 * 
	 * ****************************************************************
	 * Common code to store PFKey
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void abendRoutine(final CocrdupcContext ctx, final ExecutionController ctrl);

}
