package com.company.app.codate01.service;

import com.company.app.codate01.business.context.Codate01Context;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;

/**
 * Interface Codate01Process.
 * 
 * Defines application services for Codate01Process
 */
public interface Codate01Process {

	/**
	 * Process operation codate01.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void codate01(final Codate01Context ctx, final ExecutionController ctrl);

	/**
	 * Process operation _8000TerminationPostif.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8000TerminationPostif(final Codate01Context ctx, final ExecutionController ctrl);

	/**
	 * Process operation _8000TerminationPostif1.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	void _8000TerminationPostif1(final Codate01Context ctx, final ExecutionController ctrl);

}
