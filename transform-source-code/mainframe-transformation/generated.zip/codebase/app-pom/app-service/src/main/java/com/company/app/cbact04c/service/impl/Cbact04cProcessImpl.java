
package com.company.app.cbact04c.service.impl;

import com.company.app.cbact04c.business.context.Cbact04cContext;
import com.company.app.cbact04c.service.Cbact04cProcess;
import com.company.app.core.helper.BluageUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.DataUtils;
import com.netfective.bluage.gapwalk.datasimplifier.utils.NumberUtils;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import com.netfective.bluage.gapwalk.rt.io.IndexedFile;
import com.netfective.bluage.gapwalk.rt.io.OpenMode;
import com.netfective.bluage.gapwalk.rt.io.SequentialFile;
import com.netfective.bluage.gapwalk.rt.utils.ArgUtils;
import com.netfective.bluage.gapwalk.runtime.statements.CallBuilder;
import com.netfective.bluage.gapwalk.runtime.statements.DateHelper;
import com.netfective.bluage.gapwalk.runtime.statements.StringConcatenationBuilder;
import com.netfective.bluage.gapwalk.runtime.tool.DisplayUtils;
import java.math.BigDecimal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import static com.netfective.bluage.gapwalk.datasimplifier.metadata.CobolScaleAdapter.scale;

/**
 * Class Cbact04cProcessImpl
 * 
 * Defines application services for Cbact04cProcess
 * @see Cbact04cProcess
 */
@Service("com.company.app.cbact04c.service.Cbact04cProcess")
@Lazy

public class Cbact04cProcessImpl implements Cbact04cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Cbact04cProcessImpl.class);


	/**
	 * Process operation procedureDivision.
	 * 
	 * PROGRAM-ID.CBACT04C.
	 *  AUTHOR.        AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void procedureDivision(final Cbact04cContext ctx, final ExecutionController ctrl) {
		ctx.getExternalParms().bind(ArgUtils.get(ctx, 0));
		
		/* 
		*****************************************************************
		Program     : CBACT04C.CBL
		Application : CardDemo
		Type        : BATCH COBOL Program
		Function    : This is a interest calculator program.
		*****************************************************************
		Copyright Amazon.com, Inc. or its affiliates.
		All Rights Reserved.
		Licensed under the Apache License, Version 2.0 (the \"License\").
		You may not use this file except in compliance with the License.
		You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
		Unless required by applicable law or agreed to in writing,
		software distributed under the License is distributed on an
		\"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
		either express or implied. See the License for the specific
		language governing permissions and limitations under the License
		*****************************************************************
		**************************************************************** */
		DisplayUtils.display(ctx, ctrl, LOGGER, "START OF EXECUTION OF PROGRAM CBACT04C");
		_0000TcatbalfOpen(ctx, ctrl);
		_0100XreffileOpen(ctx, ctrl);
		_0200DiscgrpOpen(ctx, ctrl);
		_0300AcctfileOpen(ctx, ctrl);
		_0400TranfileOpen(ctx, ctrl);
		while (DataUtils.compare(ctx.getEndOfFile().getEndOfFileReference(), "Y") != 0) {
			if (DataUtils.compare(ctx.getEndOfFile().getEndOfFileReference(), "N") == 0) {
				_1000TcatbalfGetNext(ctx, ctrl);
				if (DataUtils.compare(ctx.getEndOfFile().getEndOfFileReference(), "N") == 0) {
					ctx.getWsCounters().setWsRecordCount(ctx.getWsCounters().getWsRecordCount() + 1);
					// FIXME An error occured while generating Java from BAGS (@LoggerUtils.info(@BluageUtils.unsupported("TRAN-CAT-BAL-RECORD")))
					BluageUtils.unsupported();
					if (DataUtils.compare(BluageUtils.unsupported(), ctx.getWsMiscVars().getWsLastAcctNumReference()) != 0) {
						if (DataUtils.compare(ctx.getWsMiscVars().getWsFirstTimeReference(), "Y") != 0) {
							_1050UpdateAccount(ctx, ctrl);
						} else {
							ctx.getWsMiscVars().setWsFirstTime("N");
						}
						ctx.getWsMiscVars().setWsTotalInt(BigDecimal.ZERO);
						ctx.getWsMiscVars().setWsLastAcctNum(BluageUtils.unsupported());
						ctx.getAccountFile().setFdAcctId(BluageUtils.unsupported());
						_1100GetAcctData(ctx, ctrl);
						ctx.getXrefFile().setFdXrefAcctId(BluageUtils.unsupported());
						_1110GetXrefData(ctx, ctrl);
					} 
					
					/* 
					DISPLAY 'ACCT-GROUP-ID: ' ACCT-GROUP-ID
					DISPLAY 'TRANCAT-CD: ' TRANCAT-CD
					DISPLAY 'TRANCAT-TYPE-CD: ' TRANCAT-TYPE-CD */
					ctx.getDiscgrpFile().setFdDisAcctGroupId(BluageUtils.unsupported());
					ctx.getDiscgrpFile().setFdDisTranCatCd(BluageUtils.unsupported());
					ctx.getDiscgrpFile().setFdDisTranTypeCd(BluageUtils.unsupported());
					_1200GetInterestRate(ctx, ctrl);
					if (DataUtils.compare("0", BluageUtils.unsupported()) != 0) {
						_1300ComputeInterest(ctx, ctrl);
					} 
				} 
			} else {
				_1050UpdateAccount(ctx, ctrl);
			}
		}
		_9000TcatbalfClose(ctx, ctrl);
		_9100XreffileClose(ctx, ctrl);
		_9200DiscgrpClose(ctx, ctrl);
		_9300AcctfileClose(ctx, ctrl);
		_9400TranfileClose(ctx, ctrl);
		DisplayUtils.display(ctx, ctrl, LOGGER, "END OF EXECUTION OF PROGRAM CBACT04C");
		if (ctx.isMainProgram()) {
			ctrl.stopRunUnit();
		}
	}

	/**
	 * Process operation _0000TcatbalfOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0000TcatbalfOpen(final Cbact04cContext ctx, final ExecutionController ctrl) {
		IndexedFile tcatbalFile = ctx.getTcatbalFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		tcatbalFile.open(OpenMode.INPUT);
		if (DataUtils.compare("00", ctx.getTcatbalfStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR OPENING TRANSACTION CATEGORY BALANCE");
			ctx.getIoStatus().setBytes(ctx.getTcatbalfStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _0100XreffileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0100XreffileOpen(final Cbact04cContext ctx, final ExecutionController ctrl) {
		IndexedFile xrefFile = ctx.getXrefFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		xrefFile.open(OpenMode.INPUT);
		if (DataUtils.compare("00", ctx.getXreffileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ERROR OPENING CROSS REF FILE" , DataUtils.toString(ctx.getXreffileStatus().getBytes()));
			ctx.getIoStatus().setBytes(ctx.getXreffileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _0200DiscgrpOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0200DiscgrpOpen(final Cbact04cContext ctx, final ExecutionController ctrl) {
		IndexedFile discgrpFile = ctx.getDiscgrpFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		discgrpFile.open(OpenMode.INPUT);
		if (DataUtils.compare("00", ctx.getDiscgrpStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR OPENING DALY REJECTS FILE");
			ctx.getIoStatus().setBytes(ctx.getDiscgrpStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _0300AcctfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0300AcctfileOpen(final Cbact04cContext ctx, final ExecutionController ctrl) {
		IndexedFile accountFile = ctx.getAccountFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		accountFile.open(OpenMode.IO);
		if (DataUtils.compare("00", ctx.getAcctfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR OPENING ACCOUNT MASTER FILE");
			ctx.getIoStatus().setBytes(ctx.getAcctfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _0400TranfileOpen.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _0400TranfileOpen(final Cbact04cContext ctx, final ExecutionController ctrl) {
		SequentialFile transactFile = ctx.getTransactFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		transactFile.open(OpenMode.OUTPUT);
		if (DataUtils.compare("00", ctx.getTranfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR OPENING TRANSACTION FILE");
			ctx.getIoStatus().setBytes(ctx.getTranfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _1000TcatbalfGetNext.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1000TcatbalfGetNext(final Cbact04cContext ctx, final ExecutionController ctrl) {
		boolean result = false; 
		IndexedFile tcatbalFile = ctx.getTcatbalFileHandler(ctrl.getExecutionContext()); 
		result = tcatbalFile.read();
		if (result) {
			
			/* 
			FIXME: TRAN-CAT-BAL-RECORD */
			BluageUtils.unsupported();
		} 
		if (DataUtils.compare("00", ctx.getTcatbalfStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			if (DataUtils.compare("10", ctx.getTcatbalfStatus()) == 0) {
				ctx.getApplResult().setApplResult(16);
			} else {
				ctx.getApplResult().setApplResult(12);
			}
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			if (ctx.getApplResult().isApplEof()) {
				ctx.getEndOfFile().setEndOfFile("Y");
			} else {
				DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR READING TRANSACTION CATEGORY FILE");
				ctx.getIoStatus().setBytes(ctx.getTcatbalfStatus().getBytes());
				_9910DisplayIoStatus(ctx, ctrl);
				_9999AbendProgram(ctx, ctrl);
			}
		}
	}

	/**
	 * Process operation _1050UpdateAccount.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1050UpdateAccount(final Cbact04cContext ctx, final ExecutionController ctrl) {
		IndexedFile accountFile = ctx.getAccountFileHandler(ctrl.getExecutionContext()); 
		/* 
		FIXME: ACCT-CURR-BAL
		Update the balances in account record to reflect posted trans. */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACCT-CURR-CYC-CREDIT */
		BluageUtils.unsupported();
		
		/* 
		FIXME: ACCT-CURR-CYC-DEBIT */
		BluageUtils.unsupported();
		ctx.getAccountFile().getFdAcctfileRecReference().setBytes(BluageUtils.unsupported());
		accountFile.rewrite(ctx.getAccountFile().getFdAcctfileRecReference());
		if (DataUtils.compare("00", ctx.getAcctfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR RE-WRITING ACCOUNT FILE");
			ctx.getIoStatus().setBytes(ctx.getAcctfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _1100GetAcctData.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1100GetAcctData(final Cbact04cContext ctx, final ExecutionController ctrl) {
		IndexedFile accountFile = ctx.getAccountFileHandler(ctrl.getExecutionContext()); 
		boolean invalidKey = false; 
		accountFile.read();
		invalidKey = accountFile.isInvalidKey();
		if (invalidKey) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCOUNT NOT FOUND: " , ctx.getAccountFile().getFdAcctIdReference().getDisplayValue(String.class));
		} else {
			
			/* 
			FIXME: ACCOUNT-RECORD */
			BluageUtils.unsupported();
		}
		if (DataUtils.compare("00", ctx.getAcctfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR READING ACCOUNT FILE");
			ctx.getIoStatus().setBytes(ctx.getAcctfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _1110GetXrefData.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1110GetXrefData(final Cbact04cContext ctx, final ExecutionController ctrl) {
		boolean invalidKey = false; 
		IndexedFile xrefFile = ctx.getXrefFileHandler(ctrl.getExecutionContext()); 
		xrefFile.read(ctx.getXrefFile().getFdXrefAcctIdReference());
		invalidKey = xrefFile.isInvalidKey();
		if (invalidKey) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "ACCOUNT NOT FOUND: " , ctx.getXrefFile().getFdXrefAcctIdReference().getDisplayValue(String.class));
		} else {
			
			/* 
			FIXME: CARD-XREF-RECORD */
			BluageUtils.unsupported();
		}
		if (DataUtils.compare("00", ctx.getXreffileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR READING XREF FILE");
			ctx.getIoStatus().setBytes(ctx.getXreffileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _1200GetInterestRate.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1200GetInterestRate(final Cbact04cContext ctx, final ExecutionController ctrl) {
		IndexedFile discgrpFile = ctx.getDiscgrpFileHandler(ctrl.getExecutionContext()); 
		boolean invalidKey = false; 
		discgrpFile.read();
		invalidKey = discgrpFile.isInvalidKey();
		if (invalidKey) {
			DisplayUtils.display(ctx, ctrl, LOGGER, "DISCLOSURE GROUP RECORD MISSING");
			DisplayUtils.display(ctx, ctrl, LOGGER, "TRY WITH DEFAULT GROUP CODE");
		} else {
			
			/* 
			FIXME: DIS-GROUP-RECORD */
			BluageUtils.unsupported();
		}
		if (DataUtils.compare("00", ctx.getDiscgrpStatus()) == 0 || DataUtils.compare("23", ctx.getDiscgrpStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR READING DISCLOSURE GROUP FILE");
			ctx.getIoStatus().setBytes(ctx.getDiscgrpStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
		if (DataUtils.compare("23", ctx.getDiscgrpStatus()) == 0) {
			ctx.getDiscgrpFile().setFdDisAcctGroupId("DEFAULT");
			_1200AGetDefaultIntRate(ctx, ctrl);
		}
	}

	/**
	 * Process operation _1200AGetDefaultIntRate.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1200AGetDefaultIntRate(final Cbact04cContext ctx, final ExecutionController ctrl) {
		IndexedFile discgrpFile = ctx.getDiscgrpFileHandler(ctrl.getExecutionContext()); 
		boolean result = false; 
		result = discgrpFile.read();
		if (result) {
			
			/* 
			FIXME: DIS-GROUP-RECORD */
			BluageUtils.unsupported();
		} 
		if (DataUtils.compare("00", ctx.getDiscgrpStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR READING DEFAULT DISCLOSURE GROUP");
			ctx.getIoStatus().setBytes(ctx.getDiscgrpStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _1300ComputeInterest.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1300ComputeInterest(final Cbact04cContext ctx, final ExecutionController ctrl) {
		ctx.getWsMiscVars().setWsMonthlyInt(scale(scale(new BigDecimal(BluageUtils.unsupported())).multiply(new BigDecimal(BluageUtils.unsupported())), ctx.getWsMiscVars().getWsMonthlyIntReference()).divide(new BigDecimal("1200")).value());
		ctx.getWsMiscVars().setWsTotalInt(ctx.getWsMiscVars().getWsTotalInt().add(ctx.getWsMiscVars().getWsMonthlyInt()));
		_1300BWriteTx(ctx, ctrl);
	}

	/**
	 * Process operation _1300BWriteTx.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _1300BWriteTx(final Cbact04cContext ctx, final ExecutionController ctrl) {
		SequentialFile transactFile = ctx.getTransactFileHandler(ctrl.getExecutionContext()); 
		ctx.getWsCounters().setWsTranidSuffix(ctx.getWsCounters().getWsTranidSuffix() + 1);
		StringConcatenationBuilder.newInstance(BluageUtils.unsupported())
			.addDelimitedBySize(ctx.getExternalParms().getParmDateReference().getBytes())
			.addDelimitedBySize(ctx.getWsCounters().getWsTranidSuffixReference().getValue(String.class))
			.end();
		
		/* 
		FIXME: TRAN-TYPE-CD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-CAT-CD */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-SOURCE */
		BluageUtils.unsupported();
		StringConcatenationBuilder.newInstance(BluageUtils.unsupported())
			.addDelimitedBySize("Int. for a/c ")
			.addDelimitedBySize(BluageUtils.unsupported())
			.end();
		
		/* 
		FIXME: TRAN-AMT */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-MERCHANT-ID */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-MERCHANT-NAME */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-MERCHANT-CITY */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-MERCHANT-ZIP */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-CARD-NUM */
		BluageUtils.unsupported();
		zGetDb2FormatTimestamp(ctx, ctrl);
		
		/* 
		FIXME: TRAN-ORIG-TS */
		BluageUtils.unsupported();
		
		/* 
		FIXME: TRAN-PROC-TS */
		BluageUtils.unsupported();
		ctx.getTransactFile().getFdTranfileRecReference().setBytes(BluageUtils.unsupported());
		transactFile.write(ctx.getTransactFile().getFdTranfileRecReference());
		if (DataUtils.compare("00", ctx.getTranfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR WRITING TRANSACTION RECORD");
			ctx.getIoStatus().setBytes(ctx.getTranfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
		
		/* 
		---------------------------------------------------------------*
		To be implemented */
		return;
	}

	/**
	 * Process operation _9000TcatbalfClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9000TcatbalfClose(final Cbact04cContext ctx, final ExecutionController ctrl) {
		IndexedFile tcatbalFile = ctx.getTcatbalFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		tcatbalFile.close();
		if (DataUtils.compare("00", ctx.getTcatbalfStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR CLOSING TRANSACTION BALANCE FILE");
			ctx.getIoStatus().setBytes(ctx.getTcatbalfStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _9100XreffileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9100XreffileClose(final Cbact04cContext ctx, final ExecutionController ctrl) {
		IndexedFile xrefFile = ctx.getXrefFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		xrefFile.close();
		if (DataUtils.compare("00", ctx.getXreffileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR CLOSING CROSS REF FILE");
			ctx.getIoStatus().setBytes(ctx.getXreffileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _9200DiscgrpClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9200DiscgrpClose(final Cbact04cContext ctx, final ExecutionController ctrl) {
		IndexedFile discgrpFile = ctx.getDiscgrpFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		discgrpFile.close();
		if (DataUtils.compare("00", ctx.getDiscgrpStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR CLOSING DISCLOSURE GROUP FILE");
			ctx.getIoStatus().setBytes(ctx.getDiscgrpStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _9300AcctfileClose.
	 * 
	 * ---------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9300AcctfileClose(final Cbact04cContext ctx, final ExecutionController ctrl) {
		IndexedFile accountFile = ctx.getAccountFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		accountFile.close();
		if (DataUtils.compare("00", ctx.getAcctfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR CLOSING ACCOUNT FILE");
			ctx.getIoStatus().setBytes(ctx.getAcctfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation _9400TranfileClose.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9400TranfileClose(final Cbact04cContext ctx, final ExecutionController ctrl) {
		SequentialFile transactFile = ctx.getTransactFileHandler(ctrl.getExecutionContext()); 
		ctx.getApplResult().setApplResult(8);
		transactFile.close();
		if (DataUtils.compare("00", ctx.getTranfileStatus()) == 0) {
			ctx.getApplResult().setApplResult(0);
		} else {
			ctx.getApplResult().setApplResult(12);
		}
		if (ctx.getApplResult().isApplAok()) {
			
			/* 
			Do nothing */
		} else {
			DisplayUtils.display(ctx, ctrl, LOGGER, "ERROR CLOSING TRANSACTION FILE");
			ctx.getIoStatus().setBytes(ctx.getTranfileStatus().getBytes());
			_9910DisplayIoStatus(ctx, ctrl);
			_9999AbendProgram(ctx, ctrl);
		}
	}

	/**
	 * Process operation zGetDb2FormatTimestamp.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void zGetDb2FormatTimestamp(final Cbact04cContext ctx, final ExecutionController ctrl) {
		ctx.getCobolTs().setBytes(DataUtils.getBytes(DateHelper.getFormattedDate("yyyyMMddHHmmssSSZZZ")));
		ctx.getGroup2().getDb2YyyyReference().setValue(ctx.getCobolTs().getCobYyyyReference());
		ctx.getGroup2().getDb2MmReference().setValue(ctx.getCobolTs().getCobMmReference());
		ctx.getGroup2().getDb2DdReference().setValue(ctx.getCobolTs().getCobDdReference());
		ctx.getGroup2().getDb2HhReference().setValue(ctx.getCobolTs().getCobHhReference());
		ctx.getGroup2().getDb2MinReference().setValue(ctx.getCobolTs().getCobMinReference());
		ctx.getGroup2().getDb2SsReference().setValue(ctx.getCobolTs().getCobSsReference());
		ctx.getGroup2().setDb2Mil(NumberUtils.convert(ctx.getCobolTs().getCobMil()).intValue());
		ctx.getGroup2().setDb2Rest("0000");
		ctx.getGroup2().setDb2Streep1("-");
		ctx.getGroup2().setDb2Streep2("-");
		ctx.getGroup2().setDb2Streep3("-");
		ctx.getGroup2().setDb2Dot1(".");
		ctx.getGroup2().setDb2Dot2(".");
		ctx.getGroup2().setDb2Dot3(".");
		
		/* 
		DISPLAY 'DB2-TIMESTAMP = ' DB2-FORMAT-TS */
		return;
	}

	/**
	 * Process operation _9999AbendProgram.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9999AbendProgram(final Cbact04cContext ctx, final ExecutionController ctrl) {
		DisplayUtils.display(ctx, ctrl, LOGGER, "ABENDING PROGRAM");
		ctx.getTiming().setTiming(0);
		ctx.getAbcode().setAbcode(999);
		ctrl.callSubProgram("CEE3ABD", CallBuilder.newInstance()
			.byReference(ctx.getAbcode().getAbcodeReference())
			.byReference(ctx.getTiming().getTimingReference())
			.getArguments(), ctx);
	}

	/**
	 * Process operation _9910DisplayIoStatus.
	 * 
	 * ****************************************************************
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void _9910DisplayIoStatus(final Cbact04cContext ctx, final ExecutionController ctrl) {
		if (!(DataUtils.isNumeric(ctx.getIoStatus())) || DataUtils.compare(ctx.getIoStatus().getIoStat1Reference(), "9") == 0) {
			ctx.getIoStatus04().setBytes(ctx.getIoStatus().getIoStat1Reference().getBytes(), 0, 1);
			ctx.getGroup1().setTwoBytesBinary(0);
			ctx.getGroup1().getTwoBytesRightReference().setValue(ctx.getIoStatus().getIoStat2Reference());
			ctx.getIoStatus04().setIoStatus0403(ctx.getGroup1().getTwoBytesBinary());
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "FILE STATUS IS: NNNN" , DataUtils.toString(ctx.getIoStatus04().getBytes()));
		} else {
			ctx.getIoStatus04().setBytes(DataUtils.getBytes("0000"));
			ctx.getIoStatus04().setBytes(ctx.getIoStatus().getBytes(), 2, 2);
			DisplayUtils.display(ctx, ctrl, LOGGER, "{}{}" , "FILE STATUS IS: NNNN" , DataUtils.toString(ctx.getIoStatus04().getBytes()));
		}
		
		/* 
		Ver: CardDemo_v2.0-25-gdb72e6b-235 Date: 2025-04-29 11:01:28 CDT */
		return;
	}

}
