// Import
import com.netfective.bluage.gapwalk.rt.provider.ScriptRegistry
import com.netfective.bluage.gapwalk.rt.call.MainProgramRunner
import com.netfective.bluage.gapwalk.io.support.FileConfigurationUtils
import com.netfective.bluage.gapwalk.rt.job.support.DefaultJobContext
import com.netfective.bluage.gapwalk.rt.utils.GroovyUtils
import com.netfective.bluage.gapwalk.rt.io.support.FileConfiguration
import com.netfective.bluage.gapwalk.rt.shared.AbendException
import com.netfective.bluage.gapwalk.rt.call.exception.GroovyExecutionException
// Variables
mpr = applicationContext.getBean("com.netfective.bluage.gapwalk.rt.call.ExecutionController", MainProgramRunner.class)
TreeMap mapTransfo = [:]
Map params = ["MapTransfo":mapTransfo]
// Execute job with utility functions
Binding binding = new Binding()
binding.setVariable("jobContext", jobContext)
def shell = new GroovyShell(binding).parse(ScriptRegistry.getScript("functions"))
//*********************************************************************
//*                             JOB                                   *
//*********************************************************************
shell.with {
	def jobName = "INTRDRJ1"
	mpr.setJobContext(jobContext)
	displayStartJob(jobName)
	Map programResults = jobContext.getProgramResults().clone()
	def lastProgramResult
	//********************************************************************
	//** THIS INTRDR JOB WILL TRIGGER ANOTHER JCL
	//********************************************************************
	lastProgramResult = stepIDCAMS(shell, params, programResults)
	//********************************************************************
	lastProgramResult = stepSTEP01(shell, params, programResults)
	displayEndJob(jobName)
	return programResults.get("GroovyExecutionResult")
}
//*********************************************************************
//*                            STEPS                                  *
//*********************************************************************
// STEP IDCAMS - PGM - IDCAMS*****************************************************
def stepIDCAMS(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("IDCAMS", "IDCAMS", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.bluesam("IN")
						.dataset("AWS.M2.CARDEMO.FTP.TEST")
						.disposition("SHR")
						.build()
						.bluesam("OUT")
						.dataset("AWS.M2.CARDEMO.FTP.TEST.BKUP")
						.disposition("SHR")
						.build()
						.fileSystem("SYSIN")
						.stream("  REPRO IFILE(IN) OFILE(OUT)", getEncoding())
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IDCAMS")
				})
		}
	}
}
// STEP STEP01 - PGM - IEBGENER***************************************************
def stepSTEP01(Object shell, Map params, Map programResults){
	shell.with {
		if (checkValidProgramResults(programResults)) {
			return execStep("STEP01", "IEBGENER", programResults, {
				mpr
					.withFileConfigurations(new FileConfigurationUtils()
						.withJobContext(jobContext)
						.systemOut("SYSPRINT")
						.output("*")
						.build()
						.dummy("SYSIN")
						.build()
						.fileSystem("SYSUT1")
						.path("AWS.M2.CARDDEMO.JCL(INTRDRJ2)")
						.disposition("SHR")
						.build()
						.systemOut("SYSUT2")
						.output("A,INTRDR")
						.build()
						.getFileConfigurations())
					.withParameters(params)
					.runProgram("IEBGENER")
				})
		}
	}
}
