
package com.company.app.cosgn00c.service.impl;

import com.company.app.cosgn00c.business.context.Cosgn00cContext;
import com.company.app.cosgn00c.service.Cosgn00cProcess;
import com.netfective.bluage.gapwalk.rt.call.ExecutionController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * Class Cosgn00cProcessImpl
 * 
 * Defines application services for Cosgn00cProcess
 * @see Cosgn00cProcess
 */
@Service("com.company.app.cosgn00c.service.Cosgn00cProcess")
@Lazy

public class Cosgn00cProcessImpl implements Cosgn00cProcess {

	/**
	 * The logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Cosgn00cProcessImpl.class);

	/**
	 * Process operation mainPara.
	 * 
	 * PROGRAM-ID.COSGN00C.
	 *  AUTHOR.     AWS.
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void mainPara(final Cosgn00cContext ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation processEnterKey.
	 * 
	 * ----------------------------------------------------------------*
	 *                       PROCESS-ENTER-KEY
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void processEnterKey(final Cosgn00cContext ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation sendSignonScreen.
	 * 
	 * ----------------------------------------------------------------*
	 *                       SEND-SIGNON-SCREEN
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendSignonScreen(final Cosgn00cContext ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation sendPlainText.
	 * 
	 * ----------------------------------------------------------------*
	 *                       SEND-PLAIN-TEXT
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void sendPlainText(final Cosgn00cContext ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation populateHeaderInfo.
	 * 
	 * ----------------------------------------------------------------*
	 *                       POPULATE-HEADER-INFO
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void populateHeaderInfo(final Cosgn00cContext ctx, final ExecutionController ctrl) {
	}

	/**
	 * Process operation readUserSecFile.
	 * 
	 * ----------------------------------------------------------------*
	 *                       READ-USER-SEC-FILE
	 * ----------------------------------------------------------------*
	 * 
	 * @param ctx 
	 * @param ctrl 
	 */
	@Override
	public void readUserSecFile(final Cosgn00cContext ctx, final ExecutionController ctrl) {
	}

}
